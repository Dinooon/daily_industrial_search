#!/usr/bin/env python3
"""
Round 3: Fetch HTML pages and look for RSS <link> tags in the HTML source.
Also try fetching the page HTML and extracting any feed URLs.
"""
import subprocess
import json
import re
import concurrent.futures

# The source URLs from config/sources.json for each brand we still need
BRAND_PAGES = {
    "sony_design": [
        "https://www.sony.com/en/SonyInfo/design/",
        "https://www.sony.com/en/",
        "https://www.sony.net/SonyInfo/News/",
    ],
    "nothing_newsroom": [
        "https://nothing.tech/pages/newsroom",
        "https://nothing.tech/blogs/news",
    ],
    "teenage_engineering": [
        "https://teenage.engineering/",
        "https://teenage.engineering/about",
    ],
    "bang_olufsen": [
        "https://www.bang-olufsen.com/en",
        "https://www.bang-olufsen.com/en/the-latest",
    ],
    "bose_press_room": [
        "https://www.bose.com/pressroom",
        "https://www.bose.com/",
    ],
    "gopro_news": [
        "https://gopro.com/en/us/news",
        "https://gopro.com/blogs/news",
    ],
    "canon_global_news": [
        "https://global.canon/en/news/",
        "https://global.canon/",
    ],
    "nikon_news": [
        "https://www.nikon.com/company/news/",
        "https://www.nikon.com/",
    ],
    "fujifilm_news": [
        "https://www.fujifilm.com/us/en/news",
        "https://www.fujifilm.com/",
    ],
    "framework_blog": [
        "https://frame.work/blog",
        "https://frame.work/",
    ],
    "consumer": [  # Huawei
        "https://consumer.huawei.com/en/press/",
        "https://consumer.huawei.com/en/",
    ],
    "mi": [  # Xiaomi
        "https://www.mi.com/global/event/",
        "https://blog.mi.com/",
        "https://blog.mi.com/global/",
    ],
    "honor": [
        "https://www.honor.com/global/news/",
        "https://www.honor.com/",
    ],
    "oppo_newsroom": [
        "https://www.oppo.com/en/newsroom/",
        "https://www.oppo.com/",
    ],
    "vivo_news": [
        "https://www.vivo.com/en/about-vivo/news",
        "https://www.vivo.com/",
    ],
    "realme_newsroom": [
        "https://www.realme.com/global/newsroom",
        "https://www.realme.com/",
    ],
    "dji_media_center": [
        "https://www.dji.com/newsroom",
        "https://www.dji.com/",
    ],
    "insta360_blog": [
        "https://www.insta360.com/blog/",
        "https://www.insta360.com/",
    ],
    "anker_news": [
        "https://www.anker.com/blogs/news",
        "https://www.anker.com/",
    ],
    "dyson_newsroom": [
        "https://www.dyson.com/discover/news",
        "https://www.dyson.com/",
        "https://www.dyson.com/discover",
    ],
    "braun": [
        "https://www.braun.com/",
        "https://www.braun.com/global/en.html",
        "https://www.braun.com/global/en/braun-prize.html",
    ],
    "philips_news_center": [
        "https://www.philips.com/a-w/about/news/home.html",
        "https://www.philips.com/",
    ],
    "bosch_press_portal": [
        "https://www.bosch-presse.de/pressportal/de/en/",
        "https://www.bosch.com/",
    ],
    "lg_newsroom": [
        "https://www.lgnewsroom.com/",
    ],
    "panasonic_newsroom": [
        "https://news.panasonic.com/global/",
        "https://news.panasonic.com/",
    ],
    "ikea_newsroom": [
        "https://www.ikea.com/global/en/newsroom/",
        "https://www.ikea.com/",
    ],
    "design_milk": [
        "https://design-milk.com/",
    ],
    "fast_company_design": [
        "https://www.fastcompany.com/co-design",
        "https://www.fastcompany.com/",
    ],
    "new_atlas": [
        "https://newatlas.com/",
    ],
    "herman_miller": [
        "https://www.hermanmiller.com/",
        "https://www.hermanmiller.com/en_US/",
    ],
    "vitra": [
        "https://www.vitra.com/",
        "https://www.vitra.com/en",
    ],
    "mercedes_benz_media": [
        "https://media.mercedes-benz.com/",
        "https://media.mercedes-benz.com/en",
    ],
    "audi_mediacenter": [
        "https://www.audi-mediacenter.com/en",
        "https://www.audi-mediacenter.com/",
    ],
    "porsche_newsroom": [
        "https://newsroom.porsche.com/en",
        "https://newsroom.porsche.com/",
    ],
    "volvo_cars_media": [
        "https://www.media.volvocars.com/",
        "https://www.media.volvocars.com/global/en-gb",
    ],
    "tesla": [
        "https://www.tesla.com/blog",
        "https://www.tesla.com/",
    ],
    "toyota_global_newsroom": [
        "https://global.toyota/en/newsroom/",
        "https://global.toyota/",
    ],
    "honda_global_newsroom": [
        "https://global.honda/en/newsroom/",
        "https://global.honda/",
    ],
}

def fetch_and_find_rss(url):
    """Fetch HTML page and find RSS/Atom feed links."""
    try:
        result = subprocess.run(
            ["curl", "-sL", "--max-time", "12", "--connect-timeout", "10",
             "-H", "User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36",
             url],
            capture_output=True, text=True, timeout=20
        )
        html = result.stdout
        
        if not html or len(html) < 50:
            return (url, [], "empty response")
        
        # Search for RSS/Atom link tags
        # Patterns: <link rel="alternate" type="application/rss+xml" href="..." />
        #           <link rel="alternate" type="application/atom+xml" href="..." />
        patterns = [
            r'<link[^>]*type=["\']application/rss\+xml["\'][^>]*href=["\']([^"\']+)["\']',
            r'<link[^>]*href=["\']([^"\']+)["\'][^>]*type=["\']application/rss\+xml["\']',
            r'<link[^>]*type=["\']application/atom\+xml["\'][^>]*href=["\']([^"\']+)["\']',
            r'<link[^>]*href=["\']([^"\']+)["\'][^>]*type=["\']application/atom\+xml["\']',
        ]
        
        feeds = []
        for pattern in patterns:
            matches = re.findall(pattern, html, re.IGNORECASE)
            feeds.extend(matches)
        
        # Also search for common RSS URL references in the page
        rss_url_pattern = r'href=["\']([^"\']*(?:feed|rss|atom)[^"\']*)["\']'
        rss_refs = re.findall(rss_url_pattern, html, re.IGNORECASE)
        # Filter to only XML/RSS-like ones
        for ref in rss_refs:
            if any(ext in ref.lower() for ext in ['.xml', '.rss', '/feed', '/rss', '/atom', 'feedburner']):
                if ref not in feeds:
                    feeds.append(ref)
        
        # Also look for meta tags with feed info
        meta_pattern = r'<meta[^>]*content=["\']([^"\']*(?:rss|atom|feed)[^"\']*)["\']'
        meta_feeds = re.findall(meta_pattern, html, re.IGNORECASE)
        feeds.extend([f for f in meta_feeds if f.startswith('http')])
        
        return (url, feeds, f"html_size={len(html)}")
    except Exception as e:
        return (url, [], str(e)[:100])

def main():
    results = {}
    
    all_pages = []
    page_to_brand = {}
    for brand, pages in BRAND_PAGES.items():
        for page in pages:
            all_pages.append(page)
            page_to_brand[page] = brand

    print(f"Round 3: Fetching {len(all_pages)} HTML pages to find RSS <link> tags...")
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=15) as executor:
        future_to_page = {executor.submit(fetch_and_find_rss, page): page for page in all_pages}
        
        for future in concurrent.futures.as_completed(future_to_page):
            page = future_to_page[future]
            try:
                url, feeds, info = future.result()
                brand = page_to_brand[url]
                if feeds:
                    print(f"[FEEDS FOUND] {brand}: {url} -> {feeds}")
                    if brand not in results:
                        results[brand] = []
                    for f in feeds:
                        if f not in results[brand]:
                            results[brand].append(f)
                else:
                    print(f"[NO FEEDS] {brand}: {url} ({info})")
            except Exception as e:
                print(f"[ERROR] {page}: {e}")
    
    return results

if __name__ == "__main__":
    results = main()
    
    print("\n" + "="*80)
    print("ROUND 3 RESULTS SUMMARY")
    print("="*80)
    
    print(f"\nFeeds found in HTML for {len(results)} brands:")
    for brand, feeds in sorted(results.items()):
        print(f"  {brand}:")
        for f in feeds:
            print(f"    {f}")
    
    # Save results
    with open("/home/ubuntu/workdir/daily-industrial-design-image-search/rss_html_results.json", "w") as f:
        json.dump(results, f, indent=2)
    
    print(f"\nResults saved to rss_html_results.json")
