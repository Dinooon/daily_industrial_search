#!/usr/bin/env python3
"""
Round 7: Fix false positives and try new patterns.
Some previously found feeds returned HTML instead of RSS.
Also try new URL patterns for brands that were never found.
"""
import subprocess
import json
import concurrent.futures

# Re-test false positives with correct URLs and try new patterns
NEW_CANDIDATES = {
    # Apple: the /pr/rss.xml returns HTML now. Try other patterns
    "apple_newsroom": [
        "https://www.apple.com/newsroom/rss.xml",
        "https://www.apple.com/newsroom/rss/",
        "https://www.apple.com/rss.xml",
        "https://www.apple.com/rss/",
        "https://www.apple.com/pr/rss.xml",
        # Apple might use a different feed format
        "https://www.apple.com/newsroom/feed.xml",
        "https://www.apple.com/newsroom/atom.xml",
    ],
    # Microsoft: blogs.windows.com returned 403 on verify but worked before
    "microsoft_surface_blog": [
        "https://blogs.windows.com/devices/feed/",
        "https://blogs.windows.com/feed/",
        # Try with different approach
        "https://devblogs.microsoft.com/devices/rss.xml",
        "https://blogs.windows.com/devices/rss/",
    ],
    # Wallpaper: returned 403 on re-verify
    "wallpaper": [
        "https://www.wallpaper.com/rss.xml",
        "https://www.wallpaper.com/rss/",
        "https://www.wallpaper.com/feed",
        "https://www.wallpaper.com/feeds/all.xml",
    ],
    # Logitech: blog.logitech.com returned HTML
    "logitech_newsroom": [
        "https://news.logitech.com/feed/",
        "https://news.logitech.com/rss.xml",
        "https://news.logitech.com/feed.xml",
        "https://news.logitech.com/rss/",
        # Try WordPress patterns
        "https://news.logitech.com/?feed=rss2",
        "https://news.logitech.com/wp-json/wp/v2/posts",
    ],
    # Sonos: news.xml returned XML but not standard RSS (company info XML)
    "sonos_newsroom": [
        "https://newsroom.sonos.com/feed/",
        "https://newsroom.sonos.com/rss.xml",
        "https://newsroom.sonos.com/rss/",
        "https://newsroom.sonos.com/press-releases/feed",
        "https://newsroom.sonos.com/press-releases.rss",
        "https://newsroom.sonos.com/news/feed",
    ],
    # Xiaomi: blog.mi.com returned HTML for atom.xml
    "mi": [
        "https://blog.mi.com/global/feed/",
        "https://blog.mi.com/global/rss/",
        "https://blog.mi.com/feed/",
        "https://blog.mi.com/rss/",
        # WordPress patterns
        "https://blog.mi.com/?feed=rss2",
        "https://blog.mi.com/global/?feed=rss2",
    ],
    # Vivo: news.atom returned HTML
    "vivo_news": [
        "https://www.vivo.com/en/about-vivo/news.rss.xml",  # was found as valid before
        "https://www.vivo.com/en/about-vivo/news/feed",
        "https://www.vivo.com/en/about-vivo/news/rss",
        "https://www.vivo.com/en/about-vivo/news/index.xml",
    ],
    # Braun: index.rss returned HTML
    "braun": [
        "https://www.braun.com/en/index.rss",
        "https://www.braun.com/rss.xml",
        "https://www.braun.com/feed",
        "https://www.braun.com/en/rss",
        "https://www.braun.com/global/en/braun-prize.rss",
        # Braun prize page might have its own feed
        "https://www.braun.com/global/en/braun-prize.html/feed",
    ],
    # Sony: presscentre returned 403, sony.com/rss returned HTML
    "sony_design": [
        # Try Sony group/IR news
        "https://www.sony.net/SonyInfo/IR/news/modules/rdf/",
        "https://www.sony.net/SonyInfo/IR/news/rss/index.rdf",
        # Sony Electronics
        "https://electronics.sony.com/press/rss",
        "https://press.sony.com/en/rss",
        "https://press.sony.com/rss",
        # Sony Group
        "https://www.sony.net/en/SonyInfo/IR/news/rss/",
        "https://www.sony.net/SonyInfo/News/PressReleases/en/index.xml",
    ],
    # B&O: ?feed=rss2 returned HTML (not WordPress)
    "bang_olufsen": [
        "https://www.bang-olufsen.com/en/the-latest/feed",
        "https://www.bang-olufsen.com/en/the-latest.rss",
        "https://www.bang-olufsen.com/en/stories.rss",
        "https://www.bang-olufsen.com/en/feed",
        # Contentful might serve RSS
        "https://www.bang-olufsen.com/feed.xml",
        "https://www.bang-olufsen.com/atom.xml",
    ],
    # OPPO: newsroom.xml returned HTML
    "oppo_newsroom": [
        "https://www.oppo.com/en/newsroom/rss",
        "https://www.oppo.com/en/newsroom/feed",
        "https://www.oppo.com/en/newsroom/index.xml",
        "https://www.oppo.com/en/newsroom.rss",
        "https://www.oppo.com/en/news.atom",
    ],
    # Brands never found - try more patterns
    "nothing_newsroom": [
        # Shopify-based, might need .atom suffix
        "https://nothing.tech/blogs/news.atom",
        "https://nothing.tech/blogs/news.rss",
        # Shopify's default feed URL
        "https://nothing.tech/collections/all.atom",
    ],
    "teenage_engineering": [
        "https://teenage.engineering/all.atom",
        "https://teenage.engineering/all.rss",
        "https://teenage.engineering/about.atom",
        "https://teenage.engineering/about.rss",
    ],
    "bose_press_room": [
        "https://www.bose.com/pressroom.rss",
        "https://www.bose.com/pressroom.xml",
        "https://www.bose.com/feed",
        "https://www.bose.com/pressroom/feed",
    ],
    "gopro_news": [
        "https://gopro.com/blogs/news.atom",
        "https://gopro.com/blogs/news.rss",
        "https://gopro.com/blogs/news.rss.xml",
        "https://gopro.com/blogs/the-current.atom",
        "https://gopro.com/blogs/the-current.rss",
    ],
    "canon_global_news": [
        "https://global.canon/en/news/index.rdf",
        "https://global.canon/en/news/rss/news.xml",
        "https://global.canon/en/news/rss.xml",
        "https://www.canon-europe.com/press-centre/rss",
    ],
    "fujifilm_news": [
        # Fujifilm might not have RSS
        "https://www.fujifilm.com/news/rss.xml",
        "https://www.fujifilm.com/news/feed",
        "https://www.fujifilm.com/news/rss/",
        # Try global news
        "https://www.fujifilm.com/us/en/news/feed/",
        "https://www.fujifilm.com/us/en/news/rss.xml",
    ],
    "framework_blog": [
        # Ghost CMS RSS
        "https://frame.work/blog/rss/index.xml",
        "https://frame.work/ghost/rss/index.xml",
        "https://frame.work/blog/atom/index.xml",
    ],
    "consumer": [  # Huawei
        "https://consumer.huawei.com/en/press/feed.xml",
        "https://consumer.huawei.com/en/press/news.rss",
        # Corporate
        "https://www.huawei.com/en/press/news/index.xml",
        "https://www.huawei.com/en/press/rss",
    ],
    "honor": [
        "https://www.honor.com/global/news.rss.xml",
        "https://www.honor.com/global/news.atom.xml",
        "https://www.honor.com/global/news/rss",
        "https://www.honor.com/global/news/atom",
        "https://www.honor.com/global/news/feed",
    ],
    "realme_newsroom": [
        "https://www.realme.com/global/newsroom.rss",
        "https://www.realme.com/global/newsroom.atom",
        "https://www.realme.com/global/newsroom.xml",
        "https://www.realme.com/global/newsroom/feed",
    ],
    "dji_media_center": [
        "https://www.dji.com/newsroom/rss",
        "https://www.dji.com/newsroom/index.xml",
        "https://www.dji.com/newsroom.atom",
        "https://www.dji.com/rss.xml",
    ],
    "insta360_blog": [
        "https://www.insta360.com/blog/rss.xml",
        "https://www.insta360.com/blog/index.xml",
        "https://blog.insta360.com/rss.xml",
        "https://blog.insta360.com/index.xml",
    ],
    "anker_news": [
        "https://www.anker.com/blogs/news.atom",
        "https://www.anker.com/blogs/news.rss",
        "https://www.anker.com/blogs/news.rss.xml",
        "https://www.anker.com/blogs/news-feed.xml",
    ],
    "dyson_newsroom": [
        "https://www.dyson.com/discover/news.rss",
        "https://www.dyson.com/discover/news.atom",
        "https://www.dyson.com/discover/news/index.xml",
        "https://www.dyson.com/news.xml",
    ],
    "bosch_press_portal": [
        "https://www.bosch-presse.de/pressportal/de/en/rss.xml",
        "https://www.bosch-presse.de/pressportal/de/en/index.xml",
        "https://www.bosch.com/newsroom/rss.xml",
        "https://www.bosch.com/rss.xml",
    ],
    "lg_newsroom": [
        "https://www.lgnewsroom.com/feed/",
        "https://www.lgnewsroom.com/rss.xml",
        "https://www.lgnewsroom.com/?feed=rss2",
        "https://www.lgnewsroom.com/wp-json/wp/v2/posts",
    ],
    "panasonic_newsroom": [
        "https://news.panasonic.com/global/rss/all/index.xml",
        "https://news.panasonic.com/global/rss/press/index.xml",
    ],
    "ikea_newsroom": [
        "https://www.ikea.com/global/en/newsroom/feed",
        "https://www.ikea.com/global/en/newsroom.rss",
        "https://www.ikea.com/global/en/newsroom/rss",
        "https://www.ikea.com/feed",
    ],
    "design_milk": [
        "https://design-milk.com/feed/",
        "https://design-milk.com/rss.xml",
        "https://feeds.feedburner.com/designmilk",
    ],
    "fast_company_design": [
        "https://www.fastcompany.com/feed",
        "https://www.fastcompany.com/section/co-design/feed",
        "https://feeds.feedburner.com/fastcompany/headlines",
    ],
    "new_atlas": [
        "https://newatlas.com/feed",
        "https://newatlas.com/rss.xml",
        "https://feeds.feedburner.com/newatlas",
    ],
    "herman_miller": [
        "https://www.hermanmiller.com/en_US/ideas/feed",
        "https://www.hermanmiller.com/en_US/stories/feed",
        "https://www.hermanmiller.com/feed",
        "https://www.hermanmiller.com/en_US/feed",
    ],
    "vitra": [
        "https://www.vitra.com/en/stories/feed",
        "https://www.vitra.com/en/stories.rss",
        "https://www.vitra.com/feed",
        "https://www.vitra.com/en/feed",
    ],
    "mercedes_benz_media": [
        "https://media.mercedes-benz.com/feed",
        "https://media.mercedes-benz.com/rss.xml",
        "https://media.mercedes-benz.com/rss",
    ],
    "audi_mediacenter": [
        "https://www.audi-mediacenter.com/en/feed",
        "https://www.audi-mediacenter.com/en/rss.xml",
        "https://www.audi-mediacenter.com/rss",
    ],
    "porsche_newsroom": [
        "https://newsroom.porsche.com/en/feed",
        "https://newsroom.porsche.com/en/rss.xml",
        "https://newsroom.porsche.com/rss",
    ],
    "volvo_cars_media": [
        "https://www.media.volvocars.com/feed",
        "https://www.media.volvocars.com/rss.xml",
        "https://www.media.volvocars.com/rss",
    ],
    "tesla": [
        "https://www.tesla.com/blog/feed",
        "https://www.tesla.com/blog/rss.xml",
        "https://www.tesla.com/feed",
        "https://www.tesla.com/rss.xml",
    ],
    "toyota_global_newsroom": [
        "https://global.toyota/en/newsroom/rss.xml",
        "https://global.toyota/en/newsroom/feed",
        "https://global.toyota/en/newsroom/rss",
    ],
    "honda_global_newsroom": [
        "https://global.honda/en/newsroom/rss.xml",
        "https://global.honda/en/newsroom/feed",
        "https://global.honda/en/newsroom/rss",
    ],
}

def verify_feed_strict(url):
    """Strictly verify that a URL returns valid RSS/Atom XML feed."""
    try:
        result = subprocess.run(
            ["curl", "-sL", "--compressed", "-o", "-", "-w", "\\n__HTTP_CODE__%{http_code}",
             "--max-time", "15", "--connect-timeout", "12",
             "-H", "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
             "-H", "Accept: application/rss+xml, application/atom+xml, application/xml, text/xml, */*",
             url],
            capture_output=True, text=True, timeout=25
        )
        output = result.stdout
        http_code = "000"
        if "__HTTP_CODE__" in output:
            parts = output.rsplit("__HTTP_CODE__", 1)
            body = parts[0]
            http_code = parts[1].strip()
        else:
            body = output

        if http_code != "200":
            return (url, False, http_code, 0, "")

        body_stripped = body.strip()
        
        # Reject HTML
        if body_stripped.lower().startswith('<!doctype html') or body_stripped.lower().startswith('<html'):
            return (url, False, http_code, len(body), "HTML")
        
        # Check for valid RSS/Atom
        starts_with_xml = (
            body_stripped.startswith('<?xml') or
            body_stripped.startswith('<rss') or
            body_stripped.startswith('<feed') or
            body_stripped.startswith('<rdf:RDF')
        )
        
        first_2000 = body_stripped[:2000].lower()
        has_rss_elements = (
            ('<channel>' in first_2000 or '<channel ' in first_2000) or
            ('<entry>' in first_2000 or '<entry ' in first_2000) or
            ('<item>' in first_2000 or '<item ' in first_2000) or
            ('<feed' in first_2000 and 'xmlns' in first_2000)
        )
        
        is_valid = starts_with_xml and has_rss_elements and len(body) > 200
        
        return (url, is_valid, http_code, len(body), body_stripped[:200])
    except Exception as e:
        return (url, False, "ERR", 0, str(e)[:100])

def main():
    all_urls = {}
    for brand, urls in NEW_CANDIDATES.items():
        for url in urls:
            all_urls[url] = brand

    # Also re-verify the 8 confirmed feeds
    CONFIRMED = {
        "google_blog_products": "https://blog.google/rss/",
        "nikon_news": "https://www.nikon.com/company/rss/feeds/news.rss",
        "leica_camera": "https://leica-camera.com/rss.xml",
        "meta_newsroom": "https://about.fb.com/news/feed/",
        "bmw_group_pressclub": "https://www.press.bmwgroup.com/global/rss",
        "philips_news_center": "https://www.philips.com/content/corporate/en_AA/feed.rss.xml?pageSize=15&startIndex=0&src=/content/corporate/en_AA/about/news/archive&sortMode=createdDate",
        "steelcase": "https://www.steelcase.com/feed/",
        "the_verge": "https://www.theverge.com/rss/index.xml",
        "panasonic_newsroom": "https://news.panasonic.com/global/rss/all/index.xml",
    }
    
    print(f"Testing {len(all_urls)} new candidate URLs...")
    
    results = dict(CONFIRMED)  # Start with confirmed feeds
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=15) as executor:
        future_to_url = {executor.submit(verify_feed_strict, url): url for url in all_urls}
        
        for future in concurrent.futures.as_completed(future_to_url):
            url = future_to_url[future]
            try:
                result_url, is_valid, http_code, size, preview = future.result()
                brand = all_urls[result_url]
                status = "VALID RSS" if is_valid else f"INVALID({http_code})"
                print(f"[{status}] {brand}: {result_url} (size={size})")
                if not is_valid and size > 0:
                    print(f"  Preview: {preview[:100]}")
                if is_valid and brand not in results:
                    results[brand] = result_url
            except Exception as e:
                print(f"[ERROR] {url}: {e}")
    
    return results

if __name__ == "__main__":
    results = main()
    
    print("\n" + "="*80)
    print("ROUND 7 - FINAL VERIFIED RESULTS")
    print("="*80)
    
    print(f"\nVerified RSS feeds for {len(results)} brands:")
    for brand, url in sorted(results.items()):
        print(f"  {brand}: {url}")
    
    # Determine not found
    ALL_BRANDS = set(NEW_CANDIDATES.keys()) | set([
        "apple_newsroom", "samsung_global_newsroom", "sony_design", "google_blog_products",
        "microsoft_surface_blog", "meta_newsroom", "nothing_newsroom", "teenage_engineering",
        "bang_olufsen", "bose_press_room", "sonos_newsroom", "logitech_newsroom",
        "garmin_newsroom", "gopro_news", "leica_camera", "canon_global_news",
        "nikon_news", "fujifilm_news", "framework_blog", "consumer", "mi",
        "honor", "oppo_newsroom", "vivo_news", "realme_newsroom", "lenovo_storyhub",
        "dji_media_center", "insta360_blog", "anker_news", "cmf_by_nothing",
        "dyson_newsroom", "braun", "philips_news_center", "bosch_press_portal",
        "miele_press", "siemens_home_appliances", "gaggenau", "electrolux_group_newsroom",
        "lg_newsroom", "panasonic_newsroom", "balmuda", "muji", "ikea_newsroom",
        "haier", "midea-group", "fotile", "robam", "newsroom", "ecovacs",
        "dreametech", "global", "narwal", "mi_2", "bears",
        "herman_miller", "knoll", "vitra", "steelcase", "haworth", "humanscale",
        "usm", "fritz_hansen", "hay", "muuto", "artek", "cassina", "b_b_italia",
        "kartell", "magis", "molteni_c", "poliform", "flos", "artemide",
        "louis_poulsen", "tradition", "bosch_professional", "hilti", "festool",
        "makita", "dewalt", "milwaukee_tool", "stihl", "husqvarna", "leatherman",
        "victorinox", "stanley", "pelican", "yeti", "patagonia", "arc_teryx",
        "the_north_face", "snow_peak", "bmw_group_pressclub", "mini_pressclub",
        "mercedes_benz_media", "audi_mediacenter", "porsche_newsroom",
        "volvo_cars_media", "polestar_media", "hyundai_newsroom",
        "kia_global_media_center", "toyota_global_newsroom", "honda_global_newsroom",
        "nissan_global_newsroom", "yamaha_motor_news", "tesla", "rivian_stories",
        "lucid_media_room", "nio", "lixiang", "xpeng", "zeekrglobal",
        "xiaomiev", "bydglobal", "yangwangauto", "fangchengbao", "global_2",
        "avatr", "voyah", "philips_healthcare", "siemens_healthineers_press_center",
        "ge_healthcare_newsroom", "medtronic_newsroom", "stryker_news",
        "dr_ger_press_center", "leica_microsystems_news", "zebra_technologies_newsroom",
        "honeywell_news", "fluke_news", "k_rcher", "abb_news", "kuka_press",
        "universal_robots_news", "boston_dynamics_blog", "ideo", "frog",
        "designworks", "lunar", "fuseproject", "layer", "map_project_office",
        "seymourpowell", "priestmangoode", "pentagram", "ammunition", "whipsaw",
        "newdealdesign", "teams_design", "veryday", "kiska", "astro_studios",
        "nendo", "naoto_fukasawa_design", "studio_f_a_porsche", "lkkdesign",
        "artopgroup", "moomadesign", "xivo-design", "yang_design", "gk_design_group",
        "tangible", "native_design", "materialdistrict", "material_connexion",
        "materiom", "matmatch", "basf_designfabrik", "covestro_cmf", "sabic",
        "3m_design", "eastman", "coloro", "wgsn", "pantone", "specialchem",
        "additive_manufacturing_media", "protolabs", "xometry", "fictiv", "hubs",
        "formlabs", "stratasys", "materialise", "carbon", "hp_3d_printing",
    ])
    
    # The 50 target brands from the task
    TARGET_BRANDS = [
        "apple_newsroom", "sony_design", "google_blog_products", "microsoft_surface_blog",
        "meta_newsroom", "nothing_newsroom", "teenage_engineering", "bang_olufsen",
        "bose_press_room", "sonos_newsroom", "logitech_newsroom", "gopro_news",
        "leica_camera", "canon_global_news", "nikon_news", "fujifilm_news",
        "framework_blog", "consumer", "mi", "honor", "oppo_newsroom", "vivo_news",
        "realme_newsroom", "dji_media_center", "insta360_blog", "anker_news",
        "dyson_newsroom", "braun", "philips_news_center", "bosch_press_portal",
        "lg_newsroom", "panasonic_newsroom", "ikea_newsroom", "the_verge",
        "wallpaper", "design_milk", "fast_company_design", "new_atlas",
        "herman_miller", "vitra", "steelcase", "bmw_group_pressclub",
        "mercedes_benz_media", "audi_mediacenter", "porsche_newsroom",
        "volvo_cars_media", "tesla", "toyota_global_newsroom", "honda_global_newsroom",
    ]
    
    not_found = [b for b in TARGET_BRANDS if b not in results]
    
    print(f"\nNot found ({len(not_found)}): {not_found}")
    
    # Save
    output = {
        "found": results,
        "not_found": not_found,
    }
    with open("/home/ubuntu/workdir/daily-industrial-design-image-search/rss_final.json", "w") as f:
        json.dump(output, f, indent=2)
    
    print(f"\nResults saved to rss_final.json")
