#!/usr/bin/env python3
"""Application entry point for the Industrial Design Intelligence Gallery.

Usage:
    uvicorn main:app --host 0.0.0.0 --port 8000

Or directly:
    python main.py
"""
from __future__ import annotations
import logging
import os
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles

from app.routes import router, image_router
from app import scheduler
from app import database as db

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger(__name__)

ROOT = Path(__file__).resolve().parent
OUTPUT_DIR = ROOT / "output"
STATIC_DIR = ROOT / "static"


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Start scheduler on startup
    scheduler.start_scheduler()
    logger.info("Application started")
    yield
    # Shutdown
    scheduler.stop_scheduler()
    logger.info("Application stopped")


app = FastAPI(
    title="工业设计情报画廊",
    description="Industrial Design Intelligence Gallery API",
    version="1.0.0",
    lifespan=lifespan,
)

# Include API routes
app.include_router(router)
app.include_router(image_router)


# --- Static file serving ---

import re

_FALLBACK_OUTPUT_DIR = Path("/var/www/static/output")

def _date_dirs() -> list[Path]:
    dirs = []
    for base in (OUTPUT_DIR, _FALLBACK_OUTPUT_DIR):
        if base.exists():
            dirs.extend(
                d for d in base.iterdir()
                if d.is_dir() and re.match(r'\d{4}-\d{2}-\d{2}', d.name)
            )
    seen = set()
    unique = []
    for d in sorted(dirs, key=lambda x: x.name, reverse=True):
        if d.name not in seen:
            seen.add(d.name)
            unique.append(d)
    return unique


def _find_portal_html() -> Path | None:
    """Search all date dirs for the portal HTML, preferring dynamic over static."""
    for d in _date_dirs():
        dynamic = d / "design_intelligence_portal_dynamic.html"
        if dynamic.exists():
            return dynamic
    for d in _date_dirs():
        static = d / "design_intelligence_portal.html"
        if static.exists():
            return static
    return None


_all_date_dirs = _date_dirs()
latest_dir = _all_date_dirs[0] if _all_date_dirs else None

# Mount details at /details/
if latest_dir:
    details_dir = latest_dir / "details"
    if details_dir.exists():
        app.mount("/details", StaticFiles(directory=str(details_dir)), name="details")

# NOTE: /history_images/ and /images/ are served by routes in app/routes.py
# which search all date dirs under output/ for the requested file.


# Serve the portal HTML at /
@app.get("/")
async def serve_portal():
    portal = _find_portal_html()
    if portal:
        html = portal.read_text(encoding="utf-8")
        # Server-side replacement of hardcoded hero stats so the
        # initial page source is correct even before client JS runs
        try:
            stats = db.get_stats()
            total = stats["total_products"]
            cats = len(stats.get("categories", []))
            srcs = stats.get("distinct_sources", 0)
            import datetime as _dt
            _today = _dt.date.today().isoformat()
            report_date = stats.get("latest_date") or _today
            import re as _re
            # Replace hero stats block: <strong>N</strong><span>Products</span> etc.
            html = _re.sub(
                r'(<div class="stats">.*?<strong>)(\d+)(</strong><span>Products</span></div>.*?<strong>)(\d+)(</strong><span>Images</span></div>.*?<strong>)(\d+)(</strong><span>Categories</span></div>.*?<strong>)(\d+)(</strong><span>Sources</span></div>)',
                lambda m: m.group(1) + str(total) + m.group(3) + str(total) + m.group(5) + str(cats) + m.group(7) + str(srcs) + m.group(9),
                html, count=1, flags=_re.DOTALL,
            )
            # Replace the "全部" filter count
            html = _re.sub(
                r'(data-category="all">全部 <span class="count">)(\d+)(</span>)',
                lambda m: m.group(1) + str(total) + m.group(3),
                html, count=1,
            )
            # Inject the correct report date into eyebrow, side-rail, body attributes
            if report_date:
                html = _re.sub(
                    r'(<div class="eyebrow"[^>]*>)(\d{4}-\d{2}-\d{2})( · DAILY IMAGE INTELLIGENCE</div>)',
                    lambda m: m.group(1) + report_date + m.group(3),
                    html, count=1,
                )
                html = _re.sub(
                    r'(<span class="rail-label"[^>]*>)(\d{4}-\d{2}-\d{2})(</span><span class="rail-label">Daily Gallery</span>)',
                    lambda m: m.group(1) + report_date + m.group(3),
                    html, count=1,
                )
                html = _re.sub(
                    r'(data-report-date=")\d{4}-\d{2}-\d{2}(")',
                    lambda m: m.group(1) + report_date + m.group(2),
                    html, count=1,
                )
                html = _re.sub(
                    r'(data-report-id="daily-)\d{4}-\d{2}-\d{2}(")',
                    lambda m: m.group(1) + report_date + m.group(2),
                    html, count=1,
                )
        except Exception:
            logger.exception("Failed to inject server-side stats")
        return HTMLResponse(html)
    # Fallback: serve static index.html when portal HTML is not found
    static_index = Path("/var/www/static/index.html")
    if static_index.exists():
        return HTMLResponse(static_index.read_text(encoding="utf-8"))
    return {"message": "Portal HTML not found. Run the pipeline first."}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=int(os.environ.get("PORT", 8000)),
        reload=False,
    )
