# 全栈升级需求规格分析

## 一、需求理解

用户要求将现有静态 HTML 工业设计画廊项目升级为带数据库、每日自动抓取、实时更新的全栈应用，并公网部署。

现有项目是一个成熟的 Python 数据采集 + 静态 HTML 生成管线，已具备：
- 286+ 个工业设计来源的配置和调度
- 多层采集管线（RSS/Sitemap/HTML → 评分 → 详情提取 → 质量门禁 → 去重 → 分析 → 图片验证 → HTML 生成）
- 分层画廊体系（daily/weekly/monthly/half_year/annual）
- 飞书云盘发布和 Bitable 同步
- 但所有产物是静态 HTML 文件 + 内联 JSON，无后端服务、无数据库、无实时 API

---

## 二、产品数据字段表

### 2.1 采集管线原始字段（collected_data.json — pipeline/run.py 输出）

| 字段名 | 类型 | 来源 | 是否必填 | 说明 |
|--------|------|------|----------|------|
| product_id | string | pipeline/dedupe.py | ✅ 必填 | `prod_` + SHA1(brand\|product_name\|canonical_url)[:16] |
| title | string | collectors/extract.py | ✅ 必填 | 从 og:title / h1 / title 提取 |
| product_name | string | collectors/extract.py | ⬜ 可选 | 从 JSON-LD Product/Article name 提取 |
| brand | string | collectors/extract.py | ⬜ 可选 | 从 JSON-LD brand 提取，空时用 source 配置 |
| canonical_url | string | collectors/extract.py + pipeline/dedupe.py | ✅ 必填 | URL 归一化后（去 UTM 等 tracking 参数） |
| official_url | string | pipeline/run.py | ⬜ 可选 | 仅 official_brand 来源设置 |
| page_url | string | collectors/extract.py | ✅ 必填 | 实际页面 URL |
| url | string | collectors/discovery.py | ⬜ 可选 | 原始发现 URL |
| image_url | string | collectors/extract.py | ✅ 必填 | og:image / twitter:image / JSON-LD image |
| published_at | string(ISO) | collectors/extract.py | ⬜ 可选 | ISO 8601 UTC 时间戳 |
| modified_at | string(ISO) | collectors/extract.py | ⬜ 可选 | JSON-LD dateModified |
| body_text | string | collectors/extract.py | ⬜ 可选 | 正文文本，截断到 12000 字符 |
| summary | string | collectors/discovery.py | ⬜ 可选 | RSS description / HTML 入口摘要，500 字符 |
| source | string | pipeline/run.py | ✅ 必填 | = publisher |
| source_id | string | pipeline/run.py | ✅ 必填 | source_catalog.json 中的 id |
| source_type | string | config/sources.json | ✅ 必填 | official_brand / design_media / award / event |
| publisher | string | pipeline/run.py | ✅ 必填 | source 配置中的 publisher |
| source_trust | float | pipeline/run.py | ✅ 必填 | 0.0-1.0，official=1.0, media=0.75 |
| discovery_mode | string | collectors/discovery.py | ✅ 必填 | rss / sitemap / html / api |
| domain | string | collectors/extract.py | ⬜ 可选 | canonical_url 的 netloc |
| candidate_score | int | pipeline/candidate_scoring.py | ✅ 必填 | -100~100，评分后筛选阈值 |
| score_reasons | list[string] | pipeline/candidate_scoring.py | ✅ 必填 | 评分理由列表 |
| accepted | bool | pipeline/quality.py | ✅ 必填 | 是否通过质量门禁 |
| exclude_reasons | list[string] | pipeline/quality.py | ⬜ 可选 | 排除理由 |
| content_type | string | pipeline/quality.py | ✅ 必填 | physical_product / unknown |
| release_status | string | pipeline/quality.py | ✅ 必填 | released / unverified |
| quality_score | float | pipeline/quality.py | ✅ 必填 | 0.0-1.0 综合质量分 |

### 2.2 图片处理追加字段（materialize_product_images.py + validate_product_images.py）

| 字段名 | 类型 | 来源 | 是否必填 | 说明 |
|--------|------|------|----------|------|
| local_image_path | string | materialize_product_images.py | ✅ 发布必填 | 相对于项目根的路径，如 `images/prod_xxx.jpg` |
| image_sha256 | string | (部分管线) | ⬜ 可选 | 图片内容 SHA-256 |
| image_verified | bool | validate_product_images.py | ✅ 发布必填 | Pillow 验证通过 |
| image_validation_reasons | list[string] | validate_product_images.py | ⬜ 可选 | 验证失败原因 |
| image_acquisition_method | string | materialize_product_images.py | ⬜ 可选 | `native_http_download` |

### 2.3 分析追加字段（pipeline/analyze.py — ai_analysis 子对象）

| 字段名 | 类型 | 来源 | 是否必填 | 说明 |
|--------|------|------|----------|------|
| ai_analysis.category | string | pipeline/analyze.py | ✅ 必填 | 12 个分类之一 |
| ai_analysis.category_label | string | pipeline/analyze.py | ✅ 必填 | 中文标签 |
| ai_analysis.description | string | pipeline/analyze.py | ✅ 必填 | 60-120 字中文产品说明 |
| ai_analysis.features | string | pipeline/analyze.py | ✅ 必填 | = description（兼容） |
| ai_analysis.style | string | pipeline/analyze.py | ⬜ 可选 | 设计风格 |
| ai_analysis.materials | list[string] | pipeline/analyze.py | ⬜ 可选 | 材料 |
| ai_analysis.subcategory | string | pipeline/analyze.py | ⬜ 可选 | 子类 |
| ai_analysis.target_user | string | pipeline/analyze.py | ⬜ 可选 | 目标用户 |
| ai_analysis.confidence | float | pipeline/analyze.py | ✅ 必填 | 0.0-1.0 |
| ai_analysis.analysis_mode | string | pipeline/analyze.py | ✅ 必填 | `model_evidence` / `heuristic_evidence` |
| ai_analysis.verified_facts | list[string] | pipeline/analyze.py | ⬜ 可选 | 可验证事实 |
| ai_analysis.design_observations | list[string] | pipeline/analyze.py | ⬜ 可选 | 设计观察 |
| ai_analysis.evidence | list[object] | pipeline/analyze.py | ⬜ 可选 | {field, value, evidence_text, source_url} |

### 2.4 全局画廊增强字段（global_gallery_input.json — build_gallery_hierarchy.py 输出）

| 字段名 | 类型 | 来源 | 是否必填 | 说明 |
|--------|------|------|----------|------|
| first_seen_date | string | build_gallery_hierarchy.py | ✅ 必填 | YYYY-MM-DD，首次入库日期 |
| local_image_path | string | build_gallery_hierarchy.py | ✅ 必填 | 重写为 history_images/ 路径 |
| news_type | string | build_portal_pages.py | ✅ 必填 | 官方新品 / 媒体新稿 |
| maturity | string | build_portal_pages.py | ✅ 必填 | media_coverage / released 等 |
| verification_status | string | run_tiered_batches.py | ✅ 必填 | confirmed / needs_review |
| collection_tier | string | run_tiered_batches.py | ⬜ 可选 | official_structured / official_pages / design_media |
| collection_tier_label | string | run_tiered_batches.py | ⬜ 可选 | 中文分层标签 |
| description_zh | string | pipeline/analyze.py | ✅ 必填 | 中文产品说明 |
| cmf_colors | list[string] | 增强 | ⬜ 可选 | 颜色标签 |
| cmf_materials | list[string] | 增强 | ⬜ 可选 | 材料标签 |
| cmf_finishes | list[string] | 增强 | ⬜ 可选 | 工艺标签 |
| style_keywords | list[string] | 增强 | ⬜ 可选 | 风格关键词 |
| design_drivers | list[string] | 增强 | ⬜ 可选 | 设计驱动因素 |
| region | string | 增强 | ⬜ 可选 | 地区 |
| feishu_file_token | string | 飞书上传 | ⬜ 可选 | 飞书文件 token |

### 2.5 顶层元数据字段（collected_data.json）

| 字段名 | 类型 | 说明 |
|--------|------|------|
| schema_version | string | 当前 `2.1` |
| run_date | string | YYYY-MM-DD |
| products | list[object] | 产品列表 |
| entities | list[object] | = products（别名） |
| stats | object | {configured_sources, checked_sources, detail_pages, accepted, target_min, target_met, duplicates} |

---

## 三、数据库 Schema 设计建议

### 3.1 核心表设计

```sql
-- 来源配置表
CREATE TABLE sources (
    id VARCHAR(64) PRIMARY KEY,              -- 'core77', 'designboom' 等
    publisher VARCHAR(128) NOT NULL,
    source_type VARCHAR(32) NOT NULL,        -- official_brand / design_media / award / event
    priority VARCHAR(4) DEFAULT 'P2',        -- P0/P1/P2/P3
    url TEXT NOT NULL,
    enabled BOOLEAN DEFAULT TRUE,
    check_frequency VARCHAR(20) DEFAULT 'daily', -- daily/every_2_days/weekly/monthly
    discovery JSONB,                          -- ['rss','sitemap','html']
    candidate_budget INT DEFAULT 30,
    detail_fetch_budget INT DEFAULT 6,
    candidate_score_threshold INT DEFAULT 38,
    max_age_days INT DEFAULT 14,
    trust_level FLOAT DEFAULT 0.75,
    feed_urls JSONB,                         -- ['https://.../feed/']
    sitemap_urls JSONB,
    api_urls JSONB,
    include_terms JSONB,
    event_only BOOLEAN DEFAULT FALSE,
    event_start DATE,
    event_end DATE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 来源状态表（替代 data/state/source_state.json）
CREATE TABLE source_state (
    source_id VARCHAR(64) REFERENCES sources(id),
    last_checked_at TIMESTAMPTZ,
    last_success_at TIMESTAMPTZ,
    last_error TEXT,
    entrance_hash VARCHAR(64),
    last_discovered INT DEFAULT 0,
    last_accepted INT DEFAULT 0,
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (source_id)
);

-- 产品表（核心表）
CREATE TABLE products (
    product_id VARCHAR(32) PRIMARY KEY,      -- prod_xxx (SHA1[:16])
    title TEXT NOT NULL,
    product_name TEXT,
    brand VARCHAR(256),
    canonical_url TEXT NOT NULL,
    official_url TEXT,
    page_url TEXT NOT NULL,
    image_url TEXT,
    local_image_path TEXT,                   -- images/prod_xxx.jpg
    image_sha256 VARCHAR(64),
    image_verified BOOLEAN DEFAULT FALSE,
    image_acquisition_method VARCHAR(32),
    published_at TIMESTAMPTZ,
    modified_at TIMESTAMPTZ,
    first_seen_date DATE NOT NULL,
    body_text TEXT,                           -- 截断 12000 字符
    summary TEXT,
    description_zh TEXT,                      -- 中文说明
    source_id VARCHAR(64) REFERENCES sources(id),
    source VARCHAR(128),
    publisher VARCHAR(128),
    source_type VARCHAR(32),
    source_trust FLOAT,
    discovery_mode VARCHAR(16),
    domain VARCHAR(256),
    candidate_score INT,
    score_reasons JSONB,
    content_type VARCHAR(32),                 -- physical_product / unknown
    release_status VARCHAR(32),               -- released / unverified
    quality_score FLOAT,
    accepted BOOLEAN DEFAULT FALSE,
    exclude_reasons JSONB,
    verification_status VARCHAR(32),          -- confirmed / needs_review
    news_type VARCHAR(32),                    -- 官方新品 / 媒体新稿
    maturity VARCHAR(32),                     -- media_coverage / released
    collection_tier VARCHAR(32),
    collection_tier_label VARCHAR(64),
    ai_analysis JSONB,                        -- 完整 ai_analysis 子对象
    cmf_colors JSONB,
    cmf_materials JSONB,
    cmf_finishes JSONB,
    style_keywords JSONB,
    design_drivers JSONB,
    region VARCHAR(64),
    feishu_file_token TEXT,
    review_status VARCHAR(32) DEFAULT '待审核',
    is_retained BOOLEAN DEFAULT FALSE,
    human_category VARCHAR(64),
    human_tags JSONB,
    internal_notes TEXT,
    owner VARCHAR(64),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 产品证据表（可选，用于规范化 ai_analysis.evidence）
CREATE TABLE product_evidence (
    id SERIAL PRIMARY KEY,
    product_id VARCHAR(32) REFERENCES products(product_id),
    field VARCHAR(128),
    value TEXT,
    evidence_text TEXT,
    source_url TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 采集运行日志表
CREATE TABLE pipeline_runs (
    id SERIAL PRIMARY KEY,
    run_date DATE NOT NULL,
    schema_version VARCHAR(8),
    acquisition_mode VARCHAR(20),             -- auto/native_http/agent_assisted/offline
    configured_sources INT,
    checked_sources INT,
    detail_pages INT,
    accepted_count INT,
    target_min INT,
    target_met BOOLEAN,
    duplicates_count INT,
    source_health JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(run_date)
);

-- 来源健康检查表
CREATE TABLE source_health (
    id SERIAL PRIMARY KEY,
    run_date DATE NOT NULL,
    source_id VARCHAR(64) REFERENCES sources(id),
    publisher VARCHAR(128),
    source_type VARCHAR(32),
    priority VARCHAR(4),
    status VARCHAR(32),                       -- ok/failed/not_due/unchanged/not_checked_budget
    due BOOLEAN,
    due_reason VARCHAR(64),
    discovered INT DEFAULT 0,
    scored INT DEFAULT 0,
    detail_fetched INT DEFAULT 0,
    parsed INT DEFAULT 0,
    accepted INT DEFAULT 0,
    skipped_unchanged BOOLEAN DEFAULT FALSE,
    errors JSONB
);

-- 图片审查队列
CREATE TABLE image_review_queue (
    id SERIAL PRIMARY KEY,
    product_id VARCHAR(32),
    local_image_path TEXT,
    image_url TEXT,
    image_validation_reasons JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
```

### 3.2 索引建议

```sql
CREATE INDEX idx_products_first_seen ON products(first_seen_date DESC);
CREATE INDEX idx_products_source_type ON products(source_type);
CREATE INDEX idx_products_category ON products USING gin((ai_analysis->>'category'));
CREATE INDEX idx_products_brand ON products(brand);
CREATE INDEX idx_products_published ON products(published_at DESC);
CREATE INDEX idx_products_canonical_url ON products(canonical_url);
CREATE INDEX idx_source_health_date ON source_health(run_date, source_id);
CREATE INDEX idx_pipeline_runs_date ON pipeline_runs(run_date);
```

---

## 四、采集管线完整数据流图

```
┌─────────────────────────────────────────────────────────────────┐
│                    config/sources.json (286+ 来源)               │
│  source_type: official_brand / design_media / award / event     │
│  discovery: [api,] rss, sitemap, html                           │
│  check_frequency: daily / every_2_days / weekly / monthly      │
└───────────────────────────────┬─────────────────────────────────┘
                                │
                    pipeline/source_loader.py
                                │
                    pipeline/scheduler.py (is_due)
                    → 按到期+优先级排序
                    → daily_source_budget=40, detail_budget=60
                                │
              ┌─────────────────┼──────────────────┐
              │                 │                  │
     ┌────────▼────┐   ┌────────▼────┐   ┌────────▼────┐
     │ RSS/Atom    │   │ Sitemap     │   │ HTML 入口   │
     │ discovery.py│   │ discovery.py│   │ discovery.py│
     │ feed_links()│   │ sitemap_links│  │ html_links()│
     └────────┬────┘   └────────┬────┘   └────────┬────┘
              │                 │                  │
              └─────────────────┼──────────────────┘
                                │
                   candidates = [{url, title, summary, 
                                  published_at, image_url,
                                  discovery_mode}]
                                │
                   pipeline/candidate_scoring.py
                   score_candidate(candidate, source)
                   → positive/negative 关键词评分
                   → 新鲜度加分 (≤3d:+22, ≤14d:+12, >60d:-30)
                   → URL 路径加分/扣分
                   → source_type 加分 (official:+30, media:+18)
                   → 过滤 score >= threshold(38-42)
                                │
                   collectors/http_client.py
                   → 条件请求 (ETag / Last-Modified)
                   → 304 复用缓存
                   → 429/5xx 指数退避重试
                   → .cache/ 目录缓存
                                │
                   collectors/extract.py
                   extract_article(html, url)
                   → canonical URL (link rel=canonical)
                   → title (og:title / h1 / <title>)
                   → image (og:image / twitter:image / JSON-LD)
                   → published_at (JSON-LD datePublished / meta)
                   → brand (JSON-LD brand)
                   → body_text (article p / main p, ≤12000 chars)
                   → product_name (JSON-LD Product/Article name)
                                │
                   pipeline/quality.py
                   classify(item, max_age_days=14)
                   → 排除非产品 (interview/opinion/exhibition)
                   → 排除服务 (leasing/subscription/financing)
                   → 排除占位图 (placehold.co 等)
                   → 排除过期 (>14 days)
                   → content_type / release_status / quality_score
                                │
                   pipeline/dedupe.py
                   dedupe(items)
                   → URL 归一化去重 (去 UTM 等)
                   → 产品实体去重 (brand|product_name)
                   → 图片内容去重 (image_sha256)
                   → 生成稳定 product_id
                                │
                   pipeline/analyze.py
                   analyze_payload(payload)
                   → 尝试 AI API (gpt-4.1-mini)
                   → 失败回退 heuristic_evidence
                   → 输出 ai_analysis: category, description_zh,
                     verified_facts, design_observations, evidence
                                │
              ┌─────────────────┴──────────────────┐
              │                                      │
   ┌──────────▼──────────┐         ┌─────────────────▼──────────────┐
   │ scripts/             │         │ scripts/                       │
   │ materialize_product_ │         │ validate_product_images.py     │
   │ images.py            │         → Pillow 验证                   │
   → 下载真实图片         │         → 最小 500x300, 20KB             │
   → PIL 转 JPEG q=90     │         → 排除低方差/纯色/占位          │
   → 禁止 unsplash/stock │         → image_verified = true/false     │
   └──────────┬──────────┘         └─────────────────┬──────────────┘
              │                                      │
              └─────────────────┬────────────────────┘
                                │
                   scripts/build_verified_gallery_input.py
                   → 过滤 image_verified && local_image_path && page_url
                   → 输出 gallery_input.json (publishable products)
                                │
                   scripts/stage_verified_images.py
                   → 复制图片到 output/{date}/images/
                   → 重写 local_image_path = images/prod_xxx.jpg
                                │
                   scripts/generate_html.py
                   → 生成 gallery_canonical_source.html
                   → 使用 templates/daily_gallery.html.j2
                   → 内联 CSS/JS，卡片数据嵌入 HTML
                                │
                   scripts/build_gallery_hierarchy.py
                   → 按日期分层: daily(<7d) / weekly(8-30d) / monthly(31-182d) 
                     / half_year(183-365d) / annual(>365d)
                   → 生成 global_gallery_input.json (全量去重产品)
                   → 各层独立 gallery_input.json
                                │
                   scripts/build_portal_pages.py
                   → 生成 design_intelligence_portal.html
                   → 内联 PORTAL_PRODUCTS JSON 数组
                   → 生成 details/{product_id}.html 详情页
                   → 生成兼容跳转页 (explore/compare/board/topics/trends)
                                │
                   scripts/build_portable_preview.py
                   → Base64 嵌入图片，单文件便携版
                   → 最长边 1100px, JPEG q72, ≤15MB
                                │
                   scripts/build_download_manifest.py
                   → 验证所有图片引用存在
                   → 记录 SHA-256 和文件大小
                                │
                   [可选] scripts/publish_to_feishu.py
                   → 飞书云盘目录结构
                   → Bitable 记录 upsert
```

### 4.1 多通道采集模式

```
scripts/run_full_workflow.py --date YYYY-MM-DD --acquisition-mode auto
    │
    ├── scripts/detect_network_capability.py
    │   → 输出 network_capability.json
    │   → recommended_mode: native_http / agent_assisted / offline
    │
    ├── native_http 模式:
    │   └── scripts/run_daily_pipeline.py
    │       └── pipeline/run.py (标准 RSS→Sitemap→HTML 管线)
    │
    ├── agent_assisted 模式:
    │   ├── scripts/validate_tool_manifest.py (验证 Agent 清单)
    │   ├── scripts/import_agent_acquisition.py (导入 Agent 采集数据)
    │   └── 或 scripts/agent_daily_pipeline.py (直接 curl RSS 采集)
    │
    └── offline 模式:
        └── 使用已有本地数据
```

### 4.2 分层批次采集模式（run_tiered_batches.py）

```
Tier 1: official_structured (官方 RSS/API, trust=1.0)
  → Samsung, Lenovo, Garmin, Apple, Sony, Google, Microsoft, Meta...
Tier 2: official_pages (官方 HTML, trust=1.0)
  → 官方新品页 sitemap/html
Tier 3: design_media (设计媒体, trust=0.8)
  → Core77, Dezeen, Designboom, Yanko Design...

每 source 独立 state.json → 可并发 → 合并去重
→ 按 published_at 过滤当日产品
→ 输出 data/{date}/tiered/merged_data.json
```

---

## 五、现有 HTML 中前端消费数据的方式

### 5.1 数据嵌入方式：内联 JSON

`build_portal_pages.py` 将产品数据以 **内联 JSON** 方式注入 HTML：

```javascript
// 在 design_intelligence_portal.html 中：
const PORTAL_PRODUCTS = [
  {
    "id": "prod_cba41932c16c18dd",
    "title": "ASUS Zenbook A16 (UX3607OA) Review...",
    "brand": "ASUS",
    "source": "Yanko Design",
    "category": "家具照明",
    "description": "该家具产品通过造型、结构和材质优化...",
    "news_type": "媒体新稿",
    "added_date": "2026-07-09",
    "image": "history_images/prod_xxx.jpg",
    "detail": "details/prod_cba41932c16c18dd.html",
    "page_url": "https://www.yankodesign.com/...",
    "official": false,
    // + trend enrichment fields
  },
  // ... 156 items
];
const PORTAL_ISSUE_IDS = ["prod_xxx", ...];  // 当期产品 ID
const PORTAL_REPORT_DATE = "2026-08-09";
const PORTAL_LATEST_DATE = "2026-08-09";
const PORTAL_LATEST_URL = "";
```

### 5.2 前端消费方式

| 功能 | 消费方式 | localStorage 依赖 |
|------|----------|-------------------|
| 今日画廊 | 过滤 `PORTAL_PRODUCTS` 中 `added_date == PORTAL_REPORT_DATE` | 无 |
| 按周期浏览 | `periodHierarchy()` 按日期分桶 (day/week/month/year) | 无 |
| 品牌新品对比 | 按品牌分组，checkbox 最多选 6 项 | `did-project-board` |
| 项目板（收藏） | `boardIds()` 从 localStorage 读取 ID 数组 | `did-project-board` |
| 全局搜索 | `headerSearch` input → 过滤 card 的 `data-search` 属性 | 无 |
| 品类筛选 | `filter-btn` 按钮 → 按 `data-category` 过滤 card | 无 |
| 趋势看板 | `trendView()` 统计 PORTAL_PRODUCTS 分类分布 | 无 |
| 产品详情 | 独立 HTML 文件 `details/{product_id}.html` | 无 |
| 灯箱 | `data-lightbox-src` / `data-lightbox-title` 属性 | 无 |
| 导出选择清单 | 序列化 selected 数组为 JSON Blob 下载 | selected[] 运行时 |

### 5.3 前端改造关键点

1. **数据源替换**：将内联 `PORTAL_PRODUCTS` JSON 替换为 API fetch
2. **分页/无限滚动**：当前 156 条全量内联，需改为 API 分页
3. **今日过滤**：从内联 `PORTAL_ISSUE_IDS` 改为 API 查询 `?date=today`
4. **搜索/筛选**：从客户端 JS 过滤改为服务端查询
5. **趋势数据**：从客户端统计改为预聚合的 API 响应
6. **收藏/项目板**：从 localStorage 改为用户认证后的服务端持久化
7. **图片路径**：从相对路径 `images/xxx.jpg` 改为 CDN 或 API 提供的 URL

---

## 六、API 端点设计建议

### 6.1 公开 API（前端消费）

| 方法 | 路径 | 说明 | 查询参数 |
|------|------|------|----------|
| GET | `/api/products` | 产品列表（分页） | `?page=1&per_page=24&date=YYYY-MM-DD&category=transportation&brand=ASUS&source_type=official_brand&q=keyword&sort=newest\|score\|date&verified=true` |
| GET | `/api/products/{product_id}` | 产品详情（含 ai_analysis, evidence, body_text） | — |
| GET | `/api/products/{product_id}/image` | 产品图片（代理或重定向） | `?size=thumb\|full` |
| GET | `/api/today` | 当日产品列表 | `?date=YYYY-MM-DD` |
| GET | `/api/gallery` | 全局画廊（分层） | `?layer=daily\|weekly\|monthly\|half_year\|annual&page=1` |
| GET | `/api/categories` | 品类统计 | `?date=YYYY-MM-DD` |
| GET | `/api/brands` | 品牌统计 | `?date=YYYY-MM-DD` |
| GET | `/api/trends` | 趋势数据 | `?period=week\|month\|half\|year` |
| GET | `/api/search` | 搜索 | `?q=keyword&filters=...` |
| GET | `/api/sources` | 来源列表（公开） | `?enabled=true` |
| GET | `/api/source_health` | 来源健康状态 | `?date=YYYY-MM-DD` |

### 6.2 管理 API（需认证）

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/api/admin/pipeline/run` | 触发采集管线 `?date=YYYY-MM-DD&mode=auto\|native_http\|agent_assisted\|offline` |
| GET | `/api/admin/pipeline/status` | 管线运行状态 |
| GET | `/api/admin/pipeline/runs` | 历史运行日志 |
| PUT | `/api/admin/products/{id}` | 更新产品（人工审核字段） |
| PUT | `/api/admin/products/{id}/review` | 审核操作 (retained, review_status, human_category, human_tags) |
| POST | `/api/admin/sources` | 新增来源 |
| PUT | `/api/admin/sources/{id}` | 更新来源配置 |
| GET | `/api/admin/image_review` | 图片审查队列 |
| POST | `/api/admin/import` | 导入选择清单 |
| GET | `/api/admin/stats` | 系统统计 |

### 6.3 用户 API（如需用户功能）

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/api/auth/login` | 登录 |
| GET | `/api/user/board` | 用户项目板 |
| POST | `/api/user/board` | 加入项目板 |
| DELETE | `/api/user/board/{product_id}` | 移除 |
| POST | `/api/user/compare` | 保存对比组 |

---

## 七、定时抓取触发点和数据入库流程设计

### 7.1 当前触发方式

当前管线由 **手动命令** 触发：
```bash
python scripts/run_full_workflow.py --date YYYY-MM-DD
```

无定时调度器。`pipeline/scheduler.py` 的 `is_due()` 函数仅判断来源是否到期（基于上次检查时间），不负责触发管线运行。

### 7.2 全栈升级后定时抓取设计

```
┌─────────────────────────────────────────────────────┐
│              定时调度器 (cron / APScheduler)         │
│                                                     │
│  1. 每日 06:00 UTC (14:00 CST)                      │
│     → 触发全量管线                                   │
│     → python scripts/run_full_workflow.py            │
│       --date $(date -u +%Y-%m-%d)                    │
│       --acquisition-mode auto                        │
│                                                     │
│  2. 每 2 小时                                        │
│     → 触发 official_structured tier 增量采集          │
│     → python scripts/run_tiered_batches.py          │
│       --date $(date -u +%Y-%m-%d)                    │
│       --batch-size 5 --workers 3                    │
│                                                     │
│  3. 每周一 03:00 UTC                                 │
│     → 触发周报/月报合并                               │
│     → 重建 global_gallery_input.json                 │
│                                                     │
└───────────────────────┬─────────────────────────────┘
                        │
          ┌─────────────▼──────────────┐
          │   管线执行 → 数据库入库       │
          │                              │
          │  1. pipeline/run.py          │
          │     → 采集 → 质量门禁 → 去重  │
          │     → INSERT/UPSERT products │
          │     → UPSERT source_state    │
          │     → INSERT source_health   │
          │     → INSERT pipeline_runs   │
          │                              │
          │  2. analyze.py               │
          │     → UPDATE products        │
          │       SET ai_analysis=...    │
          │                              │
          │  3. materialize + validate   │
          │     → UPDATE products        │
          │       SET local_image_path,  │
          │       image_verified=...     │
          │     → INSERT image_review    │
          │                              │
          │  4. build_gallery_hierarchy   │
          │     → 全局去重 → UPSERT       │
          │     → 更新 first_seen_date   │
          │                              │
          │  5. HTML 生成（可选，缓存层）  │
          │     → 生成静态 HTML 或        │
          │     → 标记 API 缓存失效       │
          └──────────────────────────────┘
```

### 7.3 入库流程关键设计点

1. **幂等入库**：`product_id` 作为主键，UPSERT (ON CONFLICT UPDATE)
2. **增量更新**：同一 product_id 的产品在不同运行中可能获得更完整的字段（如后续运行补全了 ai_analysis），需 merge 而非覆盖
3. **图片存储**：图片保持文件系统存储（`output/{date}/images/`），数据库只存路径；升级后可考虑对象存储（S3/MinIO）
4. **状态持久化迁移**：`source_state.json` → `source_state` 表
5. **产物兼容**：HTML 生成管线可保留作为缓存层（预渲染），API 也可直接从数据库查询
6. **发布门禁**：`pipeline/release_gate.py` 的 `require_minimum_products` (24) 和 `require_healthy_priority_sources` 逻辑需在入库后执行
7. **去重逻辑**：`pipeline/dedupe.py` 的 URL 归一化、产品实体去重、图片 SHA-256 去重逻辑需在数据库层面用唯一约束 + 应用层双重保障

---

## 八、不确定点

| 编号 | 问题 | 影响执行路径 | 附件/原话是否能回答 |
|------|------|-------------|-------------------|
| 1 | 公网部署的目标平台是什么？ | 影响 Dockerfile/部署脚本/CI-CD 设计 | 否 — 原话和项目均未提及 |
| 2 | 技术栈偏好？Python(FastAPI/Django) vs Node.js？ | 直接决定后端框架选择 | 否 — 现有代码全部 Python |
| 3 | 数据库选型偏好？PostgreSQL vs MySQL vs SQLite？ | 影响 schema 语法和部署复杂度 | 否 |
| 4 | 是否需要用户认证系统？ | 影响是否需要用户表、权限设计 | 否 — 当前仅 localStorage 项目板 |
| 5 | 图片存储策略？本地文件系统 vs 对象存储(S3/MinIO)？ | 影响架构复杂度和成本 | 否 |
| 6 | 是否保留飞书发布集成？ | 影响 integrations/ 目录是否需要适配 | 否 |

---

## 九、是否建议追问用户

**是**，建议追问以下问题（均会导致执行路径分叉）：

### 问题 1：后端技术栈选择
- **A) Python FastAPI** — 与现有采集管线同语言，可直接复用 pipeline/collectors 代码，最快落地
- **B) Python Django** — 自带 admin 和 ORM，适合管理后台密集场景
- **C) Node.js (Express/NestJS)** — 前后端同语言，适合前端团队主导
- **D) 自定义/我来决定**

### 问题 2：数据库选型
- **A) PostgreSQL** — 支持 JSONB（完美匹配 ai_analysis 嵌套结构），推荐
- **B) SQLite** — 轻量部署，单文件，适合小规模
- **C) MySQL** — 运维团队已熟悉
- **D) 自定义/我来决定**

### 问题 3：部署方式和目标平台
- **A) Docker + 单服务器** — Docker Compose 一键部署（API + DB + Nginx）
- **B) 云原生 (K8s)** — 适合规模化，但复杂度高
- **C) Vercel/Netlify + 托管数据库** — 前端静态托管 + API serverless
- **D) 自定义/我来决定**

### 问题 4：前端改造范围
- **A) 最小改造** — 保留现有 HTML 模板，仅将内联 JSON 替换为 API fetch（最快）
- **B) 保留设计重写前端** — 用 React/Vue 重写，保持现有视觉设计
- **C) 全新设计** — 重新设计前端 UI
- **D) 自定义/我来决定**

---

## 十、建议专家分工

| 专家 | 负责内容 | 依赖 |
|------|----------|------|
| **后端架构师** | API 框架搭建（FastAPI/Django）、数据库 schema 实现、ORM 模型、管线入库适配层 | 需先确定技术栈和数据库 |
| **前端工程师** | 静态 HTML → 动态前端改造（API fetch 替换内联 JSON、分页、搜索服务端化、用户认证 UI） | 依赖 API 端点定义完成 |
| **DevOps 工程师** | Docker 化、CI/CD、定时调度器配置、Nginx 反向代理、SSL、公网部署 | 依赖部署平台确定 |
| **数据工程师** | pipeline/run.py 入库适配（JSON → DB UPSERT）、增量更新逻辑、去重迁移到 DB 约束、source_state 迁移 | 依赖 DB schema 确认 |
| **QA 工程师** | 端到端测试（采集 → 入库 → API → 前端展示）、数据一致性验证、管线回归测试 | 依赖全链路完成 |

### 关键依赖关系
```
[确定技术栈+DB] → 后端架构师(框架+schema) 
                    ↓
              数据工程师(入库适配) ← 并行 → 前端工程师(API fetch 改造)
                    ↓                        ↓
              DevOps(Docker+部署+定时) ← ← ← 
                    ↓
              QA(端到端测试)
```

---

## 十一、给 planning_context 的摘要

**项目路径**: `/home/ubuntu/workdir/daily-industrial-design-image-search/`

**现有架构**: Python 采集管线 (collectors → pipeline → scripts) 生成静态 HTML + 内联 JSON，无后端服务/数据库/API。

**核心数据模型**: 产品实体 (product_id 主键) + 来源配置 (286+ sources) + 来源状态 + 运行日志 + 图片验证。产品字段约 40+ 个，含嵌套 ai_analysis JSON。

**全栈升级关键改造点**:
1. 数据库 schema: 7 张核心表 (sources, source_state, products, product_evidence, pipeline_runs, source_health, image_review_queue)
2. API: ~15 个公开端点 + ~10 个管理端点
3. 入库适配: pipeline/run.py 输出从 JSON 文件改为 DB UPSERT
4. 前端改造: 内联 JSON → API fetch，localStorage → 服务端持久化
5. 定时调度: cron/APScheduler 每日触发 run_full_workflow.py
6. 图片存储: 文件系统 → 可选对象存储

**已知约束**: 
- 现有代码全 Python，requirements.txt 仅 requests/bs4/Pillow/dateutil
- 图片真实性有严格门禁 (≥500x300, ≥20KB, 排除占位图/stock photo/AI 生成)
- 产品最少 24 个/最多 40 个的发布门禁
- 12 个固定品类分类
- 来源调度 (daily/every_2_days/weekly/monthly) + 全局 budget 限制

**需用户确认**: 后端框架 (FastAPI vs Django vs Node)、数据库 (PG vs SQLite vs MySQL)、部署方式 (Docker vs 云原生 vs Serverless)、前端改造范围 (最小 vs 重写 vs 全新)。

