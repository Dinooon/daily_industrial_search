# 3.1.0

- Merged all phase-one primary functions into one hash-routed `design_intelligence_portal.html`.
- Kept independent product detail pages under `details/` and generated compatibility redirect pages for legacy URLs.
- Portable Feishu preview is now built from the integrated portal rather than a separate gallery page.
- Added portal-specific HTML quality validation and Feishu `details/` folder routing.
- Preserved Chinese descriptions and always-visible Feishu synchronization states across gallery, search, comparison, board, and detail views.

# 2.9.0

- Fixed duplicate Feishu folders with pagination-aware normalized lookup.
- Disabled blind retries for non-idempotent folder creation and added read-after-write reconciliation.
- Existing duplicate folders are reused deterministically and reported as diagnostics.
- Added Chinese lightbox descriptions using the same normalized description as cards.
- Canonical template fingerprint upgraded to canonical-v2.9.

# 2.8.0
- Removed the legacy inline gallery path from agent-assisted collection.
- Added canonical template fingerprint and publication quality gate.
- Added compressed portable-preview size limits and responsive-layout tests.
- Fixed report-date output routing in the agent pipeline.

# Changelog

## 2.2.0

- 将用户维护的网站清单转换为 241 条机器可读来源。
- 明确禁用邮件订阅和邮箱发现。
- 新增来源调度、持久化状态、入口哈希和全局抓取预算。
- RSS/Sitemap 优先于 HTML 页面发现。
- 新增候选评分，低分候选不抓详情页。
- 新增跨来源候选预去重与官方来源优先级。
- 新增证据驱动的产品说明和结构化 AI 输出。
- 新增相关自动测试和目录说明。

## 2.3.0 — Feishu Drive structured publishing

- Added idempotent creation of the canonical Feishu Drive folder tree.
- Publishing now requires `FEISHU_WORKSPACE_ROOT_FOLDER_TOKEN` and refuses flat-folder fallback.
- Public reports, archive files, internal data, logs, manifests, and selection manifests are routed to separate folders by role.
- The full workflow now publishes `collected_data.json`, `duplicates.json`, and `source_health.json` only into restricted internal folders.

## 2.4.0 - Multi-channel acquisition and verified images
- Added automatic native-network capability detection.
- Added `native_http`, `agent_assisted`, `offline`, and `auto` acquisition modes.
- Added strict agent acquisition manifest schema and validator.
- Added real-image validation and a rejected-image review queue.
- Formal reports now require a verified local bitmap and a traceable source page.
- Prohibited stock-photo substitutes, fabricated image URLs, text SVG placeholders, and AI-generated product images.
- Portable preview generation now fails closed when any image cannot be embedded.

## 2.5.0 — Complete offline gallery package

- Added `资源图库/今日资讯/YYYY-MM-DD/images/` as a mandatory public folder.
- Routed every verified final image to the public images subfolder instead of flattening files.
- Added `scripts/build_download_manifest.py` to validate every relative HTML asset and record SHA-256 checksums.
- `run_full_workflow.py --publish` now always publishes the standard HTML, portable HTML, verified images, and `download_manifest.json` together.
- Publishing fails when a standard HTML image reference is missing.

## 2.5.1 — Sandboxed agent-assisted pipeline and verified RSS feeds

- Documented 11 RSS feeds verified reachable in sandbox environment (designboom, Dezeen, Yanko Design, Engadget, TechCrunch, Samsung, Lenovo, Garmin, SlashGear).
- Added `agent_daily_pipeline.py` as a self-contained agent-assisted pipeline: RSS fetch via curl → product filtering → image download/verification → HTML/portable/manifest/summary generation.
- Added `upload_to_feishu.py` for user-token-based Feishu Drive upload with full v2.5 directory structure creation.
- Added `test_extended_feeds.py` for RSS feed reachability testing.
- Noted that `source_catalog.json` lacks RSS feed URL fields despite declaring RSS discovery; agents must use the documented feed list or test extended feeds.
- Agent-assisted mode section now includes two paths: direct curl-based RSS collection and the standard `agent_acquisition_manifest` flow.

## 3.2.0
- 飞书正式发布强制使用 design_intelligence_portal.html。
- 同步上传六个兼容分区入口文件和 details/。
- 门户导航改为锚点链接，飞书禁用 JavaScript 时仍可跳转并查看全部分区。
- 移除硬编码旧上传器，统一委托幂等发布器。

## 3.3.0
- Removed all public Feishu synchronization status chips and counters from gallery cards, portal homepage, and product detail pages.
- Replaced generic Chinese fallback copy with deterministic category/keyword-based Chinese descriptions when only English source text is available.
- Updated gallery and portal template fingerprints to canonical-v3.3 / phase1-v3.3.
- Added regression tests ensuring informative Chinese lightbox descriptions and absence of Feishu sync UI.
