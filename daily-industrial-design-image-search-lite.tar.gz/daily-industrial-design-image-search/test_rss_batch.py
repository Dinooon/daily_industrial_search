#!/usr/bin/env python3
"""
Batch test RSS feed URLs for 50 brands.
Tries common RSS URL patterns and checks if they return valid XML/feed content.
"""
import subprocess
import json
import re
import concurrent.futures
import sys

# Candidate RSS URLs for each brand (multiple candidates per brand)
RSS_CANDIDATES = {
    "apple_newsroom": [
        "https://www.apple.com/newsroom/rss.xml",
        "https://www.apple.com/newsroom/rss/",
        "https://www.apple.com/rss/",
        "https://www.apple.com/pr/rss.xml",
    ],
    "sony_design": [
        "https://www.sony.com/en/SonyInfo/News/rss.xml",
        "https://www.sony.net/SonyInfo/News/rss.xml",
        "https://presscentre.sony.eu/feed",
        "https://news.sony.com/rss",
        "https://www.sony.com/rss.xml",
    ],
    "google_blog_products": [
        "https://blog.google/rss/",
        "https://blog.google/atom/",
        "https://blog.google/feed/",
        "https://blog.google/rss.xml",
    ],
    "microsoft_surface_blog": [
        "https://blogs.windows.com/devices/feed/",
        "https://blogs.windows.com/devices/rss.xml",
        "https://blogs.windows.com/feed/",
        "https://devblogs.microsoft.com/devices/rss",
    ],
    "meta_newsroom": [
        "https://about.fb.com/news/feed/",
        "https://about.fb.com/feed/",
        "https://about.fb.com/news/rss/",
        "https://www.meta.com/newsroom/feed/",
    ],
    "nothing_newsroom": [
        "https://nothing.tech/pages/newsroom/feed",
        "https://nothing.tech/feed",
        "https://nothing.tech/blogs/news.atom",
        "https://nothing.tech/rss.xml",
    ],
    "teenage_engineering": [
        "https://teenage.engineering/rss.xml",
        "https://teenage.engineering/feed.xml",
        "https://teenage.engineering/feed/",
        "https://teenage.engineering/blog/feed/",
    ],
    "bang_olufsen": [
        "https://www.bang-olufsen.com/en/newsroom/feed",
        "https://www.bang-olufsen.com/feed",
        "https://www.bang-olufsen.com/rss.xml",
        "https://www.bang-olufsen.com/en/support/news-rss",
    ],
    "bose_press_room": [
        "https://www.bose.com/pressroom/rss.xml",
        "https://www.bose.com/feed",
        "https://www.bose.com/en-us/about-bose/press-room.rss",
        "https://www.bose.com/rss",
    ],
    "sonos_newsroom": [
        "https://newsroom.sonos.com/feed/",
        "https://newsroom.sonos.com/rss.xml",
        "https://newsroom.sonos.com/rss/",
        "https://www.sonos.com/en-us/feed",
    ],
    "logitech_newsroom": [
        "https://news.logitech.com/feed/",
        "https://news.logitech.com/rss.xml",
        "https://news.logitech.com/rss/",
        "https://blog.logitech.com/feed/",
    ],
    "gopro_news": [
        "https://gopro.com/en/us/news/feed",
        "https://gopro.com/blogs/news/feed",
        "https://gopro.com/en/us/news/rss.xml",
        "https://gopro.com/feed",
    ],
    "leica_camera": [
        "https://leica-camera.com/news.rss",
        "https://leica-camera.com/rss.xml",
        "https://leica-camera.com/en/news.rss",
        "https://leica-camera.com/en-leica/news.rss",
    ],
    "canon_global_news": [
        "https://global.canon/en/news/rss/news.xml",
        "https://global.canon/en/news/rss.xml",
        "https://global.canon/rss.xml",
        "https://global.canon/en/news/feed/",
    ],
    "nikon_news": [
        "https://www.nikon.com/company/news/rss.xml",
        "https://www.nikon.com/company/news/feed/",
        "https://www.nikon.com/rss.xml",
        "https://press.nikon.com/feed",
    ],
    "fujifilm_news": [
        "https://www.fujifilm.com/us/en/news/rss",
        "https://www.fujifilm.com/rss.xml",
        "https://www.fujifilm.com/us/en/news/feed",
        "https://fujifilm-x.com/feed/",
    ],
    "framework_blog": [
        "https://frame.work/blog/rss.xml",
        "https://frame.work/blog/feed/",
        "https://frame.work/feed",
        "https://frame.work/rss.xml",
    ],
    "consumer": [  # Huawei consumer
        "https://consumer.huawei.com/en/press/feed/",
        "https://consumer.huawei.com/en/press/rss.xml",
        "https://consumer.huawei.com/rss.xml",
        "https://consumer.huawei.com/en/press/rss/",
    ],
    "mi": [  # Xiaomi
        "https://www.mi.com/global/rss",
        "https://www.mi.com/global/event/feed",
        "https://www.mi.com/global/feed",
        "https://blog.mi.com/global/feed/",
    ],
    "honor": [
        "https://www.honor.com/global/news/feed/",
        "https://www.honor.com/global/news/rss.xml",
        "https://www.honor.com/rss.xml",
        "https://www.honor.com/feed",
    ],
    "oppo_newsroom": [
        "https://www.oppo.com/en/newsroom/feed",
        "https://www.oppo.com/en/newsroom/rss.xml",
        "https://www.oppo.com/rss.xml",
        "https://www.oppo.com/en/feed",
    ],
    "vivo_news": [
        "https://www.vivo.com/en/about-vivo/news/feed",
        "https://www.vivo.com/en/about-vivo/news/rss.xml",
        "https://www.vivo.com/rss.xml",
        "https://www.vivo.com/en/feed",
    ],
    "realme_newsroom": [
        "https://www.realme.com/global/newsroom/feed",
        "https://www.realme.com/global/newsroom/rss.xml",
        "https://www.realme.com/rss.xml",
        "https://www.realme.com/feed",
    ],
    "dji_media_center": [
        "https://www.dji.com/newsroom/rss.xml",
        "https://www.dji.com/newsroom/feed",
        "https://www.dji.com/rss.xml",
        "https://www.dji.com/newsroom.atom",
    ],
    "insta360_blog": [
        "https://www.insta360.com/blog/rss.xml",
        "https://www.insta360.com/blog/feed",
        "https://www.insta360.com/feed",
        "https://www.insta360.com/rss.xml",
    ],
    "anker_news": [
        "https://www.anker.com/blogs/news/feed",
        "https://www.anker.com/blogs/news.atom",
        "https://www.anker.com/blogs/news/rss.xml",
        "https://www.anker.com/feed",
    ],
    "dyson_newsroom": [
        "https://www.dyson.com/discover/news/feed",
        "https://www.dyson.com/discover/news/rss.xml",
        "https://www.dyson.com/feed",
        "https://www.dyson.com/newsroom/feed",
        "https://www.dyson.com/discover/rss.xml",
    ],
    "braun": [
        "https://www.braun.com/feed",
        "https://www.braun.com/rss.xml",
        "https://www.braun.com/global/en/feed",
        "https://www.braun.com/en/rss.xml",
    ],
    "philips_news_center": [
        "https://www.philips.com/a-w/about/news/home.rss",
        "https://www.philips.com/a-w/about/news/rss.xml",
        "https://www.philips.com/a-w/about/news/feed",
        "https://www.philips.com/rss.xml",
    ],
    "bosch_press_portal": [
        "https://www.bosch-presse.de/pressportal/de/en/rss.xml",
        "https://www.bosch-presse.de/pressportal/de/en/feed",
        "https://www.bosch-presse.de/pressportal/de/en/rss",
        "https://www.bosch.com/rss.xml",
    ],
    "lg_newsroom": [
        "https://www.lgnewsroom.com/feed/",
        "https://www.lgnewsroom.com/rss.xml",
        "https://www.lgnewsroom.com/rss/",
        "https://www.lgnewsroom.com/feed.xml",
    ],
    "panasonic_newsroom": [
        "https://news.panasonic.com/global/feed",
        "https://news.panasonic.com/global/rss.xml",
        "https://news.panasonic.com/global/rss",
        "https://news.panasonic.com/feed",
    ],
    "ikea_newsroom": [
        "https://www.ikea.com/global/en/newsroom/feed/",
        "https://www.ikea.com/global/en/newsroom/rss.xml",
        "https://www.ikea.com/rss.xml",
        "https://www.ikea.com/feed",
    ],
    "the_verge": [
        "https://www.theverge.com/rss/index.xml",
        "https://www.theverge.com/rss/full.xml",
        "https://www.theverge.com/rss/",
        "https://www.theverge.com/feeds/rss.xml",
    ],
    "wallpaper": [
        "https://www.wallpaper.com/rss.xml",
        "https://www.wallpaper.com/rss/",
        "https://www.wallpaper.com/feed",
        "https://www.wallpaper.com/feeds/all.xml",
    ],
    "design_milk": [
        "https://design-milk.com/feed/",
        "https://design-milk.com/rss.xml",
        "https://feeds.feedburner.com/designmilk",
        "https://design-milk.com/rss/",
    ],
    "fast_company_design": [
        "https://www.fastcompany.com/co-design/feed",
        "https://www.fastcompany.com/feed/",
        "https://www.fastcompany.com/rss.xml",
        "https://feeds.feedburner.com/fastcompany/headlines",
    ],
    "new_atlas": [
        "https://newatlas.com/rss.xml",
        "https://newatlas.com/feed/",
        "https://newatlas.com/rss/",
        "https://feeds.feedburner.com/newatlas",
    ],
    "herman_miller": [
        "https://www.hermanmiller.com/feed",
        "https://www.hermanmiller.com/rss.xml",
        "https://www.hermanmiller.com/en_us/feed",
        "https://www.hermanmiller.com/stories/feed/",
    ],
    "vitra": [
        "https://www.vitra.com/feed",
        "https://www.vitra.com/rss.xml",
        "https://www.vitra.com/en/feed",
        "https://www.vitra.com/stories/rss",
    ],
    "steelcase": [
        "https://www.steelcase.com/feed/",
        "https://www.steelcase.com/rss.xml",
        "https://www.steelcase.com/rss/",
        "https://www.steelcase.com/feed.xml",
    ],
    "bmw_group_pressclub": [
        "https://www.press.bmwgroup.com/feed",
        "https://www.press.bmwgroup.com/global/rss",
        "https://www.press.bmwgroup.com/global/feed",
        "https://www.press.bmwgroup.com/rss.xml",
    ],
    "mercedes_benz_media": [
        "https://media.mercedes-benz.com/feed",
        "https://media.mercedes-benz.com/rss.xml",
        "https://media.mercedes-benz.com/rss",
        "https://media.mercedes-benz.com/service/feed/en",
    ],
    "audi_mediacenter": [
        "https://www.audi-mediacenter.com/en/rss",
        "https://www.audi-mediacenter.com/en/feed",
        "https://www.audi-mediacenter.com/feed",
        "https://www.audi-mediacenter.com/rss.xml",
    ],
    "porsche_newsroom": [
        "https://newsroom.porsche.com/feed",
        "https://newsroom.porsche.com/rss.xml",
        "https://newsroom.porsche.com/en/feed",
        "https://newsroom.porsche.com/rss",
    ],
    "volvo_cars_media": [
        "https://www.media.volvocars.com/feed",
        "https://www.media.volvocars.com/rss.xml",
        "https://www.media.volvocars.com/rss",
        "https://www.media.volvocars.com/global/feed",
    ],
    "tesla": [
        "https://www.tesla.com/blog/feed",
        "https://www.tesla.com/blog/rss.xml",
        "https://www.tesla.com/rss.xml",
        "https://www.tesla.com/feed",
    ],
    "toyota_global_newsroom": [
        "https://global.toyota/en/newsroom/feed",
        "https://global.toyota/en/newsroom/rss.xml",
        "https://global.toyota/rss.xml",
        "https://global.toyota/en/newsroom/rss",
    ],
    "honda_global_newsroom": [
        "https://global.honda/en/newsroom/feed",
        "https://global.honda/en/newsroom/rss.xml",
        "https://global.honda/rss.xml",
        "https://global.honda/en/newsroom/rss",
    ],
}

def test_url(url):
    """Test a URL and check if it returns valid RSS/Atom feed content."""
    try:
        result = subprocess.run(
            ["curl", "-sL", "-o", "-", "-w", "\\n__HTTP_CODE__%{http_code}",
             "--max-time", "10", "--connect-timeout", "8",
             "-H", "User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36",
             url],
            capture_output=True, text=True, timeout=15
        )
        output = result.stdout
        # Extract HTTP code
        http_code = "000"
        if "__HTTP_CODE__" in output:
            parts = output.rsplit("__HTTP_CODE__", 1)
            body = parts[0]
            http_code = parts[1].strip()
        else:
            body = output

        if http_code == "200":
            # Check if body looks like RSS/Atom
            body_lower = body.lower().strip()
            is_rss = any(marker in body_lower for marker in [
                "<rss", "<feed", "<channel", "<entry", "<?xml",
                "application/rss+xml", "application/atom+xml",
            ])
            if is_rss and len(body) > 100:
                return (url, True, http_code, len(body), body[:200])
        return (url, False, http_code, 0, "")
    except Exception as e:
        return (url, False, "ERR", 0, str(e)[:100])

def main():
    results = {}
    
    # Build list of all URLs to test
    all_urls = []
    url_to_brand = {}
    for brand, urls in RSS_CANDIDATES.items():
        for url in urls:
            all_urls.append(url)
            url_to_brand[url] = brand

    print(f"Testing {len(all_urls)} candidate URLs across {len(RSS_CANDIDATES)} brands...")
    
    # Test URLs in parallel
    with concurrent.futures.ThreadPoolExecutor(max_workers=20) as executor:
        future_to_url = {executor.submit(test_url, url): url for url in all_urls}
        
        for future in concurrent.futures.as_completed(future_to_url):
            url = future_to_url[future]
            try:
                result_url, is_valid, http_code, size, preview = future.result()
                brand = url_to_brand[result_url]
                status = "VALID" if is_valid else f"INVALID({http_code})"
                print(f"[{status}] {brand}: {result_url} (size={size})")
                if is_valid:
                    if brand not in results:
                        results[brand] = result_url
            except Exception as e:
                print(f"[ERROR] {url}: {e}")
    
    return results

if __name__ == "__main__":
    results = main()
    
    print("\n" + "="*80)
    print("RESULTS SUMMARY")
    print("="*80)
    
    # Output found feeds
    found = {}
    not_found = []
    for brand in RSS_CANDIDATES.keys():
        if brand in results:
            found[brand] = results[brand]
        else:
            not_found.append(brand)
    
    print(f"\nFound RSS feeds for {len(found)} brands:")
    for brand, url in sorted(found.items()):
        print(f"  {brand}: {url}")
    
    print(f"\nNo RSS found for {len(not_found)} brands:")
    for brand in sorted(not_found):
        print(f"  {brand}")
    
    # Save results to JSON
    output = {
        "found": found,
        "not_found": not_found,
    }
    with open("/home/ubuntu/workdir/daily-industrial-design-image-search/rss_test_results.json", "w") as f:
        json.dump(output, f, indent=2)
    
    print(f"\nResults saved to rss_test_results.json")
