# Daily Industrial Design Intelligence Gallery 3.1

完整的工业设计新品情报与图片画廊流程。新版采用“轻发现、重验证”架构，并明确不使用邮件订阅。

## 核心变化

- 将《工业设计新品资讯网站清单》转换成 200+ 条机器可读来源。
- RSS、Sitemap 优先，HTML 入口页作为后备。
- 保存 ETag、Last-Modified、入口内容哈希和来源检查状态。
- 每日默认最多检查 40 个来源、抓取 60 个详情页。
- 候选先评分，再抓取详情；低分候选不访问详情页。
- 品牌官网作为产品名、发布日期、发布状态的高可信证据。
- 产品说明改为证据驱动：先提取事实和设计观察，再生成摘要。
- 不读取邮件、不订阅 Newsletter、不依赖邮箱 Agent。

## 运行

```bash
python -m pip install -r requirements.txt
python scripts/run_full_workflow.py --date YYYY-MM-DD
```

缩小范围验证：

```bash
python scripts/run_daily_pipeline.py --date YYYY-MM-DD --max-sources 5 --limit-per-source 2
```

## 配置

- `config/source_catalog.json`：完整来源目录
- `config/sources.json`：当前运行目录，默认与完整目录一致
- `data/state/source_state.json`：来源增量状态

环境变量：

```env
DID_DAILY_SOURCE_BUDGET=40
DID_DAILY_DETAIL_BUDGET=60
DID_HTTP_TIMEOUT=25
DID_USER_AGENT=DailyIndustrialDesignIntelligence/2.1
```

## 产品说明

有 AI 接口时，正文被转换成结构化字段：已验证事实、设计观察、证据和中文说明。无 AI 时，系统从正文中选择包含设计、材料、功能、发布等证据关键词的句子，不再直接截取正文前 420 字。

## 飞书云盘标准目录（v2.3）

发布前程序会在 `FEISHU_WORKSPACE_ROOT_FOLDER_TOKEN` 指定的父目录中幂等创建：

```text
资源图库/
├── 今日资讯/YYYY-MM-DD/
├── 历史归档/
├── 月度画廊/
└── 半年度报告/
工业设计情报数据库/
工业设计情报系统_内部/
├── raw-data/YYYY-MM-DD/
├── processed-data/YYYY-MM-DD/
├── selection-manifests/
├── logs/YYYY-MM-DD/
└── manifests/YYYY-MM-DD/
```

必须配置：

```env
FEISHU_WORKSPACE_ROOT_FOLDER_TOKEN=
```

旧的多个目标文件夹 token 不再作为平铺上传的后备方案。应用需要“创建云空间文件夹”和文件上传权限。目录已存在时会复用，不会重复创建。

## v2.4 multi-channel acquisition

The formal daily report must contain traceable real product images. The workflow no longer creates SVG title cards or substitutes unrelated stock images when networking fails.

### Native HTTP mode

```bash
python scripts/run_full_workflow.py --date 2026-07-30 --acquisition-mode native_http
```

### Agent-assisted mode

When Python DNS/HTTP is unavailable, the calling Agent must use its web/page/image tools to verify products, save actual product images locally, and create a manifest conforming to `schemas/tool_acquisition_manifest.schema.json`.

```bash
python scripts/run_full_workflow.py \
  --date 2026-07-30 \
  --acquisition-mode agent_assisted \
  --agent-manifest incoming/tool_acquisition_manifest.json
```

Each product requires a real source page, a traceable image URL, a local bitmap path, and evidence. Random stock photography, malformed URLs, screenshots containing only text, SVG placeholders, and AI-generated product images are forbidden.

### Offline mode

```bash
python scripts/run_full_workflow.py \
  --date 2026-07-30 \
  --acquisition-mode offline \
  --offline-products data/history/products_with_local_images.json
```


## v2.5 complete downloadable gallery package

The public daily folder is a complete resource package:

```text
资源图库/今日资讯/YYYY-MM-DD/
├── daily_gallery.html
├── YYYY-MM-DD_工业设计图片日报_预览版.html
├── download_manifest.json
└── images/
    └── verified product images
```

The portable HTML is for direct Feishu preview. The standard HTML is for local or static-site use and must remain beside `images/`. `build_download_manifest.py` blocks publication when any relative image reference is missing.


## 3.1 单入口设计情报工作台

第一阶段的画廊、检索、对比、项目板、专题和趋势已合并到：

```text
output/YYYY-MM-DD/design_intelligence_portal.html
```

导航栏通过 hash 在同一页面切换功能分区。产品详情仍位于 `details/`，图片位于 `images/`。旧的 `daily_gallery.html` 等入口会自动跳转到主门户对应分区。
