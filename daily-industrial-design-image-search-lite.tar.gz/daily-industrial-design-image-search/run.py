"""Single-URL gateway: backend API + static frontend (same process)."""
import sys
from pathlib import Path

from fastapi import HTTPException
from fastapi.responses import FileResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response
from uvicorn.middleware.proxy_headers import ProxyHeadersMiddleware

# run.py 需在两种布局下均可 import（契约测试见 tests/test_deploy_bundle_contract.py）：
# - 发布前 bundle 校验：.coolify-bundle/run.py + .coolify-bundle/backend/
# - Docker 镜像：COPY backend/. → /app/ 后 run.py 与 app/ 或 main.py 同级
_ROOT = Path(__file__).resolve().parent
_BACKEND = _ROOT / "backend"
if (_BACKEND / "app").is_dir() or (_BACKEND / "main.py").is_file() or (_BACKEND / "requirements.txt").is_file():
    if str(_BACKEND) not in sys.path:
        sys.path.insert(0, str(_BACKEND))
elif str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from main import app

# Coolify / reverse-proxy: honor X-Forwarded-* for redirects and absolute URLs
app.add_middleware(ProxyHeadersMiddleware, trusted_hosts="*")

# Coolify / orchestrator health probes (no-op if app already defines it)
if not any(getattr(r, "path", None) == "/api/health" for r in app.routes):
    @app.get("/api/health")
    async def _gateway_health():
        return {"status": "ok"}

if not any(getattr(r, "path", None) == "/health" for r in app.routes):
    @app.get("/health")
    async def _gateway_health_root():
        return {"status": "ok"}

_STATIC = Path("/var/www/static")
_INDEX = _STATIC / "index.html"


class _StaticCacheMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next) -> Response:
        response = await call_next(request)
        path = request.url.path
        if path in ("/", "/index.html"):
            response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
            response.headers["Pragma"] = "no-cache"
        elif path.startswith("/assets/"):
            response.headers["Cache-Control"] = "public, max-age=31536000, immutable"
        return response


if _INDEX.is_file():
    app.add_middleware(_StaticCacheMiddleware)

    @app.api_route("/{full_path:path}", methods=["GET", "HEAD"])
    async def _serve_spa(full_path: str = ""):
        # Never serve SPA for /api/* — preview nginx proxies API separately; production must too.
        if full_path == "api" or full_path.startswith("api/"):
            raise HTTPException(status_code=404, detail="Not Found")
        # Let main.py's serve_portal handle / and /index.html so the dynamic
        # HTML from output/ (with XHR to /api/portal-data) is served, not the
        # potentially stale static copy in /var/www/static/.
        if full_path in ("", "index.html"):
            raise HTTPException(status_code=404, detail="Not Found")
        target = _STATIC / full_path if full_path else _INDEX
        if full_path and target.is_file():
            return FileResponse(target)
        return FileResponse(_INDEX)
