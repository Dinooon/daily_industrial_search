#!/bin/bash
# 发布前预验证：检查所有Dockerfile COPY源文件是否存在且为实体文件
BUNDLE=/home/ubuntu/workdir/daily-industrial-design-image-search/.manus/bundle

echo "=== Pre-check: bundle structure ==="

# 检查符号链接
LINKS=$(find $BUNDLE -type l 2>/dev/null | wc -l)
[ "$LINKS" -gt 0 ] && { echo "FAIL: $LINKS symlinks found"; exit 1; } || echo "OK: No symlinks"

# 检查关键文件
KEYS="backend/main.py backend/app/routes.py backend/app/database.py backend/app/scheduler.py backend/app/__init__.py backend/scripts/agent_daily_pipeline.py backend/config/sources.json backend/db/gallery.db backend/start.sh run.py frontend/dist/index.html"
for f in $KEYS; do
    [ -f "$BUNDLE/$f" ] && echo "OK: $f" || { echo "FAIL: $f missing"; exit 1; }
done

# 检查Dockerfile
[ -f "$BUNDLE/Dockerfile" ] && echo "OK: Dockerfile" || { echo "FAIL: Dockerfile missing"; exit 1; }
grep -q "start.sh" "$BUNDLE/Dockerfile" && echo "OK: start.sh in Dockerfile" || echo "WARN: start.sh not in Dockerfile"

# 检查图片
JPG=$(find $BUNDLE/backend/output/ -name "*.jpg" 2>/dev/null | wc -l)
echo "JPG files: $JPG"
[ "$JPG" -lt 100 ] && echo "WARN: Less than 100 jpg" || echo "OK: JPG count"

# 检查routes.py有中文关键词修复
grep -q "扫地机器人" "$BUNDLE/backend/app/routes.py" 2>/dev/null && echo "OK: routes.py has Chinese keywords" || echo "WARN: routes.py may be old version"
grep -q "latest_date or _today" "$BUNDLE/backend/app/routes.py" 2>/dev/null && echo "OK: report_date fix" || echo "WARN: report_date fix missing"

# 检查agent_daily_pipeline.py有中文关键词
grep -q "扫地机器人" "$BUNDLE/backend/scripts/agent_daily_pipeline.py" 2>/dev/null && echo "OK: pipeline has Chinese keywords" || echo "WARN: pipeline may be old version"

echo ""
echo "=== Pre-check passed! Ready to publish. ==="

