#!/usr/bin/env python3
"""
Round 6: Re-verify ALL previously found RSS feeds with stricter validation.
Also test some additional patterns.
"""
import subprocess
import json
import concurrent.futures

# Load all found feeds from previous rounds
with open("/home/ubuntu/workdir/daily-industrial-design-image-search/rss_test_results.json", "r") as f:
    prev = json.load(f)

# All found feeds to re-verify
VERIFY_FEEDS = dict(prev["found"])

# Also add some new candidates for brands still not found
NEW_CANDIDATES = {
    "fujifilm_news": [
        "https://www.fujifilm.com/news/rss",  # returned HTML before, but maybe has RSS link
        "https://www.fujifilm.com/news/atom", 
        "https://www.fujifilm.com/news/index.atom",
        # These all returned 200 with 260K but were HTML
    ],
    "canon_global_news": [
        "https://global.canon/en/news/index.rdf",
        "https://global.canon/en/news/release.rdf",
        # Try Canon Europe
        "https://www.canon-europe.com/press-centre/rss",
        "https://www.canon-europe.com/press-centre/feed",
    ],
    "consumer": [  # Huawei
        "https://consumer.huawei.com/en/press/news/index.htm.rss",
        # Try huawei corporate news
        "https://www.huawei.com/en/news/feed",
        "https://www.huawei.com/en/press/feed",
    ],
    "honor": [
        "https://www.honor.com/global/news.rss.xml",
        "https://www.honor.com/global/news.atom.xml",
    ],
    "anker_news": [
        # Anker uses Shopify, try standard Shopify blog feed
        "https://www.anker.com/blogs/news.atom",
        "https://www.anker.com/blogs/news.rss",
    ],
    "sony_design": [
        # Re-test with different user agent
        "https://presscentre.sony.eu/press-releases/feed",
        "https://www.sony.com/rss",
        # Try Sony Electronics news
        "https://electronics.sony.com/press",
        "https://press.sony.com/en/press-releases",
    ],
}

def verify_feed(url):
    """Strictly verify that a URL returns valid RSS/Atom XML feed."""
    try:
        result = subprocess.run(
            ["curl", "-sL", "--compressed", "-o", "-", "-w", "\\n__HTTP_CODE__%{http_code}",
             "--max-time", "15", "--connect-timeout", "12",
             "-H", "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
             "-H", "Accept: application/rss+xml, application/atom+xml, application/xml, text/xml, */*",
             url],
            capture_output=True, text=True, timeout=25
        )
        output = result.stdout
        http_code = "000"
        if "__HTTP_CODE__" in output:
            parts = output.rsplit("__HTTP_CODE__", 1)
            body = parts[0]
            http_code = parts[1].strip()
        else:
            body = output

        if http_code != "200":
            return (url, False, http_code, 0, "", "")

        body_stripped = body.strip()
        
        # Strict RSS/Atom check: must start with <?xml or <rss or <feed
        # (allowing for BOM or whitespace)
        starts_with_xml = (
            body_stripped.startswith('<?xml') or
            body_stripped.startswith('<rss') or
            body_stripped.startswith('<feed') or
            body_stripped.startswith('<rdf:RDF')
        )
        
        # Also check for key RSS/Atom elements anywhere in the first 2000 chars
        first_2000 = body_stripped[:2000].lower()
        has_rss_elements = (
            ('<channel>' in first_2000 or '<channel ' in first_2000) or
            ('<entry>' in first_2000 or '<entry ' in first_2000) or
            ('<item>' in first_2000 or '<item ' in first_2000) or
            ('<feed' in first_2000 and 'xmlns' in first_2000)
        )
        
        # Check content-type if available from headers
        is_valid = starts_with_xml and has_rss_elements and len(body) > 200
        
        # Also check for false positive: if body starts with <!DOCTYPE html, it's HTML
        if body_stripped.lower().startswith('<!doctype html') or body_stripped.lower().startswith('<html'):
            is_valid = False
        
        content_type = ""
        # Try to get content type
        ct_result = subprocess.run(
            ["curl", "-sI", "--compressed", "--max-time", "10",
             "-H", "User-Agent: Mozilla/5.0",
             url],
            capture_output=True, text=True, timeout=15
        )
        for line in ct_result.stdout.split('\n'):
            if 'content-type' in line.lower():
                content_type = line.strip()
                break
        
        return (url, is_valid, http_code, len(body), body_stripped[:300], content_type)
    except Exception as e:
        return (url, False, "ERR", 0, "", str(e)[:100])

def main():
    # Merge all URLs to verify/test
    all_urls = {}
    for brand, url in VERIFY_FEEDS.items():
        all_urls[url] = brand
    for brand, urls in NEW_CANDIDATES.items():
        for url in urls:
            all_urls[url] = brand

    print(f"Verifying {len(all_urls)} URLs...")
    
    results = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
        future_to_url = {executor.submit(verify_feed, url): url for url in all_urls}
        
        for future in concurrent.futures.as_completed(future_to_url):
            url = future_to_url[future]
            try:
                result_url, is_valid, http_code, size, preview, content_type = future.result()
                brand = all_urls[result_url]
                status = "VALID RSS" if is_valid else f"INVALID({http_code})"
                print(f"[{status}] {brand}: {result_url} (size={size})")
                if not is_valid:
                    print(f"  Preview: {preview[:100]}")
                    if content_type:
                        print(f"  Content-Type: {content_type}")
                if is_valid and brand not in results:
                    results[brand] = result_url
            except Exception as e:
                print(f"[ERROR] {url}: {e}")
    
    return results

if __name__ == "__main__":
    results = main()
    
    print("\n" + "="*80)
    print("ROUND 6 - VERIFIED RESULTS")
    print("="*80)
    
    print(f"\nVerified RSS feeds for {len(results)} brands:")
    for brand, url in sorted(results.items()):
        print(f"  {brand}: {url}")
    
    # Load previous not_found
    with open("/home/ubuntu/workdir/daily-industrial-design-image-search/rss_test_results.json", "r") as f:
        prev = json.load(f)
    
    still_not_found = [b for b in prev["not_found"] if b not in results]
    # Also add brands from found that turned out to be false positives
    false_positives = [b for b in prev["found"] if b not in results]
    
    output = {
        "found": results,
        "not_found": still_not_found + false_positives,
        "false_positives_removed": false_positives,
    }
    with open("/home/ubuntu/workdir/daily-industrial-design-image-search/rss_verified.json", "w") as f:
        json.dump(output, f, indent=2)
    
    print(f"\nFalse positives removed: {false_positives}")
    print(f"Total verified: {len(results)}, still not found: {len(still_not_found) + len(false_positives)}")
    print(f"\nResults saved to rss_verified.json")
