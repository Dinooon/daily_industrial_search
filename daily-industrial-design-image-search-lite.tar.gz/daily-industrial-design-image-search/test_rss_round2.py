#!/usr/bin/env python3
"""
Round 2: Test more RSS URL patterns and fetch HTML pages to find RSS <link> tags.
"""
import subprocess
import json
import re
import concurrent.futures

# More candidate URLs for brands that weren't found in round 1
RSS_CANDIDATES_R2 = {
    "sony_design": [
        "https://www.sony.com/en/SonyInfo/News/PressCenter/rss/",
        "https://www.sony.com/en/rss/",
        "https://news.sony.com/pressroom/rss",
        "https://press.sony.com/en/press-releases/rss",
        "https://www.sony.net/SonyInfo/News/PressReleases/rss/",
        "https://presscentre.sony.eu/feed.xml",
        "https://presscentre.sony.eu/rss",
        "https://www.sony.com/en/SonyInfo/News/PressReleases/rss.xml",
        "https://www.sony.net/SonyInfo/News/PressReleases/rss.xml",
    ],
    "nothing_newsroom": [
        "https://nothing.tech/blogs/news.rss",
        "https://nothing.tech/pages/newsroom.rss",
        "https://nothing.tech/collections/newsroom.atom",
        "https://nothing.tech/blogs/news.rss.xml",
        "https://nothing.tech/blogs/news",
    ],
    "teenage_engineering": [
        "https://teenage.engineering/all.atom",
        "https://teenage.engineering/all.rss",
        "https://teenage.engineering/feeds/all",
        "https://teenage.engineering/products.rss",
        "https://teenage.engineering/all.xml",
    ],
    "bang_olufsen": [
        "https://www.bang-olufsen.com/en/the-latest/feed",
        "https://www.bang-olufsen.com/en/the-latest.rss",
        "https://www.bang-olufsen.com/en/the-latest/rss",
        "https://www.bang-olufsen.com/en/blog/feed",
        "https://www.bang-olufsen.com/da/nyheder/feed",
    ],
    "bose_press_room": [
        "https://www.bose.com/en-US/about-bose/press-room/rss.xml",
        "https://www.bose.com/en-US/about-bose/press-room/feed",
        "https://www.bose.com/en/about-bose/press-room/rss",
        "https://www.bose.com/en-US/about-bose/press-room.atom",
    ],
    "sonos_newsroom": [
        "https://newsroom.sonos.com/news.xml",
        "https://newsroom.sonos.com/news/feed",
        "https://www.sonos.com/en-us/blog/feed",
        "https://www.sonos.com/en/blog/rss",
        "https://www.sonos.com/en-us/blog/rss.xml",
    ],
    "gopro_news": [
        "https://gopro.com/blogs/news.atom",
        "https://gopro.com/blogs/news.rss",
        "https://gopro.com/blogs/the-current.rss",
        "https://gopro.com/blogs/news.xml",
        "https://gopro.com/en/us/news.rss",
    ],
    "canon_global_news": [
        "https://global.canon/en/news/release.rdf",
        "https://global.canon/en/news/press.rdf",
        "https://global.canon/en/news/index.rdf",
        "https://cps.canon-europe.com/rss",
        "https://global.canon/en/news/rss/index.xml",
        "https://global.canon/en/news/news.rdf",
    ],
    "nikon_news": [
        "https://www.nikon.com/company/news/index.rdf",
        "https://www.nikon.com/company/news/press.rdf",
        "https://press.nikon.com/rss",
        "https://www.nikon.com/rss",
        "https://www.nikon.com/company/news/index.xml",
        "https://www.nikonimaging.com/news/rss.xml",
    ],
    "fujifilm_news": [
        "https://www.fujifilm.com/news/feed.xml",
        "https://www.fujifilm.com/news/rss.xml",
        "https://www.fujifilm.com/news/rss",
        "https://fujifilm-x.com/en-us/feed/",
        "https://fujifilm-x.com/en-us/rss.xml",
    ],
    "framework_blog": [
        "https://frame.work/blog/index.xml",
        "https://frame.work/blog.atom",
        "https://frame.work/blog/rss",
        "https://frame.work/blog/index.rss",
        "https://frame.work/atom.xml",
    ],
    "consumer": [  # Huawei
        "https://consumer.huawei.com/en/press/news/index.htm/rss",
        "https://consumer.huawei.com/en/press/index.htm/rss",
        "https://consumer.huawei.com/en/press/index.xml",
        "https://consumer.huawei.com/en/press/press-rss.xml",
        "https://consumer.huawei.com/rss",
        "https://www.huawei.com/en/rss.xml",
    ],
    "mi": [  # Xiaomi
        "https://blog.mi.com/global/feed.xml",
        "https://blog.mi.com/feed",
        "https://blog.mi.com/global/rss.xml",
        "https://www.mi.com/global/blog/feed",
        "https://www.mi.com/blog/feed",
        "https://blog.mi.com/rss.xml",
    ],
    "honor": [
        "https://www.honor.com/global/news/index.xml",
        "https://www.honor.com/global/news/rss",
        "https://www.honor.com/en/news/rss.xml",
        "https://www.honor.com/en/news/feed",
        "https://www.honor.com/global/press-release/feed",
    ],
    "oppo_newsroom": [
        "https://www.oppo.com/en/newsroom/index.xml",
        "https://www.oppo.com/en/newsroom/rss",
        "https://www.oppo.com/en/newsroom/news.rss",
        "https://www.oppo.com/en/news.atom",
        "https://www.oppo.com/en/newsroom.xml",
    ],
    "vivo_news": [
        "https://www.vivo.com/en/about-vivo/news/index.xml",
        "https://www.vivo.com/en/about-vivo/news/rss",
        "https://www.vivo.com/en/about-vivo/news.atom",
        "https://www.vivo.com/en/about-vivo/news/index.rss",
        "https://www.vivo.com/en/about-vivo/news.rss",
    ],
    "realme_newsroom": [
        "https://www.realme.com/global/newsroom/index.xml",
        "https://www.realme.com/global/newsroom/rss",
        "https://www.realme.com/global/newsroom.atom",
        "https://www.realme.com/m/newsroom/feed",
        "https://www.realme.com/global/newsroom/news.rss",
    ],
    "dji_media_center": [
        "https://www.dji.com/newsroom/index.xml",
        "https://www.dji.com/newsroom.atom",
        "https://www.dji.com/rss",
        "https://www.dji.com/newsroom/index.rss",
        "https://www.dji.com/news/rss",
    ],
    "insta360_blog": [
        "https://www.insta360.com/blog/index.xml",
        "https://www.insta360.com/blog.atom",
        "https://www.insta360.com/blog/rss",
        "https://blog.insta360.com/feed",
        "https://blog.insta360.com/rss.xml",
    ],
    "anker_news": [
        "https://www.anker.com/blogs/news.rss",
        "https://www.anker.com/blogs/news.xml",
        "https://www.anker.com/blogs/news/index.xml",
        "https://blog.anker.com/feed",
        "https://blog.anker.com/rss.xml",
        "https://www.anker.com/blogs/news.rss.xml",
    ],
    "dyson_newsroom": [
        "https://www.dyson.com/discover/news/index.xml",
        "https://www.dyson.com/discover/news.atom",
        "https://www.dyson.com/discover/news/rss",
        "https://www.dyson.com/discover/news/index.rss",
        "https://www.dyson.com/newsroom.xml",
        "https://www.dyson.com/discover/feed",
        "https://www.dyson.co.uk/discover/news/feed",
        "https://www.dyson.com/discover/dyson-newsroom/feed",
    ],
    "braun": [
        "https://www.braun.com/global/en/rss.xml",
        "https://www.braun.com/global/en/news.rss",
        "https://www.braun.com/global/en/news/rss",
        "https://www.braun.com/en/news.rss",
        "https://www.braun.com/global/en/braun-prize.rss",
    ],
    "philips_news_center": [
        "https://www.philips.com/a-w/about/news/index.rss",
        "https://www.philips.com/a-w/about/news/index.xml",
        "https://www.philips.com/a-w/about/news.rss",
        "https://www.philips.com/a-w/about/news/press.xml",
        "https://www.philips.com/a-w/about/news/news.rss",
    ],
    "bosch_press_portal": [
        "https://www.bosch-presse.de/pressportal/de/en/index.rss",
        "https://www.bosch-presse.de/pressportal/de/en/press.xml",
        "https://www.bosch-presse.de/pressportal/de/en/news.rss",
        "https://www.bosch.com/en/news/rss.xml",
        "https://www.bosch.com/news/rss.xml",
        "https://www.bosch-presse.de/pressportal/de/en/presseinfos.rss",
    ],
    "lg_newsroom": [
        "https://www.lgnewsroom.com/news.xml",
        "https://www.lgnewsroom.com/feed.rss",
        "https://www.lgnewsroom.com/index.xml",
        "https://www.lgnewsroom.com/rss",
        "https://www.lgnewsroom.com/news/feed",
    ],
    "panasonic_newsroom": [
        "https://news.panasonic.com/global/rss/index.xml",
        "https://news.panasonic.com/global/index.xml",
        "https://news.panasonic.com/global/news.rss",
        "https://news.panasonic.com/rss",
        "https://news.panasonic.com/global/press.rss",
    ],
    "ikea_newsroom": [
        "https://www.ikea.com/global/en/newsroom/index.xml",
        "https://www.ikea.com/global/en/newsroom/news.rss",
        "https://www.ikea.com/global/en/newsroom.rss",
        "https://www.ikea.com/gb/en/newsroom/feed",
        "https://www.ikea.com/ms/en_GB/rss/press.xml",
    ],
    "design_milk": [
        "https://design-milk.com/index.xml",
        "https://design-milk.com/index.rss",
        "https://design-milk.com/atom.xml",
        "https://feeds.feedburner.com/design-milk",
        "https://feeds.feedburner.com/designmilkblog",
    ],
    "fast_company_design": [
        "https://www.fastcompany.com/section/co-design/feed",
        "https://www.fastcompany.com/section/co-design/rss",
        "https://www.fastcompany.com/section/co-design/index.xml",
        "https://www.fastcompany.com/index.xml",
        "https://feeds.feedburner.com/fastcompany/co-design",
        "https://www.fastcompany.com/section/design/feed",
    ],
    "new_atlas": [
        "https://newatlas.com/index.xml",
        "https://newatlas.com/index.rss",
        "https://newatlas.com/atom.xml",
        "https://feeds.feedburner.com/weblogsinc/newatlas",
        "https://newatlas.com/technology/feed",
        "https://newatlas.com/science/feed",
    ],
    "herman_miller": [
        "https://www.hermanmiller.com/stories/index.xml",
        "https://www.hermanmiller.com/stories.rss",
        "https://www.hermanmiller.com/en_us/stories/feed",
        "https://www.hermanmiller.com/content/hermanmiller/feeds/stories.rss",
        "https://www.hermanmiller.com/content/hermanmiller/feeds/stories.xml",
    ],
    "vitra": [
        "https://www.vitra.com/en/rss.xml",
        "https://www.vitra.com/en/content/stories.rss",
        "https://www.vitra.com/stories/feed",
        "https://www.vitra.com/content/stories/rss.xml",
        "https://www.vitra.com/en/stories.rss",
    ],
    "mercedes_benz_media": [
        "https://media.mercedes-benz.com/page/rss/index.html",
        "https://media.mercedes-benz.com/page/rss/en.xml",
        "https://media.mercedes-benz.com/service/rss/en",
        "https://media.mercedes-benz.com/feed/en",
        "https://media.mercedes-benz.com/feeds/press-releases.xml",
    ],
    "audi_mediacenter": [
        "https://www.audi-mediacenter.com/en/press-releases/rss.xml",
        "https://www.audi-mediacenter.com/de/rss.xml",
        "https://www.audi-mediacenter.com/en/press-releases.rss",
        "https://www.audi-mediacenter.com/rss",
        "https://www.audi.com/rss.xml",
    ],
    "porsche_newsroom": [
        "https://newsroom.porsche.com/en/rss.xml",
        "https://newsroom.porsche.com/english/rss.xml",
        "https://newsroom.porsche.com/en/press-releases.rss",
        "https://newsroom.porsche.com/press-releases.rss",
        "https://newsroom.porsche.com/index.xml",
    ],
    "volvo_cars_media": [
        "https://www.media.volvocars.com/global/en-gb/rss.xml",
        "https://www.media.volvocars.com/rss.xml",
        "https://www.media.volvocars.com/global/en-gb/feed",
        "https://www.media.volvocars.com/feeds/press-releases.xml",
        "https://www.media.volvocars.com/global/press-releases.rss",
    ],
    "tesla": [
        "https://www.tesla.com/blog.atom",
        "https://www.tesla.com/blog.xml",
        "https://www.tesla.com/blog/index.xml",
        "https://www.tesla.com/blog/rss",
        "https://www.tesla.com/blog/feed.xml",
    ],
    "toyota_global_newsroom": [
        "https://global.toyota/en/newsroom/index.xml",
        "https://global.toyota/en/newsroom/rss/index.xml",
        "https://global.toyota/en/newsroom/news.rss",
        "https://global.toyota/en/newsroom/press.rss",
        "https://global.toyota/en/rss.xml",
    ],
    "honda_global_newsroom": [
        "https://global.honda/en/newsroom/index.xml",
        "https://global.honda/en/newsroom/rss/index.xml",
        "https://global.honda/en/newsroom/news.rss",
        "https://global.honda/en/newsroom/press.rss",
        "https://global.honda/en/rss.xml",
    ],
}

def test_url(url):
    """Test a URL and check if it returns valid RSS/Atom feed content."""
    try:
        result = subprocess.run(
            ["curl", "-sL", "-o", "-", "-w", "\\n__HTTP_CODE__%{http_code}",
             "--max-time", "12", "--connect-timeout", "10",
             "-H", "User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36",
             url],
            capture_output=True, text=True, timeout=20
        )
        output = result.stdout
        http_code = "000"
        if "__HTTP_CODE__" in output:
            parts = output.rsplit("__HTTP_CODE__", 1)
            body = parts[0]
            http_code = parts[1].strip()
        else:
            body = output

        if http_code == "200":
            body_lower = body.lower().strip()
            is_rss = any(marker in body_lower for marker in [
                "<rss", "<feed", "<channel", "<entry", "<?xml",
                "application/rss+xml", "application/atom+xml",
            ])
            if is_rss and len(body) > 100:
                return (url, True, http_code, len(body), body[:200])
        return (url, False, http_code, 0, "")
    except Exception as e:
        return (url, False, "ERR", 0, str(e)[:100])

def main():
    results = {}
    
    all_urls = []
    url_to_brand = {}
    for brand, urls in RSS_CANDIDATES_R2.items():
        for url in urls:
            all_urls.append(url)
            url_to_brand[url] = brand

    print(f"Round 2: Testing {len(all_urls)} candidate URLs across {len(RSS_CANDIDATES_R2)} brands...")
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=20) as executor:
        future_to_url = {executor.submit(test_url, url): url for url in all_urls}
        
        for future in concurrent.futures.as_completed(future_to_url):
            url = future_to_url[future]
            try:
                result_url, is_valid, http_code, size, preview = future.result()
                brand = url_to_brand[result_url]
                status = "VALID" if is_valid else f"INVALID({http_code})"
                print(f"[{status}] {brand}: {result_url} (size={size})")
                if is_valid:
                    if brand not in results:
                        results[brand] = result_url
            except Exception as e:
                print(f"[ERROR] {url}: {e}")
    
    return results

if __name__ == "__main__":
    results = main()
    
    print("\n" + "="*80)
    print("ROUND 2 RESULTS SUMMARY")
    print("="*80)
    
    found = {}
    not_found = []
    for brand in RSS_CANDIDATES_R2.keys():
        if brand in results:
            found[brand] = results[brand]
        else:
            not_found.append(brand)
    
    print(f"\nFound RSS feeds for {len(found)} brands:")
    for brand, url in sorted(found.items()):
        print(f"  {brand}: {url}")
    
    print(f"\nNo RSS found for {len(not_found)} brands:")
    for brand in sorted(not_found):
        print(f"  {brand}")
    
    # Merge with round 1 results
    with open("/home/ubuntu/workdir/daily-industrial-design-image-search/rss_test_results.json", "r") as f:
        r1 = json.load(f)
    
    all_found = {}
    all_found.update(r1["found"])
    all_found.update(found)
    
    still_not_found = [b for b in r1["not_found"] if b not in all_found]
    
    output = {
        "found": all_found,
        "not_found": still_not_found,
    }
    with open("/home/ubuntu/workdir/daily-industrial-design-image-search/rss_test_results.json", "w") as f:
        json.dump(output, f, indent=2)
    
    print(f"\nTotal found: {len(all_found)}, still not found: {len(still_not_found)}")
    print(f"Results saved to rss_test_results.json")
