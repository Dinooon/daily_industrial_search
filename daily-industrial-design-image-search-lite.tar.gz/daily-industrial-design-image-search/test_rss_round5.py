#!/usr/bin/env python3
"""
Round 5: Try more creative patterns and use different user agents for 403/timeout sites.
Also try fetching with --compressed for gzip responses.
"""
import subprocess
import json
import concurrent.futures

# Additional patterns and different approaches
ROUND5_CANDIDATES = {
    "sony_design": [
        # Sony press center alternative domains
        "https://presscentre.sony.eu/press-releases/feed",
        "https://www.sony.co.uk/rss",
        "https://www.sony.com/en/press/press-releases/rss.xml",
        "https://www.sony.com/rss",
        "https://news.sony.com/feed",
        # Sony design specific
        "https://www.sony.com/en/SonyInfo/design/news/index.xml",
    ],
    "nothing_newsroom": [
        # Shopify blog feed pattern (nothing.tech uses Shopify)
        "https://nothing.tech/blogs/news.rss.xml",
        "https://nothing.tech/blogs/news.atom",
        # Shopify blog
        "https://nothing.tech/collections/all.atom",
        "https://nothing.tech/blogs/news.rss",
    ],
    "teenage_engineering": [
        # Try with /all
        "https://teenage.engineering/about/all.atom",
        "https://teenage.engineering/products/rss",
        "https://teenage.engineering/about/feed",
        "https://teenage.engineering/about/all.rss",
    ],
    "bang_olufsen": [
        # WordPress
        "https://www.bang-olufsen.com/wp-json/wp/v2/posts",
        "https://www.bang-olufsen.com/?feed=rss2",
        "https://www.bang-olufsen.com/?feed=atom",
        # Specific paths
        "https://www.bang-olufsen.com/en/the-latest.rss",
        "https://www.bang-olufsen.com/en/stories/feed",
    ],
    "bose_press_room": [
        # Bose might use Drupal or similar
        "https://www.bose.com/en-US/about-bose/press-room.xml",
        "https://www.bose.com/en-US/about-bose/news.rss",
        "https://www.bose.com/en-US/about-bose/feed",
        "https://www.bose.com/en-US/about-bose.atom",
    ],
    "gopro_news": [
        # Shopify pattern with proper headers
        "https://gopro.com/blogs/news.atom",
        "https://gopro.com/blogs/news.rss",
        "https://gopro.com/blogs/news.rss.xml",
        # Alternative blog
        "https://gopro.com/blogs/the-current.atom",
        "https://gopro.com/blogs/the-current.rss",
    ],
    "canon_global_news": [
        # Canon Europe/CIS
        "https://www.canon-cna.com/rss.xml",
        "https://www.canon-cna.com/feed",
        # Canon USA
        "https://www.usa.canon.com/rss",
        "https://www.usa.canon.com/feed",
        # Canon global alternative
        "https://global.canon/en/news/index.rdf",
    ],
    "fujifilm_news": [
        # Fujifilm Europe
        "https://www.fujifilm.eu/rss",
        "https://www.fujifilm.eu/press/rss",
        # Fujifilm US
        "https://www.fujifilm.com/us/en/news/feed.xml",
        "https://www.fujifilm.com/us/en/news.atom",
        # Fujifilm global
        "https://www.fujifilm.com/news/rss.xml",
        "https://www.fujifilm.com/news/index.rdf",
    ],
    "framework_blog": [
        # Ghost CMS standard feeds
        "https://frame.work/blog/rss",
        "https://frame.work/blog/atom",
        "https://frame.work/ghost/feed/",
        # Alternative
        "https://frame.work/blog/rss.xml",
        "https://frame.work/blog/atom.xml",
    ],
    "consumer": [  # Huawei
        "https://consumer.huawei.com/en/press/news/index.htm.atom",
        "https://consumer.huawei.com/en/press/news/feed",
        "https://consumer.huawei.com/en/press/news.rss",
        "https://consumer.huawei.com/en/press/index.htm.rss",
        # Huawei corporate
        "https://www.huawei.com/en/news-feed.xml",
        "https://www.huawei.com/en/press/rss.xml",
    ],
    "honor": [
        "https://www.honor.com/global/news.rss",
        "https://www.honor.com/global/news.atom",
        "https://www.honor.com/global/news.rss.xml",
        "https://www.honor.com/global/press.rss",
        "https://www.honor.com/global/news/feed.xml",
    ],
    "oppo_newsroom": [
        "https://www.oppo.com/en/newsroom.rss",
        "https://www.oppo.com/en/newsroom.atom",
        "https://www.oppo.com/en/newsroom.xml",
        "https://www.oppo.com/en/newsroom/index.rss",
        "https://www.oppo.com/en/press/feed",
    ],
    "realme_newsroom": [
        "https://www.realme.com/global/newsroom.rss",
        "https://www.realme.com/global/newsroom.atom",
        "https://www.realme.com/global/newsroom.xml",
        "https://www.realme.com/global/newsroom/index.atom",
        "https://www.realme.com/global/newsroom/feed.xml",
    ],
    "dji_media_center": [
        "https://www.dji.com/news/index.atom",
        "https://www.dji.com/newsroom/index.atom",
        "https://www.dji.com/news/feed",
        "https://www.dji.com/news.atom",
        "https://www.dji.com/atom.xml",
    ],
    "insta360_blog": [
        "https://www.insta360.com/blog/feed.xml",
        "https://www.insta360.com/blog/index.atom",
        "https://www.insta360.com/blog/index.rdf",
        "https://www.insta360.com/blog/atom",
        "https://www.insta360.com/atom.xml",
    ],
    "anker_news": [
        # Shopify blog
        "https://www.anker.com/blogs/news.atom",
        "https://www.anker.com/blogs/news.rss",
        "https://www.anker.com/blogs/news.rss.xml",
        "https://www.anker.com/blogs/news-feed.xml",
        "https://www.anker.com/blogs/news.atom.xml",
    ],
    "dyson_newsroom": [
        "https://www.dyson.com/discover/news.rss",
        "https://www.dyson.com/discover/news.atom",
        "https://www.dyson.com/discover/dyson-newsroom.atom",
        "https://www.dyson.com/news.xml",
        "https://www.dyson.com/discover/news/index.rdf",
        "https://www.dyson.com/discover/dyson-newsroom/index.xml",
    ],
    "bosch_press_portal": [
        "https://www.bosch-presse.de/pressportal/de/en/press.rss",
        "https://www.bosch-presse.de/pressportal/de/en/index.xml",
        "https://www.bosch-presse.de/pressportal/de/en/atom.xml",
        "https://www.bosch-presse.de/pressportal/de/en/press-releases.xml",
        "https://www.bosch-presse.de/pressportal/de/en/feed.xml",
    ],
    "lg_newsroom": [
        "https://www.lgnewsroom.com/feed/",
        "https://www.lgnewsroom.com/rss.xml",
        "https://www.lgnewsroom.com/feed.xml",
        "https://www.lgnewsroom.com/rss/",
        "https://www.lgnewsroom.com/atom.xml",
    ],
    "panasonic_newsroom": [
        # Try different path patterns
        "https://news.panasonic.com/global/rss/index.xml",
        "https://news.panasonic.com/global/feed/index.xml",
        "https://news.panasonic.com/global/news.rss",
        "https://news.panasonic.com/global/atom.xml",
        "https://news.panasonic.com/global/rss.xml",
    ],
    "ikea_newsroom": [
        "https://www.ikea.com/global/en/newsroom.rss",
        "https://www.ikea.com/global/en/newsroom.atom",
        "https://www.ikea.com/global/en/news/feed",
        "https://www.ikea.com/global/en/press/feed",
        "https://www.ikea.com/ms/en_US/press/feed.xml",
    ],
    "design_milk": [
        "https://design-milk.com/feed/",
        "https://design-milk.com/rss.xml",
        "https://design-milk.com/rss/",
        "https://design-milk.com/atom/",
        "https://feeds.feedburner.com/designmilk",
    ],
    "fast_company_design": [
        "https://www.fastcompany.com/feed",
        "https://www.fastcompany.com/rss.xml",
        "https://www.fastcompany.com/section/co-design/feed",
        "https://feeds.feedburner.com/fastcompany/headlines",
        "https://www.fastcompany.com/atom.xml",
    ],
    "new_atlas": [
        "https://newatlas.com/feed/",
        "https://newatlas.com/rss.xml",
        "https://newatlas.com/rss/",
        "https://feeds.feedburner.com/newatlas",
        "https://newatlas.com/atom.xml",
    ],
    "herman_miller": [
        # Try with content path
        "https://www.hermanmiller.com/content/hermanmiller/en_US/stories.rss",
        "https://www.hermanmiller.com/en_US/stories/feed",
        "https://www.hermanmiller.com/en_US/stories.rss",
        "https://www.hermanmiller.com/content/hermanmiller/en_US/feed.rss.xml",
        "https://www.hermanmiller.com/en_US/ideas/feed",
    ],
    "vitra": [
        "https://www.vitra.com/en/stories/feed",
        "https://www.vitra.com/en/stories.rss",
        "https://www.vitra.com/en/stories/index.xml",
        "https://www.vitra.com/stories/feed",
        "https://www.vitra.com/en/stories.atom",
    ],
    "mercedes_benz_media": [
        "https://media.mercedes-benz.com/feed",
        "https://media.mercedes-benz.com/rss.xml",
        "https://media.mercedes-benz.com/rss",
        "https://media.mercedes-benz.com/page/rss.xml",
        "https://media.mercedes-benz.com/page/feed.xml",
    ],
    "audi_mediacenter": [
        "https://www.audi-mediacenter.com/en/rss.xml",
        "https://www.audi-mediacenter.com/en/feed",
        "https://www.audi-mediacenter.com/en/rss",
        "https://www.audi-mediacenter.com/rss.xml",
        "https://www.audi-mediacenter.com/feed",
    ],
    "porsche_newsroom": [
        "https://newsroom.porsche.com/en/rss.xml",
        "https://newsroom.porsche.com/en/feed",
        "https://newsroom.porsche.com/en/rss",
        "https://newsroom.porsche.com/rss.xml",
        "https://newsroom.porsche.com/feed",
    ],
    "volvo_cars_media": [
        "https://www.media.volvocars.com/global/en-gb/rss.xml",
        "https://www.media.volvocars.com/global/en-gb/feed",
        "https://www.media.volvocars.com/rss.xml",
        "https://www.media.volvocars.com/feed",
        "https://www.media.volvocars.com/global/en-gb/rss",
    ],
    "tesla": [
        "https://www.tesla.com/blog/rss",
        "https://www.tesla.com/blog/feed",
        "https://www.tesla.com/blog.xml",
        "https://www.tesla.com/rss.xml",
        "https://www.tesla.com/feed",
    ],
    "toyota_global_newsroom": [
        "https://global.toyota/en/newsroom/rss.xml",
        "https://global.toyota/en/newsroom/feed",
        "https://global.toyota/en/newsroom/rss",
        "https://global.toyota/en/newsroom.xml",
        "https://global.toyota/en/feed.xml",
    ],
    "honda_global_newsroom": [
        "https://global.honda/en/newsroom/rss.xml",
        "https://global.honda/en/newsroom/feed",
        "https://global.honda/en/newsroom/rss",
        "https://global.honda/en/newsroom.xml",
        "https://global.honda/en/feed.xml",
    ],
}

def test_url_with_headers(url):
    """Test URL with more aggressive headers and --compressed flag."""
    try:
        result = subprocess.run(
            ["curl", "-sL", "--compressed", "-o", "-", "-w", "\\n__HTTP_CODE__%{http_code}",
             "--max-time", "15", "--connect-timeout", "12",
             "-H", "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
             "-H", "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
             "-H", "Accept-Language: en-US,en;q=0.9",
             "-H", "Accept-Encoding: gzip, deflate, br",
             url],
            capture_output=True, text=True, timeout=25
        )
        output = result.stdout
        http_code = "000"
        if "__HTTP_CODE__" in output:
            parts = output.rsplit("__HTTP_CODE__", 1)
            body = parts[0]
            http_code = parts[1].strip()
        else:
            body = output

        if http_code == "200":
            body_lower = body.lower().strip()
            is_rss = any(marker in body_lower for marker in [
                "<rss", "<feed", "<channel", "<entry", "<?xml",
                "application/rss+xml", "application/atom+xml",
                "<item", "<items",
            ])
            is_json = '"posts"' in body_lower or ('"title"' in body_lower and '"link"' in body_lower)
            
            if (is_rss or is_json) and len(body) > 100:
                return (url, True, http_code, len(body), body[:200])
        return (url, False, http_code, 0, "")
    except Exception as e:
        return (url, False, "ERR", 0, str(e)[:100])

def main():
    results = {}
    
    all_urls = []
    url_to_brand = {}
    for brand, urls in ROUND5_CANDIDATES.items():
        for url in urls:
            all_urls.append(url)
            url_to_brand[url] = brand

    print(f"Round 5: Testing {len(all_urls)} candidate URLs with better headers...")
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=15) as executor:
        future_to_url = {executor.submit(test_url_with_headers, url): url for url in all_urls}
        
        for future in concurrent.futures.as_completed(future_to_url):
            url = future_to_url[future]
            try:
                result_url, is_valid, http_code, size, preview = future.result()
                brand = url_to_brand[result_url]
                status = "VALID" if is_valid else f"INVALID({http_code})"
                print(f"[{status}] {brand}: {result_url} (size={size})")
                if is_valid:
                    if brand not in results:
                        results[brand] = result_url
            except Exception as e:
                print(f"[ERROR] {url}: {e}")
    
    return results

if __name__ == "__main__":
    results = main()
    
    print("\n" + "="*80)
    print("ROUND 5 RESULTS SUMMARY")
    print("="*80)
    
    print(f"\nFound RSS feeds for {len(results)} brands:")
    for brand, url in sorted(results.items()):
        print(f"  {brand}: {url}")
    
    # Merge with all previous results
    with open("/home/ubuntu/workdir/daily-industrial-design-image-search/rss_test_results.json", "r") as f:
        prev = json.load(f)
    
    all_found = {}
    all_found.update(prev["found"])
    all_found.update(results)
    
    still_not_found = [b for b in prev["not_found"] if b not in all_found]
    
    output = {
        "found": all_found,
        "not_found": still_not_found,
    }
    with open("/home/ubuntu/workdir/daily-industrial-design-image-search/rss_test_results.json", "w") as f:
        json.dump(output, f, indent=2)
    
    print(f"\nTotal found: {len(all_found)}, still not found: {len(still_not_found)}")
    print(f"Brands still not found: {still_not_found}")
    print(f"\nResults saved to rss_test_results.json")
