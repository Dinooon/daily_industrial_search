# 工业设计新品资讯追踪网站名单

> 生成日期: 2026-08-18
> 来源配置文件: `config/sources.json` (schema v2.1)
> 来源总数: 241 个

## 全局策略

- 每日来源预算 (daily_source_budget): 40
- 每日详情页预算 (daily_detail_budget): 60
- 发现顺序 (discovery_order): rss → sitemap → html
- 邮件订阅 (mail_subscriptions_enabled): False

## 默认参数

- enabled: True
- max_age_days: 14
- request_interval_seconds: 1.2

## 网站清单

| # | ID | 发布者 | 类型 | 优先级 | URL | 频率 | 启用 | 发现方式 | 信任度 |
|---|-----|--------|------|--------|-----|------|------|----------|--------|
| 1 | core77 | Core77 | design_media | P0 | https://www.core77.com/ | daily | ✅ | rss, sitemap, html | 0.8 |
| 2 | dezeen | Dezeen | design_media | P0 | https://www.dezeen.com/ | daily | ✅ | rss, sitemap, html | 0.8 |
| 3 | designboom | designboom | design_media | P0 | https://www.designboom.com/ | daily | ✅ | rss, sitemap, html | 0.8 |
| 4 | yanko_design | Yanko Design | design_media | P0 | https://www.yankodesign.com/ | daily | ✅ | rss, sitemap, html | 0.8 |
| 5 | wallpaper | Wallpaper\* | design_media | P2 | https://www.wallpaper.com/ | daily | ✅ | rss, sitemap, html | 0.8 |
| 6 | design_milk | Design Milk | design_media | P2 | https://design-milk.com/ | daily | ✅ | rss, sitemap, html | 0.8 |
| 7 | architonic | Architonic | design_media | P2 | https://www.architonic.com/ | daily | ✅ | rss, sitemap, html | 0.8 |
| 8 | design_week | Design Week | design_media | P2 | https://www.designweek.co.uk/ | daily | ✅ | rss, sitemap, html | 0.8 |
| 9 | fast_company_design | Fast Company Design | design_media | P2 | https://www.fastcompany.com/co-design | daily | ✅ | rss, sitemap, html | 0.8 |
| 10 | the_verge | The Verge | design_media | P2 | https://www.theverge.com/ | daily | ✅ | rss, sitemap, html | 0.8 |
| 11 | engadget | Engadget | design_media | P2 | https://www.engadget.com/ | daily | ✅ | rss, sitemap, html | 0.8 |
| 12 | techcrunch | TechCrunch | design_media | P2 | https://techcrunch.com/ | daily | ✅ | rss, sitemap, html | 0.8 |
| 13 | new_atlas | New Atlas | design_media | P2 | https://newatlas.com/ | daily | ✅ | rss, sitemap, html | 0.8 |
| 14 | auto_design | Auto & Design | design_media | P2 | https://autodesignmagazine.com/ | daily | ✅ | rss, sitemap, html | 0.8 |
| 15 | car_design_news | Car Design News | design_media | P2 | https://www.cardesignnews.com/ | daily | ✅ | rss, sitemap, html | 0.8 |
| 16 | form | FORM | design_media | P2 | https://form.de/ | daily | ✅ | rss, sitemap, html | 0.8 |
| 17 | frame | FRAME | design_media | P2 | https://frameweb.com/ | daily | ✅ | rss, sitemap, html | 0.8 |
| 18 | domus | Domus | design_media | P2 | https://www.domusweb.it/ | daily | ✅ | rss, sitemap, html | 0.8 |
| 19 | if_design_award | iF Design Award | award | P2 | https://ifdesign.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 20 | red_dot_design_award | Red Dot Design Award | award | P2 | https://www.red-dot.org/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 21 | idea_idsa | IDEA / IDSA | award | P2 | https://www.idsa.org/idea/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 22 | german_design_award | German Design Award | award | P2 | https://www.german-design-award.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 23 | good_design_award_japan | Good Design Award Japan | award | P2 | https://www.g-mark.org/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 24 | chicago_good_design_awards | Chicago Good Design Awards | award | P2 | https://www.good-designawards.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 25 | dezeen_awards | Dezeen Awards | award | P2 | https://www.dezeen.com/awards/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 26 | a_design_award | A' Design Award | award | P2 | https://competition.adesignaward.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 27 | james_dyson_award | James Dyson Award | award | P2 | https://www.jamesdysonaward.org/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 28 | lexus_design_award | Lexus Design Award | award | P2 | https://www.lexusdesignaward.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 29 | braunprize | BraunPrize | award | P2 | https://www.braun.com/global/en/braun-prize.html | weekly | ✅ | rss, sitemap, html | 0.7 |
| 30 | cmf_design_award | CMF Design Award | award | P2 | https://www.cmfdesignaward.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 31 | ces | CES | event | P2 | https://www.ces.tech/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 32 | mwc_barcelona | MWC Barcelona | event | P2 | https://www.mwcbarcelona.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 33 | ifa_berlin | IFA Berlin | event | P2 | https://www.ifa-berlin.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 34 | computex | Computex | event | P2 | https://www.computextaipei.com.tw/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 35 | nab_show | NAB Show | event | P2 | https://www.nabshow.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 36 | salone_del_mobile_milano | Salone del Mobile Milano | event | P2 | https://www.salonemilano.it/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 37 | fuorisalone | Fuorisalone | event | P2 | https://www.fuorisalone.it/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 38 | 3_days_of_design | 3 Days of Design | event | P2 | https://www.3daysofdesign.dk/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 39 | maison_objet | Maison&Objet | event | P2 | https://www.maison-objet.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 40 | stockholm_furniture_fair | Stockholm Furniture Fair | event | P2 | https://stockholmfurniturefair.se/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 41 | imm_cologne | IMM Cologne | event | P2 | https://www.imm-cologne.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 42 | neocon | NeoCon | event | P2 | https://neocon.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 43 | clerkenwell_design_week | Clerkenwell Design Week | event | P2 | https://www.clerkenwelldesignweek.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 44 | iaa_mobility | IAA Mobility | event | P2 | https://www.iaa-mobility.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 45 | japan_mobility_show | Japan Mobility Show | event | P2 | https://www.japan-mobility-show.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 46 | auto_shanghai | Auto Shanghai | event | P2 | https://www.autoshanghai.org/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 47 | beijing_auto_show | Beijing Auto Show | event | P2 | https://www.autochinashow.org/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 48 | eicma | EICMA | event | P2 | https://www.eicma.it/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 49 | eurobike | Eurobike | event | P2 | https://www.eurobike.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 50 | awe | AWE 中国家电及消费电子博览会 | event | P2 | https://www.awe.com.cn/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 51 | furniture_china | Furniture China | event | P2 | https://www.furniture-china.cn/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 52 | szdif | 深圳国际工业设计大展 | event | P2 | https://www.szdif.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 53 | designshanghai | 设计上海 | event | P2 | https://www.designshanghai.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 54 | gzdesignweek | 广州设计周 | event | P2 | https://www.gzdesignweek.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 55 | wdcc | 世界设计之都大会 WDCC | event | P2 | https://www.wdcc2023.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 56 | chinajoy | ChinaJoy | event | P2 | https://www.chinajoy.net/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 57 | apple_newsroom | Apple Newsroom | official_brand | P1 | https://www.apple.com/newsroom/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 58 | samsung_global_newsroom | Samsung Global Newsroom | official_brand | P1 | https://news.samsung.com/global/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 59 | sony_design | Sony Design | official_brand | P1 | https://www.sony.com/en/SonyInfo/design/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 60 | google_blog_products | Google Blog — Products | official_brand | P1 | https://blog.google/products/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 61 | microsoft_surface_blog | Microsoft Surface Blog | official_brand | P1 | https://blogs.windows.com/devices/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 62 | meta_newsroom | Meta Newsroom | official_brand | P1 | https://about.fb.com/news/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 63 | nothing_newsroom | Nothing Newsroom | official_brand | P1 | https://nothing.tech/pages/newsroom | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 64 | teenage_engineering | Teenage Engineering | official_brand | P1 | https://teenage.engineering/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 65 | bang_olufsen | Bang & Olufsen | official_brand | P1 | https://www.bang-olufsen.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 66 | bose_press_room | Bose Press Room | official_brand | P1 | https://www.bose.com/pressroom | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 67 | sonos_newsroom | Sonos Newsroom | official_brand | P1 | https://newsroom.sonos.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 68 | logitech_newsroom | Logitech Newsroom | official_brand | P1 | https://news.logitech.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 69 | garmin_newsroom | Garmin Newsroom | official_brand | P1 | https://www.garmin.com/en-US/newsroom/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 70 | gopro_news | GoPro News | official_brand | P1 | https://gopro.com/en/us/news | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 71 | leica_camera | Leica Camera | official_brand | P1 | https://leica-camera.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 72 | canon_global_news | Canon Global News | official_brand | P1 | https://global.canon/en/news/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 73 | nikon_news | Nikon News | official_brand | P1 | https://www.nikon.com/company/news/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 74 | fujifilm_news | Fujifilm News | official_brand | P1 | https://www.fujifilm.com/us/en/news | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 75 | framework_blog | Framework Blog | official_brand | P1 | https://frame.work/blog | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 76 | consumer | 华为消费者业务新闻中心 | official_brand | P1 | https://consumer.huawei.com/en/press/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 77 | mi | 小米全球活动与发布 | official_brand | P1 | https://www.mi.com/global/event/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 78 | honor | 荣耀新闻 | official_brand | P1 | https://www.honor.com/global/news/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 79 | oppo_newsroom | OPPO Newsroom | official_brand | P1 | https://www.oppo.com/en/newsroom/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 80 | vivo_news | vivo News | official_brand | P1 | https://www.vivo.com/en/about-vivo/news | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 81 | realme_newsroom | realme Newsroom | official_brand | P1 | https://www.realme.com/global/newsroom | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 82 | lenovo_storyhub | Lenovo StoryHub | official_brand | P1 | https://news.lenovo.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 83 | dji_media_center | DJI Media Center | official_brand | P1 | https://www.dji.com/newsroom | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 84 | insta360_blog | Insta360 Blog | official_brand | P1 | https://www.insta360.com/blog/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 85 | anker_news | Anker News | official_brand | P1 | https://www.anker.com/blogs/news | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 86 | cmf_by_nothing | CMF by Nothing | official_brand | P1 | https://cmf.tech/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 87 | dyson_newsroom | Dyson Newsroom | official_brand | P1 | https://www.dyson.com/discover/news | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 88 | braun | Braun | official_brand | P1 | https://www.braun.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 89 | philips_news_center | Philips News Center | official_brand | P1 | https://www.philips.com/a-w/about/news/home.html | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 90 | bosch_press_portal | Bosch Press Portal | official_brand | P1 | https://www.bosch-presse.de/pressportal/de/en/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 91 | miele_press | Miele Press | official_brand | P1 | https://www.miele.com/en/com/press-218.htm | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 92 | siemens_home_appliances | Siemens Home Appliances | official_brand | P1 | https://www.siemens-home.bsh-group.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 93 | gaggenau | Gaggenau | official_brand | P1 | https://www.gaggenau.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 94 | electrolux_group_newsroom | Electrolux Group Newsroom | official_brand | P1 | https://www.electroluxgroup.com/en/newsroom/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 95 | lg_newsroom | LG Newsroom | official_brand | P1 | https://www.lgnewsroom.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 96 | panasonic_newsroom | Panasonic Newsroom | official_brand | P1 | https://news.panasonic.com/global/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 97 | balmuda | BALMUDA | official_brand | P1 | https://www.balmuda.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 98 | muji | MUJI | official_brand | P1 | https://www.muji.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 99 | ikea_newsroom | IKEA Newsroom | official_brand | P1 | https://www.ikea.com/global/en/newsroom/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 100 | haier | 海尔全球新闻 | official_brand | P1 | https://www.haier.com/global/press-events/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 101 | midea-group | 美的集团新闻 | official_brand | P1 | https://www.midea-group.com/our-businesses/news | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 102 | fotile | 方太 | official_brand | P1 | https://www.fotile.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 103 | robam | 老板电器 | official_brand | P1 | https://www.robam.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 104 | newsroom | 石头科技 Newsroom | official_brand | P1 | https://global.roborock.com/pages/newsroom | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 105 | ecovacs | 科沃斯 | official_brand | P1 | https://www.ecovacs.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 106 | dreametech | 追觅科技 | official_brand | P1 | https://www.dreametech.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 107 | global | 添可 | official_brand | P1 | https://global.tineco.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 108 | narwal | 云鲸 | official_brand | P1 | https://www.narwal.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 109 | mi_2 | 米家 | official_brand | P1 | https://www.mi.com/global/smart-home/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 110 | bears | 小熊电器 | official_brand | P1 | https://www.bears.com.cn/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 111 | herman_miller | Herman Miller | official_brand | P1 | https://www.hermanmiller.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 112 | knoll | Knoll | official_brand | P1 | https://www.knoll.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 113 | vitra | Vitra | official_brand | P1 | https://www.vitra.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 114 | steelcase | Steelcase | official_brand | P1 | https://www.steelcase.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 115 | haworth | Haworth | official_brand | P1 | https://www.haworth.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 116 | humanscale | Humanscale | official_brand | P1 | https://www.humanscale.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 117 | usm | USM | official_brand | P1 | https://www.usm.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 118 | fritz_hansen | Fritz Hansen | official_brand | P1 | https://www.fritzhansen.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 119 | hay | HAY | official_brand | P1 | https://www.hay.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 120 | muuto | Muuto | official_brand | P1 | https://www.muuto.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 121 | artek | Artek | official_brand | P1 | https://www.artek.fi/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 122 | cassina | Cassina | official_brand | P1 | https://www.cassina.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 123 | b_b_italia | B&B Italia | official_brand | P1 | https://www.bebitalia.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 124 | kartell | Kartell | official_brand | P1 | https://www.kartell.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 125 | magis | Magis | official_brand | P1 | https://www.magisdesign.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 126 | molteni_c | Molteni&C | official_brand | P1 | https://www.molteni.it/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 127 | poliform | Poliform | official_brand | P1 | https://www.poliform.it/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 128 | flos | Flos | official_brand | P1 | https://flos.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 129 | artemide | Artemide | official_brand | P1 | https://www.artemide.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 130 | louis_poulsen | Louis Poulsen | official_brand | P1 | https://www.louispoulsen.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 131 | tradition | &Tradition | official_brand | P1 | https://andtradition.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 132 | bosch_professional | Bosch Professional | official_brand | P1 | https://www.bosch-professional.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 133 | hilti | Hilti | official_brand | P1 | https://www.hilti.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 134 | festool | Festool | official_brand | P1 | https://www.festool.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 135 | makita | Makita | official_brand | P1 | https://www.makita.biz/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 136 | dewalt | DeWalt | official_brand | P1 | https://www.dewalt.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 137 | milwaukee_tool | Milwaukee Tool | official_brand | P1 | https://www.milwaukeetool.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 138 | stihl | STIHL | official_brand | P1 | https://www.stihl.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 139 | husqvarna | Husqvarna | official_brand | P1 | https://www.husqvarna.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 140 | leatherman | Leatherman | official_brand | P1 | https://www.leatherman.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 141 | victorinox | Victorinox | official_brand | P1 | https://www.victorinox.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 142 | stanley | Stanley | official_brand | P1 | https://www.stanleytools.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 143 | pelican | Pelican | official_brand | P1 | https://www.pelican.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 144 | yeti | YETI | official_brand | P1 | https://www.yeti.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 145 | patagonia | Patagonia | official_brand | P1 | https://www.patagonia.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 146 | arc_teryx | Arc'teryx | official_brand | P1 | https://arcteryx.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 147 | the_north_face | The North Face | official_brand | P1 | https://www.thenorthface.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 148 | snow_peak | Snow Peak | official_brand | P1 | https://www.snowpeak.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 149 | bmw_group_pressclub | BMW Group PressClub | official_brand | P1 | https://www.press.bmwgroup.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 150 | mini_pressclub | MINI PressClub | official_brand | P1 | https://www.press.bmwgroup.com/global/article/topic/4186/mini | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 151 | mercedes_benz_media | Mercedes-Benz Media | official_brand | P1 | https://media.mercedes-benz.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 152 | audi_mediacenter | Audi MediaCenter | official_brand | P1 | https://www.audi-mediacenter.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 153 | porsche_newsroom | Porsche Newsroom | official_brand | P1 | https://newsroom.porsche.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 154 | volvo_cars_media | Volvo Cars Media | official_brand | P1 | https://www.media.volvocars.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 155 | polestar_media | Polestar Media | official_brand | P1 | https://media.polestar.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 156 | hyundai_newsroom | Hyundai Newsroom | official_brand | P1 | https://www.hyundainews.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 157 | kia_global_media_center | Kia Global Media Center | official_brand | P1 | https://www.kianewscenter.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 158 | toyota_global_newsroom | Toyota Global Newsroom | official_brand | P1 | https://global.toyota/en/newsroom/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 159 | honda_global_newsroom | Honda Global Newsroom | official_brand | P1 | https://global.honda/en/newsroom/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 160 | nissan_global_newsroom | Nissan Global Newsroom | official_brand | P1 | https://global.nissannews.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 161 | yamaha_motor_news | Yamaha Motor News | official_brand | P1 | https://global.yamaha-motor.com/news/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 162 | tesla | Tesla | official_brand | P1 | https://www.tesla.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 163 | rivian_stories | Rivian Stories | official_brand | P1 | https://stories.rivian.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 164 | lucid_media_room | Lucid Media Room | official_brand | P1 | https://media.lucidmotors.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 165 | nio | 蔚来新闻 | official_brand | P1 | https://www.nio.com/news | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 166 | lixiang | 理想汽车新闻 | official_brand | P1 | https://www.lixiang.com/news | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 167 | xpeng | 小鹏汽车新闻 | official_brand | P1 | https://www.xpeng.com/news | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 168 | zeekrglobal | 极氪 | official_brand | P1 | https://www.zeekrglobal.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 169 | xiaomiev | 小米汽车 | official_brand | P1 | https://www.xiaomiev.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 170 | bydglobal | 比亚迪新闻 | official_brand | P1 | https://www.bydglobal.com/en/news | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 171 | yangwangauto | 仰望汽车 | official_brand | P1 | https://www.yangwangauto.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 172 | fangchengbao | 方程豹 | official_brand | P1 | https://www.fangchengbao.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 173 | global_2 | 吉利汽车 | official_brand | P1 | https://global.geely.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 174 | avatr | 阿维塔 | official_brand | P1 | https://www.avatr.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 175 | voyah | 岚图汽车 | official_brand | P1 | https://www.voyah.com.cn/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 176 | philips_healthcare | Philips Healthcare | official_brand | P1 | https://www.usa.philips.com/healthcare | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 177 | siemens_healthineers_press_center | Siemens Healthineers Press Center | official_brand | P1 | https://www.siemens-healthineers.com/press | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 178 | ge_healthcare_newsroom | GE HealthCare Newsroom | official_brand | P1 | https://www.gehealthcare.com/about/newsroom | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 179 | medtronic_newsroom | Medtronic Newsroom | official_brand | P1 | https://news.medtronic.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 180 | stryker_news | Stryker News | official_brand | P1 | https://www.stryker.com/us/en/about/news.html | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 181 | dr_ger_press_center | Dräger Press Center | official_brand | P1 | https://www.draeger.com/en-us_us/Press-Center | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 182 | leica_microsystems_news | Leica Microsystems News | official_brand | P1 | https://www.leica-microsystems.com/company/news/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 183 | zebra_technologies_newsroom | Zebra Technologies Newsroom | official_brand | P1 | https://www.zebra.com/us/en/about-zebra/newsroom.html | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 184 | honeywell_news | Honeywell News | official_brand | P1 | https://www.honeywell.com/us/en/news | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 185 | fluke_news | Fluke News | official_brand | P1 | https://www.fluke.com/en-us/learn/blog | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 186 | k_rcher | Kärcher | official_brand | P1 | https://www.kaercher.com/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 187 | abb_news | ABB News | official_brand | P1 | https://global.abb/group/en/media | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 188 | kuka_press | KUKA Press | official_brand | P1 | https://www.kuka.com/en-de/company/press | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 189 | universal_robots_news | Universal Robots News | official_brand | P1 | https://www.universal-robots.com/news-and-media/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 190 | boston_dynamics_blog | Boston Dynamics Blog | official_brand | P1 | https://bostondynamics.com/blog/ | every_2_days | ✅ | rss, sitemap, html | 1.0 |
| 191 | ideo | IDEO | design_studio | P2 | https://www.ideo.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 192 | frog | frog | design_studio | P2 | https://www.frog.co/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 193 | designworks | Designworks | design_studio | P2 | https://www.bmwgroupdesignworks.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 194 | lunar | Lunar | design_studio | P2 | https://www.lunar.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 195 | fuseproject | fuseproject | design_studio | P2 | https://fuseproject.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 196 | layer | LAYER | design_studio | P2 | https://layerdesign.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 197 | map_project_office | Map Project Office | design_studio | P2 | https://mapprojectoffice.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 198 | seymourpowell | Seymourpowell | design_studio | P2 | https://www.seymourpowell.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 199 | priestmangoode | PriestmanGoode | design_studio | P2 | https://www.priestmangoode.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 200 | pentagram | Pentagram | design_studio | P2 | https://www.pentagram.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 201 | ammunition | Ammunition | design_studio | P2 | https://ammunitiongroup.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 202 | whipsaw | Whipsaw | design_studio | P2 | https://whipsaw.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 203 | newdealdesign | NewDealDesign | design_studio | P2 | https://newdealdesign.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 204 | teams_design | TEAMS Design | design_studio | P2 | https://www.teamsdesign.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 205 | veryday | Veryday | design_studio | P2 | https://veryday.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 206 | kiska | KISKA | design_studio | P2 | https://kiska.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 207 | astro_studios | Astro Studios | design_studio | P2 | https://astrostudios.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 208 | nendo | nendo | design_studio | P2 | https://www.nendo.jp/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 209 | naoto_fukasawa_design | Naoto Fukasawa Design | design_studio | P2 | https://naotofukasawa.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 210 | studio_f_a_porsche | Studio F. A. Porsche | design_studio | P2 | https://www.studiofaporsche.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 211 | lkkdesign | 洛可可设计 | design_studio | P2 | https://www.lkkdesign.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 212 | artopgroup | 浪尖设计 | design_studio | P2 | https://www.artopgroup.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 213 | moomadesign | 木马设计 | design_studio | P2 | https://www.moomadesign.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 214 | xivo-design | 佳简几何 | design_studio | P2 | https://www.xivo-design.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 215 | yang_design | YANG DESIGN | design_studio | P2 | https://www.yang-design.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 216 | gk_design_group | GK Design Group | design_studio | P2 | https://www.gk-design.co.jp/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 217 | tangible | Tangible | design_studio | P2 | https://tangible.co.jp/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 218 | native_design | Native Design | design_studio | P2 | https://www.native.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 219 | materialdistrict | MaterialDistrict | materials_manufacturing | P2 | https://materialdistrict.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 220 | material_connexion | Material ConneXion | materials_manufacturing | P2 | https://materialconnexion.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 221 | materiom | Materiom | materials_manufacturing | P2 | https://materiom.org/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 222 | matmatch | Matmatch | materials_manufacturing | P2 | https://matmatch.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 223 | basf_designfabrik | BASF Designfabrik | materials_manufacturing | P2 | https://designfabrik.basf.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 224 | covestro_cmf | Covestro CMF | materials_manufacturing | P2 | https://solutions.covestro.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 225 | sabic | SABIC | materials_manufacturing | P2 | https://www.sabic.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 226 | 3m_design | 3M Design | materials_manufacturing | P2 | https://www.3m.com/3M/en_US/design-us/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 227 | eastman | Eastman | materials_manufacturing | P2 | https://www.eastman.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 228 | coloro | Coloro | materials_manufacturing | P2 | https://www.coloro.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 229 | wgsn | WGSN | materials_manufacturing | P2 | https://www.wgsn.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 230 | pantone | Pantone | materials_manufacturing | P2 | https://www.pantone.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 231 | specialchem | SpecialChem | materials_manufacturing | P2 | https://www.specialchem.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 232 | additive_manufacturing_media | Additive Manufacturing Media | materials_manufacturing | P2 | https://www.additivemanufacturing.media/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 233 | protolabs | Protolabs | materials_manufacturing | P2 | https://www.protolabs.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 234 | xometry | Xometry | materials_manufacturing | P2 | https://www.xometry.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 235 | fictiv | Fictiv | materials_manufacturing | P2 | https://www.fictiv.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 236 | hubs | Hubs | materials_manufacturing | P2 | https://www.hubs.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 237 | formlabs | Formlabs | materials_manufacturing | P2 | https://formlabs.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 238 | stratasys | Stratasys | materials_manufacturing | P2 | https://www.stratasys.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 239 | materialise | Materialise | materials_manufacturing | P2 | https://www.materialise.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 240 | carbon | Carbon | materials_manufacturing | P2 | https://www.carbon3d.com/ | weekly | ✅ | rss, sitemap, html | 0.7 |
| 241 | hp_3d_printing | HP 3D Printing | materials_manufacturing | P2 | https://www.hp.com/us-en/printers/3d-printers.html | weekly | ✅ | rss, sitemap, html | 0.7 |

## 按来源类型分组

### award (12 个)

| # | ID | 发布者 | 优先级 | URL | 频率 | 启用 | 信任度 |
|---|-----|--------|--------|-----|------|------|--------|
| 1 | if_design_award | iF Design Award | P2 | https://ifdesign.com/ | weekly | ✅ | 0.7 |
| 2 | red_dot_design_award | Red Dot Design Award | P2 | https://www.red-dot.org/ | weekly | ✅ | 0.7 |
| 3 | idea_idsa | IDEA / IDSA | P2 | https://www.idsa.org/idea/ | weekly | ✅ | 0.7 |
| 4 | german_design_award | German Design Award | P2 | https://www.german-design-award.com/ | weekly | ✅ | 0.7 |
| 5 | good_design_award_japan | Good Design Award Japan | P2 | https://www.g-mark.org/ | weekly | ✅ | 0.7 |
| 6 | chicago_good_design_awards | Chicago Good Design Awards | P2 | https://www.good-designawards.com/ | weekly | ✅ | 0.7 |
| 7 | dezeen_awards | Dezeen Awards | P2 | https://www.dezeen.com/awards/ | weekly | ✅ | 0.7 |
| 8 | a_design_award | A' Design Award | P2 | https://competition.adesignaward.com/ | weekly | ✅ | 0.7 |
| 9 | james_dyson_award | James Dyson Award | P2 | https://www.jamesdysonaward.org/ | weekly | ✅ | 0.7 |
| 10 | lexus_design_award | Lexus Design Award | P2 | https://www.lexusdesignaward.com/ | weekly | ✅ | 0.7 |
| 11 | braunprize | BraunPrize | P2 | https://www.braun.com/global/en/braun-prize.html | weekly | ✅ | 0.7 |
| 12 | cmf_design_award | CMF Design Award | P2 | https://www.cmfdesignaward.com/ | weekly | ✅ | 0.7 |

### design_media (18 个)

| # | ID | 发布者 | 优先级 | URL | 频率 | 启用 | 信任度 |
|---|-----|--------|--------|-----|------|------|--------|
| 1 | core77 | Core77 | P0 | https://www.core77.com/ | daily | ✅ | 0.8 |
| 2 | dezeen | Dezeen | P0 | https://www.dezeen.com/ | daily | ✅ | 0.8 |
| 3 | designboom | designboom | P0 | https://www.designboom.com/ | daily | ✅ | 0.8 |
| 4 | yanko_design | Yanko Design | P0 | https://www.yankodesign.com/ | daily | ✅ | 0.8 |
| 5 | wallpaper | Wallpaper\* | P2 | https://www.wallpaper.com/ | daily | ✅ | 0.8 |
| 6 | design_milk | Design Milk | P2 | https://design-milk.com/ | daily | ✅ | 0.8 |
| 7 | architonic | Architonic | P2 | https://www.architonic.com/ | daily | ✅ | 0.8 |
| 8 | design_week | Design Week | P2 | https://www.designweek.co.uk/ | daily | ✅ | 0.8 |
| 9 | fast_company_design | Fast Company Design | P2 | https://www.fastcompany.com/co-design | daily | ✅ | 0.8 |
| 10 | the_verge | The Verge | P2 | https://www.theverge.com/ | daily | ✅ | 0.8 |
| 11 | engadget | Engadget | P2 | https://www.engadget.com/ | daily | ✅ | 0.8 |
| 12 | techcrunch | TechCrunch | P2 | https://techcrunch.com/ | daily | ✅ | 0.8 |
| 13 | new_atlas | New Atlas | P2 | https://newatlas.com/ | daily | ✅ | 0.8 |
| 14 | auto_design | Auto & Design | P2 | https://autodesignmagazine.com/ | daily | ✅ | 0.8 |
| 15 | car_design_news | Car Design News | P2 | https://www.cardesignnews.com/ | daily | ✅ | 0.8 |
| 16 | form | FORM | P2 | https://form.de/ | daily | ✅ | 0.8 |
| 17 | frame | FRAME | P2 | https://frameweb.com/ | daily | ✅ | 0.8 |
| 18 | domus | Domus | P2 | https://www.domusweb.it/ | daily | ✅ | 0.8 |

### design_studio (28 个)

| # | ID | 发布者 | 优先级 | URL | 频率 | 启用 | 信任度 |
|---|-----|--------|--------|-----|------|------|--------|
| 1 | ideo | IDEO | P2 | https://www.ideo.com/ | weekly | ✅ | 0.7 |
| 2 | frog | frog | P2 | https://www.frog.co/ | weekly | ✅ | 0.7 |
| 3 | designworks | Designworks | P2 | https://www.bmwgroupdesignworks.com/ | weekly | ✅ | 0.7 |
| 4 | lunar | Lunar | P2 | https://www.lunar.com/ | weekly | ✅ | 0.7 |
| 5 | fuseproject | fuseproject | P2 | https://fuseproject.com/ | weekly | ✅ | 0.7 |
| 6 | layer | LAYER | P2 | https://layerdesign.com/ | weekly | ✅ | 0.7 |
| 7 | map_project_office | Map Project Office | P2 | https://mapprojectoffice.com/ | weekly | ✅ | 0.7 |
| 8 | seymourpowell | Seymourpowell | P2 | https://www.seymourpowell.com/ | weekly | ✅ | 0.7 |
| 9 | priestmangoode | PriestmanGoode | P2 | https://www.priestmangoode.com/ | weekly | ✅ | 0.7 |
| 10 | pentagram | Pentagram | P2 | https://www.pentagram.com/ | weekly | ✅ | 0.7 |
| 11 | ammunition | Ammunition | P2 | https://ammunitiongroup.com/ | weekly | ✅ | 0.7 |
| 12 | whipsaw | Whipsaw | P2 | https://whipsaw.com/ | weekly | ✅ | 0.7 |
| 13 | newdealdesign | NewDealDesign | P2 | https://newdealdesign.com/ | weekly | ✅ | 0.7 |
| 14 | teams_design | TEAMS Design | P2 | https://www.teamsdesign.com/ | weekly | ✅ | 0.7 |
| 15 | veryday | Veryday | P2 | https://veryday.com/ | weekly | ✅ | 0.7 |
| 16 | kiska | KISKA | P2 | https://kiska.com/ | weekly | ✅ | 0.7 |
| 17 | astro_studios | Astro Studios | P2 | https://astrostudios.com/ | weekly | ✅ | 0.7 |
| 18 | nendo | nendo | P2 | https://www.nendo.jp/ | weekly | ✅ | 0.7 |
| 19 | naoto_fukasawa_design | Naoto Fukasawa Design | P2 | https://naotofukasawa.com/ | weekly | ✅ | 0.7 |
| 20 | studio_f_a_porsche | Studio F. A. Porsche | P2 | https://www.studiofaporsche.com/ | weekly | ✅ | 0.7 |
| 21 | lkkdesign | 洛可可设计 | P2 | https://www.lkkdesign.com/ | weekly | ✅ | 0.7 |
| 22 | artopgroup | 浪尖设计 | P2 | https://www.artopgroup.com/ | weekly | ✅ | 0.7 |
| 23 | moomadesign | 木马设计 | P2 | https://www.moomadesign.com/ | weekly | ✅ | 0.7 |
| 24 | xivo-design | 佳简几何 | P2 | https://www.xivo-design.com/ | weekly | ✅ | 0.7 |
| 25 | yang_design | YANG DESIGN | P2 | https://www.yang-design.com/ | weekly | ✅ | 0.7 |
| 26 | gk_design_group | GK Design Group | P2 | https://www.gk-design.co.jp/ | weekly | ✅ | 0.7 |
| 27 | tangible | Tangible | P2 | https://tangible.co.jp/ | weekly | ✅ | 0.7 |
| 28 | native_design | Native Design | P2 | https://www.native.com/ | weekly | ✅ | 0.7 |

### event (26 个)

| # | ID | 发布者 | 优先级 | URL | 频率 | 启用 | 信任度 |
|---|-----|--------|--------|-----|------|------|--------|
| 1 | ces | CES | P2 | https://www.ces.tech/ | weekly | ✅ | 0.7 |
| 2 | mwc_barcelona | MWC Barcelona | P2 | https://www.mwcbarcelona.com/ | weekly | ✅ | 0.7 |
| 3 | ifa_berlin | IFA Berlin | P2 | https://www.ifa-berlin.com/ | weekly | ✅ | 0.7 |
| 4 | computex | Computex | P2 | https://www.computextaipei.com.tw/ | weekly | ✅ | 0.7 |
| 5 | nab_show | NAB Show | P2 | https://www.nabshow.com/ | weekly | ✅ | 0.7 |
| 6 | salone_del_mobile_milano | Salone del Mobile Milano | P2 | https://www.salonemilano.it/ | weekly | ✅ | 0.7 |
| 7 | fuorisalone | Fuorisalone | P2 | https://www.fuorisalone.it/ | weekly | ✅ | 0.7 |
| 8 | 3_days_of_design | 3 Days of Design | P2 | https://www.3daysofdesign.dk/ | weekly | ✅ | 0.7 |
| 9 | maison_objet | Maison&Objet | P2 | https://www.maison-objet.com/ | weekly | ✅ | 0.7 |
| 10 | stockholm_furniture_fair | Stockholm Furniture Fair | P2 | https://stockholmfurniturefair.se/ | weekly | ✅ | 0.7 |
| 11 | imm_cologne | IMM Cologne | P2 | https://www.imm-cologne.com/ | weekly | ✅ | 0.7 |
| 12 | neocon | NeoCon | P2 | https://neocon.com/ | weekly | ✅ | 0.7 |
| 13 | clerkenwell_design_week | Clerkenwell Design Week | P2 | https://www.clerkenwelldesignweek.com/ | weekly | ✅ | 0.7 |
| 14 | iaa_mobility | IAA Mobility | P2 | https://www.iaa-mobility.com/ | weekly | ✅ | 0.7 |
| 15 | japan_mobility_show | Japan Mobility Show | P2 | https://www.japan-mobility-show.com/ | weekly | ✅ | 0.7 |
| 16 | auto_shanghai | Auto Shanghai | P2 | https://www.autoshanghai.org/ | weekly | ✅ | 0.7 |
| 17 | beijing_auto_show | Beijing Auto Show | P2 | https://www.autochinashow.org/ | weekly | ✅ | 0.7 |
| 18 | eicma | EICMA | P2 | https://www.eicma.it/ | weekly | ✅ | 0.7 |
| 19 | eurobike | Eurobike | P2 | https://www.eurobike.com/ | weekly | ✅ | 0.7 |
| 20 | awe | AWE 中国家电及消费电子博览会 | P2 | https://www.awe.com.cn/ | weekly | ✅ | 0.7 |
| 21 | furniture_china | Furniture China | P2 | https://www.furniture-china.cn/ | weekly | ✅ | 0.7 |
| 22 | szdif | 深圳国际工业设计大展 | P2 | https://www.szdif.com/ | weekly | ✅ | 0.7 |
| 23 | designshanghai | 设计上海 | P2 | https://www.designshanghai.com/ | weekly | ✅ | 0.7 |
| 24 | gzdesignweek | 广州设计周 | P2 | https://www.gzdesignweek.com/ | weekly | ✅ | 0.7 |
| 25 | wdcc | 世界设计之都大会 WDCC | P2 | https://www.wdcc2023.com/ | weekly | ✅ | 0.7 |
| 26 | chinajoy | ChinaJoy | P2 | https://www.chinajoy.net/ | weekly | ✅ | 0.7 |

### materials_manufacturing (23 个)

| # | ID | 发布者 | 优先级 | URL | 频率 | 启用 | 信任度 |
|---|-----|--------|--------|-----|------|------|--------|
| 1 | materialdistrict | MaterialDistrict | P2 | https://materialdistrict.com/ | weekly | ✅ | 0.7 |
| 2 | material_connexion | Material ConneXion | P2 | https://materialconnexion.com/ | weekly | ✅ | 0.7 |
| 3 | materiom | Materiom | P2 | https://materiom.org/ | weekly | ✅ | 0.7 |
| 4 | matmatch | Matmatch | P2 | https://matmatch.com/ | weekly | ✅ | 0.7 |
| 5 | basf_designfabrik | BASF Designfabrik | P2 | https://designfabrik.basf.com/ | weekly | ✅ | 0.7 |
| 6 | covestro_cmf | Covestro CMF | P2 | https://solutions.covestro.com/ | weekly | ✅ | 0.7 |
| 7 | sabic | SABIC | P2 | https://www.sabic.com/ | weekly | ✅ | 0.7 |
| 8 | 3m_design | 3M Design | P2 | https://www.3m.com/3M/en_US/design-us/ | weekly | ✅ | 0.7 |
| 9 | eastman | Eastman | P2 | https://www.eastman.com/ | weekly | ✅ | 0.7 |
| 10 | coloro | Coloro | P2 | https://www.coloro.com/ | weekly | ✅ | 0.7 |
| 11 | wgsn | WGSN | P2 | https://www.wgsn.com/ | weekly | ✅ | 0.7 |
| 12 | pantone | Pantone | P2 | https://www.pantone.com/ | weekly | ✅ | 0.7 |
| 13 | specialchem | SpecialChem | P2 | https://www.specialchem.com/ | weekly | ✅ | 0.7 |
| 14 | additive_manufacturing_media | Additive Manufacturing Media | P2 | https://www.additivemanufacturing.media/ | weekly | ✅ | 0.7 |
| 15 | protolabs | Protolabs | P2 | https://www.protolabs.com/ | weekly | ✅ | 0.7 |
| 16 | xometry | Xometry | P2 | https://www.xometry.com/ | weekly | ✅ | 0.7 |
| 17 | fictiv | Fictiv | P2 | https://www.fictiv.com/ | weekly | ✅ | 0.7 |
| 18 | hubs | Hubs | P2 | https://www.hubs.com/ | weekly | ✅ | 0.7 |
| 19 | formlabs | Formlabs | P2 | https://formlabs.com/ | weekly | ✅ | 0.7 |
| 20 | stratasys | Stratasys | P2 | https://www.stratasys.com/ | weekly | ✅ | 0.7 |
| 21 | materialise | Materialise | P2 | https://www.materialise.com/ | weekly | ✅ | 0.7 |
| 22 | carbon | Carbon | P2 | https://www.carbon3d.com/ | weekly | ✅ | 0.7 |
| 23 | hp_3d_printing | HP 3D Printing | P2 | https://www.hp.com/us-en/printers/3d-printers.html | weekly | ✅ | 0.7 |

### official_brand (134 个)

| # | ID | 发布者 | 优先级 | URL | 频率 | 启用 | 信任度 |
|---|-----|--------|--------|-----|------|------|--------|
| 1 | apple_newsroom | Apple Newsroom | P1 | https://www.apple.com/newsroom/ | every_2_days | ✅ | 1.0 |
| 2 | samsung_global_newsroom | Samsung Global Newsroom | P1 | https://news.samsung.com/global/ | every_2_days | ✅ | 1.0 |
| 3 | sony_design | Sony Design | P1 | https://www.sony.com/en/SonyInfo/design/ | every_2_days | ✅ | 1.0 |
| 4 | google_blog_products | Google Blog — Products | P1 | https://blog.google/products/ | every_2_days | ✅ | 1.0 |
| 5 | microsoft_surface_blog | Microsoft Surface Blog | P1 | https://blogs.windows.com/devices/ | every_2_days | ✅ | 1.0 |
| 6 | meta_newsroom | Meta Newsroom | P1 | https://about.fb.com/news/ | every_2_days | ✅ | 1.0 |
| 7 | nothing_newsroom | Nothing Newsroom | P1 | https://nothing.tech/pages/newsroom | every_2_days | ✅ | 1.0 |
| 8 | teenage_engineering | Teenage Engineering | P1 | https://teenage.engineering/ | every_2_days | ✅ | 1.0 |
| 9 | bang_olufsen | Bang & Olufsen | P1 | https://www.bang-olufsen.com/ | every_2_days | ✅ | 1.0 |
| 10 | bose_press_room | Bose Press Room | P1 | https://www.bose.com/pressroom | every_2_days | ✅ | 1.0 |
| 11 | sonos_newsroom | Sonos Newsroom | P1 | https://newsroom.sonos.com/ | every_2_days | ✅ | 1.0 |
| 12 | logitech_newsroom | Logitech Newsroom | P1 | https://news.logitech.com/ | every_2_days | ✅ | 1.0 |
| 13 | garmin_newsroom | Garmin Newsroom | P1 | https://www.garmin.com/en-US/newsroom/ | every_2_days | ✅ | 1.0 |
| 14 | gopro_news | GoPro News | P1 | https://gopro.com/en/us/news | every_2_days | ✅ | 1.0 |
| 15 | leica_camera | Leica Camera | P1 | https://leica-camera.com/ | every_2_days | ✅ | 1.0 |
| 16 | canon_global_news | Canon Global News | P1 | https://global.canon/en/news/ | every_2_days | ✅ | 1.0 |
| 17 | nikon_news | Nikon News | P1 | https://www.nikon.com/company/news/ | every_2_days | ✅ | 1.0 |
| 18 | fujifilm_news | Fujifilm News | P1 | https://www.fujifilm.com/us/en/news | every_2_days | ✅ | 1.0 |
| 19 | framework_blog | Framework Blog | P1 | https://frame.work/blog | every_2_days | ✅ | 1.0 |
| 20 | consumer | 华为消费者业务新闻中心 | P1 | https://consumer.huawei.com/en/press/ | every_2_days | ✅ | 1.0 |
| 21 | mi | 小米全球活动与发布 | P1 | https://www.mi.com/global/event/ | every_2_days | ✅ | 1.0 |
| 22 | honor | 荣耀新闻 | P1 | https://www.honor.com/global/news/ | every_2_days | ✅ | 1.0 |
| 23 | oppo_newsroom | OPPO Newsroom | P1 | https://www.oppo.com/en/newsroom/ | every_2_days | ✅ | 1.0 |
| 24 | vivo_news | vivo News | P1 | https://www.vivo.com/en/about-vivo/news | every_2_days | ✅ | 1.0 |
| 25 | realme_newsroom | realme Newsroom | P1 | https://www.realme.com/global/newsroom | every_2_days | ✅ | 1.0 |
| 26 | lenovo_storyhub | Lenovo StoryHub | P1 | https://news.lenovo.com/ | every_2_days | ✅ | 1.0 |
| 27 | dji_media_center | DJI Media Center | P1 | https://www.dji.com/newsroom | every_2_days | ✅ | 1.0 |
| 28 | insta360_blog | Insta360 Blog | P1 | https://www.insta360.com/blog/ | every_2_days | ✅ | 1.0 |
| 29 | anker_news | Anker News | P1 | https://www.anker.com/blogs/news | every_2_days | ✅ | 1.0 |
| 30 | cmf_by_nothing | CMF by Nothing | P1 | https://cmf.tech/ | every_2_days | ✅ | 1.0 |
| 31 | dyson_newsroom | Dyson Newsroom | P1 | https://www.dyson.com/discover/news | every_2_days | ✅ | 1.0 |
| 32 | braun | Braun | P1 | https://www.braun.com/ | every_2_days | ✅ | 1.0 |
| 33 | philips_news_center | Philips News Center | P1 | https://www.philips.com/a-w/about/news/home.html | every_2_days | ✅ | 1.0 |
| 34 | bosch_press_portal | Bosch Press Portal | P1 | https://www.bosch-presse.de/pressportal/de/en/ | every_2_days | ✅ | 1.0 |
| 35 | miele_press | Miele Press | P1 | https://www.miele.com/en/com/press-218.htm | every_2_days | ✅ | 1.0 |
| 36 | siemens_home_appliances | Siemens Home Appliances | P1 | https://www.siemens-home.bsh-group.com/ | every_2_days | ✅ | 1.0 |
| 37 | gaggenau | Gaggenau | P1 | https://www.gaggenau.com/ | every_2_days | ✅ | 1.0 |
| 38 | electrolux_group_newsroom | Electrolux Group Newsroom | P1 | https://www.electroluxgroup.com/en/newsroom/ | every_2_days | ✅ | 1.0 |
| 39 | lg_newsroom | LG Newsroom | P1 | https://www.lgnewsroom.com/ | every_2_days | ✅ | 1.0 |
| 40 | panasonic_newsroom | Panasonic Newsroom | P1 | https://news.panasonic.com/global/ | every_2_days | ✅ | 1.0 |
| 41 | balmuda | BALMUDA | P1 | https://www.balmuda.com/ | every_2_days | ✅ | 1.0 |
| 42 | muji | MUJI | P1 | https://www.muji.com/ | every_2_days | ✅ | 1.0 |
| 43 | ikea_newsroom | IKEA Newsroom | P1 | https://www.ikea.com/global/en/newsroom/ | every_2_days | ✅ | 1.0 |
| 44 | haier | 海尔全球新闻 | P1 | https://www.haier.com/global/press-events/ | every_2_days | ✅ | 1.0 |
| 45 | midea-group | 美的集团新闻 | P1 | https://www.midea-group.com/our-businesses/news | every_2_days | ✅ | 1.0 |
| 46 | fotile | 方太 | P1 | https://www.fotile.com/ | every_2_days | ✅ | 1.0 |
| 47 | robam | 老板电器 | P1 | https://www.robam.com/ | every_2_days | ✅ | 1.0 |
| 48 | newsroom | 石头科技 Newsroom | P1 | https://global.roborock.com/pages/newsroom | every_2_days | ✅ | 1.0 |
| 49 | ecovacs | 科沃斯 | P1 | https://www.ecovacs.com/ | every_2_days | ✅ | 1.0 |
| 50 | dreametech | 追觅科技 | P1 | https://www.dreametech.com/ | every_2_days | ✅ | 1.0 |
| 51 | global | 添可 | P1 | https://global.tineco.com/ | every_2_days | ✅ | 1.0 |
| 52 | narwal | 云鲸 | P1 | https://www.narwal.com/ | every_2_days | ✅ | 1.0 |
| 53 | mi_2 | 米家 | P1 | https://www.mi.com/global/smart-home/ | every_2_days | ✅ | 1.0 |
| 54 | bears | 小熊电器 | P1 | https://www.bears.com.cn/ | every_2_days | ✅ | 1.0 |
| 55 | herman_miller | Herman Miller | P1 | https://www.hermanmiller.com/ | every_2_days | ✅ | 1.0 |
| 56 | knoll | Knoll | P1 | https://www.knoll.com/ | every_2_days | ✅ | 1.0 |
| 57 | vitra | Vitra | P1 | https://www.vitra.com/ | every_2_days | ✅ | 1.0 |
| 58 | steelcase | Steelcase | P1 | https://www.steelcase.com/ | every_2_days | ✅ | 1.0 |
| 59 | haworth | Haworth | P1 | https://www.haworth.com/ | every_2_days | ✅ | 1.0 |
| 60 | humanscale | Humanscale | P1 | https://www.humanscale.com/ | every_2_days | ✅ | 1.0 |
| 61 | usm | USM | P1 | https://www.usm.com/ | every_2_days | ✅ | 1.0 |
| 62 | fritz_hansen | Fritz Hansen | P1 | https://www.fritzhansen.com/ | every_2_days | ✅ | 1.0 |
| 63 | hay | HAY | P1 | https://www.hay.com/ | every_2_days | ✅ | 1.0 |
| 64 | muuto | Muuto | P1 | https://www.muuto.com/ | every_2_days | ✅ | 1.0 |
| 65 | artek | Artek | P1 | https://www.artek.fi/ | every_2_days | ✅ | 1.0 |
| 66 | cassina | Cassina | P1 | https://www.cassina.com/ | every_2_days | ✅ | 1.0 |
| 67 | b_b_italia | B&B Italia | P1 | https://www.bebitalia.com/ | every_2_days | ✅ | 1.0 |
| 68 | kartell | Kartell | P1 | https://www.kartell.com/ | every_2_days | ✅ | 1.0 |
| 69 | magis | Magis | P1 | https://www.magisdesign.com/ | every_2_days | ✅ | 1.0 |
| 70 | molteni_c | Molteni&C | P1 | https://www.molteni.it/ | every_2_days | ✅ | 1.0 |
| 71 | poliform | Poliform | P1 | https://www.poliform.it/ | every_2_days | ✅ | 1.0 |
| 72 | flos | Flos | P1 | https://flos.com/ | every_2_days | ✅ | 1.0 |
| 73 | artemide | Artemide | P1 | https://www.artemide.com/ | every_2_days | ✅ | 1.0 |
| 74 | louis_poulsen | Louis Poulsen | P1 | https://www.louispoulsen.com/ | every_2_days | ✅ | 1.0 |
| 75 | tradition | &Tradition | P1 | https://andtradition.com/ | every_2_days | ✅ | 1.0 |
| 76 | bosch_professional | Bosch Professional | P1 | https://www.bosch-professional.com/ | every_2_days | ✅ | 1.0 |
| 77 | hilti | Hilti | P1 | https://www.hilti.com/ | every_2_days | ✅ | 1.0 |
| 78 | festool | Festool | P1 | https://www.festool.com/ | every_2_days | ✅ | 1.0 |
| 79 | makita | Makita | P1 | https://www.makita.biz/ | every_2_days | ✅ | 1.0 |
| 80 | dewalt | DeWalt | P1 | https://www.dewalt.com/ | every_2_days | ✅ | 1.0 |
| 81 | milwaukee_tool | Milwaukee Tool | P1 | https://www.milwaukeetool.com/ | every_2_days | ✅ | 1.0 |
| 82 | stihl | STIHL | P1 | https://www.stihl.com/ | every_2_days | ✅ | 1.0 |
| 83 | husqvarna | Husqvarna | P1 | https://www.husqvarna.com/ | every_2_days | ✅ | 1.0 |
| 84 | leatherman | Leatherman | P1 | https://www.leatherman.com/ | every_2_days | ✅ | 1.0 |
| 85 | victorinox | Victorinox | P1 | https://www.victorinox.com/ | every_2_days | ✅ | 1.0 |
| 86 | stanley | Stanley | P1 | https://www.stanleytools.com/ | every_2_days | ✅ | 1.0 |
| 87 | pelican | Pelican | P1 | https://www.pelican.com/ | every_2_days | ✅ | 1.0 |
| 88 | yeti | YETI | P1 | https://www.yeti.com/ | every_2_days | ✅ | 1.0 |
| 89 | patagonia | Patagonia | P1 | https://www.patagonia.com/ | every_2_days | ✅ | 1.0 |
| 90 | arc_teryx | Arc'teryx | P1 | https://arcteryx.com/ | every_2_days | ✅ | 1.0 |
| 91 | the_north_face | The North Face | P1 | https://www.thenorthface.com/ | every_2_days | ✅ | 1.0 |
| 92 | snow_peak | Snow Peak | P1 | https://www.snowpeak.com/ | every_2_days | ✅ | 1.0 |
| 93 | bmw_group_pressclub | BMW Group PressClub | P1 | https://www.press.bmwgroup.com/ | every_2_days | ✅ | 1.0 |
| 94 | mini_pressclub | MINI PressClub | P1 | https://www.press.bmwgroup.com/global/article/topic/4186/mini | every_2_days | ✅ | 1.0 |
| 95 | mercedes_benz_media | Mercedes-Benz Media | P1 | https://media.mercedes-benz.com/ | every_2_days | ✅ | 1.0 |
| 96 | audi_mediacenter | Audi MediaCenter | P1 | https://www.audi-mediacenter.com/ | every_2_days | ✅ | 1.0 |
| 97 | porsche_newsroom | Porsche Newsroom | P1 | https://newsroom.porsche.com/ | every_2_days | ✅ | 1.0 |
| 98 | volvo_cars_media | Volvo Cars Media | P1 | https://www.media.volvocars.com/ | every_2_days | ✅ | 1.0 |
| 99 | polestar_media | Polestar Media | P1 | https://media.polestar.com/ | every_2_days | ✅ | 1.0 |
| 100 | hyundai_newsroom | Hyundai Newsroom | P1 | https://www.hyundainews.com/ | every_2_days | ✅ | 1.0 |
| 101 | kia_global_media_center | Kia Global Media Center | P1 | https://www.kianewscenter.com/ | every_2_days | ✅ | 1.0 |
| 102 | toyota_global_newsroom | Toyota Global Newsroom | P1 | https://global.toyota/en/newsroom/ | every_2_days | ✅ | 1.0 |
| 103 | honda_global_newsroom | Honda Global Newsroom | P1 | https://global.honda/en/newsroom/ | every_2_days | ✅ | 1.0 |
| 104 | nissan_global_newsroom | Nissan Global Newsroom | P1 | https://global.nissannews.com/ | every_2_days | ✅ | 1.0 |
| 105 | yamaha_motor_news | Yamaha Motor News | P1 | https://global.yamaha-motor.com/news/ | every_2_days | ✅ | 1.0 |
| 106 | tesla | Tesla | P1 | https://www.tesla.com/ | every_2_days | ✅ | 1.0 |
| 107 | rivian_stories | Rivian Stories | P1 | https://stories.rivian.com/ | every_2_days | ✅ | 1.0 |
| 108 | lucid_media_room | Lucid Media Room | P1 | https://media.lucidmotors.com/ | every_2_days | ✅ | 1.0 |
| 109 | nio | 蔚来新闻 | P1 | https://www.nio.com/news | every_2_days | ✅ | 1.0 |
| 110 | lixiang | 理想汽车新闻 | P1 | https://www.lixiang.com/news | every_2_days | ✅ | 1.0 |
| 111 | xpeng | 小鹏汽车新闻 | P1 | https://www.xpeng.com/news | every_2_days | ✅ | 1.0 |
| 112 | zeekrglobal | 极氪 | P1 | https://www.zeekrglobal.com/ | every_2_days | ✅ | 1.0 |
| 113 | xiaomiev | 小米汽车 | P1 | https://www.xiaomiev.com/ | every_2_days | ✅ | 1.0 |
| 114 | bydglobal | 比亚迪新闻 | P1 | https://www.bydglobal.com/en/news | every_2_days | ✅ | 1.0 |
| 115 | yangwangauto | 仰望汽车 | P1 | https://www.yangwangauto.com/ | every_2_days | ✅ | 1.0 |
| 116 | fangchengbao | 方程豹 | P1 | https://www.fangchengbao.com/ | every_2_days | ✅ | 1.0 |
| 117 | global_2 | 吉利汽车 | P1 | https://global.geely.com/ | every_2_days | ✅ | 1.0 |
| 118 | avatr | 阿维塔 | P1 | https://www.avatr.com/ | every_2_days | ✅ | 1.0 |
| 119 | voyah | 岚图汽车 | P1 | https://www.voyah.com.cn/ | every_2_days | ✅ | 1.0 |
| 120 | philips_healthcare | Philips Healthcare | P1 | https://www.usa.philips.com/healthcare | every_2_days | ✅ | 1.0 |
| 121 | siemens_healthineers_press_center | Siemens Healthineers Press Center | P1 | https://www.siemens-healthineers.com/press | every_2_days | ✅ | 1.0 |
| 122 | ge_healthcare_newsroom | GE HealthCare Newsroom | P1 | https://www.gehealthcare.com/about/newsroom | every_2_days | ✅ | 1.0 |
| 123 | medtronic_newsroom | Medtronic Newsroom | P1 | https://news.medtronic.com/ | every_2_days | ✅ | 1.0 |
| 124 | stryker_news | Stryker News | P1 | https://www.stryker.com/us/en/about/news.html | every_2_days | ✅ | 1.0 |
| 125 | dr_ger_press_center | Dräger Press Center | P1 | https://www.draeger.com/en-us_us/Press-Center | every_2_days | ✅ | 1.0 |
| 126 | leica_microsystems_news | Leica Microsystems News | P1 | https://www.leica-microsystems.com/company/news/ | every_2_days | ✅ | 1.0 |
| 127 | zebra_technologies_newsroom | Zebra Technologies Newsroom | P1 | https://www.zebra.com/us/en/about-zebra/newsroom.html | every_2_days | ✅ | 1.0 |
| 128 | honeywell_news | Honeywell News | P1 | https://www.honeywell.com/us/en/news | every_2_days | ✅ | 1.0 |
| 129 | fluke_news | Fluke News | P1 | https://www.fluke.com/en-us/learn/blog | every_2_days | ✅ | 1.0 |
| 130 | k_rcher | Kärcher | P1 | https://www.kaercher.com/ | every_2_days | ✅ | 1.0 |
| 131 | abb_news | ABB News | P1 | https://global.abb/group/en/media | every_2_days | ✅ | 1.0 |
| 132 | kuka_press | KUKA Press | P1 | https://www.kuka.com/en-de/company/press | every_2_days | ✅ | 1.0 |
| 133 | universal_robots_news | Universal Robots News | P1 | https://www.universal-robots.com/news-and-media/ | every_2_days | ✅ | 1.0 |
| 134 | boston_dynamics_blog | Boston Dynamics Blog | P1 | https://bostondynamics.com/blog/ | every_2_days | ✅ | 1.0 |

## 按优先级汇总

### P0 (4 个)

- **Core77** () — https://www.core77.com/
- **Dezeen** () — https://www.dezeen.com/
- **designboom** () — https://www.designboom.com/
- **Yanko Design** () — https://www.yankodesign.com/

### P1 (134 个)

- **Apple Newsroom** () — https://www.apple.com/newsroom/
- **Samsung Global Newsroom** () — https://news.samsung.com/global/
- **Sony Design** () — https://www.sony.com/en/SonyInfo/design/
- **Google Blog — Products** () — https://blog.google/products/
- **Microsoft Surface Blog** () — https://blogs.windows.com/devices/
- **Meta Newsroom** () — https://about.fb.com/news/
- **Nothing Newsroom** () — https://nothing.tech/pages/newsroom
- **Teenage Engineering** () — https://teenage.engineering/
- **Bang & Olufsen** () — https://www.bang-olufsen.com/
- **Bose Press Room** () — https://www.bose.com/pressroom
- **Sonos Newsroom** () — https://newsroom.sonos.com/
- **Logitech Newsroom** () — https://news.logitech.com/
- **Garmin Newsroom** () — https://www.garmin.com/en-US/newsroom/
- **GoPro News** () — https://gopro.com/en/us/news
- **Leica Camera** () — https://leica-camera.com/
- **Canon Global News** () — https://global.canon/en/news/
- **Nikon News** () — https://www.nikon.com/company/news/
- **Fujifilm News** () — https://www.fujifilm.com/us/en/news
- **Framework Blog** () — https://frame.work/blog
- **华为消费者业务新闻中心** () — https://consumer.huawei.com/en/press/
- **小米全球活动与发布** () — https://www.mi.com/global/event/
- **荣耀新闻** () — https://www.honor.com/global/news/
- **OPPO Newsroom** () — https://www.oppo.com/en/newsroom/
- **vivo News** () — https://www.vivo.com/en/about-vivo/news
- **realme Newsroom** () — https://www.realme.com/global/newsroom
- **Lenovo StoryHub** () — https://news.lenovo.com/
- **DJI Media Center** () — https://www.dji.com/newsroom
- **Insta360 Blog** () — https://www.insta360.com/blog/
- **Anker News** () — https://www.anker.com/blogs/news
- **CMF by Nothing** () — https://cmf.tech/
- **Dyson Newsroom** () — https://www.dyson.com/discover/news
- **Braun** () — https://www.braun.com/
- **Philips News Center** () — https://www.philips.com/a-w/about/news/home.html
- **Bosch Press Portal** () — https://www.bosch-presse.de/pressportal/de/en/
- **Miele Press** () — https://www.miele.com/en/com/press-218.htm
- **Siemens Home Appliances** () — https://www.siemens-home.bsh-group.com/
- **Gaggenau** () — https://www.gaggenau.com/
- **Electrolux Group Newsroom** () — https://www.electroluxgroup.com/en/newsroom/
- **LG Newsroom** () — https://www.lgnewsroom.com/
- **Panasonic Newsroom** () — https://news.panasonic.com/global/
- **BALMUDA** () — https://www.balmuda.com/
- **MUJI** () — https://www.muji.com/
- **IKEA Newsroom** () — https://www.ikea.com/global/en/newsroom/
- **海尔全球新闻** () — https://www.haier.com/global/press-events/
- **美的集团新闻** () — https://www.midea-group.com/our-businesses/news
- **方太** () — https://www.fotile.com/
- **老板电器** () — https://www.robam.com/
- **石头科技 Newsroom** () — https://global.roborock.com/pages/newsroom
- **科沃斯** () — https://www.ecovacs.com/
- **追觅科技** () — https://www.dreametech.com/
- **添可** () — https://global.tineco.com/
- **云鲸** () — https://www.narwal.com/
- **米家** () — https://www.mi.com/global/smart-home/
- **小熊电器** () — https://www.bears.com.cn/
- **Herman Miller** () — https://www.hermanmiller.com/
- **Knoll** () — https://www.knoll.com/
- **Vitra** () — https://www.vitra.com/
- **Steelcase** () — https://www.steelcase.com/
- **Haworth** () — https://www.haworth.com/
- **Humanscale** () — https://www.humanscale.com/
- **USM** () — https://www.usm.com/
- **Fritz Hansen** () — https://www.fritzhansen.com/
- **HAY** () — https://www.hay.com/
- **Muuto** () — https://www.muuto.com/
- **Artek** () — https://www.artek.fi/
- **Cassina** () — https://www.cassina.com/
- **B&B Italia** () — https://www.bebitalia.com/
- **Kartell** () — https://www.kartell.com/
- **Magis** () — https://www.magisdesign.com/
- **Molteni&C** () — https://www.molteni.it/
- **Poliform** () — https://www.poliform.it/
- **Flos** () — https://flos.com/
- **Artemide** () — https://www.artemide.com/
- **Louis Poulsen** () — https://www.louispoulsen.com/
- **&Tradition** () — https://andtradition.com/
- **Bosch Professional** () — https://www.bosch-professional.com/
- **Hilti** () — https://www.hilti.com/
- **Festool** () — https://www.festool.com/
- **Makita** () — https://www.makita.biz/
- **DeWalt** () — https://www.dewalt.com/
- **Milwaukee Tool** () — https://www.milwaukeetool.com/
- **STIHL** () — https://www.stihl.com/
- **Husqvarna** () — https://www.husqvarna.com/
- **Leatherman** () — https://www.leatherman.com/
- **Victorinox** () — https://www.victorinox.com/
- **Stanley** () — https://www.stanleytools.com/
- **Pelican** () — https://www.pelican.com/
- **YETI** () — https://www.yeti.com/
- **Patagonia** () — https://www.patagonia.com/
- **Arc'teryx** () — https://arcteryx.com/
- **The North Face** () — https://www.thenorthface.com/
- **Snow Peak** () — https://www.snowpeak.com/
- **BMW Group PressClub** () — https://www.press.bmwgroup.com/
- **MINI PressClub** () — https://www.press.bmwgroup.com/global/article/topic/4186/mini
- **Mercedes-Benz Media** () — https://media.mercedes-benz.com/
- **Audi MediaCenter** () — https://www.audi-mediacenter.com/
- **Porsche Newsroom** () — https://newsroom.porsche.com/
- **Volvo Cars Media** () — https://www.media.volvocars.com/
- **Polestar Media** () — https://media.polestar.com/
- **Hyundai Newsroom** () — https://www.hyundainews.com/
- **Kia Global Media Center** () — https://www.kianewscenter.com/
- **Toyota Global Newsroom** () — https://global.toyota/en/newsroom/
- **Honda Global Newsroom** () — https://global.honda/en/newsroom/
- **Nissan Global Newsroom** () — https://global.nissannews.com/
- **Yamaha Motor News** () — https://global.yamaha-motor.com/news/
- **Tesla** () — https://www.tesla.com/
- **Rivian Stories** () — https://stories.rivian.com/
- **Lucid Media Room** () — https://media.lucidmotors.com/
- **蔚来新闻** () — https://www.nio.com/news
- **理想汽车新闻** () — https://www.lixiang.com/news
- **小鹏汽车新闻** () — https://www.xpeng.com/news
- **极氪** () — https://www.zeekrglobal.com/
- **小米汽车** () — https://www.xiaomiev.com/
- **比亚迪新闻** () — https://www.bydglobal.com/en/news
- **仰望汽车** () — https://www.yangwangauto.com/
- **方程豹** () — https://www.fangchengbao.com/
- **吉利汽车** () — https://global.geely.com/
- **阿维塔** () — https://www.avatr.com/
- **岚图汽车** () — https://www.voyah.com.cn/
- **Philips Healthcare** () — https://www.usa.philips.com/healthcare
- **Siemens Healthineers Press Center** () — https://www.siemens-healthineers.com/press
- **GE HealthCare Newsroom** () — https://www.gehealthcare.com/about/newsroom
- **Medtronic Newsroom** () — https://news.medtronic.com/
- **Stryker News** () — https://www.stryker.com/us/en/about/news.html
- **Dräger Press Center** () — https://www.draeger.com/en-us_us/Press-Center
- **Leica Microsystems News** () — https://www.leica-microsystems.com/company/news/
- **Zebra Technologies Newsroom** () — https://www.zebra.com/us/en/about-zebra/newsroom.html
- **Honeywell News** () — https://www.honeywell.com/us/en/news
- **Fluke News** () — https://www.fluke.com/en-us/learn/blog
- **Kärcher** () — https://www.kaercher.com/
- **ABB News** () — https://global.abb/group/en/media
- **KUKA Press** () — https://www.kuka.com/en-de/company/press
- **Universal Robots News** () — https://www.universal-robots.com/news-and-media/
- **Boston Dynamics Blog** () — https://bostondynamics.com/blog/

### P2 (103 个)

- **Wallpaper\*** () — https://www.wallpaper.com/
- **Design Milk** () — https://design-milk.com/
- **Architonic** () — https://www.architonic.com/
- **Design Week** () — https://www.designweek.co.uk/
- **Fast Company Design** () — https://www.fastcompany.com/co-design
- **The Verge** () — https://www.theverge.com/
- **Engadget** () — https://www.engadget.com/
- **TechCrunch** () — https://techcrunch.com/
- **New Atlas** () — https://newatlas.com/
- **Auto & Design** () — https://autodesignmagazine.com/
- **Car Design News** () — https://www.cardesignnews.com/
- **FORM** () — https://form.de/
- **FRAME** () — https://frameweb.com/
- **Domus** () — https://www.domusweb.it/
- **iF Design Award** () — https://ifdesign.com/
- **Red Dot Design Award** () — https://www.red-dot.org/
- **IDEA / IDSA** () — https://www.idsa.org/idea/
- **German Design Award** () — https://www.german-design-award.com/
- **Good Design Award Japan** () — https://www.g-mark.org/
- **Chicago Good Design Awards** () — https://www.good-designawards.com/
- **Dezeen Awards** () — https://www.dezeen.com/awards/
- **A' Design Award** () — https://competition.adesignaward.com/
- **James Dyson Award** () — https://www.jamesdysonaward.org/
- **Lexus Design Award** () — https://www.lexusdesignaward.com/
- **BraunPrize** () — https://www.braun.com/global/en/braun-prize.html
- **CMF Design Award** () — https://www.cmfdesignaward.com/
- **CES** () — https://www.ces.tech/
- **MWC Barcelona** () — https://www.mwcbarcelona.com/
- **IFA Berlin** () — https://www.ifa-berlin.com/
- **Computex** () — https://www.computextaipei.com.tw/
- **NAB Show** () — https://www.nabshow.com/
- **Salone del Mobile Milano** () — https://www.salonemilano.it/
- **Fuorisalone** () — https://www.fuorisalone.it/
- **3 Days of Design** () — https://www.3daysofdesign.dk/
- **Maison&Objet** () — https://www.maison-objet.com/
- **Stockholm Furniture Fair** () — https://stockholmfurniturefair.se/
- **IMM Cologne** () — https://www.imm-cologne.com/
- **NeoCon** () — https://neocon.com/
- **Clerkenwell Design Week** () — https://www.clerkenwelldesignweek.com/
- **IAA Mobility** () — https://www.iaa-mobility.com/
- **Japan Mobility Show** () — https://www.japan-mobility-show.com/
- **Auto Shanghai** () — https://www.autoshanghai.org/
- **Beijing Auto Show** () — https://www.autochinashow.org/
- **EICMA** () — https://www.eicma.it/
- **Eurobike** () — https://www.eurobike.com/
- **AWE 中国家电及消费电子博览会** () — https://www.awe.com.cn/
- **Furniture China** () — https://www.furniture-china.cn/
- **深圳国际工业设计大展** () — https://www.szdif.com/
- **设计上海** () — https://www.designshanghai.com/
- **广州设计周** () — https://www.gzdesignweek.com/
- **世界设计之都大会 WDCC** () — https://www.wdcc2023.com/
- **ChinaJoy** () — https://www.chinajoy.net/
- **IDEO** () — https://www.ideo.com/
- **frog** () — https://www.frog.co/
- **Designworks** () — https://www.bmwgroupdesignworks.com/
- **Lunar** () — https://www.lunar.com/
- **fuseproject** () — https://fuseproject.com/
- **LAYER** () — https://layerdesign.com/
- **Map Project Office** () — https://mapprojectoffice.com/
- **Seymourpowell** () — https://www.seymourpowell.com/
- **PriestmanGoode** () — https://www.priestmangoode.com/
- **Pentagram** () — https://www.pentagram.com/
- **Ammunition** () — https://ammunitiongroup.com/
- **Whipsaw** () — https://whipsaw.com/
- **NewDealDesign** () — https://newdealdesign.com/
- **TEAMS Design** () — https://www.teamsdesign.com/
- **Veryday** () — https://veryday.com/
- **KISKA** () — https://kiska.com/
- **Astro Studios** () — https://astrostudios.com/
- **nendo** () — https://www.nendo.jp/
- **Naoto Fukasawa Design** () — https://naotofukasawa.com/
- **Studio F. A. Porsche** () — https://www.studiofaporsche.com/
- **洛可可设计** () — https://www.lkkdesign.com/
- **浪尖设计** () — https://www.artopgroup.com/
- **木马设计** () — https://www.moomadesign.com/
- **佳简几何** () — https://www.xivo-design.com/
- **YANG DESIGN** () — https://www.yang-design.com/
- **GK Design Group** () — https://www.gk-design.co.jp/
- **Tangible** () — https://tangible.co.jp/
- **Native Design** () — https://www.native.com/
- **MaterialDistrict** () — https://materialdistrict.com/
- **Material ConneXion** () — https://materialconnexion.com/
- **Materiom** () — https://materiom.org/
- **Matmatch** () — https://matmatch.com/
- **BASF Designfabrik** () — https://designfabrik.basf.com/
- **Covestro CMF** () — https://solutions.covestro.com/
- **SABIC** () — https://www.sabic.com/
- **3M Design** () — https://www.3m.com/3M/en_US/design-us/
- **Eastman** () — https://www.eastman.com/
- **Coloro** () — https://www.coloro.com/
- **WGSN** () — https://www.wgsn.com/
- **Pantone** () — https://www.pantone.com/
- **SpecialChem** () — https://www.specialchem.com/
- **Additive Manufacturing Media** () — https://www.additivemanufacturing.media/
- **Protolabs** () — https://www.protolabs.com/
- **Xometry** () — https://www.xometry.com/
- **Fictiv** () — https://www.fictiv.com/
- **Hubs** () — https://www.hubs.com/
- **Formlabs** () — https://formlabs.com/
- **Stratasys** () — https://www.stratasys.com/
- **Materialise** () — https://www.materialise.com/
- **Carbon** () — https://www.carbon3d.com/
- **HP 3D Printing** () — https://www.hp.com/us-en/printers/3d-printers.html

## 按检查频率汇总

### daily (18 个)

- **Core77** ()
- **Dezeen** ()
- **designboom** ()
- **Yanko Design** ()
- **Wallpaper\*** ()
- **Design Milk** ()
- **Architonic** ()
- **Design Week** ()
- **Fast Company Design** ()
- **The Verge** ()
- **Engadget** ()
- **TechCrunch** ()
- **New Atlas** ()
- **Auto & Design** ()
- **Car Design News** ()
- **FORM** ()
- **FRAME** ()
- **Domus** ()

### every_2_days (134 个)

- **Apple Newsroom** ()
- **Samsung Global Newsroom** ()
- **Sony Design** ()
- **Google Blog — Products** ()
- **Microsoft Surface Blog** ()
- **Meta Newsroom** ()
- **Nothing Newsroom** ()
- **Teenage Engineering** ()
- **Bang & Olufsen** ()
- **Bose Press Room** ()
- **Sonos Newsroom** ()
- **Logitech Newsroom** ()
- **Garmin Newsroom** ()
- **GoPro News** ()
- **Leica Camera** ()
- **Canon Global News** ()
- **Nikon News** ()
- **Fujifilm News** ()
- **Framework Blog** ()
- **华为消费者业务新闻中心** ()
- **小米全球活动与发布** ()
- **荣耀新闻** ()
- **OPPO Newsroom** ()
- **vivo News** ()
- **realme Newsroom** ()
- **Lenovo StoryHub** ()
- **DJI Media Center** ()
- **Insta360 Blog** ()
- **Anker News** ()
- **CMF by Nothing** ()
- **Dyson Newsroom** ()
- **Braun** ()
- **Philips News Center** ()
- **Bosch Press Portal** ()
- **Miele Press** ()
- **Siemens Home Appliances** ()
- **Gaggenau** ()
- **Electrolux Group Newsroom** ()
- **LG Newsroom** ()
- **Panasonic Newsroom** ()
- **BALMUDA** ()
- **MUJI** ()
- **IKEA Newsroom** ()
- **海尔全球新闻** ()
- **美的集团新闻** ()
- **方太** ()
- **老板电器** ()
- **石头科技 Newsroom** ()
- **科沃斯** ()
- **追觅科技** ()
- **添可** ()
- **云鲸** ()
- **米家** ()
- **小熊电器** ()
- **Herman Miller** ()
- **Knoll** ()
- **Vitra** ()
- **Steelcase** ()
- **Haworth** ()
- **Humanscale** ()
- **USM** ()
- **Fritz Hansen** ()
- **HAY** ()
- **Muuto** ()
- **Artek** ()
- **Cassina** ()
- **B&B Italia** ()
- **Kartell** ()
- **Magis** ()
- **Molteni&C** ()
- **Poliform** ()
- **Flos** ()
- **Artemide** ()
- **Louis Poulsen** ()
- **&Tradition** ()
- **Bosch Professional** ()
- **Hilti** ()
- **Festool** ()
- **Makita** ()
- **DeWalt** ()
- **Milwaukee Tool** ()
- **STIHL** ()
- **Husqvarna** ()
- **Leatherman** ()
- **Victorinox** ()
- **Stanley** ()
- **Pelican** ()
- **YETI** ()
- **Patagonia** ()
- **Arc'teryx** ()
- **The North Face** ()
- **Snow Peak** ()
- **BMW Group PressClub** ()
- **MINI PressClub** ()
- **Mercedes-Benz Media** ()
- **Audi MediaCenter** ()
- **Porsche Newsroom** ()
- **Volvo Cars Media** ()
- **Polestar Media** ()
- **Hyundai Newsroom** ()
- **Kia Global Media Center** ()
- **Toyota Global Newsroom** ()
- **Honda Global Newsroom** ()
- **Nissan Global Newsroom** ()
- **Yamaha Motor News** ()
- **Tesla** ()
- **Rivian Stories** ()
- **Lucid Media Room** ()
- **蔚来新闻** ()
- **理想汽车新闻** ()
- **小鹏汽车新闻** ()
- **极氪** ()
- **小米汽车** ()
- **比亚迪新闻** ()
- **仰望汽车** ()
- **方程豹** ()
- **吉利汽车** ()
- **阿维塔** ()
- **岚图汽车** ()
- **Philips Healthcare** ()
- **Siemens Healthineers Press Center** ()
- **GE HealthCare Newsroom** ()
- **Medtronic Newsroom** ()
- **Stryker News** ()
- **Dräger Press Center** ()
- **Leica Microsystems News** ()
- **Zebra Technologies Newsroom** ()
- **Honeywell News** ()
- **Fluke News** ()
- **Kärcher** ()
- **ABB News** ()
- **KUKA Press** ()
- **Universal Robots News** ()
- **Boston Dynamics Blog** ()

### weekly (89 个)

- **iF Design Award** ()
- **Red Dot Design Award** ()
- **IDEA / IDSA** ()
- **German Design Award** ()
- **Good Design Award Japan** ()
- **Chicago Good Design Awards** ()
- **Dezeen Awards** ()
- **A' Design Award** ()
- **James Dyson Award** ()
- **Lexus Design Award** ()
- **BraunPrize** ()
- **CMF Design Award** ()
- **CES** ()
- **MWC Barcelona** ()
- **IFA Berlin** ()
- **Computex** ()
- **NAB Show** ()
- **Salone del Mobile Milano** ()
- **Fuorisalone** ()
- **3 Days of Design** ()
- **Maison&Objet** ()
- **Stockholm Furniture Fair** ()
- **IMM Cologne** ()
- **NeoCon** ()
- **Clerkenwell Design Week** ()
- **IAA Mobility** ()
- **Japan Mobility Show** ()
- **Auto Shanghai** ()
- **Beijing Auto Show** ()
- **EICMA** ()
- **Eurobike** ()
- **AWE 中国家电及消费电子博览会** ()
- **Furniture China** ()
- **深圳国际工业设计大展** ()
- **设计上海** ()
- **广州设计周** ()
- **世界设计之都大会 WDCC** ()
- **ChinaJoy** ()
- **IDEO** ()
- **frog** ()
- **Designworks** ()
- **Lunar** ()
- **fuseproject** ()
- **LAYER** ()
- **Map Project Office** ()
- **Seymourpowell** ()
- **PriestmanGoode** ()
- **Pentagram** ()
- **Ammunition** ()
- **Whipsaw** ()
- **NewDealDesign** ()
- **TEAMS Design** ()
- **Veryday** ()
- **KISKA** ()
- **Astro Studios** ()
- **nendo** ()
- **Naoto Fukasawa Design** ()
- **Studio F. A. Porsche** ()
- **洛可可设计** ()
- **浪尖设计** ()
- **木马设计** ()
- **佳简几何** ()
- **YANG DESIGN** ()
- **GK Design Group** ()
- **Tangible** ()
- **Native Design** ()
- **MaterialDistrict** ()
- **Material ConneXion** ()
- **Materiom** ()
- **Matmatch** ()
- **BASF Designfabrik** ()
- **Covestro CMF** ()
- **SABIC** ()
- **3M Design** ()
- **Eastman** ()
- **Coloro** ()
- **WGSN** ()
- **Pantone** ()
- **SpecialChem** ()
- **Additive Manufacturing Media** ()
- **Protolabs** ()
- **Xometry** ()
- **Fictiv** ()
- **Hubs** ()
- **Formlabs** ()
- **Stratasys** ()
- **Materialise** ()
- **Carbon** ()
- **HP 3D Printing** ()

## 说明

- 本名单由 `config/sources.json` 自动生成，涵盖所有追踪的工业设计资讯来源。
- 来源分为设计媒体 (design_media)、官方品牌 (official_brand)、奖项 (award)、设计工作室 (studio)、材料与制造 (materials_manufacturing)、展会 (event) 等类型。
- 每个来源根据优先级和检查频率轮询，不会每天深度抓取所有站点。
- 采集方式仅限公开 RSS/Atom、Sitemap、条件 HTTP 请求和轻量 HTML 入口页发现，不绕过认证或访问控制。
- 官方品牌页面作为证据来源，不会被自动当作新品发布渠道。