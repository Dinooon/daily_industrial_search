"""Database access layer for the gallery app."""
from __future__ import annotations
import json
import sqlite3
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "db" / "gallery.db"


def get_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def _parse_json_fields(row: sqlite3.Row) -> dict[str, Any]:
    """Parse JSON array/object fields from DB row into Python types."""
    d = dict(row)
    for key in ("style_keywords", "design_drivers", "cmf_colors", "cmf_materials", "cmf_finishes"):
        if key in d and isinstance(d[key], str):
            try:
                d[key] = json.loads(d[key])
            except (json.JSONDecodeError, TypeError):
                d[key] = []
    if "ai_analysis" in d and isinstance(d["ai_analysis"], str):
        try:
            d["ai_analysis"] = json.loads(d["ai_analysis"])
        except (json.JSONDecodeError, TypeError):
            d["ai_analysis"] = {}
    return d


def get_products(
    page: int = 1,
    per_page: int = 50,
    category: str | None = None,
    source_type: str | None = None,
    brand: str | None = None,
    search: str | None = None,
) -> dict[str, Any]:
    conn = get_conn()
    where_parts: list[str] = []
    params: list[Any] = []
    if category:
        where_parts.append("category = ?")
        params.append(category)
    if source_type:
        where_parts.append("source_type = ?")
        params.append(source_type)
    if brand:
        where_parts.append("brand = ?")
        params.append(brand)
    if search:
        where_parts.append("(title LIKE ? OR description LIKE ? OR brand LIKE ?)")
        params.extend([f"%{search}%"] * 3)
    where_clause = f"WHERE {' AND '.join(where_parts)}" if where_parts else ""

    total = conn.execute(f"SELECT COUNT(*) FROM products {where_clause}", params).fetchone()[0]
    offset = (page - 1) * per_page
    rows = conn.execute(
        f"SELECT * FROM products {where_clause} ORDER BY date_collected DESC, rowid DESC LIMIT ? OFFSET ?",
        [*params, per_page, offset],
    ).fetchall()
    conn.close()

    return {
        "total": total,
        "page": page,
        "per_page": per_page,
        "total_pages": (total + per_page - 1) // per_page,
        "products": [_parse_json_fields(r) for r in rows],
    }


def get_today_products() -> list[dict[str, Any]]:
    conn = get_conn()
    import datetime
    today = datetime.date.today().isoformat()
    rows = conn.execute(
        "SELECT * FROM products WHERE date_collected = ? ORDER BY rowid DESC", (today,)
    ).fetchall()
    if not rows:
        # Fallback: latest date_collected
        rows = conn.execute(
            "SELECT * FROM products WHERE date_collected = (SELECT MAX(date_collected) FROM products) ORDER BY rowid DESC"
        ).fetchall()
    conn.close()
    return [_parse_json_fields(r) for r in rows]


def get_product_by_id(product_id: str) -> dict[str, Any] | None:
    conn = get_conn()
    row = conn.execute("SELECT * FROM products WHERE id = ?", (product_id,)).fetchone()
    conn.close()
    if row is None:
        return None
    return _parse_json_fields(row)


def get_categories() -> list[dict[str, Any]]:
    conn = get_conn()
    rows = conn.execute(
        "SELECT category, COUNT(*) as count FROM products GROUP BY category ORDER BY count DESC"
    ).fetchall()
    conn.close()
    return [{"name": r["category"], "count": r["count"]} for r in rows]


def get_sources() -> list[dict[str, Any]]:
    conn = get_conn()
    rows = conn.execute("SELECT * FROM sources ORDER BY priority, publisher").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_stats() -> dict[str, Any]:
    conn = get_conn()
    total_products = conn.execute("SELECT COUNT(*) FROM products").fetchone()[0]
    total_sources = conn.execute("SELECT COUNT(*) FROM sources").fetchone()[0]
    enabled_sources = conn.execute("SELECT COUNT(*) FROM sources WHERE enabled=1").fetchone()[0]
    categories = conn.execute(
        "SELECT category, COUNT(*) as count FROM products GROUP BY category ORDER BY count DESC"
    ).fetchall()
    brands = conn.execute(
        "SELECT COUNT(DISTINCT brand) FROM products WHERE brand IS NOT NULL AND brand != ''"
    ).fetchone()[0]
    distinct_sources = conn.execute(
        "SELECT COUNT(DISTINCT source) FROM products WHERE source IS NOT NULL AND source != ''"
    ).fetchone()[0]
    latest_date = conn.execute(
        "SELECT MAX(date_collected) FROM products"
    ).fetchone()[0]
    source_types = conn.execute(
        "SELECT source_type, COUNT(*) as count FROM products GROUP BY source_type"
    ).fetchall()
    last_run = conn.execute(
        "SELECT * FROM pipeline_runs ORDER BY id DESC LIMIT 1"
    ).fetchone()
    conn.close()
    return {
        "total_products": total_products,
        "total_sources": total_sources,
        "enabled_sources": enabled_sources,
        "total_brands": brands,
        "distinct_sources": distinct_sources,
        "categories": [{"name": r["category"], "count": r["count"]} for r in categories],
        "source_types": [{"name": r["source_type"], "count": r["count"]} for r in source_types],
        "latest_date": latest_date,
        "last_run": dict(last_run) if last_run else None,
    }


def get_all_products_flat() -> list[dict[str, Any]]:
    """Get all products without pagination, for frontend portal use."""
    conn = get_conn()
    rows = conn.execute("SELECT * FROM products ORDER BY date_collected DESC, rowid DESC").fetchall()
    conn.close()
    return [_parse_json_fields(r) for r in rows]


# --- Pipeline run helpers ---

def create_pipeline_run(run_date: str, mode: str = "auto") -> int:
    conn = get_conn()
    import datetime
    cur = conn.execute(
        "INSERT INTO pipeline_runs (run_date, started_at, status, mode) VALUES (?,?,?,?)",
        (run_date, datetime.datetime.now().isoformat(), "running", mode),
    )
    conn.commit()
    run_id = cur.lastrowid
    conn.close()
    return run_id


def update_pipeline_run(
    run_id: int,
    status: str,
    products_found: int = 0,
    products_new: int = 0,
    products_updated: int = 0,
    images_downloaded: int = 0,
    error_message: str | None = None,
    log_file: str | None = None,
):
    conn = get_conn()
    import datetime
    conn.execute(
        """UPDATE pipeline_runs SET
           finished_at=?, status=?, products_found=?, products_new=?,
           products_updated=?, images_downloaded=?, error_message=?, log_file=?
           WHERE id=?""",
        (
            datetime.datetime.now().isoformat(), status,
            products_found, products_new, products_updated, images_downloaded,
            error_message, log_file, run_id,
        ),
    )
    conn.commit()
    conn.close()


def get_pipeline_status() -> dict[str, Any] | None:
    conn = get_conn()
    row = conn.execute(
        "SELECT * FROM pipeline_runs ORDER BY id DESC LIMIT 1"
    ).fetchone()
    conn.close()
    return dict(row) if row else None


def get_pipeline_runs(limit: int = 20) -> list[dict[str, Any]]:
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM pipeline_runs ORDER BY id DESC LIMIT ?", (limit,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def upsert_product(item: dict[str, Any]) -> bool:
    """UPSERT a product from pipeline output. Returns True if new, False if updated."""
    conn = get_conn()
    pid = item.get("product_id") or item.get("id", "")
    if not pid:
        conn.close()
        return False
    existing = conn.execute("SELECT id FROM products WHERE id=?", (pid,)).fetchone()
    image_local = item.get("local_image_path", "")
    if not image_local:
        image_local = f"history_images/{pid}.jpg"
    detail_path = f"details/{pid}.html"

    # gallery_input.json uses different field names than the DB schema.
    # Provide fallbacks so collected data maps correctly.
    publisher = item.get("publisher", "")
    brand = item.get("brand", "") or publisher
    source = item.get("source", "") or publisher or item.get("source_id", "")
    is_official = item.get("official", False)
    source_type = item.get("source_type", "")
    if not source_type:
        source_type = "official_brand" if is_official else "design_media"
    description = item.get("description_zh", "") or item.get("description", "")
    image_url = item.get("image_url", "")

    def _jf(val):
        if val is None: return "[]"
        if isinstance(val, str): return val
        return json.dumps(val, ensure_ascii=False)

    conn.execute(
        """INSERT OR REPLACE INTO products
           (id, title, brand, publisher, source, source_type, category,
            description, page_url, image_url, image_local_path, detail_path,
            news_type, region, verification_status, maturity,
            style_keywords, design_drivers, cmf_colors, cmf_materials, cmf_finishes,
            ai_analysis, first_seen_date, date_collected,
            compare_visible, official)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (
            pid, item.get("title", ""), brand, publisher,
            source, source_type,
            item.get("category", "其他产品"), description,
            item.get("page_url", "") or item.get("link", ""),
            image_url, image_local, detail_path,
            item.get("news_type", "媒体新稿"), item.get("region", "全球/未标注"),
            item.get("verification_status", "needs_review"), item.get("maturity", "media_coverage"),
            _jf(item.get("style_keywords")), _jf(item.get("design_drivers")),
            _jf(item.get("cmf_colors")), _jf(item.get("cmf_materials")),
            _jf(item.get("cmf_finishes")), _jf(item.get("ai_analysis")),
            item.get("first_seen_date", ""), item.get("first_seen_date", ""),
            1 if item.get("compare_visible", True) else 0,
            1 if is_official else 0,
        ),
    )
    conn.commit()
    conn.close()
    return existing is None
