"""APScheduler integration for daily pipeline runs.

Reuses the existing collection pipeline (scripts/agent_daily_pipeline.py) and
imports results into the database.
"""
from __future__ import annotations
import json
import logging
import subprocess
import sys
from datetime import date, datetime
from pathlib import Path

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger

from . import database as db

logger = logging.getLogger(__name__)
ROOT = Path(__file__).resolve().parents[1]
SCHEDULER: BackgroundScheduler | None = None

# Run daily at 02:00 and 14:00 Beijing time (Asia/Shanghai)
# 02:00 CST = early morning auto-fetch, ready when users wake up
# 14:00 CST = afternoon catch-up
CRON_SCHEDULES = [
    {"hour": 2, "minute": 0, "id": "daily_pipeline_early_morning"},
    {"hour": 14, "minute": 0, "id": "daily_pipeline_afternoon"},
]


def run_pipeline_sync(run_id: int, run_date: str):
    """Run the collection pipeline and import results into the database.

    This function is called in a background thread by the scheduler or
    by the manual trigger endpoint.
    """
    logger.info("Pipeline run %d started for date %s", run_id, run_date)
    products_found = 0
    products_new = 0
    products_updated = 0
    images_downloaded = 0
    error_message = None

    try:
        # Try to run the agent_daily_pipeline script
        script = ROOT / "scripts" / "agent_daily_pipeline.py"
        if not script.exists():
            raise FileNotFoundError(f"Pipeline script not found: {script}")

        result = subprocess.run(
            [sys.executable, str(script), "--date", run_date, "--include-media", "--max-sources", "20"],
            cwd=str(ROOT),
            capture_output=True,
            text=True,
            timeout=600,
        )

        if result.returncode != 0:
            error_message = f"Pipeline exited with code {result.returncode}: {result.stderr[-500:]}"
            logger.error("Pipeline failed: %s", error_message)
            db.update_pipeline_run(run_id, "failed", error_message=error_message)
            return

        # Only import today's freshly collected products from gallery_input.json.
        # Never fall back to global_gallery_input.json — it contains the full
        # historical catalog, so importing it produces products_found=159,
        # products_new=0 every time.
        output_dir = ROOT / "output" / run_date
        gallery_input = output_dir / "gallery_input.json"

        if gallery_input.exists():
            data = json.loads(gallery_input.read_text(encoding="utf-8"))
            products_found = len(data)
            for item in data:
                pid = item.get("product_id") or item.get("id", "")
                if not pid:
                    continue
                if not item.get("first_seen_date"):
                    item["first_seen_date"] = run_date
                is_new = db.upsert_product(item)
                if is_new:
                    products_new += 1
                else:
                    products_updated += 1

        # Count downloaded images
        images_dir = output_dir / "images"
        if images_dir.exists():
            images_downloaded = len(list(images_dir.glob("*.jpg")))

        # Detect likely network failure: 0 products + very short duration
        # Normal pipeline takes 50-60s; completing in <20s with 0 products
        # means network requests all failed silently.
        started_at_str = db.get_conn().execute(
            "SELECT started_at FROM pipeline_runs WHERE id=?", (run_id,)
        ).fetchone()[0]
        started_at_dt = datetime.fromisoformat(started_at_str)
        finished_at = datetime.now()
        duration = (finished_at - started_at_dt).total_seconds()
        if products_found == 0 and duration < 20:
            status = "failed"
            error_message = f"Pipeline completed in {duration:.0f}s with 0 products - likely network failure"
        else:
            status = "success"

        db.update_pipeline_run(
            run_id, status,
            products_found=products_found,
            products_new=products_new,
            products_updated=products_updated,
            images_downloaded=images_downloaded,
            error_message=error_message,
        )
        logger.info(
            "Pipeline run %d %s: %d found, %d new, %d updated (%.0fs)",
            run_id, status, products_found, products_new, products_updated, duration,
        )

    except Exception as e:
        error_message = str(e)
        logger.exception("Pipeline run %d failed", run_id)
        db.update_pipeline_run(run_id, "failed", error_message=error_message)


def scheduled_pipeline_run():
    """Called by APScheduler on schedule."""
    run_date = date.today().isoformat()
    run_id = db.create_pipeline_run(run_date, mode="auto")
    run_pipeline_sync(run_id, run_date)


def get_scheduler() -> BackgroundScheduler:
    global SCHEDULER
    if SCHEDULER is not None:
        return SCHEDULER
    SCHEDULER = BackgroundScheduler()
    for sched in CRON_SCHEDULES:
        SCHEDULER.add_job(
            scheduled_pipeline_run,
            CronTrigger(hour=sched["hour"], minute=sched["minute"], timezone='Asia/Shanghai'),
            id=sched["id"],
            name=f"Daily design intelligence collection ({sched['id']})",
            replace_existing=True,
        )
    return SCHEDULER


def start_scheduler():
    scheduler = get_scheduler()
    if not scheduler.running:
        scheduler.start()
        logger.info("Scheduler started, daily runs at %s Asia/Shanghai",
                    ", ".join(f"{s['hour']:02d}:{s['minute']:02d}" for s in CRON_SCHEDULES))


def stop_scheduler():
    global SCHEDULER
    if SCHEDULER and SCHEDULER.running:
        SCHEDULER.shutdown(wait=False)
        logger.info("Scheduler stopped")
