"""FastAPI routes for the gallery app."""
from __future__ import annotations
import os
import secrets
from pathlib import Path
from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

from . import database as db

ROOT = Path(__file__).resolve().parents[1]
OUTPUT_DIR = ROOT / "output"

router = APIRouter(prefix="/api")

# Also register a top-level router (no /api prefix) for serving images
image_router = APIRouter()

# --- Simple token-based auth for pipeline trigger ---
API_TOKEN = os.environ.get("GALLERY_API_TOKEN", "")


def verify_token(request: Request):
    if not API_TOKEN:
        return  # No token configured, allow all
    token = request.headers.get("Authorization", "").replace("Bearer ", "")
    if not secrets.compare_digest(token, API_TOKEN):
        raise HTTPException(status_code=401, detail="Unauthorized")


@router.get("/products")
def list_products(
    page: int = Query(1, ge=1),
    per_page: int = Query(50, ge=1, le=500),
    category: str | None = None,
    source_type: str | None = None,
    brand: str | None = None,
    search: str | None = None,
):
    return db.get_products(page, per_page, category, source_type, brand, search)


@router.get("/products/today")
def today_products():
    products = db.get_today_products()
    return {"total": len(products), "products": products}


@router.get("/products/{product_id}")
def get_product(product_id: str):
    product = db.get_product_by_id(product_id)
    if product is None:
        raise HTTPException(status_code=404, detail="Product not found")
    return product


@router.get("/categories")
def list_categories():
    return db.get_categories()


@router.get("/sources")
def list_sources():
    return db.get_sources()


@router.get("/stats")
def stats():
    return db.get_stats()


@router.post("/pipeline/run")
def trigger_pipeline(request: Request, _auth=Depends(verify_token)):
    """Manually trigger a pipeline run. Requires auth token if GALLERY_API_TOKEN is set."""
    from .scheduler import run_pipeline_sync
    import threading
    import datetime

    run_date = datetime.date.today().isoformat()
    run_id = db.create_pipeline_run(run_date, mode="manual")

    def run_async():
        run_pipeline_sync(run_id, run_date)

    thread = threading.Thread(target=run_async, daemon=True)
    thread.start()

    return {"run_id": run_id, "run_date": run_date, "status": "started", "message": "Pipeline started in background"}


@router.get("/pipeline/status")
def pipeline_status():
    return db.get_pipeline_status() or {}


@router.get("/pipeline/runs")
def pipeline_runs(limit: int = Query(20, ge=1, le=100)):
    return db.get_pipeline_runs(limit)


@router.get("/portal-data")
def portal_data():
    """Return all products in the format expected by the frontend PORTAL_PRODUCTS."""
    products = db.get_all_products_flat()
    portal_items = []
    for p in products:
        portal_items.append({
            "id": p["id"],
            "title": p["title"],
            "brand": p.get("brand") or "",
            "source": p.get("source") or "",
            "category": p.get("category") or "",
            "description": p.get("description") or "",
            "news_type": p.get("news_type") or "",
            "added_date": p.get("date_collected") or p.get("first_seen_date") or "",
            "image": p.get("image_local_path") or "",
            "detail": p.get("detail_path") or f"details/{p['id']}.html",
            "page_url": p.get("page_url") or "",
            "compare_visible": bool(p.get("compare_visible", 1)),
            "official": bool(p.get("official", 0)),
            "source_type": p.get("source_type") or "",
            "region": p.get("region") or "",
            "verification_status": p.get("verification_status") or "",
            "maturity": p.get("maturity") or "",
            "style_keywords": p.get("style_keywords") or [],
            "design_drivers": p.get("design_drivers") or [],
            "cmf_colors": p.get("cmf_colors") or [],
            "cmf_materials": p.get("cmf_materials") or [],
            "cmf_finishes": p.get("cmf_finishes") or [],
        })

    import datetime
    latest_date = max((p["added_date"] for p in portal_items if p["added_date"]), default="")
    _today = datetime.date.today().isoformat()
    report_date = latest_date or _today

    return {
        "PORTAL_PRODUCTS": portal_items,
        "PORTAL_REPORT_DATE": report_date,
        "PORTAL_LATEST_DATE": latest_date,
        "PORTAL_LATEST_URL": "design_intelligence_portal.html",
        "PORTAL_GLOBAL_GALLERY_URL": "design_intelligence_portal.html#gallery",
        "PORTAL_ISSUE_IDS": [],
    }


# --- Static file serving for images and details ---

# Fallback: /var/www/static/output/ (Docker COPY ensures this location always has files)
_FALLBACK_OUTPUT_DIR = Path("/var/www/static/output")

# Additional candidate output dirs searched in containers
_EXTRA_OUTPUT_DIRS = [
    Path("/app/output"),
    Path("/app/backend/output"),
    Path.cwd() / "output",
]

def _all_output_dirs() -> list[Path]:
    """Return all candidate output directories, preserving search priority."""
    dirs = [OUTPUT_DIR, _FALLBACK_OUTPUT_DIR]
    for d in _EXTRA_OUTPUT_DIRS:
        if d not in dirs:
            dirs.append(d)
    return dirs

def _date_dirs() -> list[Path]:
    import re
    dirs = []
    for base in _all_output_dirs():
        if base.exists():
            dirs.extend(
                d for d in base.iterdir()
                if d.is_dir() and re.match(r'\d{4}-\d{2}-\d{2}', d.name)
            )
    # Deduplicate by name, preferring earlier (higher-priority) entries
    seen = set()
    unique = []
    for d in sorted(dirs, key=lambda x: x.name, reverse=True):
        if d.name not in seen:
            seen.add(d.name)
            unique.append(d)
    return unique


def _find_image_fuzzy(directory: Path, filepath: str) -> Path | None:
    """Find an image by exact match first, then by prefix match to handle
    accumulated filename doubling (e.g. pid_pid.jpg vs pid_pid_pid.jpg)."""
    img_path = directory / filepath
    if img_path.exists():
        return img_path
    stem = Path(filepath).stem
    if not stem:
        return None
    try:
        for f in directory.iterdir():
            if f.is_file() and f.stem.startswith(stem):
                return f
    except (OSError, PermissionError):
        pass
    return None


def _find_image_global(filepath: str, subdirs: list[str] | None = None) -> Path | None:
    """Global fallback: search ALL subdirectories of ALL output dirs for the image.
    This catches cases where _date_dirs() misses a dir due to symlink issues or
    non-standard directory naming."""
    if subdirs is None:
        subdirs = ["images", "history_images"]
    for base in _all_output_dirs():
        if not base.exists():
            continue
        try:
            for date_dir in base.iterdir():
                if not date_dir.is_dir():
                    continue
                for subdir in subdirs:
                    found = _find_image_fuzzy(date_dir / subdir, filepath)
                    if found:
                        return found
        except (OSError, PermissionError):
            pass
    return None


def _get_remote_url_by_path(local_path: str) -> str:
    """Query database for the remote image_url matching a local path."""
    try:
        conn = db.get_conn()
        filename = local_path.split("/")[-1]
        row = conn.execute(
            "SELECT image_url FROM products WHERE image_local_path = ? OR image_local_path LIKE ?",
            (local_path, f"%{filename}%"),
        ).fetchone()
        conn.close()
        return row["image_url"] if row and row["image_url"] else ""
    except Exception:
        return ""


def _download_remote_image(remote_url: str, filepath: str, subdir: str = "images") -> Path | None:
    """Download a remote image to the latest date dir under output/, return the local path."""
    import urllib.request
    date_dirs = _date_dirs()
    if date_dirs:
        local_dir = date_dirs[0] / subdir
    else:
        import datetime
        local_dir = OUTPUT_DIR / datetime.date.today().isoformat() / subdir
    local_dir.mkdir(parents=True, exist_ok=True)
    local_file = local_dir / filepath
    try:
        req = urllib.request.Request(remote_url, headers={"User-Agent": "Mozilla/5.0 Gallery/1.0"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            local_file.write_bytes(resp.read())
        return local_file
    except Exception:
        return None


@image_router.get("/history_images/{filepath:path}")
def serve_history_image(filepath: str):
    """Serve image files from history_images/ directories under output/,
    searching all date dirs so images from older runs are still accessible.
    Falls back to prefix matching when exact filename not found (handles
    filename accumulation across pipeline runs). When no local file exists,
    downloads the remote image_url from the database to local disk, then serves it."""
    for date_dir in _date_dirs():
        found = _find_image_fuzzy(date_dir / "history_images", filepath)
        if found:
            return FileResponse(str(found))

    # Global fallback: search all subdirs of all output dirs
    found = _find_image_global(filepath, subdirs=["history_images"])
    if found:
        return FileResponse(str(found))

    remote_url = _get_remote_url_by_path(f"history_images/{filepath}")
    if remote_url:
        local_file = _download_remote_image(remote_url, filepath, subdir="history_images")
        if local_file and local_file.exists():
            return FileResponse(str(local_file), media_type="image/jpeg")
        return RedirectResponse(url=remote_url)

    raise HTTPException(status_code=404, detail="Image not found")


@image_router.get("/images/{filepath:path}")
def serve_image(filepath: str):
    """Serve image files from images/ or history_images/ directories under output/,
    searching all date dirs so images from older runs are still accessible.
    Falls back to prefix matching when exact filename not found. When no local
    file exists, downloads the remote image_url from the database to local disk,
    then serves it."""
    for date_dir in _date_dirs():
        found = _find_image_fuzzy(date_dir / "images", filepath)
        if found:
            return FileResponse(str(found))
        # fallback: check history_images dir
        found = _find_image_fuzzy(date_dir / "history_images", filepath)
        if found:
            return FileResponse(str(found))

    # Global fallback: search all subdirs of all output dirs
    found = _find_image_global(filepath)
    if found:
        return FileResponse(str(found))

    remote_url = _get_remote_url_by_path(f"images/{filepath}")
    if remote_url:
        local_file = _download_remote_image(remote_url, filepath, subdir="images")
        if local_file and local_file.exists():
            return FileResponse(str(local_file), media_type="image/jpeg")
        return RedirectResponse(url=remote_url)

    # Also check history_images remote URL
    remote_url2 = _get_remote_url_by_path(f"history_images/{filepath}")
    if remote_url2:
        local_file = _download_remote_image(remote_url2, filepath, subdir="history_images")
        if local_file and local_file.exists():
            return FileResponse(str(local_file), media_type="image/jpeg")
        return RedirectResponse(url=remote_url2)

    raise HTTPException(status_code=404, detail="Image not found")


@router.get("/details/{filepath:path}")
def serve_detail(filepath: str):
    """Serve detail HTML files from details/ directories under output/."""
    for date_dir in _date_dirs():
        detail_path = date_dir / "details" / filepath
        if detail_path.exists():
            return FileResponse(str(detail_path), media_type="text/html")
    raise HTTPException(status_code=404, detail="Detail page not found")


@router.get("/debug/paths")
async def debug_paths():
    """Diagnostic endpoint: report actual filesystem paths inside the container."""
    import os
    result = {
        "OUTPUT_DIR": str(OUTPUT_DIR),
        "OUTPUT_DIR_exists": OUTPUT_DIR.exists(),
        "FALLBACK_DIR": str(_FALLBACK_OUTPUT_DIR),
        "FALLBACK_exists": _FALLBACK_OUTPUT_DIR.exists(),
        "all_output_dirs": [str(d) for d in _all_output_dirs()],
        "date_dirs": [str(d) for d in _date_dirs()],
        "output_contents": [],
        "var_www_contents": [],
    }
    if OUTPUT_DIR.exists():
        result["output_contents"] = os.listdir(str(OUTPUT_DIR))[:20]
    if _FALLBACK_OUTPUT_DIR.exists():
        result["var_www_contents"] = os.listdir(str(_FALLBACK_OUTPUT_DIR))[:20]
    # Check well-known paths
    for p in ["/app/output", "/app/backend/output", "/var/www/static/output",
              "/app/output/2026-08-14", "/app/output/2026-08-14/images"]:
        result[p] = os.path.exists(p)
        if os.path.isdir(p):
            files = os.listdir(p)[:10]
            result[p + "_contents"] = files
    # Check specific test images
    test_paths = [
        "/app/output/2026-08-14/images/ba0d7a6090d4.jpg",
        "/app/output/2026-08-09/history_images/prod_cba41932c16c18dd_prod_cba41932c16c18dd.jpg",
        "/var/www/static/output/2026-08-14/images/ba0d7a6090d4.jpg",
    ]
    for tp in test_paths:
        result["file_" + tp] = os.path.exists(tp)
    return result
