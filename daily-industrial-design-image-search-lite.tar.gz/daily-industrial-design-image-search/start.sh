#!/usr/bin/env bash
set -e

echo "[start.sh] Starting Industrial Design Gallery..."

# --- Ensure /app/output/ has ALL historical date dirs (not just today) ---
# Docker COPY backend/ . should have placed output/ at /app/output/, but
# symlinks in backend/backend/ can cause silent COPY failures. Recover
# any missing date dirs from /app/backend/output/ BEFORE running pipeline.
mkdir -p /app/output
RECOVERED=0
if [ -d /app/backend/output ]; then
  for hist_dir in /app/backend/output/20*/; do
    dir_name=$(basename "$hist_dir")
    if [ ! -d "/app/output/$dir_name" ]; then
      echo "[start.sh] Restoring missing date dir: $dir_name"
      cp -r "$hist_dir" "/app/output/"
      RECOVERED=$((RECOVERED + 1))
    fi
  done
fi
if [ "$RECOVERED" -gt 0 ]; then
  echo "[start.sh] Restored $RECOVERED historical date dirs from /app/backend/output/"
fi

# --- Ensure /app/output/ is populated (Docker COPY sometimes silently fails) ---
JPG_COUNT=$(find /app/output/ -name "*.jpg" 2>/dev/null | wc -l)
if [ "$JPG_COUNT" -eq 0 ]; then
  echo "[start.sh] WARNING: /app/output/ has 0 jpg files, attempting recovery..."
  # Try copying from /app/backend/output/ if it exists (COPY backend/ . may place files here)
  if [ -d /app/backend/output ]; then
    BACKEND_JPGS=$(find /app/backend/output/ -name "*.jpg" 2>/dev/null | wc -l)
    if [ "$BACKEND_JPGS" -gt 0 ]; then
      echo "[start.sh] Recovering from /app/backend/output/ ($BACKEND_JPGS jpgs)"
      cp -rn /app/backend/output/* /app/output/ 2>/dev/null || true
    fi
  fi
  # Re-check after recovery
  JPG_COUNT=$(find /app/output/ -name "*.jpg" 2>/dev/null | wc -l)
  if [ "$JPG_COUNT" -eq 0 ]; then
    echo "[start.sh] FATAL: /app/output/ still empty after recovery. Images will 404."
  else
    echo "[start.sh] Recovery successful: $JPG_COUNT jpgs now in /app/output/"
  fi
else
  echo "[start.sh] Output directory OK: $JPG_COUNT jpg files in /app/output/"
fi

# --- Run pipeline to download latest images (ensures output dir has files) ---
echo "[start.sh] Running pipeline to download images..."
python3 scripts/agent_daily_pipeline.py --date $(date +%Y-%m-%d) --include-media 2>/dev/null || {
  echo "[start.sh] Pipeline completed with warnings or failed (non-fatal)"
}
echo "[start.sh] Pipeline step done."

# --- Generate dynamic portal HTML ---
echo "[start.sh] Generating dynamic portal HTML..."
python3 scripts/create_dynamic_portal.py 2>/dev/null || {
  echo "[start.sh] Dynamic portal generation failed (non-fatal)"
}

# --- Ensure /var/www/static/output is populated (symlink or real directory) ---
# Remove broken symlink if present, then ensure it points to /app/output or is a real dir
if [ -L /var/www/static/output ] && [ ! -e /var/www/static/output ]; then
  echo "[start.sh] /var/www/static/output is a broken symlink, removing..."
  rm -f /var/www/static/output
fi

if [ ! -e /var/www/static/output ]; then
  mkdir -p /var/www/static
  ln -s /app/output /var/www/static/output
  echo "[start.sh] Created symlink /var/www/static/output -> /app/output"
elif [ -d /var/www/static/output ]; then
  # Real directory — ensure it has files
  STATIC_JPGS=$(find /var/www/static/output/ -name "*.jpg" 2>/dev/null | wc -l)
  if [ "$STATIC_JPGS" -eq 0 ]; then
    echo "[start.sh] /var/www/static/output/ is empty, restoring from /app/output/ or /app/backend/output/..."
    if [ "$(find /app/output/ -name '*.jpg' 2>/dev/null | wc -l)" -gt 0 ]; then
      cp -rn /app/output/* /var/www/static/output/ 2>/dev/null || true
    elif [ -d /app/backend/output ]; then
      cp -rn /app/backend/output/* /var/www/static/output/ 2>/dev/null || true
    fi
    STATIC_JPGS=$(find /var/www/static/output/ -name "*.jpg" 2>/dev/null | wc -l)
    echo "[start.sh] /var/www/static/output/ now has $STATIC_JPGS jpgs"
  else
    echo "[start.sh] /var/www/static/output/ OK: $STATIC_JPGS jpg files"
  fi
fi

# Initialize database if it doesn't exist
if [ ! -f /app/db/gallery.db ]; then
    echo "[start.sh] Database not found, initializing..."
    if [ -f /app/output/2026-08-09/global_gallery_input.json ]; then
        python /app/db/init_db.py --seed \
            --json /app/output/2026-08-09/global_gallery_input.json \
            --sources /app/config/source_catalog.json
    else
        echo "[start.sh] Seed data not found, creating empty schema..."
        python /app/db/init_db.py
    fi
else
    echo "[start.sh] Database exists, skipping initialization."
fi

# Sync the latest dynamic portal HTML to /var/www/static/index.html
# so run.py's SPA gateway serves the dynamic version (XHR to /api/portal-data).
LATEST_DYNAMIC=$(ls -1 /app/output/20*/design_intelligence_portal_dynamic.html 2>/dev/null | sort -r | head -1)
if [ -n "$LATEST_DYNAMIC" ]; then
  mkdir -p /var/www/static
  cp "$LATEST_DYNAMIC" /var/www/static/index.html
  echo "[start.sh] Synced dynamic portal: $LATEST_DYNAMIC -> /var/www/static/index.html"
else
  echo "[start.sh] WARNING: No design_intelligence_portal_dynamic.html found, SPA will 404"
fi

echo "[start.sh] Launching on 0.0.0.0:${PORT:-8000}"
exec python run.py
