#!/usr/bin/env python3
"""
Round 4: Validate feeds from Round 3, try more patterns for remaining brands,
and use alternative approaches.
"""
import subprocess
import json
import concurrent.futures

# URLs to validate from round 3
VALIDATE_URLS = {
    "nikon_news": [
        "https://www.nikon.com/company/rss/feeds/news.rss",
        "https://www.nikon.com/company/rss/",
    ],
    "panasonic_newsroom": [
        "https://news.panasonic.com/global/rss/",
        "https://news.panasonic.com/global/rss/index.xml",
    ],
    "philips_news_center": [
        "https://www.philips.com/content/corporate/en_AA/feed.rss.xml?pageSize=15&startIndex=0&src=/content/corporate/en_AA/about/news/archive&sortMode=createdDate",
        # Also try the en_US variant
        "https://www.philips.com/content/corporate/en_US/feed.rss.xml?pageSize=15&startIndex=0&src=/content/corporate/en_US/about/news/archive&sortMode=createdDate",
    ],
}

# Additional patterns for brands still not found
EXTRA_PATTERNS = {
    "sony_design": [
        # Sony Electronics press center
        "https://presscentre.sony.eu/sony-electronics/feed",
        "https://presscentre.sony.eu/feed",
        # Sony group
        "https://www.sony.net/SonyInfo/IR/news/modules/rdf/",
        "https://www.sony.net/SonyInfo/IR/news/rss/",
        "https://www.sony.com/en/news/press-releases/rss/",
        # Sony design specific
        "https://www.sony.com/en/SonyInfo/design/news/feed",
        "https://www.sony.com/en/SonyInfo/design/rss",
    ],
    "nothing_newsroom": [
        "https://nothing.tech/blogs/news-feed.xml",
        "https://nothing.tech/blogs/news/rss",
        # Shopify blog feed
        "https://nothing.tech/blogs/news-feed.rss",
        "https://nothing.tech/blogs/news.atom.xml",
        "https://nothing.tech/blogs/news.rss.xml",
    ],
    "teenage_engineering": [
        "https://teenage.engineering/about/atom.xml",
        "https://teenage.engineering/about.rss",
        "https://teenage.engineering/rss",
        "https://teenage.engineering/atom",
    ],
    "bang_olufsen": [
        "https://www.bang-olufsen.com/en/rss",
        "https://www.bang-olufsen.com/rss",
        "https://www.bang-olufsen.com/feed.xml",
        "https://www.bang-olufsen.com/atom.xml",
    ],
    "bose_press_room": [
        "https://www.bose.com/pressroom.rss",
        "https://www.bose.com/pressroom.xml",
        "https://www.bose.com/pressroom.atom",
        "https://www.bose.com/en-US/about-bose/press-room.html.rss",
    ],
    "gopro_news": [
        "https://gopro.com/blogs/news.feed",
        "https://gopro.com/blogs/news/index.rss",
        "https://gopro.com/blogs/news.rss.xml",
        # Shopify pattern
        "https://gopro.com/blogs/news.atom",
    ],
    "canon_global_news": [
        "https://global.canon/en/news/press-release.rss",
        "https://global.canon/en/news/index.xml",
        "https://global.canon/en/news/atom.xml",
        # Canon Europe
        "https://www.canon-europe.com/press-centre/rss.xml",
        "https://www.canon-europe.com/rss.xml",
    ],
    "fujifilm_news": [
        "https://www.fujifilm.com/us/en/news/index.xml",
        "https://www.fujifilm.com/us/en/news/atom.xml",
        "https://www.fujifilm.com/news/index.xml",
        "https://www.fujifilm.com/news/atom.xml",
        # Fujifilm Europe
        "https://www.fujifilm.eu/press/feed.xml",
    ],
    "framework_blog": [
        # Ghost CMS patterns
        "https://frame.work/blog/rss/",
        "https://frame.work/ghost/rss/",
        "https://frame.work/rss",
        "https://frame.work/atom",
        "https://frame.work/blog/atom.xml",
    ],
    "consumer": [  # Huawei
        "https://consumer.huawei.com/en/press/news/index.htm.rss",
        "https://consumer.huawei.com/en/press/news-feed.xml",
        "https://consumer.huawei.com/en/press/press-release.xml",
        # Alternative
        "https://consumer.huawei.com/en/feed/",
        "https://consumer.huawei.com/en/press/feed.xml",
    ],
    "mi": [  # Xiaomi
        "https://blog.mi.com/global/feed.rss",
        "https://blog.mi.com/global/index.xml",
        "https://blog.mi.com/global/atom.xml",
        "https://blog.mi.com/global/index.rss",
        "https://blog.mi.com/rss.xml",
    ],
    "honor": [
        "https://www.honor.com/global/news/index.xml",
        "https://www.honor.com/global/news/rss",
        "https://www.honor.com/global/news/atom.xml",
        "https://www.honor.com/global/press-releases.xml",
    ],
    "oppo_newsroom": [
        "https://www.oppo.com/en/newsroom/index.rss",
        "https://www.oppo.com/en/newsroom.atom.xml",
        "https://www.oppo.com/en/newsroom/index.atom",
        "https://www.oppo.com/en/news.rss",
    ],
    "vivo_news": [
        "https://www.vivo.com/en/about-vivo/news/index.rss",
        "https://www.vivo.com/en/about-vivo/news.rss.xml",
        "https://www.vivo.com/en/about-vivo/news/atom.xml",
        "https://www.vivo.com/en/about-vivo/news.atom",
    ],
    "realme_newsroom": [
        "https://www.realme.com/global/newsroom/index.rss",
        "https://www.realme.com/global/newsroom.rss.xml",
        "https://www.realme.com/global/newsroom.atom",
        "https://www.realme.com/global/newsroom/index.atom",
    ],
    "dji_media_center": [
        "https://www.dji.com/newsroom/rss",
        "https://www.dji.com/newsroom/index.rss",
        "https://www.dji.com/news/index.xml",
        "https://www.dji.com/news/index.rss",
        "https://www.dji.com/news/rss.xml",
        "https://www.dji.com/rss",
    ],
    "insta360_blog": [
        "https://www.insta360.com/blog/index.rss",
        "https://www.insta360.com/blog/rss",
        "https://www.insta360.com/blog/atom.xml",
        "https://www.insta360.com/blog/atom",
    ],
    "anker_news": [
        # Shopify blog pattern
        "https://www.anker.com/blogs/news.rss",
        "https://www.anker.com/blogs/news.atom",
        "https://www.anker.com/blogs/news.feed",
        "https://www.anker.com/blogs/news.xml",
    ],
    "dyson_newsroom": [
        "https://www.dyson.com/discover/news/index.rss",
        "https://www.dyson.com/discover/dyson-newsroom.rss",
        "https://www.dyson.com/discover/news.atom",
        "https://www.dyson.com/news.atom",
        "https://www.dyson.co.uk/discover/news/feed",
        "https://www.dyson.com/discover/feed.xml",
        "https://www.dyson.com/discover/rss",
        "https://www.dyson.com/discover/dyson-newsroom.xml",
    ],
    "braun": [
        "https://www.braun.com/global/en/braun-prize.rss",
        "https://www.braun.com/global/en/index.rss",
        "https://www.braun.com/global/en/news.xml",
        "https://www.braun.com/en/index.rss",
        "https://www.braun.com/global/en/atom.xml",
    ],
    "bosch_press_portal": [
        "https://www.bosch-presse.de/pressportal/de/en/press-releases.rss",
        "https://www.bosch-presse.de/pressportal/de/en/press.xml",
        "https://www.bosch.com/en/press/news.xml",
        "https://start.bosch.com/press-rss.xml",
        # Bosch global
        "https://www.bosch.com/rss",
        "https://www.bosch.com/feeds/press-releases.xml",
    ],
    "lg_newsroom": [
        # WordPress patterns
        "https://www.lgnewsroom.com/wp-json/wp/v2/posts",
        "https://www.lgnewsroom.com/?feed=rss2",
        "https://www.lgnewsroom.com/?feed=atom",
        "https://www.lgnewsroom.com/feed/atom/",
        "https://www.lgnewsroom.com/wp-feed.xml",
    ],
    "ikea_newsroom": [
        "https://www.ikea.com/global/en/newsroom/index.rss",
        "https://www.ikea.com/global/en/newsroom/press-releases.xml",
        "https://www.ikea.com/ms/en_GB/press/feed.xml",
        "https://www.ikea.com/gb/en/newsroom/feed.xml",
        "https://www.ikea.com/ms/en_US/rss/press.xml",
    ],
    "design_milk": [
        "https://design-milk.com/wp-json/wp/v2/posts",
        "https://design-milk.com/?feed=rss2",
        "https://design-milk.com/?feed=atom",
        "https://feeds.feedburner.com/type/design-milk",
    ],
    "fast_company_design": [
        "https://www.fastcompany.com/?feed=rss2",
        "https://www.fastcompany.com/section/co-design/index.rss",
        "https://www.fastcompany.com/section/co-design.rss",
        "https://feeds.feedburner.com/fastcompany/co.design",
        "https://www.fastcompany.com/section/co-design/atom.xml",
    ],
    "new_atlas": [
        "https://newatlas.com/?feed=rss2",
        "https://newatlas.com/index.atom",
        "https://feeds.feedburner.com/gizmag",
        "https://newatlas.com/rss/index.xml",
        "https://newatlas.com/atom",
    ],
    "herman_miller": [
        "https://www.hermanmiller.com/stories.rss",
        "https://www.hermanmiller.com/stories/index.xml",
        "https://www.hermanmiller.com/en_US/stories.rss",
        "https://www.hermanmiller.com/stories.atom",
        "https://www.hermanmiller.com/content/hermanmiller/stories.rss",
    ],
    "vitra": [
        "https://www.vitra.com/en/stories.rss",
        "https://www.vitra.com/stories.rss",
        "https://www.vitra.com/stories/index.xml",
        "https://www.vitra.com/en/stories.atom",
        "https://www.vitra.com/en/feed.xml",
    ],
    "mercedes_benz_media": [
        "https://media.mercedes-benz.com/feed/en.xml",
        "https://media.mercedes-benz.com/feed/en",
        "https://media.mercedes-benz.com/rss/en.xml",
        "https://media.mercedes-benz.com/page/rss-press-releases-en.html",
        "https://media.mercedes-benz.com/service/press-release-feed/en",
    ],
    "audi_mediacenter": [
        "https://www.audi-mediacenter.com/en/press-releases.rss",
        "https://www.audi-mediacenter.com/en/index.xml",
        "https://www.audi-mediacenter.com/en/news.xml",
        "https://www.audi-mediacenter.com/en/atom.xml",
        "https://www.audi-mediacenter.com/en/feed/press-releases",
    ],
    "porsche_newsroom": [
        "https://newsroom.porsche.com/en/press-releases.rss",
        "https://newsroom.porsche.com/en/index.xml",
        "https://newsroom.porsche.com/en/atom.xml",
        "https://newsroom.porsche.com/de/rss.xml",
        "https://newsroom.porsche.com/en/news.xml",
    ],
    "volvo_cars_media": [
        "https://www.media.volvocars.com/global/en-gb/rss",
        "https://www.media.volvocars.com/global/en-gb/index.xml",
        "https://www.media.volvocars.com/global/en-gb/news.xml",
        "https://www.media.volvocars.com/global/en-gb/atom.xml",
        "https://www.media.volvocars.com/feeds/press-releases",
    ],
    "tesla": [
        "https://www.tesla.com/blog/index.rss",
        "https://www.tesla.com/blog.atom.xml",
        "https://www.tesla.com/blog/index.atom",
        "https://www.tesla.com/blog/feed.xml",
        "https://www.tesla.com/blog/rss.xml",
    ],
    "toyota_global_newsroom": [
        "https://global.toyota/en/newsroom/index.rss",
        "https://global.toyota/en/newsroom/news.xml",
        "https://global.toyota/en/newsroom/atom.xml",
        "https://global.toyota/en/newsroom/press-release.rss",
        "https://global.toyota/en/newsroom/feed.xml",
    ],
    "honda_global_newsroom": [
        "https://global.honda/en/newsroom/index.rss",
        "https://global.honda/en/newsroom/news.xml",
        "https://global.honda/en/newsroom/atom.xml",
        "https://global.honda/en/newsroom/press-release.rss",
        "https://global.honda/en/newsroom/feed.xml",
    ],
}

def test_url(url):
    """Test a URL and check if it returns valid RSS/Atom feed content."""
    try:
        result = subprocess.run(
            ["curl", "-sL", "-o", "-", "-w", "\\n__HTTP_CODE__%{http_code}",
             "--max-time", "12", "--connect-timeout", "10",
             "-H", "User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36",
             url],
            capture_output=True, text=True, timeout=20
        )
        output = result.stdout
        http_code = "000"
        if "__HTTP_CODE__" in output:
            parts = output.rsplit("__HTTP_CODE__", 1)
            body = parts[0]
            http_code = parts[1].strip()
        else:
            body = output

        if http_code == "200":
            body_lower = body.lower().strip()
            is_rss = any(marker in body_lower for marker in [
                "<rss", "<feed", "<channel", "<entry", "<?xml",
                "application/rss+xml", "application/atom+xml",
                '<"item"', "<item", "<items",
            ])
            # Also check JSON feed
            is_json = '"posts"' in body_lower or '"title"' in body_lower and '"link"' in body_lower
            
            if (is_rss or is_json) and len(body) > 100:
                return (url, True, http_code, len(body), body[:200])
        return (url, False, http_code, 0, "")
    except Exception as e:
        return (url, False, "ERR", 0, str(e)[:100])

def main():
    results = {}
    
    # Merge all URLs to test
    all_urls = []
    url_to_brand = {}
    for brand, urls in {**VALIDATE_URLS, **EXTRA_PATTERNS}.items():
        for url in urls:
            all_urls.append(url)
            url_to_brand[url] = brand

    print(f"Round 4: Testing {len(all_urls)} candidate URLs...")
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=20) as executor:
        future_to_url = {executor.submit(test_url, url): url for url in all_urls}
        
        for future in concurrent.futures.as_completed(future_to_url):
            url = future_to_url[future]
            try:
                result_url, is_valid, http_code, size, preview = future.result()
                brand = url_to_brand[result_url]
                status = "VALID" if is_valid else f"INVALID({http_code})"
                print(f"[{status}] {brand}: {result_url} (size={size})")
                if is_valid:
                    if brand not in results:
                        results[brand] = result_url
            except Exception as e:
                print(f"[ERROR] {url}: {e}")
    
    return results

if __name__ == "__main__":
    results = main()
    
    print("\n" + "="*80)
    print("ROUND 4 RESULTS SUMMARY")
    print("="*80)
    
    print(f"\nFound RSS feeds for {len(results)} brands:")
    for brand, url in sorted(results.items()):
        print(f"  {brand}: {url}")
    
    # Merge with all previous results
    with open("/home/ubuntu/workdir/daily-industrial-design-image-search/rss_test_results.json", "r") as f:
        prev = json.load(f)
    
    all_found = {}
    all_found.update(prev["found"])
    all_found.update(results)
    
    still_not_found = [b for b in prev["not_found"] if b not in all_found]
    
    output = {
        "found": all_found,
        "not_found": still_not_found,
    }
    with open("/home/ubuntu/workdir/daily-industrial-design-image-search/rss_test_results.json", "w") as f:
        json.dump(output, f, indent=2)
    
    print(f"\nTotal found: {len(all_found)}, still not found: {len(still_not_found)}")
    print(f"Brands still not found: {still_not_found}")
    print(f"\nResults saved to rss_test_results.json")
