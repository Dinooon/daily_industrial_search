#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path

GALLERY_REQUIRED = ('class="shell"','class="topbar"','class="gallery" id="gallery"','data-gallery-template="canonical-v3.4"')
PORTAL_REQUIRED = ('class="topbar"','class="nav"','data-view="gallery"','data-view="explore"','data-view="compare"','data-view="board"','data-view="topics"','data-view="trends"','data-portal-template="phase1-v3.4"')
LEGACY = ('class="header"','class="section-title"')

def validate(path: Path, max_mb: float | None = None, kind: str = 'auto') -> dict:
    text=path.read_text(encoding='utf-8')
    if kind == 'auto':
        kind = 'portal' if 'data-portal-template=' in text else 'gallery'
    required = PORTAL_REQUIRED if kind == 'portal' else GALLERY_REQUIRED
    missing=[x for x in required if x not in text]
    legacy=[x for x in LEGACY if x in text]
    size=path.stat().st_size
    errors=[]
    if missing: errors.append(f'missing {kind} markers: {missing}')
    if legacy: errors.append(f'legacy template markers found: {legacy}')
    if '@media(max-width:' not in text: errors.append('mobile responsive CSS missing')
    if max_mb is not None and size > max_mb*1024*1024: errors.append(f'HTML size {size/1024/1024:.2f}MB exceeds {max_mb}MB')
    if errors: raise SystemExit('HTML quality gate blocked publication: '+'; '.join(errors))
    return {'path':str(path),'size_bytes':size,'kind':kind,'valid':True,'canonical':kind=='gallery','portal':kind=='portal','legacy':False}

def main():
    p=argparse.ArgumentParser();p.add_argument('--html',required=True);p.add_argument('--max-mb',type=float);p.add_argument('--kind',choices=['auto','gallery','portal'],default='auto');a=p.parse_args()
    print(json.dumps(validate(Path(a.html),a.max_mb,a.kind),ensure_ascii=False,indent=2))
if __name__=='__main__': main()
