#!/usr/bin/env python3
"""Resumable source acquisition: official feeds -> official pages -> media."""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from pipeline.dedupe import dedupe
from pipeline.run import run_pipeline
from pipeline.source_loader import load_sources

TIERS = (
    ("official_structured", "官方 RSS / API", {"official_brand"}, ["api", "rss"]),
    ("official_pages", "官方新品页", {"official_brand"}, ["sitemap", "html"]),
    ("design_media", "设计媒体", {"design_media"}, ["rss", "sitemap", "html"]),
)


def published_on(item: dict, report_date: str) -> bool:
    raw = str(item.get("published_at") or "")
    if not raw:
        return False
    # News feeds commonly expose UTC timestamps.  A post published after
    # 16:00 UTC belongs to the following calendar day for the China daily.
    try:
        moment = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        if moment.tzinfo is None:
            return moment.date().isoformat() == report_date
        return moment.astimezone(ZoneInfo("Asia/Shanghai")).date().isoformat() == report_date
    except ValueError:
        return raw[:10] == report_date


def source_queue(detail_budget: int = 2, candidate_budget: int = 15) -> list[tuple[str, str, dict]]:
    sources = load_sources()
    queue = []
    for tier_id, label, types, modes in TIERS:
        for source in sources:
            if source.get("source_type") not in types:
                continue
            item = dict(source)
            item["discovery"] = [m for m in modes if m == "api" and item.get("api_urls") or m != "api"]
            item["detail_fetch_budget"] = detail_budget
            item["candidate_budget"] = candidate_budget
            queue.append((tier_id, label, item))
    return queue


def write_source_config(path: Path, source: dict) -> None:
    path.write_text(json.dumps({"schema_version": "2.1", "defaults": {"enabled": True}, "sources": [source]}, ensure_ascii=False, indent=2), encoding="utf-8")


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--date", required=True)
    p.add_argument("--batch-size", type=int, default=1)
    p.add_argument("--timeout", type=float, default=5)
    p.add_argument("--attempts", type=int, default=1)
    p.add_argument("--workers", type=int, default=1)
    p.add_argument("--reset", action="store_true")
    a = p.parse_args()

    run_dir = ROOT / "data" / a.date / "tiered"
    batch_dir = run_dir / "batches"
    batch_dir.mkdir(parents=True, exist_ok=True)
    progress_path = run_dir / "progress.json"
    progress = {"next_index": 0, "completed": [], "failed": []}
    if progress_path.exists() and not a.reset:
        progress.update(json.loads(progress_path.read_text(encoding="utf-8")))
    queue = source_queue()
    start = int(progress.get("next_index", 0))
    os.environ["DID_HTTP_TIMEOUT"] = str(a.timeout)
    os.environ["DID_HTTP_ATTEMPTS"] = str(a.attempts)

    end = min(start + a.batch_size, len(queue))

    def collect_one(index: int) -> dict:
        tier_id, label, source = queue[index]
        source_id = source["id"]
        safe_id = re.sub(r"[^A-Za-z0-9._-]+", "-", source_id)
        source_out = batch_dir / f"{index:04d}_{tier_id}_{safe_id}"
        source_out.mkdir(parents=True, exist_ok=True)
        config_path = source_out / "source.json"
        write_source_config(config_path, source)
        try:
            payload = run_pipeline(
                source_out,
                config_path,
                max_sources=1,
                max_items_per_source=2,
                force=True,
                state_path=source_out / "state.json",
            )
            products = [x for x in payload.get("products", []) if published_on(x, a.date)]
            for item in products:
                item["collection_tier"] = tier_id
                item["collection_tier_label"] = label
                item["first_seen_at"] = item.get("first_seen_at") or datetime.now().astimezone().isoformat()
                item["verification_status"] = "confirmed" if source.get("source_type") == "official_brand" else "needs_review"
            (source_out / "today_products.json").write_text(json.dumps(products, ensure_ascii=False, indent=2), encoding="utf-8")
            return {"ok": True, "index": index, "tier": tier_id, "source_id": source_id, "products": len(products)}
        except Exception as exc:
            return {"ok": False, "index": index, "tier": tier_id, "source_id": source_id, "error": str(exc)[:500]}

    indexes = list(range(start, end))
    if max(1, a.workers) == 1:
        results = [collect_one(index) for index in indexes]
    else:
        with ThreadPoolExecutor(max_workers=max(1, a.workers)) as executor:
            futures = [executor.submit(collect_one, index) for index in indexes]
            results = [future.result() for future in as_completed(futures)]

    for result in sorted(results, key=lambda item: item["index"]):
        target = "completed" if result.pop("ok") else "failed"
        progress[target].append(result)
    progress["next_index"] = end
    if indexes:
        progress["total_sources"] = len(queue)
        progress_path.write_text(json.dumps(progress, ensure_ascii=False, indent=2), encoding="utf-8")

    # Rebuild today's slice from durable per-source output.  This means date
    # handling fixes or timezone changes do not require hitting 286 sites again.
    tier_labels = {tier_id: label for tier_id, label, _, _ in TIERS}
    merged = []
    for path in sorted(batch_dir.glob("*/collected_data.json")):
        match = re.match(r"^\d+_(official_structured|official_pages|design_media)_", path.parent.name)
        tier_id = match.group(1) if match else ""
        source_payload = json.loads((path.parent / "source.json").read_text(encoding="utf-8"))
        source = source_payload.get("sources", [{}])[0]
        products = [x for x in json.loads(path.read_text(encoding="utf-8")).get("products", []) if published_on(x, a.date)]
        for item in products:
            item["collection_tier"] = tier_id
            item["collection_tier_label"] = tier_labels.get(tier_id, tier_id)
            item["first_seen_at"] = item.get("first_seen_at") or datetime.now().astimezone().isoformat()
            item["verification_status"] = "confirmed" if source.get("source_type") == "official_brand" else "needs_review"
        (path.parent / "today_products.json").write_text(json.dumps(products, ensure_ascii=False, indent=2), encoding="utf-8")
        merged.extend(products)
    clean, duplicates = dedupe(merged)
    (run_dir / "merged_data.json").write_text(json.dumps({"report_date": a.date, "products": clean}, ensure_ascii=False, indent=2), encoding="utf-8")
    (run_dir / "duplicates.json").write_text(json.dumps(duplicates, ensure_ascii=False, indent=2), encoding="utf-8")
    summary = {"report_date": a.date, "processed": progress["next_index"], "total_sources": len(queue), "accepted_today": len(clean), "duplicates": len(duplicates), "complete": progress["next_index"] >= len(queue)}
    (run_dir / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
