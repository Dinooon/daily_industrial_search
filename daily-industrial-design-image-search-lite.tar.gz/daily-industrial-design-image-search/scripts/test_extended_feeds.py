#!/usr/bin/env python3
"""
Extended RSS fetcher - fixes XML parsing issues and adds more sources.
"""
import subprocess, re, time, os
from pathlib import Path
import xml.etree.ElementTree as ET

def fetch_and_fix_rss(url, timeout=20):
    """Fetch RSS and fix common XML issues"""
    try:
        cmd = ['curl', '-sL', '--max-time', str(timeout),
               '-H', 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
               url]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout+5)
        xml_text = result.stdout
        
        # Fix leading whitespace before XML declaration
        xml_text = xml_text.lstrip()
        
        # Fix BOM
        if xml_text.startswith('\ufeff'):
            xml_text = xml_text[1:]
        
        # Try to parse
        try:
            root = ET.fromstring(xml_text)
            return root, xml_text
        except ET.ParseError:
            # Try stripping everything before <?xml
            idx = xml_text.find('<?xml')
            if idx > 0:
                xml_text = xml_text[idx:]
            # Remove invalid characters
            xml_text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', xml_text)
            try:
                root = ET.fromstring(xml_text)
                return root, xml_text
            except ET.ParseError as e2:
                print(f"  [ERROR] Cannot parse {url}: {e2}")
                return None, xml_text
    except Exception as e:
        print(f"  [WARN] Failed to fetch {url}: {e}")
        return None, ""

# Extended RSS feeds
EXTENDED_FEEDS = [
    {"id": "dezeen", "publisher": "Dezeen", "url": "https://www.dezeen.com/feed/", "trust": 0.8},
    {"id": "new_atlas", "publisher": "New Atlas", "url": "https://newatlas.com/feed/", "trust": 0.8},
    {"id": "designboom_design", "publisher": "designboom", "url": "https://www.designboom.com/design/feed/", "trust": 0.8},
    {"id": "designboom_tech", "publisher": "designboom", "url": "https://www.designboom.com/technology/feed/", "trust": 0.8},
    {"id": "core77", "publisher": "Core77", "url": "https://feeds.feedburner.com/core77/blog", "trust": 0.8},
    {"id": "design_milk", "publisher": "Design Milk", "url": "https://design-milk.com/feed/", "trust": 0.8},
    {"id": "wallpaper", "publisher": "Wallpaper", "url": "https://www.wallpaper.com/feed", "trust": 0.8},
    {"id": "architonic", "publisher": "Architonic", "url": "https://www.architonic.com/en/rss/news.xml", "trust": 0.8},
    {"id": "fast_company_tech", "publisher": "Fast Company", "url": "https://www.fastcompany.com/technology/feed", "trust": 0.8},
    {"id": "fast_company_design", "publisher": "Fast Company", "url": "https://www.fastcompany.com/design/feed", "trust": 0.8},
    {"id": "verge_tech", "publisher": "The Verge", "url": "https://www.theverge.com/rss/tech.xml", "trust": 0.8},
    {"id": "gizmodo", "publisher": "Gizmodo", "url": "https://gizmodo.com/rss", "trust": 0.8},
    {"id": "slashgear", "publisher": "SlashGear", "url": "https://www.slashgear.com/feed/", "trust": 0.8},
    {"id": "apple_newsroom", "publisher": "Apple Newsroom", "url": "https://www.apple.com/newsroom/rss-feed.rss", "trust": 1.0},
    {"id": "sony_design", "publisher": "Sony Design", "url": "https://www.sony.com/en/SonyInfo/News/PressReleases/Design/feed.xml", "trust": 1.0},
    {"id": "samsung", "publisher": "Samsung", "url": "https://news.samsung.com/global/feed", "trust": 1.0},
    {"id": "lg_newsroom", "publisher": "LG Newsroom", "url": "https://www.lgnewsroom.com/feed/", "trust": 1.0},
    {"id": "logitech", "publisher": "Logitech", "url": "https://news.logitech.com/press-releases?feed=rss", "trust": 1.0},
    {"id": "anker", "publisher": "Anker", "url": "https://www.anker.com/blogs/news.atom", "trust": 1.0},
    {"id": "dyson", "publisher": "Dyson", "url": "https://www.dyson.com/discover/news/rss", "trust": 1.0},
    {"id": "b_o", "publisher": "Bang & Olufsen", "url": "https://www.bang-olufsen.com/en/blog/rss", "trust": 1.0},
    {"id": "garmin", "publisher": "Garmin", "url": "https://www.garmin.com/en-US/newsroom/feed/", "trust": 1.0},
    {"id": "oppo", "publisher": "OPPO", "url": "https://www.oppo.com/en/newsroom/rss/", "trust": 1.0},
    {"id": "lenovo", "publisher": "Lenovo", "url": "https://news.lenovo.com/feed/", "trust": 1.0},
    {"id": "nikon", "publisher": "Nikon", "url": "https://www.nikon.com/company/news/rss/index.xml", "trust": 1.0},
    {"id": "canon", "publisher": "Canon", "url": "https://global.canon/en/news/rss/index.xml", "trust": 1.0},
    {"id": "fujifilm", "publisher": "Fujifilm", "url": "https://www.fujifilm.com/us/en/news/rss", "trust": 1.0},
    {"id": "panasonic", "publisher": "Panasonic", "url": "https://news.panasonic.com/global/feed/", "trust": 1.0},
    {"id": "ikea", "publisher": "IKEA", "url": "https://www.ikea.com/global/en/newsroom/feed/", "trust": 1.0},
    {"id": "bosch", "publisher": "Bosch", "url": "https://www.bosch-presse.de/pressportal/de/en/rss/index.xml", "trust": 1.0},
]

if __name__ == '__main__':
    results = {}
    for feed in EXTENDED_FEEDS:
        print(f"Testing: {feed['publisher']} - {feed['url']}")
        root, xml = fetch_and_fix_rss(feed['url'])
        if root is not None:
            items = root.findall('.//item')
            entries = root.findall('.//entry')  # Atom feeds
            count = len(items) + len(entries)
            results[feed['id']] = count
            print(f"  -> OK: {count} items")
        else:
            results[feed['id']] = 0
            print(f"  -> FAILED")
        time.sleep(0.5)
    
    print(f"\nSummary: {sum(1 for v in results.values() if v > 0)}/{len(results)} feeds working")
