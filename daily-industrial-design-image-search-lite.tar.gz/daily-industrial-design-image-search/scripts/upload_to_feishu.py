#!/usr/bin/env python3
"""Deprecated compatibility wrapper.

This file intentionally contains no hard-coded date, token, folder creation, or
legacy upload logic. It delegates to the canonical publisher so every upload
includes the v3.2 portal entry, compatibility section pages, images, details,
and manifest under the idempotent Drive structure.
"""
from __future__ import annotations
import runpy
import warnings

warnings.warn(
    "upload_to_feishu.py 已弃用；请使用 publish_to_feishu.py 或 run_full_workflow.py --publish",
    DeprecationWarning,
)
runpy.run_module("scripts.publish_to_feishu", run_name="__main__")
