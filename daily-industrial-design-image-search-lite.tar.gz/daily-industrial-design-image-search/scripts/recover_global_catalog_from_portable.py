#!/usr/bin/env python3
"""Recover the durable gallery manifest from a portable portal HTML file."""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path


CATALOG_PATTERN = re.compile(
    r"const PORTAL_PRODUCTS=(.*?);const PORTAL_ISSUE_IDS=", re.DOTALL
)


def extract_catalog(html: str) -> list[dict]:
    match = CATALOG_PATTERN.search(html)
    if not match:
        raise ValueError("PORTAL_PRODUCTS catalog was not found")
    rows = json.loads(match.group(1))
    if not isinstance(rows, list) or not rows:
        raise ValueError("PORTAL_PRODUCTS catalog is empty")
    return [dict(row) for row in rows]


def to_manifest_record(row: dict) -> dict:
    record = {
        "product_id": row.get("id"),
        "title": row.get("title"),
        "brand": row.get("brand"),
        "publisher": row.get("source"),
        "source": row.get("source"),
        "category": row.get("category"),
        "description_zh": row.get("description"),
        "first_seen_date": row.get("added_date"),
        "local_image_path": row.get("image"),
        "page_url": row.get("page_url"),
        "source_type": row.get("source_type"),
    }
    for field in (
        "news_type",
        "region",
        "verification_status",
        "maturity",
        "style_keywords",
        "design_drivers",
        "cmf_colors",
        "cmf_materials",
        "cmf_finishes",
    ):
        value = row.get(field)
        if value not in (None, "", []):
            record[field] = value
    return record


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    source, target = Path(args.input), Path(args.output)
    records = [
        to_manifest_record(row)
        for row in extract_catalog(source.read_text(encoding="utf-8"))
    ]
    target.write_text(json.dumps(records, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"input": str(source), "output": str(target), "products": len(records)}, ensure_ascii=False))


if __name__ == "__main__":
    main()

