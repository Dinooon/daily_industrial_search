#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path

IMG_RE = re.compile(r'''(?:src|data-lightbox-src)=["']([^"']+)["']''', re.I)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    ap = argparse.ArgumentParser(description='Build and validate a complete offline gallery download manifest')
    ap.add_argument('--date', required=True)
    ap.add_argument('--html', required=True)
    ap.add_argument('--portable-preview', required=True)
    ap.add_argument('--images-dir', required=True)
    ap.add_argument('--output', required=True)
    ap.add_argument('--details-dir')
    args = ap.parse_args()

    html = Path(args.html).resolve()
    preview = Path(args.portable_preview).resolve()
    images_dir = Path(args.images_dir).resolve()
    if not html.is_file() or not preview.is_file() or not images_dir.is_dir():
        raise SystemExit('HTML、便携预览版或 images 目录不存在')

    text = html.read_text(encoding='utf-8')
    refs = sorted({x.split('#', 1)[0].split('?', 1)[0] for x in IMG_RE.findall(text)
                   if x and not x.startswith(('data:', 'http://', 'https://', '//', '${'))})
    missing = []
    assets = []
    for ref in refs:
        target = (html.parent / ref).resolve()
        try:
            target.relative_to(html.parent.resolve())
        except ValueError:
            missing.append(ref)
            continue
        if not target.is_file():
            missing.append(ref)
            continue
        assets.append({
            'path': target.relative_to(html.parent).as_posix(),
            'size_bytes': target.stat().st_size,
            'sha256': sha256(target),
        })
    if missing:
        raise SystemExit('标准 HTML 存在未纳入下载包的相对资源: ' + ', '.join(missing))

    disk_images = sorted(p for p in images_dir.iterdir() if p.is_file())
    referenced = {a['path'] for a in assets}
    unreferenced = [f'images/{p.name}' for p in disk_images if f'images/{p.name}' not in referenced]
    detail_assets = []
    if args.details_dir:
        details_dir = Path(args.details_dir).resolve()
        if not details_dir.is_dir():
            raise SystemExit('details 目录不存在')
        for page in sorted(details_dir.glob('*.html')):
            detail_assets.append({'path': page.relative_to(html.parent).as_posix(), 'size_bytes': page.stat().st_size, 'sha256': sha256(page)})

    payload = {
        'schema_version': '1.0',
        'report_date': args.date,
        'entry_html': html.name,
        'portable_html': preview.name,
        'images_directory': 'images',
        'image_count': len(assets),
        'required_assets': assets,
        'detail_pages': detail_assets,
        'detail_count': len(detail_assets),
        'unreferenced_images': unreferenced,
        'offline_opening': '下载日期目录后，打开 design_intelligence_portal.html，并保持 details/ 与 images/ 相对位置不变。',
        'complete': True,
    }
    out = Path(args.output).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
