#!/usr/bin/env python3
"""Build rolling daily/weekly/monthly/half-year/year gallery layers."""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
from datetime import date
from pathlib import Path

DATE_DIR = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def layer_for(age: int) -> str:
    if age < 7:
        return "daily"
    if age < 31:
        return "weekly"
    if age < 183:
        return "monthly"
    if age < 366:
        return "half_year"
    return "annual"


def load_products(path: Path) -> list[dict]:
    if not path.exists():
        return []
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return []
    rows = payload.get("products", payload) if isinstance(payload, dict) else payload
    return [dict(row) for row in rows] if isinstance(rows, list) else []


def best_manifest(folder: Path) -> tuple[Path, list[dict]]:
    # The global catalog is the durable source of truth after older report
    # directories have been archived or moved offline.  Keep it in the
    # candidate set so rerunning the hierarchy is idempotent.
    candidates = [
        folder / "global_gallery_input.json",
        folder / "gallery_input.json",
        folder / "portal_input.json",
    ]
    candidates.extend(folder.glob("galleries/*/monthly/gallery_input.json"))
    candidates.extend(folder.glob("galleries/monthly/gallery_input.json"))
    ranked = [(path, load_products(path)) for path in candidates]
    return max(ranked, key=lambda item: len(item[1]), default=(folder, []))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True, help="output directory containing YYYY-MM-DD runs")
    parser.add_argument("--date", required=True)
    args = parser.parse_args()
    root, report_day = Path(args.root), date.fromisoformat(args.date)
    current = root / args.date
    layers: dict[str, list[dict]] = {k: [] for k in ("daily", "weekly", "monthly", "half_year", "annual")}
    catalog_entries: list[tuple[Path, str, dict]] = []
    seen: set[str] = set()

    for folder in sorted(root.iterdir(), reverse=True):
        if not folder.is_dir() or not DATE_DIR.match(folder.name):
            continue
        run_day = date.fromisoformat(folder.name)
        if run_day > report_day:
            continue
        source, entries = best_manifest(folder)
        source_base = source.parent
        for entry in entries:
            product = dict(entry)
            product["first_seen_date"] = str(product.get("first_seen_date") or folder.name)[:10]
            # Prefer the stable product entity. Image hashes are deliberately
            # not part of this key: older records may predate hash capture.
            identity = str(product.get("product_id") or product.get("page_url") or product.get("title") or "").casefold()
            if identity in seen:
                continue
            seen.add(identity)
            age = (report_day - date.fromisoformat(product["first_seen_date"])).days
            if age < 0:
                continue
            record = (source_base, folder.name, product)
            layers[layer_for(age)].append(record)
            # Layer generation rewrites image paths relative to each layer.
            # Keep an independent copy for the global catalog so those
            # mutations cannot leak into the top-level portable gallery.
            catalog_entries.append((source_base, folder.name, dict(product)))

    script = Path(__file__).with_name("build_portal_pages.py")
    index: dict[str, dict] = {}
    for name, entries in layers.items():
        target = current / "galleries" / name
        target.mkdir(parents=True, exist_ok=True)
        products = []
        for source_base, source_day, product in entries:
            image = product.get("local_image_path")
            if image:
                source_image = source_base / str(image).replace("/", os.sep)
                if source_image.exists():
                    product["local_image_path"] = os.path.relpath(source_image, target).replace("\\", "/")
            products.append(product)
        manifest = target / "gallery_input.json"
        manifest.write_text(json.dumps(products, ensure_ascii=False, indent=2), encoding="utf-8")
        subprocess.run([sys.executable, str(script), "--input", str(manifest), "--output-dir", str(target), "--date", args.date], check=True)
        index[name] = {"products": len(products), "path": str(target.relative_to(current) / "design_intelligence_portal.html")}

    history_images = current / "history_images"
    history_images.mkdir(parents=True, exist_ok=True)
    catalog_products = []
    for source_base, source_day, product in catalog_entries:
        row = dict(product)
        image = row.get("local_image_path")
        if image:
            source_image = source_base / str(image).replace("/", os.sep)
            if source_image.exists():
                if source_image.resolve().parent == history_images.resolve():
                    row["local_image_path"] = source_image.relative_to(current).as_posix()
                    catalog_products.append(row)
                    continue
                safe_id = re.sub(r"[^A-Za-z0-9._-]+", "-", str(row.get("product_id") or row.get("title") or "product")).strip("-")
                src_name = source_image.name
                if not src_name.startswith(safe_id + "_"):
                    staged_name = f"{safe_id}_{src_name}"
                else:
                    staged_name = src_name
                staged = history_images / staged_name
                if source_image.resolve() != staged.resolve() and not staged.exists():
                    shutil.copy2(source_image, staged)
                row["local_image_path"] = staged.relative_to(current).as_posix()
        catalog_products.append(row)

    global_manifest = current / "global_gallery_input.json"
    global_manifest.write_text(json.dumps(catalog_products, ensure_ascii=False, indent=2), encoding="utf-8")
    issue_manifest = current / "gallery_input.json"
    command = [sys.executable, str(script), "--input", str(global_manifest), "--output-dir", str(current), "--date", args.date]
    if issue_manifest.exists():
        command.extend(["--issue-input", str(issue_manifest)])
    subprocess.run(command, check=True)
    index["global"] = {"products": len(catalog_products), "path": "design_intelligence_portal.html#gallery"}

    (current / "gallery_hierarchy.json").write_text(json.dumps({"report_date": args.date, "layers": index}, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"report_date": args.date, "layers": index}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
