#!/usr/bin/env python3
from __future__ import annotations

import argparse
import html
import json
import os
import re
from collections import Counter
from pathlib import Path
from urllib.parse import quote
try:
    from .generate_html import CATEGORY_LABELS, HTMLGenerator
    from .trend_dashboard import enrich_trend_record
    from .trend_dashboard_v2 import TREND_CSS, TREND_JS
except ImportError:  # direct execution: python scripts/build_portal_pages.py
    from generate_html import CATEGORY_LABELS, HTMLGenerator
    from trend_dashboard import enrich_trend_record
    from trend_dashboard_v2 import TREND_CSS, TREND_JS

FALLBACK = '该条资讯已完成来源核验，但公开资料中的产品功能、结构与设计细节仍不足，建议打开原文继续查看。'
PORTAL_NAME = 'design_intelligence_portal.html'

_PRODUCT_TERMS = [
    (("lawn mower", "robot mower", "smart mower"), "该资讯聚焦电动或智能割草设备，重点涉及自动作业、草坪维护效率与户外使用规范，并提示用户根据设备类型和场地条件调整操作方式。"),
    (("battery", "charging", "energy storage"), "该资讯聚焦电池与能源技术创新，重点关注续航、安全、充电效率及面向消费产品的应用潜力，并展示相关技术成果或行业认可。"),
    (("speaker", "audio", "sound"), "该产品围绕音频体验展开设计，通过造型、材料与交互方式强化使用仪式感，同时兼顾空间陈设与日常聆听需求。"),
    (("chair", "sofa", "table", "furniture"), "该产品属于家具设计，重点关注人体工学、结构比例、材料触感与空间适配性，以提升长期使用的舒适度和视觉协调性。"),
    (("lamp", "lighting", "light"), "该产品属于照明设计，重点处理光线控制、结构形态与环境氛围之间的关系，并兼顾安装、操作和空间适配需求。"),
    (("watch", "wearable"), "该产品属于可穿戴设备，重点整合佩戴舒适性、传感功能、交互效率与耐用性，以适应日常和户外使用场景。"),
    (("phone", "smartphone", "tablet", "laptop", "computer"), "该产品属于消费电子设备，重点关注机身结构、显示与交互体验、便携性及性能配置之间的平衡。"),
    (("car", "vehicle", "mobility", "bike", "bicycle"), "该产品属于交通与出行设计，重点关注造型空气动力学、乘坐或操控体验、安全性以及能源效率。"),
    (("medical", "health", "ultrasound"), "该产品面向医疗健康场景，重点关注操作清晰度、使用安全、设备便携性与医护工作流程之间的适配。"),
    (("kitchen", "cook", "coffee", "appliance"), "该产品面向厨房或家电场景，重点关注操作便利性、清洁维护、空间占用以及日常使用效率。"),
]

def esc(value, quote_attr: bool = False) -> str:
    return html.escape(str(value or ''), quote=quote_attr)

def _clean_text(value) -> str:
    text = html.unescape(str(value or ''))
    text = re.sub(r'<[^>]+>', ' ', text)
    return re.sub(r'\s+', ' ', text).strip()

def _chinese_primary(text: str) -> bool:
    zh = len(re.findall(r'[\u4e00-\u9fff]', text))
    latin = len(re.findall(r'[A-Za-z]', text))
    return zh >= 6 and zh >= latin * 0.35

def chinese_description(product: dict) -> str:
    ai = product.get('ai_analysis') or {}
    candidates = (ai.get('description_zh'), product.get('description_zh'), product.get('summary_zh'), ai.get('description'), product.get('description'), product.get('summary'))
    for candidate in candidates:
        text = _clean_text(candidate)
        if _chinese_primary(text):
            return text
    source_summary = _clean_text(product.get('source_summary'))
    if source_summary:
        return source_summary
    title = _clean_text(product.get('title'))
    raw = ' '.join(_clean_text(x) for x in (product.get('description'), product.get('summary'), product.get('body_text'), ai.get('description'))).lower()
    haystack = f'{title} {raw}'.lower()
    for terms, text in _PRODUCT_TERMS:
        if any(term in haystack for term in terms):
            return text
    cat = str(ai.get('category_label') or ai.get('category') or product.get('category') or '').strip()
    maker = str(product.get('brand') or product.get('source') or product.get('publisher') or '').strip()
    prefix = f'{maker}的这项资讯' if maker else '该条资讯'
    if cat and cat not in {'other', '其他'}:
        return f'{prefix}属于{cat}领域，重点呈现产品定位、外观形态与使用场景；现有公开资料尚不足以确认更多结构、材料和功能细节。'
    return FALLBACK

def chinese_evidence_summary(product: dict) -> str:
    """A Chinese, evidence-limited fallback for galleries without a translation model."""
    # Classification must be based on the product title. Article bodies contain
    # site-wide recommendation blocks and can otherwise leak another product's
    # terms (for example, "display") into every card.
    text = str(product.get('title', '')).lower()
    brand = {'samsung': '三星', 'garmin': '佳明', 'lenovo': '联想'}.get(str(product.get('publisher') or product.get('source') or '').lower(), str(product.get('publisher') or product.get('source') or '该品牌'))
    if 'librem 16' in text or ('laptop' in text and 'cuts the wire' in text):
        return 'Purism Librem 16 是一款强调硬件隐私的 16 英寸 Linux 笔记本，通过机身物理开关切断摄像头、麦克风、Wi-Fi 与蓝牙连接；本条为本周媒体报道，产品并非本周首次发布。'
    if 'kindle scribe colorsoft' in text:
        return 'Kindle Scribe Colorsoft 将彩色电子墨水显示与手写批注结合，重点改善阅读、笔记和文档标记体验；本条属于媒体体验报道，不代表本周首次发布。'
    if 'red craft collection' in text:
        return 'Red Craft 系列把四种日本传统工艺转化为可置于日常空间的雕塑化器物，重点呈现材料纹理、手工制作痕迹与当代家居用途之间的关系。'
    if 'writing devices' in text:
        return '该低成本书写设备项目尝试以易取得的零件构成专注写作工具，重点降低同类独立写作终端的制作门槛，并保留实体键盘的直接交互。'
    if 'rx10 v' in text:
        return 'Sony RX10 V 是一款固定镜头长焦相机，媒体重点关注其覆盖范围较大的镜头、快速拍摄性能，以及面向旅行与野生动物拍摄的一体化机身设计。'
    if 'smart speaker' in text and 'openai' in text:
        return '媒体报道称 OpenAI 正筹备一款 AI 智能音箱，预期以语音交互和独立硬件形态进入家庭场景；目前仍属媒体消息，具体外观、规格和上市时间需等待官方确认。'
    if 'clip-style earbuds' in text or ('cmf' in text and 'earbud' in text):
        return 'CMF Clip Pro 采用夹耳式开放佩戴结构，以较低价格提供轻量化日常音频体验；造型重点在于耳夹结构、稳定佩戴和便携收纳。'
    if 'magnetic display' in text and 'reminder' in text:
        return '这款磁吸式桌面提醒显示器把待办信息从手机中分离出来，以持续可见的低干扰界面帮助用户关注任务，减少查看手机时被其他应用打断。'
    if 'tan france' in text and 'furniture' in text:
        return 'Tan France 与 Castlery 合作推出家居系列，通过柔和轮廓、适合日常使用的比例和易搭配材质，强调家具在不同家庭空间中的包容性与亲和感。'
    if any(k in text for k in ('foldable', 'display', 'titanium')):
        return f'{brand}介绍折叠屏显示技术；原文提及钛合金薄膜与钛金属板等结构层，用于提升耐久性并减轻折痕可见度。'
    if any(k in text for k in ('watch', 'wearable', 'health')):
        return f'{brand}推出可穿戴设备更新，聚焦全天候佩戴、健康追踪与显示体验；具体功能以原文发布信息为准。'
    if any(k in text for k in ('washer', 'dryer', 'laundry')):
        return f'{brand}发布洗衣与烘干产品系列，原文重点提到智能洗护、屏幕交互与家电互联体验。'
    if any(k in text for k in ('battery', 'charging', 'energy')):
        return '该资讯聚焦电池与能源技术创新，重点关注续航、安全、充电效率及其在消费产品中的应用。'
    if any(k in text for k in ('chair', 'furniture', '3d print')):
        return '该实体家具以数字制造为核心；原文聚焦其结构造型、材料表现与实际使用场景。'
    if any(k in text for k in ('dispenser', 'skincare', 'cosmetic')):
        return '该护肤分配器支持按需组合配方；原文提到可重复使用的容器结构与成分透明度设计。'
    return '该条产品已完成来源核验；页面展示基于原文可确认的产品定位与使用场景，更多细节请查看原文。'


def concise_product_description(product: dict, text: str, limit: int = 64) -> str:
    """Keep gallery copy factual, product-specific and short enough to scan."""
    title = _clean_text(product.get('title')).lower()
    if 'galaxy watch' in title and ('watch9' in title or 'ultra2' in title):
        return 'Galaxy Watch9 与 Watch Ultra2 强化健康监测、全天候佩戴和户外耐用性，兼顾高亮显示与长续航。'
    if 'flex titanium' in title:
        return 'Flex Titanium 屏幕结构加入钛合金薄膜与钛金属板，提升折叠耐久性并降低折痕可见度。'
    if 'bespoke ai' in title and any(word in title for word in ('washer', 'dryer')):
        return '三星 Bespoke AI 洗烘系列整合智能洗护、触屏交互与 SmartThings 联动，提升衣物护理和能耗管理效率。'

    raw_category = str(
        (product.get('ai_analysis') or {}).get('category')
        or product.get('ai_category')
        or product.get('category')
        or 'other'
    )
    category_fallbacks = {
        'consumer_electronics': '该电子产品聚焦机身形态、交互方式与便携体验，改善日常操作效率。',
        '消费电子': '该电子产品聚焦机身形态、交互方式与便携体验，改善日常操作效率。',
        'wearable_tech': '该可穿戴产品兼顾佩戴舒适度、信息显示与日常功能体验。',
        '可穿戴设备': '该可穿戴产品兼顾佩戴舒适度、信息显示与日常功能体验。',
        'transportation': '该出行产品聚焦结构效率、便携收纳与日常移动体验。',
        '交通工具': '该出行产品聚焦结构效率、便携收纳与日常移动体验。',
        'furniture_lighting': '该家具产品通过造型、结构和材质优化空间适配与使用舒适度。',
        '家具照明': '该家具产品通过造型、结构和材质优化空间适配与使用舒适度。',
        'home_appliances': '该家电产品优化操作、清洁维护与家庭场景中的使用效率。',
        '家用电器': '该家电产品优化操作、清洁维护与家庭场景中的使用效率。',
        'tools_equipment': '该工具产品围绕握持、结构强度与操作效率进行设计。',
        '工具设备': '该工具产品围绕握持、结构强度与操作效率进行设计。',
        'kitchen_tableware': '该餐厨产品兼顾操作便利、清洁维护与收纳效率。',
        '厨房餐厨': '该餐厨产品兼顾操作便利、清洁维护与收纳效率。',
        'medical_health': '该医疗健康产品强调安全操作、信息清晰度与使用流程适配。',
        '医疗健康': '该医疗健康产品强调安全操作、信息清晰度与使用流程适配。',
        'sports_outdoors': '该户外产品兼顾耐用性、便携性与复杂环境下的使用体验。',
        '户外运动': '该户外产品兼顾耐用性、便携性与复杂环境下的使用体验。',
        'commercial_equipment': '该设备围绕结构可靠性、操作效率与专业使用场景展开设计。',
        '工业设备': '该设备围绕结构可靠性、操作效率与专业使用场景展开设计。',
    }
    fallback = category_fallbacks.get(raw_category, '该产品聚焦外观、功能与实际使用体验。')

    value = _clean_text(text)
    boilerplate = (
        '具体功能以原文发布信息为准',
        '具体信息以原文为准',
        '更多细节请查看原文',
        '更多细节请打开原文查看',
        '现有公开资料尚不足以确认更多结构、材料和功能细节',
        '页面展示基于原文可确认的产品定位与使用场景',
        '该条产品已完成来源核验',
        '该条资讯已完成来源核验',
        '具体规格、上市状态与材料信息以原文为准',
    )
    for phrase in boilerplate:
        value = value.replace(phrase, '')
    value = re.sub(r'[；;，,、\s]+[。；;]+', '。', value)
    value = re.sub(r'[；;，,、\s]+$', '', value).strip('；;，,、 ')
    if not re.search(r'[\u4e00-\u9fffA-Za-z0-9]', value):
        value = fallback
    if len(value) <= limit:
        result = value if value.endswith(('。', '！', '？')) else value + '。'
    else:
        clipped = value[:limit]
        boundary = max(clipped.rfind(mark) for mark in ('，', '；', '。'))
        if boundary >= int(limit * 0.58):
            clipped = clipped[:boundary]
        result = clipped.rstrip('，；;。 ') + '。'
    return result if _chinese_primary(result) else fallback

def image_path(product: dict) -> str:
    return str(product.get('local_image_path') or product.get('image_url') or '')


def product_id(product: dict, index: int) -> str:
    raw = str(product.get('product_id') or f'product-{index}')
    return re.sub(r'[^A-Za-z0-9._-]+', '-', raw).strip('-') or f'product-{index}'


def category(product: dict) -> str:
    ai = product.get('ai_analysis') or {}
    key = str(ai.get('category') or product.get('ai_category') or product.get('category') or 'other')
    return str(ai.get('category_label') or CATEGORY_LABELS.get(key, key))


def brand(product: dict) -> str:
    return str(product.get('brand') or product.get('source') or product.get('publisher') or '未知品牌')


def has_named_brand(product: dict) -> bool:
    """Return True only for an explicit, usable product brand."""
    value = str(product.get('brand') or '').strip()
    folded = value.casefold()
    if not value:
        return False
    placeholders = ('未标注', '未知品牌', '独立设计', 'unknown brand', 'unbranded', 'independent')
    return not any(marker in folded for marker in placeholders)


def materials(product: dict) -> list[str]:
    ai = product.get('ai_analysis') or {}
    values = product.get('materials') or ai.get('materials') or []
    return [str(v) for v in values if str(v).strip()]


def redirect_page(anchor: str) -> str:
    target = f'{PORTAL_NAME}#{anchor}'
    return f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="0;url={target}"><title>正在打开设计情报工作台</title></head><body><p><a href="{target}">打开设计情报工作台</a></p><script>location.replace({json.dumps(target)});</script></body></html>'''


CSS = r'''
*{box-sizing:border-box}html{scroll-behavior:smooth;color-scheme:dark}body{margin:0;background:#090a0a;color:#f3f3f1;font-family:Inter,"Noto Sans SC",system-ui,-apple-system,sans-serif;line-height:1.55}.topbar{position:sticky;top:0;z-index:30;display:flex;justify-content:space-between;align-items:center;gap:24px;padding:16px clamp(18px,4vw,56px);background:#0b0c0ce8;border-bottom:1px solid #292a2a;backdrop-filter:blur(18px)}.brandmark{font-size:12px;letter-spacing:.14em;font-weight:800;white-space:nowrap}.nav{display:flex;gap:7px;overflow:auto;padding-bottom:2px}.nav a{min-width:68px;border:0;background:transparent;color:#8f9191;padding:8px 10px;border-radius:12px;white-space:nowrap;cursor:pointer;text-decoration:none;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:5px;font-size:11px;font-weight:700;letter-spacing:.03em}.nav a.active,.nav a:hover{background:#242626;color:#fff}.nav-icon{width:20px;height:20px;display:grid;place-items:center}.nav-icon svg{width:100%;height:100%;fill:none;stroke:currentColor;stroke-width:1.65;stroke-linecap:round;stroke-linejoin:round}.nav-label{line-height:1;white-space:nowrap}.shell{max-width:1440px;margin:auto;padding:42px clamp(18px,4vw,56px) 100px}.js .view[hidden]{display:none}.no-js-note{margin:0;padding:10px 18px;background:#2b2412;color:#f3d98a;text-align:center;font-size:12px}.js .no-js-note{display:none}.view{scroll-margin-top:96px}.hero{display:flex;justify-content:space-between;gap:30px;align-items:end;margin-bottom:34px}.hero h1{margin:0;font-size:clamp(38px,7vw,92px);line-height:.92;letter-spacing:-.06em}.hero p{max-width:560px;color:#989a9a}.stats{display:flex;gap:22px;flex-wrap:wrap;margin:18px 0 28px}.stat{min-width:120px}.stat b{font-size:30px}.stat span{display:block;color:#858787;font-size:12px}.toolbar{display:flex;gap:10px;flex-wrap:wrap;margin:24px 0}.toolbar input,.toolbar select,.pill,button.action{background:#171919;color:#f2f2f0;border:1px solid #333636;border-radius:999px;padding:11px 15px}.toolbar input{min-width:min(360px,100%)}.gallery{columns:4 280px;column-gap:20px}.card{break-inside:avoid;margin:0 0 20px;background:#121414;border:1px solid #2b2d2d;border-radius:18px;overflow:hidden}.card img{width:100%;height:auto;display:block;background:#181a1a}.copy{padding:16px}.meta{display:flex;justify-content:space-between;gap:12px;color:#8f9191;font-size:11px;text-transform:uppercase;letter-spacing:.07em}.card h3{font-size:18px;line-height:1.2;margin:10px 0}.card p{color:#a4a6a6;font-size:13px}.actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}.actions a,.actions button{font-size:12px;color:#e9e9e7;background:#202222;border:1px solid #343737;border-radius:999px;padding:8px 11px;text-decoration:none;cursor:pointer}.panel{background:#121414;border:1px solid #2b2d2d;border-radius:18px;padding:20px;margin:15px 0}.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:18px}.compare-table{width:100%;border-collapse:collapse;min-width:900px}.compare-table th,.compare-table td{padding:12px;border-bottom:1px solid #303333;text-align:left;vertical-align:top}.scroll{overflow:auto}.tag{display:inline-block;font-size:11px;background:#242626;padding:5px 8px;border-radius:999px;margin:3px}.metric{font-size:48px;font-weight:800}.bar{height:10px;background:#282a2a;border-radius:10px;overflow:hidden;margin-top:10px}.bar i{display:block;height:100%;background:#eee}.empty{padding:45px;text-align:center;border:1px dashed #3a3d3d;border-radius:18px;color:#858787}.detail-link{color:inherit}.board-card img{aspect-ratio:4/3;object-fit:cover}.toast{position:fixed;right:20px;bottom:20px;background:#f3f3f1;color:#111;padding:12px 16px;border-radius:12px;opacity:0;transform:translateY(10px);transition:.2s;pointer-events:none}.toast.show{opacity:1;transform:none}@media(max-width:780px){.topbar{align-items:flex-start;flex-direction:column}.hero{align-items:flex-start;flex-direction:column}.gallery{columns:1}.shell{padding-top:28px}.hero h1{font-size:52px}}
'''

# Keep the portal functional layout, but make it feel like the canonical editorial
# gallery: the same neutral palette, generous editorial type, glass navigation,
# masonry rhythm and restrained rounded controls.
GALLERY_STYLE = r'''
:root{color-scheme:light dark;--bg:#f3f1ec;--surface:#fff;--surface-2:#ebe8e1;--text:#11110f;--muted:#72716c;--line:rgba(17,17,15,.13);--glass:rgba(243,241,236,.82);--accent:#11110f;--accent-text:#fff;--shadow:0 22px 65px rgba(28,24,18,.13);--radius:13px}
@media(prefers-color-scheme:dark){:root{--bg:#080909;--surface:#111212;--surface-2:#171919;--text:#f2f1ec;--muted:#93938d;--line:rgba(255,255,255,.11);--glass:rgba(8,9,9,.84);--accent:#f2f1ec;--accent-text:#090a0a;--shadow:0 25px 70px rgba(0,0,0,.4)}}
body{background:var(--bg);color:var(--text);font-family:Inter,"Noto Sans SC",system-ui,sans-serif;-webkit-font-smoothing:antialiased}.topbar{position:sticky;top:0;padding:0 clamp(18px,4vw,56px);min-height:76px;background:var(--glass);border-bottom:1px solid var(--line);backdrop-filter:blur(18px) saturate(125%)}.brandmark{color:var(--text);font-size:11px;letter-spacing:.16em}.nav{gap:18px}.nav a{color:var(--muted);border-radius:0;padding:23px 2px 20px;font:650 10px/1 Inter,"Noto Sans SC",system-ui,sans-serif;letter-spacing:.1em}.nav a.active,.nav a:hover{background:transparent;color:var(--text);box-shadow:inset 0 -2px var(--text)}.shell{max-width:1340px;padding:58px clamp(18px,4vw,56px) 100px}.hero{gap:50px;margin-bottom:38px}.hero h1{font-size:clamp(44px,6.5vw,88px);line-height:.98;letter-spacing:-.068em;color:var(--text)}.hero p{color:var(--muted);font-size:14px}.stats{gap:0;border:1px solid var(--line);display:grid;grid-template-columns:repeat(2,minmax(130px,1fr));max-width:390px}.stat{padding:17px;border-right:1px solid var(--line)}.stat:last-child{border:0}.stat b{color:var(--text);font-size:28px}.stat span,.meta{color:var(--muted)}.gallery{columns:3 330px;column-gap:30px}.card{background:var(--surface);border:0;border-radius:var(--radius);box-shadow:0 0 0 1px var(--line);margin-bottom:30px;transition:transform .25s,box-shadow .25s}.card:hover{transform:translateY(-3px);box-shadow:var(--shadow)}.card img{background:var(--surface-2)}.copy{padding:17px}.card h3{font-size:18px;letter-spacing:-.025em;color:var(--text)}.card p{color:var(--muted);line-height:1.65}.actions a,.actions button,.toolbar input,.toolbar select,button.action{background:var(--surface);color:var(--text);border:1px solid var(--line);border-radius:999px}.actions a:hover,.actions button:hover,button.action:hover{background:var(--accent);color:var(--accent-text)}.panel{background:var(--surface);border:1px solid var(--line);border-radius:var(--radius);box-shadow:none}.tag{background:var(--surface-2);color:var(--text)}.compare-table th,.compare-table td{border-color:var(--line)}.bar{background:var(--surface-2)}.bar i{background:var(--text)}.toast{background:var(--text);color:var(--bg)}
@media(max-width:780px){.topbar{padding:0 18px;min-height:auto}.nav{width:100%;gap:13px}.nav a{padding:12px 2px}.shell{padding-top:34px}.gallery{columns:1}.stats{width:100%;max-width:none}.hero h1{font-size:52px}}
'''

# Structural rules copied from the canonical gallery shell.  Portal sections keep
# their own content, but sit inside the same rails, fixed header and editorial grid.
CANONICAL_PORTAL_LAYOUT = r'''
:root{--rail:78px;--header:76px}.topbar{position:fixed;z-index:80;left:var(--rail);right:var(--rail);top:0;height:var(--header);min-height:var(--header);display:grid;grid-template-columns:1fr auto 1fr;align-items:center;padding:0 30px}.topbar .brandmark{justify-self:start}.topbar .nav{justify-self:center;align-items:center}.topbar .nav a{min-width:auto;padding:26px 0 23px}.side-rail{position:fixed;z-index:90;top:0;bottom:0;width:var(--rail);background:var(--surface);display:flex;align-items:center;justify-content:center}.side-rail.left{left:0;border-right:1px solid var(--line)}.side-rail.right{right:0;border-left:1px solid var(--line)}.vertical-stack{display:flex;align-items:center;gap:13px;writing-mode:vertical-rl;transform:rotate(180deg)}.rail-label{font:650 10px/1 Inter,"Noto Sans SC",system-ui,sans-serif;letter-spacing:.16em;text-transform:uppercase;color:var(--muted)}.shell{max-width:none;padding:calc(var(--header) + 42px) calc(var(--rail) + 36px) 90px}.shell>.view{max-width:1340px;margin-left:auto;margin-right:auto}.hero{max-width:1340px}.gallery{max-width:1340px}.no-js-note{position:relative;z-index:100}@media(max-width:900px){:root{--rail:0px}.side-rail{display:none}.topbar{left:0;right:0;grid-template-columns:1fr auto;padding:0 17px}.topbar .nav{justify-self:end}.shell{padding-left:18px;padding-right:18px}}@media(max-width:780px){.topbar{position:sticky;height:auto;min-height:auto}.topbar .nav{width:100%;justify-content:flex-start}.topbar .nav a{padding:12px 2px}.shell{padding-top:34px}}
'''


def portal_document(
    products: list[dict],
    report_date: str,
    latest_date: str | None = None,
    latest_url: str | None = None,
) -> str:
    # The portal's primary view intentionally uses the canonical gallery document
    # itself as the layout source. This prevents visual drift from the reference
    # gallery (rails, header, hero, filters, card proportions and interactions).
    localized = []
    for product in products:
        item = dict(product)
        supplied = _clean_text(item.get('description_zh'))
        base_description = supplied if _chinese_primary(supplied) else chinese_evidence_summary(item)
        item['description_zh'] = concise_product_description(item, base_description)
        localized.append(item)
    canonical = HTMLGenerator(date=report_date, use_local_images=True).generate(localized)
    canonical = canonical.replace(
        'data-gallery-template="canonical-v3.4"',
        'data-gallery-template="canonical-v3.4" data-portal-template="phase1-v3.4"',
        1,
    )
    data = []
    for i, p in enumerate(localized):
        row = {
            'id': str(p.get('product_id') or i),
            'title': str(p.get('title') or ''),
            'brand': str(p.get('brand') or p.get('publisher') or p.get('source') or ''),
            'source': str(p.get('publisher') or p.get('source') or ''),
            'category': category(p),
            'description': p['description_zh'],
            'news_type': str(p.get('news_type') or p.get('verification_status') or '已入库资讯'),
            # A product without an explicit first-seen date belongs to this daily issue.
            'added_date': str(p.get('first_seen_date') or p.get('published_at') or report_date)[:10],
            'image': image_path(p),
            'detail': f'details/{product_id(p, i)}.html',
            'page_url': str(p.get('page_url') or p.get('canonical_url') or p.get('url') or ''),
            'official': any(
                marker in str(
                    p.get('news_type')
                    or p.get('source_type')
                    or p.get('source_tier')
                    or ''
                ).lower()
                for marker in ('official', '官方')
            ),
        }
        data.append(enrich_trend_record(p, row))
    categories = Counter(x['category'] or '其他' for x in data)
    panel = f'''<style>.content[hidden],.portal-workbench[hidden]{{display:none!important}}.portal-workbench{{max-width:1340px;margin:0 auto;padding:calc(var(--header) + 42px) calc(var(--rail) + 36px) 90px}}.portal-panel{{background:var(--surface);border:1px solid var(--line);border-radius:var(--radius);padding:24px}}.portal-panel h1{{font-size:clamp(38px,6vw,72px);letter-spacing:-.06em;margin:0 0 16px}}.portal-panel input{{width:min(520px,100%);padding:12px 15px;border:1px solid var(--line);border-radius:99px;background:var(--surface-2);color:var(--text)}}.portal-list{{display:grid;gap:12px;margin-top:24px}}.portal-item{{padding:16px;border:1px solid var(--line);border-radius:12px}}.portal-item p{{color:var(--muted);margin:8px 0 0}}@media(max-width:900px){{.portal-workbench{{padding-left:18px;padding-right:18px}}}}</style><main class="portal-workbench" id="portalWorkbench" hidden><section class="portal-panel"><h1 id="portalTitle">检索</h1><input id="portalSearch" placeholder="搜索产品、品牌和中文说明"><div class="portal-list" id="portalList"></div></section></main><script>const PORTAL_PRODUCTS={json.dumps(data, ensure_ascii=False)};const galleryContent=document.querySelector('.content'),workbench=document.getElementById('portalWorkbench'),title=document.getElementById('portalTitle'),list=document.getElementById('portalList'),search=document.getElementById('portalSearch');function rows(a){{list.innerHTML=a.map(x=>`<article class="portal-item"><b>${{x.title}}</b><small> · ${{x.brand}} · ${{x.category}}</small><p>${{x.description}}</p></article>`).join('')||'<p>暂无可展示内容。</p>'}}function showPortal(name){{galleryContent.hidden=false;workbench.hidden=true;if(name==='today'||name==='gallery')return;if(name==='archive'){{title.textContent='归档';rows([])}}else if(name==='trends'){{title.textContent='趋势';rows(Object.entries({json.dumps(dict(categories), ensure_ascii=False)}).map(([k,v])=>({{title:k+'：'+v+' 项',brand:'当期统计',category:'趋势',description:'仅展示本期产品结构，不作长期预测。'}})))}}else if(name==='compare'){{title.textContent='产品对比';rows(PORTAL_PRODUCTS)}}else if(name==='board'||name==='selected'){{title.textContent='项目板';rows(PORTAL_PRODUCTS)}}else{{title.textContent='高级检索';rows(PORTAL_PRODUCTS)}}galleryContent.hidden=true;workbench.hidden=false;search.value='';}}document.querySelectorAll('.nav button').forEach(b=>b.onclick=()=>showPortal(b.dataset.nav));search.oninput=()=>{{const q=search.value.toLowerCase();rows(PORTAL_PRODUCTS.filter(x=>(x.title+x.brand+x.category+x.description).toLowerCase().includes(q)))}};</script>'''
    # The live "today" view must follow the requested report date, even when
    # that date has zero qualified launches and the rolling gallery still holds
    # earlier entries from the last seven days.
    enhancements = '<script>const PORTAL_REPORT_DATE=' + json.dumps(report_date) + ';</script>' + '''<script>
const archiveButton=document.querySelector('.nav button[data-nav="archive"]');if(archiveButton)archiveButton.remove();
const boardButton=document.querySelector('.nav button[data-nav="board"]');if(boardButton)boardButton.remove();
const selectedButton=document.querySelector('.nav button[data-nav="selected"]');
if(selectedButton){const label=selectedButton.querySelector('.nav-label');if(label)label.textContent='项目板';selectedButton.title='项目板'}
const boardKey='did-project-board';
function boardIds(){try{return JSON.parse(localStorage.getItem(boardKey)||'[]')}catch(e){return []}}
function setBoard(ids){localStorage.setItem(boardKey,JSON.stringify([...new Set(ids)]))}
function selectedIds(){return [...document.querySelectorAll('.select input:checked')].map(x=>x.dataset.id)}
function syncBoardFromChecks(){const ids=new Set(boardIds());document.querySelectorAll('.select input').forEach(x=>x.checked?ids.add(x.dataset.id):ids.delete(x.dataset.id));setBoard([...ids])}
document.querySelectorAll('.select input').forEach(x=>{if(boardIds().includes(x.dataset.id))x.checked=true;x.addEventListener('change',syncBoardFromChecks)});
function compareView(){title.textContent='产品对比';list.innerHTML=PORTAL_PRODUCTS.map(x=>`<label class="portal-item"><input type="checkbox" data-compare-id="${x.id}"> <b>${x.title}</b><small> · ${x.brand} · ${x.category}</small><p>${x.description}</p></label>`).join('');}
function boardView(){syncBoardFromChecks();const ids=boardIds();const items=PORTAL_PRODUCTS.filter(x=>ids.includes(x.id));title.textContent='项目板';list.innerHTML=items.map(x=>`<article class="portal-item"><b>${x.title}</b><button data-remove-id="${x.id}">移除</button><p>${x.description}</p></article>`).join('')||'<p>请先在画廊或今日资讯卡片勾选“保留”，产品会自动加入项目板。</p>';document.querySelectorAll('[data-remove-id]').forEach(b=>b.onclick=()=>{setBoard(boardIds().filter(id=>id!==b.dataset.removeId));const card=document.querySelector(`.select input[data-id="${b.dataset.removeId}"]`);if(card)card.checked=false;boardView()})}
function trendView(){title.textContent='趋势';search.style.display='none';const periods=[['month','月趋势',31],['half','半年趋势',183],['year','年度趋势',366]];list.innerHTML=`<div class="portal-list">${periods.map(x=>`<button class="portal-item" data-trend-days="${x[2]}">${x[1]}</button>`).join('')}<div id="trendResult"></div></div>`;function render(days){const edge=new Date(PORTAL_REPORT_DATE);edge.setDate(edge.getDate()-days+1);const items=PORTAL_PRODUCTS.filter(x=>new Date(x.added_date)>=edge&&new Date(x.added_date)<=new Date(PORTAL_REPORT_DATE));const counts={};items.forEach(x=>counts[x.category]=(counts[x.category]||0)+1);document.getElementById('trendResult').innerHTML=`<article class="portal-item"><b>${days===31?'月趋势':days===183?'半年趋势':'年度趋势'} · ${items.length} 项</b><p>${Object.entries(counts).map(([k,v])=>k+' '+v+' 项').join(' · ')||'该周期暂无已入库产品。'}</p></article>`}document.querySelectorAll('[data-trend-days]').forEach(b=>b.onclick=()=>render(Number(b.datasetTrendDays)));document.querySelectorAll('[data-trend-days]').forEach(b=>b.onclick=()=>render(Number(b.dataset.trendDays)));render(31)}
function dateGalleryView(){const dates=[...new Set(PORTAL_PRODUCTS.map(x=>x.added_date))].sort().reverse();title.textContent='按入库日期浏览';search.style.display='none';list.innerHTML=`<p>近七日可按具体入库日期切换；更早资讯会自动归入对应周期画廊。</p><div class="portal-list">${['全部产品',...dates].map(d=>`<button class="portal-item" data-date-filter="${d==='全部产品'?'all':d}">${d==='全部产品'?d:d+' · '+PORTAL_PRODUCTS.filter(x=>x.added_date===d).length+' 项'}</button>`).join('')}</div><div class="portal-list"><a class="portal-item" href="galleries/weekly/design_intelligence_portal.html">周报画廊（8–30 天）</a><a class="portal-item" href="galleries/monthly/design_intelligence_portal.html">月报画廊（1–6 个月）</a><a class="portal-item" href="galleries/half_year/design_intelligence_portal.html">半年报画廊（6–12 个月）</a><a class="portal-item" href="galleries/annual/design_intelligence_portal.html">年度画廊（1 年以上）</a></div>`;galleryContent.hidden=true;workbench.hidden=false;document.querySelectorAll('[data-date-filter]').forEach(b=>b.onclick=()=>{const date=b.dataset.date;document.querySelectorAll('.card').forEach(card=>{const item=PORTAL_PRODUCTS[Number(card.dataset.index)];card.hidden=date!=='all'&&(!item||item.added_date!==date)});galleryContent.hidden=false;workbench.hidden=true;document.getElementById('gallery').scrollIntoView({behavior:'smooth'})})}
function trendView(){title.textContent='趋势';search.style.display='none';const periods=[['week','周趋势',7],['month','月趋势',31],['half','半年趋势',183],['year','年度趋势',366]];list.innerHTML=`<div class="portal-list">${periods.map(x=>`<button class="portal-item" data-trend-period="${x[2]}">${x[1]}</button>`).join('')}<div id="trendResult"></div></div>`;function render(days){const end=new Date(PORTAL_REPORT_DATE+'T00:00:00');const edge=new Date(end);edge.setDate(edge.getDate()-days+1);const items=PORTAL_PRODUCTS.filter(x=>new Date(x.added_date+'T00:00:00')>=edge&&new Date(x.added_date+'T00:00:00')<=end);const categories={};const types={};items.forEach(x=>{categories[x.category]=(categories[x.category]||0)+1;types[x.news_type]=(types[x.news_type]||0)+1});let chart='';if(days===7){const dates=Array.from({length:7},(_,i)=>{const d=new Date(edge);d.setDate(d.getDate()+i);return d.toISOString().slice(0,10)});const counts=dates.map(d=>items.filter(x=>x.added_date===d).length),max=Math.max(1,...counts);chart=`<div style="display:grid;grid-template-columns:repeat(7,1fr);gap:10px;align-items:end;height:220px;margin:24px 0">${dates.map((d,i)=>`<div style="display:grid;grid-template-rows:1fr auto auto;height:100%;text-align:center;gap:6px"><div style="display:flex;align-items:end;justify-content:center"><i style="display:block;width:min(42px,70%);height:${Math.max(4,counts[i]/max*150)}px;background:#f2f2ef;border-radius:8px 8px 2px 2px"></i></div><b>${counts[i]}</b><small>${d.slice(5)}</small></div>`).join('')}</div>`}document.getElementById('trendResult').innerHTML=`<article class="portal-item"><b>${days===7?'周趋势':days===31?'月趋势':days===183?'半年趋势':'年度趋势'} · ${items.length} 项</b>${chart}<p>品类：${Object.entries(categories).map(([k,v])=>k+' '+v+' 项').join(' · ')||'暂无'}</p><p>资讯类型：${Object.entries(types).map(([k,v])=>k+' '+v+' 项').join(' · ')||'暂无'}</p></article>`}document.querySelectorAll('[data-trend-period]').forEach(b=>b.onclick=()=>render(Number(b.dataset.trendPeriod)));render(7)}
function showTodayGallery(){const items=PORTAL_PRODUCTS.filter(x=>x.added_date===PORTAL_REPORT_DATE);document.querySelectorAll('.card').forEach(card=>{const item=PORTAL_PRODUCTS[Number(card.dataset.index)];card.hidden=!item||item.added_date!==PORTAL_REPORT_DATE});if(items.length){galleryContent.hidden=false;workbench.hidden=true;search.style.display=''}else{title.textContent='今日资讯';list.innerHTML=`<article class="portal-item"><b>${PORTAL_REPORT_DATE} 暂无通过严格核验的新品</b><p>本次仅保留当日正式发布的具体实物产品，并排除旧产品重复报道、概念作品、艺术与建筑内容。可切换到“画廊”浏览近七日入库产品。</p></article>`;galleryContent.hidden=true;workbench.hidden=false;search.style.display='none'}}
document.querySelectorAll('.nav button').forEach(b=>b.onclick=()=>{const n=b.dataset.nav;if(n==='today'){showTodayGallery();return}if(n==='gallery'){dateGalleryView();return}if(n==='compare'){galleryContent.hidden=true;workbench.hidden=false;search.value='';search.style.display='none';compareView();return}if(n==='selected'){galleryContent.hidden=true;workbench.hidden=false;search.value='';search.style.display='none';boardView();return}if(n==='trends'){galleryContent.hidden=true;workbench.hidden=false;trendView();return}search.style.display='';showPortal(n)});showTodayGallery();
</script>'''
    enhancements += f'<style>{TREND_CSS}</style><script>{TREND_JS}</script>'
    navigation_v2 = r'''
<style>
#portalSearch{display:none!important}
.period-intro{color:var(--muted);max-width:780px}.period-section{margin-top:28px}.period-section h2{margin:0 0 10px;font-size:13px;letter-spacing:.08em;color:var(--muted)}.period-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:10px}.period-btn{display:flex;justify-content:space-between;gap:14px;text-align:left;background:var(--surface);color:var(--text);cursor:pointer}.period-btn small{color:var(--muted);white-space:nowrap}.brand-compare-toolbar{display:flex;justify-content:space-between;gap:18px;align-items:center;margin:18px 0 24px;padding:16px;border:1px solid var(--line);border-radius:12px}.brand-compare-toolbar p{margin:0;color:var(--muted)}.brand-compare-toolbar button{border:1px solid var(--line);background:var(--surface-2);color:var(--text);border-radius:999px;padding:8px 12px;cursor:pointer}.compare-selection{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:10px;margin-bottom:22px}.compare-selected-card{display:grid;grid-template-columns:70px 1fr;gap:12px;padding:10px;border:1px solid var(--line);border-radius:10px}.compare-selected-card img{width:70px;height:58px;object-fit:cover;border-radius:7px;background:var(--surface-2)}.compare-selected-card small{color:var(--muted)}.brand-release-list{display:grid;gap:20px}.brand-release-group{border-top:1px solid var(--line);padding-top:16px}.brand-release-head{display:flex;justify-content:space-between;align-items:end;gap:16px;margin-bottom:10px}.brand-release-head h2{margin:0;font-size:24px}.brand-release-head span{color:var(--muted);font-size:12px}.brand-product-list{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:10px}.brand-product-row{display:grid;grid-template-columns:86px 1fr auto;gap:13px;align-items:center;padding:10px;border:1px solid var(--line);border-radius:12px;cursor:pointer}.brand-product-row:hover{background:var(--surface-2)}.brand-product-row img{width:86px;height:72px;object-fit:cover;border-radius:8px;background:var(--surface-2)}.brand-product-row b{display:block;line-height:1.25}.brand-product-row small{display:block;margin-top:6px;color:var(--muted)}.release-badge{display:inline-block;margin-top:7px;padding:3px 7px;border-radius:999px;background:var(--surface-2);font-size:9px}.release-badge.official{background:var(--text);color:var(--bg)}.brand-product-row input{width:18px;height:18px;accent-color:var(--accent)}
@media(max-width:620px){.brand-product-list{grid-template-columns:1fr}.brand-product-row{grid-template-columns:72px 1fr auto}.brand-product-row img{width:72px;height:64px}.brand-compare-toolbar{align-items:flex-start;flex-direction:column}}
</style>
<script>
let periodBuckets=[];
const portalCompareIds=new Set();
function escapePortal(value){return String(value??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]))}
function localDate(value){return new Date(String(value).slice(0,10)+'T00:00:00')}
function isoDate(value){return value.getFullYear()+'-'+String(value.getMonth()+1).padStart(2,'0')+'-'+String(value.getDate()).padStart(2,'0')}
function startOfWeek(value){const d=new Date(value),offset=(d.getDay()+6)%7;d.setDate(d.getDate()-offset);return d}
function periodHierarchy(){
  const reference=localDate(PORTAL_LATEST_DATE||PORTAL_REPORT_DATE),map=new Map();
  PORTAL_PRODUCTS.forEach(item=>{
    const d=localDate(item.added_date),age=Math.floor((reference-d)/86400000);let group,key,label,sort;
    if(age<=6){group='近七日 · 按天';key='day:'+item.added_date;label=item.added_date;sort=item.added_date}
    else if(age<=30){const start=startOfWeek(d),end=new Date(start);end.setDate(end.getDate()+6);group='八至三十日 · 周报';key='week:'+isoDate(start);label='周报 '+isoDate(start).slice(5)+'—'+isoDate(end).slice(5);sort=isoDate(start)}
    else if(age<=182){group='一至六个月 · 月报';key='month:'+item.added_date.slice(0,7);label='月报 '+item.added_date.slice(0,7);sort=item.added_date.slice(0,7)}
    else if(age<=365){group='六至十二个月 · 年报';key='year:'+item.added_date.slice(0,4);label='年报 '+item.added_date.slice(0,4);sort=item.added_date.slice(0,4)}
    else{group='历史归档';key='history';label='历史归档';sort='0000'}
    if(!map.has(key))map.set(key,{group,key,label,sort,ids:[]});map.get(key).ids.push(String(item.id));
  });
  const order=['近七日 · 按天','八至三十日 · 周报','一至六个月 · 月报','六至十二个月 · 年报','历史归档'];
  return order.map(name=>({name,rows:[...map.values()].filter(x=>x.group===name).sort((a,b)=>b.sort.localeCompare(a.sort))})).filter(x=>x.rows.length);
}
function applyPeriodBucket(index){
  const bucket=periodBuckets[Number(index)],active=bucket?new Set(bucket.ids):null;
  document.querySelectorAll('.card').forEach((card,i)=>{const id=String(PORTAL_PRODUCTS[Number(card.dataset.index)]?.id??PORTAL_PRODUCTS[i]?.id??'');card.hidden=active?!active.has(id):false;card.classList.remove('selected-only-hidden')});
  galleryContent.hidden=false;workbench.hidden=true;document.getElementById('gallery').scrollIntoView({behavior:'smooth',block:'start'});if(typeof showToast==='function')showToast(bucket?bucket.label+' · '+bucket.ids.length+' 项':'全部产品 · '+PORTAL_PRODUCTS.length+' 项');
}
function dateGalleryViewV2(){
  title.textContent='按入库周期浏览';periodBuckets=[];const sections=periodHierarchy();
  list.innerHTML=`<p class="period-intro">近七日保留每日入口；第 8–30 日自动合并为周报；第 31–182 日合并为月报；第 183–365 日进入年报。</p><div class="period-section"><div class="period-grid"><button class="portal-item period-btn" data-period-all><b>全部产品</b><small>${PORTAL_PRODUCTS.length} 项</small></button></div></div>`+sections.map(section=>`<section class="period-section"><h2>${escapePortal(section.name)}</h2><div class="period-grid">${section.rows.map(row=>{const index=periodBuckets.push(row)-1;return `<button class="portal-item period-btn" data-period-index="${index}"><b>${escapePortal(row.label)}</b><small>${row.ids.length} 项</small></button>`}).join('')}</div></section>`).join('');
  galleryContent.hidden=true;workbench.hidden=false;document.querySelector('[data-period-all]').onclick=()=>applyPeriodBucket(-1);document.querySelectorAll('[data-period-index]').forEach(button=>button.onclick=()=>applyPeriodBucket(button.dataset.periodIndex));
}
function compareSelectionHtml(){const selected=PORTAL_PRODUCTS.filter(x=>portalCompareIds.has(String(x.id)));return selected.length?`<div class="compare-selection">${selected.map(x=>`<article class="compare-selected-card"><img src="${escapePortal(x.image)}" alt=""><div><b>${escapePortal(x.title)}</b><small>${escapePortal(x.brand)} · ${escapePortal(x.category)}</small></div></article>`).join('')}</div>`:'<p class="period-intro">从下方品牌新品清单勾选产品，可同时保留最多 6 项进行横向观察。</p>'}
function compareViewV2(){
  title.textContent='品牌新品对比';const grouped=new Map();[...PORTAL_PRODUCTS].sort((a,b)=>(b.added_date||'').localeCompare(a.added_date||'')).forEach(item=>{const key=item.brand||item.source||'未知品牌';if(!grouped.has(key))grouped.set(key,[]);grouped.get(key).push(item)});
  const groups=[...grouped.entries()].sort((a,b)=>b[1].length-a[1].length||a[0].localeCompare(b[0]));
  list.innerHTML=`<div class="brand-compare-toolbar"><p><b>品牌新品清单</b><br>按品牌集中查看当期发布与媒体收录产品。</p><button id="clearPortalCompare">清空选择</button></div><div id="portalCompareSelection">${compareSelectionHtml()}</div><div class="brand-release-list">${groups.map(([brand,items])=>`<section class="brand-release-group"><header class="brand-release-head"><h2>${escapePortal(brand)}</h2><span>${items.length} 项新品/新稿</span></header><div class="brand-product-list">${items.map(x=>`<label class="brand-product-row"><img src="${escapePortal(x.image)}" alt=""><span><b>${escapePortal(x.title)}</b><small>${escapePortal(x.added_date)} · ${escapePortal(x.category)}</small><i class="release-badge ${x.official?'official':''}">${x.official?'官方新品':'媒体新稿'}</i></span><input type="checkbox" data-brand-compare="${escapePortal(x.id)}" ${portalCompareIds.has(String(x.id))?'checked':''}></label>`).join('')}</div></section>`).join('')}</div>`;
  document.querySelectorAll('[data-brand-compare]').forEach(input=>input.onchange=()=>{const id=String(input.dataset.brandCompare);if(input.checked&&portalCompareIds.size>=6){input.checked=false;if(typeof showToast==='function')showToast('最多同时选择 6 项产品');return}input.checked?portalCompareIds.add(id):portalCompareIds.delete(id);document.getElementById('portalCompareSelection').innerHTML=compareSelectionHtml()});document.getElementById('clearPortalCompare').onclick=()=>{portalCompareIds.clear();compareViewV2()};
}
function showTodayGalleryV2(){
  if(PORTAL_REPORT_DATE!==PORTAL_LATEST_DATE&&PORTAL_LATEST_URL){window.location.href=PORTAL_LATEST_URL;return}
  const activeDate=PORTAL_LATEST_DATE||PORTAL_REPORT_DATE,items=PORTAL_PRODUCTS;document.querySelectorAll('.card').forEach(card=>{card.hidden=false;card.classList.remove('selected-only-hidden')});
  if(items.length){galleryContent.hidden=false;workbench.hidden=true;window.scrollTo({top:0,behavior:'smooth'})}else{title.textContent='今日资讯';list.innerHTML=`<article class="portal-item"><b>${escapePortal(activeDate)} 暂无通过严格核验的新品</b><p>可进入“画廊”按日、周、月与年报周期浏览已入库产品。</p></article>`;galleryContent.hidden=true;workbench.hidden=false}
}
document.querySelectorAll('.nav button').forEach(button=>button.onclick=()=>{const name=button.dataset.nav;if(name==='today'){showTodayGalleryV2();return}if(name==='gallery'){dateGalleryViewV2();return}if(name==='compare'){galleryContent.hidden=true;workbench.hidden=false;compareViewV2();return}if(name==='selected'){galleryContent.hidden=true;workbench.hidden=false;boardView();return}if(name==='trends'){galleryContent.hidden=true;workbench.hidden=false;window.trendView();return}showPortal(name)});
const headerSearch=document.getElementById('globalSearch');if(headerSearch)headerSearch.addEventListener('input',()=>{galleryContent.hidden=false;workbench.hidden=true;document.querySelectorAll('.nav button').forEach(x=>x.classList.toggle('active',x.dataset.nav==='gallery'))});
if(location.hash==='#compare')compareViewV2();else if(location.hash==='#gallery')dateGalleryViewV2();else if(location.hash==='#today')showTodayGalleryV2();else if(!location.hash){document.querySelectorAll('.card').forEach(card=>{card.hidden=false;card.classList.remove('selected-only-hidden')});galleryContent.hidden=false;workbench.hidden=true}
</script>
'''
    enhancements += (
        '<script>const PORTAL_LATEST_DATE='
        + json.dumps(latest_date or report_date)
        + ';const PORTAL_LATEST_URL='
        + json.dumps(latest_url or '')
        + ';</script>'
        + navigation_v2
    )
    document = canonical.replace('</body>', panel + enhancements + '<div hidden data-view="gallery"></div><div hidden data-view="explore"></div><div hidden data-view="compare"></div><div hidden data-view="board"></div><div hidden data-view="topics"></div><div hidden data-view="trends"></div></body>', 1)
    document = document.replace("return d.toISOString().slice(0,10)", "return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')")
    weekly_href = 'design_intelligence_portal.html' if any(p.get('news_type') for p in products) else 'galleries/current_week/design_intelligence_portal.html'
    weekly_link = f'<a class="portal-item" href="{weekly_href}">本周资讯与周趋势（周一至周日）</a>'
    return document.replace('<div class="portal-list"><a class="portal-item" href="galleries/weekly/design_intelligence_portal.html">', '<div class="portal-list">' + weekly_link + '<a class="portal-item" href="galleries/weekly/design_intelligence_portal.html">', 1)

    cats = sorted({category(p) for p in products})
    product_rows = []
    cards = []
    data = []
    for i, p in enumerate(products):
        pid = product_id(p, i)
        desc = chinese_description(p)
        cat = category(p)
        br = brand(p)
        img = image_path(p)
        mats = materials(p)
        title = str(p.get('title') or '未命名产品')
        page_url = str(p.get('page_url') or p.get('url') or '')
        search_text = f'{title} {br} {cat} {desc}'.lower()
        cards.append(f'''<article class="card" data-item data-id="{esc(pid, True)}" data-category="{esc(cat, True)}" data-search="{esc(search_text, True)}"><a class="detail-link" href="details/{esc(pid, True)}.html"><img src="{esc(img, True)}" alt="{esc(title, True)}" loading="lazy"></a><div class="copy"><div class="meta"><span>{esc(cat)}</span><span>{esc(br)}</span></div><h3><a class="detail-link" href="details/{esc(pid, True)}.html">{esc(title)}</a></h3><p>{esc(desc)}</p><div class="actions"><a href="details/{esc(pid, True)}.html">详情</a>{f'<a href="{esc(page_url, True)}" target="_blank" rel="noopener">原文 ↗</a>' if page_url else ''}<button data-add-board="{esc(pid, True)}">加入项目板</button><label><input type="checkbox" data-compare="{esc(pid, True)}"> 对比</label></div></div></article>''')
        product_rows.append(f'''<tr data-compare-row="{esc(pid, True)}" hidden><td>{esc(title)}</td><td>{esc(br)}</td><td>{esc(cat)}</td><td>{esc(desc)}</td><td>{''.join(f'<span class="tag">{esc(x)}</span>' for x in mats) or '—'}</td></tr>''')
        data.append({'id': pid, 'title': title, 'brand': br, 'category': cat, 'description': desc, 'image': img, 'detail': f'details/{pid}.html'})

    brands = Counter(brand(p) for p in products)
    mats_count = Counter(x for p in products for x in materials(p))
    cat_count = Counter(category(p) for p in products)
    total = max(1, len(products))

    options = ''.join(f'<option value="{esc(c, True)}">{esc(c)}</option>' for c in cats)
    topics = ''.join(f'<div class="panel"><b>{esc(name)}</b><span style="float:right">{count}</span></div>' for name, count in brands.most_common())
    materials_html = ''.join(f'<span class="tag">{esc(name)} · {count}</span>' for name, count in mats_count.most_common()) or '<p>当前数据尚未形成稳定材料标签。</p>'
    trends = ''.join(f'<div class="panel"><b>{esc(name)}</b><span style="float:right">{count}</span><div class="bar"><i style="width:{count/total*100:.1f}%"></i></div></div>' for name, count in cat_count.most_common())

    dataset = json.dumps(data, ensure_ascii=False).replace('</', '<\\/')
    return f'''<!doctype html><html lang="zh-CN" data-portal-template="phase1-v3.4"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(report_date)} 工业设计情报工作台</title><script>document.documentElement.classList.add("js")</script><style>{CSS}{GALLERY_STYLE}{CANONICAL_PORTAL_LAYOUT}</style></head><body><aside class="side-rail left"><div class="vertical-stack"><span class="rail-label">DID / EDITORIAL</span></div></aside><aside class="side-rail right"><div class="vertical-stack"><span class="rail-label">TODAY / {esc(report_date)}</span></div></aside><div class="no-js-note">当前预览环境未启用脚本：导航仍可跳转到各功能分区，但检索、收藏和动态对比需要下载后在浏览器中打开。</div><header class="topbar"><div class="brandmark">INDUSTRIAL DESIGN INTELLIGENCE</div><nav class="nav" aria-label="主导航">
<a href="#gallery" data-view-target="gallery" title="今日画廊"><span class="nav-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="m5 18 5-5 3 3 2-2 4 4"/></svg></span><span class="nav-label">今日画廊</span></a>
<a href="#explore" data-view-target="explore" title="高级检索"><span class="nav-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m15.5 15.5 5 5"/></svg></span><span class="nav-label">高级检索</span></a>
<a href="#compare" data-view-target="compare" title="产品对比"><span class="nav-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M8 4v16M16 4v16M4 8h8M12 16h8"/></svg></span><span class="nav-label">产品对比</span></a>
<a href="#board" data-view-target="board" title="项目板"><span class="nav-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M9 4v16M9 10h12"/></svg></span><span class="nav-label">项目板</span></a>
<a href="#topics" data-view-target="topics" title="品牌与材料"><span class="nav-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M4 7h7v6H4zM13 4h7v9h-7zM4 15h7v5H4zM13 15h7v5h-7z"/></svg></span><span class="nav-label">品牌材料</span></a>
<a href="#trends" data-view-target="trends" title="趋势看板"><span class="nav-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M4 19V9M10 19V5M16 19v-7M22 19V3"/></svg></span><span class="nav-label">趋势看板</span></a>
</nav></header><main class="shell">
<section class="view" id="gallery" data-view="gallery"><div class="hero"><div><p>{esc(report_date)}</p><h1>设计资讯<br>情报工作台</h1></div><p>一个入口整合今日画廊、检索、对比、收藏、专题和基础趋势。产品详情保留独立页面，便于分享与部署。</p></div><div class="stats"><div class="stat"><b>{len(products)}</b><span>产品</span></div><div class="stat"><b>{len(brands)}</b><span>品牌/来源</span></div></div><section class="gallery" id="gallery">{''.join(cards)}</section></section>
<section class="view" id="explore" data-view="explore"><div class="hero"><div><h1>高级检索</h1></div><p>在当前日报数据内按产品、品牌、品类和中文说明快速检索。</p></div><div class="toolbar"><input id="search" placeholder="搜索产品、品牌与说明"><select id="category"><option value="">全部品类</option>{options}</select></div><section class="gallery" id="explore-results">{''.join(cards)}</section></section>
<section class="view" id="compare" data-view="compare"><div class="hero"><div><h1>产品对比</h1></div><p>从画廊勾选 2–6 项产品，对比品牌、品类、中文说明和材料标签。</p></div><div class="panel"><span id="compare-count">已选择 0 项</span> <button class="action" id="clear-compare">清空</button></div><div class="panel scroll"><table class="compare-table"><thead><tr><th>产品</th><th>品牌</th><th>品类</th><th>中文说明</th><th>材料</th></tr></thead><tbody>{''.join(product_rows)}</tbody></table><div id="compare-empty" class="empty">请在今日画廊或检索页勾选产品。</div></div></section>
<section class="view" id="board" data-view="board"><div class="hero"><div><h1>收藏与项目板</h1></div><p>收藏保存在当前浏览器，可用于静态部署和离线研究。</p></div><div id="board-grid" class="grid"></div></section>
<section class="view" id="topics" data-view="topics"><div class="hero"><div><h1>品牌与材料</h1></div><p>根据当前日报自动汇总品牌/来源和材料标签。</p></div><div class="grid"><div><h2>品牌档案</h2>{topics}</div><div class="panel"><h2>材料专题</h2>{materials_html}</div></div></section>
<section class="view" id="trends" data-view="trends"><div class="hero"><div><h1>基础趋势看板</h1></div><p>当前展示当期结构统计，不将单日数据包装为长期趋势预测。</p></div><div class="panel"><div class="metric">{len(products)}</div><p>本期合格产品</p></div>{trends}</section>
</main><div class="toast" id="toast">已更新</div><script>const PRODUCTS={dataset};
const q=(s,r=document)=>r.querySelector(s),qa=(s,r=document)=>[...r.querySelectorAll(s)];const toast=q('#toast');function notify(t){{toast.textContent=t;toast.classList.add('show');setTimeout(()=>toast.classList.remove('show'),1300)}}
function showView(name){{const valid=['gallery','explore','compare','board','topics','trends'];if(!valid.includes(name))name='gallery';qa('[data-view]').forEach(v=>v.hidden=v.dataset.view!==name);qa('[data-view-target]').forEach(b=>b.classList.toggle('active',b.dataset.viewTarget===name));if(location.hash!=='#'+name)history.replaceState(null,'','#'+name);if(name==='board')renderBoard();if(name==='compare')renderCompare();window.scrollTo(0,0)}}
qa('[data-view-target]').forEach(b=>b.addEventListener('click',e=>{{e.preventDefault();showView(b.dataset.viewTarget)}}));window.addEventListener('hashchange',()=>showView(location.hash.slice(1)));showView(location.hash.slice(1)||'gallery');
const search=q('#search'),cat=q('#category');function filter(){{const text=(search.value||'').toLowerCase(),c=cat.value||'';qa('#explore-results [data-item]').forEach(x=>x.hidden=!((!text||x.dataset.search.includes(text))&&(!c||x.dataset.category===c)))}}search.addEventListener('input',filter);cat.addEventListener('change',filter);
function boardIds(){{return JSON.parse(localStorage.getItem('design-board')||'[]')}}function setBoard(a){{localStorage.setItem('design-board',JSON.stringify(a))}}qa('[data-add-board]').forEach(b=>b.addEventListener('click',()=>{{let a=boardIds();if(!a.includes(b.dataset.addBoard))a.push(b.dataset.addBoard);setBoard(a);notify('已加入项目板')}}));function renderBoard(){{const ids=boardIds(),list=PRODUCTS.filter(x=>ids.includes(x.id));q('#board-grid').innerHTML=list.map(x=>`<article class="card board-card"><img src="${{x.image}}" alt=""><div class="copy"><div class="meta"><span>${{x.category}}</span><span>${{x.brand}}</span></div><h3><a class="detail-link" href="${{x.detail}}">${{x.title}}</a></h3><p>${{x.description}}</p><div class="actions"><a href="${{x.detail}}">详情</a><button data-remove-board="${{x.id}}">移除</button></div></div></article>`).join('')||'<div class="empty">尚未加入项目。请从画廊或检索页添加。</div>';qa('[data-remove-board]').forEach(b=>b.onclick=()=>{{setBoard(boardIds().filter(x=>x!==b.dataset.removeBoard));renderBoard()}})}}
let compared=[];qa('[data-compare]').forEach(c=>c.addEventListener('change',()=>{{if(c.checked){{if(compared.length>=6){{c.checked=false;notify('最多选择 6 项');return}}if(!compared.includes(c.dataset.compare))compared.push(c.dataset.compare)}}else compared=compared.filter(x=>x!==c.dataset.compare);qa(`[data-compare="${{c.dataset.compare}}"]`).forEach(x=>x.checked=c.checked);renderCompare()}}));function renderCompare(){{qa('[data-compare-row]').forEach(r=>r.hidden=!compared.includes(r.dataset.compareRow));q('#compare-count').textContent=`已选择 ${{compared.length}} 项`;q('#compare-empty').hidden=compared.length>0}}q('#clear-compare').onclick=()=>{{compared=[];qa('[data-compare]').forEach(x=>x.checked=false);renderCompare()}};
</script></body></html>'''


def portal_document(
    products: list[dict],
    report_date: str,
    latest_date: str | None = None,
    latest_url: str | None = None,
    issue_product_ids: list[str] | set[str] | None = None,
) -> str:
    """Build the portal with one deterministic controller for every view."""
    localized = []
    for product in products:
        item = dict(product)
        supplied = _clean_text(item.get('description_zh'))
        base_description = supplied if _chinese_primary(supplied) else chinese_evidence_summary(item)
        item['description_zh'] = concise_product_description(item, base_description)
        localized.append(item)

    issue_ids = [str(value) for value in issue_product_ids] if issue_product_ids is not None else [str(product.get('product_id') or index) for index, product in enumerate(localized)]
    canonical = HTMLGenerator(date=report_date, use_local_images=True).generate(localized)
    canonical = canonical.replace(
        'data-gallery-template="canonical-v3.4"',
        'data-gallery-template="canonical-v3.4" data-portal-template="phase1-v3.4"',
        1,
    )
    records = []
    for index, product in enumerate(localized):
        row = {
            'id': str(product.get('product_id') or index),
            'title': str(product.get('title') or ''),
            'brand': brand(product),
            'source': str(product.get('publisher') or product.get('source') or ''),
            'category': category(product),
            'description': product['description_zh'],
            'news_type': str(product.get('news_type') or product.get('verification_status') or '已入库资讯'),
            'added_date': str(product.get('first_seen_date') or product.get('published_at') or report_date)[:10],
            'image': image_path(product),
            'detail': f'details/{product_id(product, index)}.html',
            'page_url': str(product.get('page_url') or product.get('canonical_url') or product.get('url') or ''),
            'compare_visible': has_named_brand(product),
            'official': any(
                marker in str(
                    product.get('news_type')
                    or product.get('source_type')
                    or product.get('source_tier')
                    or ''
                ).lower()
                for marker in ('official', '官方')
            ),
        }
        records.append(enrich_trend_record(product, row))

    panel_css = r'''
.content[hidden],.portal-workbench[hidden]{display:none!important}.portal-workbench{max-width:1340px;margin:0 auto;padding:calc(var(--header) + 30px) calc(var(--rail) + 36px) 90px}.portal-panel{background:var(--surface);border:1px solid var(--line);border-radius:var(--radius);padding:24px}.portal-panel h1{font-size:clamp(36px,5vw,64px);line-height:1;letter-spacing:-.055em;margin:0 0 14px}.portal-panel>#portalSearch{display:none!important}.portal-list{display:grid;gap:12px;margin-top:20px}.portal-item{padding:14px 16px;border:1px solid var(--line);border-radius:12px;background:var(--surface);color:var(--text)}.portal-item p{color:var(--muted);margin:7px 0 0}.period-intro{color:var(--muted);max-width:760px;margin:0}.period-section{margin-top:25px}.period-section h2{margin:0 0 9px;font-size:12px;letter-spacing:.08em;color:var(--muted)}.period-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(205px,1fr));gap:9px}.period-btn{display:flex;justify-content:space-between;gap:12px;text-align:left;cursor:pointer}.period-btn:hover{background:var(--surface-2)}.period-btn small{color:var(--muted);white-space:nowrap}.brand-compare-toolbar{display:flex;justify-content:space-between;gap:16px;align-items:center;margin:15px 0 20px;padding:13px 15px;border:1px solid var(--line);border-radius:12px}.brand-compare-toolbar p{margin:0;color:var(--muted);font-size:12px}.brand-compare-toolbar button{border:1px solid var(--line);background:var(--surface-2);color:var(--text);border-radius:999px;padding:8px 12px;cursor:pointer}.compare-selection{display:grid;grid-template-columns:repeat(auto-fill,minmax(215px,1fr));gap:9px;margin-bottom:18px}.compare-selected-card{display:grid;grid-template-columns:60px 1fr;gap:10px;align-items:center;padding:9px;border:1px solid var(--line);border-radius:10px}.compare-selected-card img{width:60px;height:52px;object-fit:cover;border-radius:7px;background:var(--surface-2)}.compare-selected-card b{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;font-size:12px;line-height:1.3}.compare-selected-card small{display:block;color:var(--muted);font-size:9px;margin-top:4px}.brand-release-list{display:grid;gap:18px}.brand-release-group{border-top:1px solid var(--line);padding-top:14px}.brand-release-head{display:flex;justify-content:space-between;align-items:end;gap:14px;margin-bottom:9px}.brand-release-head h2{margin:0;font-size:21px}.brand-release-head span{color:var(--muted);font-size:11px}.brand-product-list{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:9px}.brand-product-row{display:grid;grid-template-columns:72px 1fr auto;gap:11px;align-items:center;padding:9px;border:1px solid var(--line);border-radius:11px;cursor:pointer}.brand-product-row:hover{background:var(--surface-2)}.brand-product-row img{width:72px;height:60px;object-fit:cover;border-radius:7px;background:var(--surface-2)}.brand-product-row b{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;font-size:12px;line-height:1.3}.brand-product-row small{display:block;margin-top:5px;color:var(--muted);font-size:9px}.release-badge{display:inline-block;margin-top:5px;padding:2px 6px;border-radius:999px;background:var(--surface-2);font:700 8px/1.4 Inter,"Noto Sans SC",system-ui,sans-serif;font-style:normal}.release-badge.official{background:var(--text);color:var(--bg)}.brand-product-row input{width:17px;height:17px;accent-color:var(--accent)}.board-list{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:10px}.board-product{display:grid;grid-template-columns:64px 1fr;gap:11px;align-items:center}.board-product img{width:64px;height:56px;object-fit:cover;border-radius:7px}.board-product b{font-size:12px;line-height:1.3}.board-product button{margin-top:6px;border:0;background:transparent;color:var(--muted);padding:0;cursor:pointer;font-size:10px}.nav button[hidden]{display:none!important}@media(max-width:900px){.portal-workbench{padding-left:18px;padding-right:18px}}@media(max-width:620px){.brand-product-list{grid-template-columns:1fr}.brand-compare-toolbar{align-items:flex-start;flex-direction:column}}
.brand-category-block{margin-top:14px}.brand-category-title{display:flex;justify-content:space-between;align-items:center;margin:0 0 8px;color:var(--muted);font-size:11px;letter-spacing:.06em}.brand-category-title small{font-size:9px;font-weight:500}.brand-product-list{grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:11px}.brand-product-row{position:relative;display:grid;grid-template-rows:minmax(150px,auto) auto;gap:0;align-items:stretch;padding:0;overflow:hidden}.brand-product-row img{width:100%;aspect-ratio:4/3;height:auto;min-height:150px;object-fit:cover;border-radius:0}.brand-product-copy{display:block;padding:9px 10px 10px}.brand-product-copy b{font-size:11px;line-height:1.25}.brand-product-copy small{font-size:8px;margin-top:4px}.brand-product-row input{position:absolute;top:9px;right:9px;width:20px;height:20px;margin:0;background:var(--surface);border-radius:5px;box-shadow:0 0 0 4px color-mix(in srgb,var(--surface) 88%,transparent)}
'''
    panel = '''<main class="portal-workbench" id="portalWorkbench" data-portal-controller="single-v1" data-compare-density="compact" hidden><section class="portal-panel"><h1 id="portalTitle">设计资讯</h1><input id="portalSearch" type="hidden" aria-hidden="true"><div class="portal-list" id="portalList"></div></section></main>'''
    constants = (
        '<script>const PORTAL_PRODUCTS='
        + json.dumps(records, ensure_ascii=False).replace('</', '<\\/')
        + ';const PORTAL_ISSUE_IDS='
        + json.dumps(issue_ids, ensure_ascii=False)
        + ';const PORTAL_REPORT_DATE='
        + json.dumps(report_date)
        + ';const PORTAL_LATEST_DATE='
        + json.dumps(latest_date or report_date)
        + ';const PORTAL_LATEST_URL='
        + json.dumps(latest_url or '')
        + ';const PORTAL_GLOBAL_GALLERY_URL='
        + json.dumps((latest_url + '#gallery') if latest_url else '')
        + ';const galleryContent=document.querySelector(".content"),workbench=document.getElementById("portalWorkbench"),title=document.getElementById("portalTitle"),list=document.getElementById("portalList"),search=document.getElementById("portalSearch");</script>'
    )
    controller = r'''
<script>
const portalState={view:'',periodBuckets:[],compareIds:new Set()};
const boardKey='did-project-board';
function escapePortal(value){return String(value??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]))}
function setPortalNav(name){document.querySelectorAll('.nav button').forEach(button=>button.classList.toggle('active',button.dataset.nav===name))}
function setPortalHash(name){const target='#'+name;if(location.hash!==target)history.replaceState(null,'',target)}
function updateHeroStats(items){const products=items||PORTAL_PRODUCTS;const productCount=products.length;const imageCount=products.filter(x=>x.image).length;const categories={};const sources={};products.forEach(x=>{if(x.category)categories[x.category]=(categories[x.category]||0)+1;if(x.source)sources[x.source]=(sources[x.source]||0)+1});const statsEls=document.querySelectorAll('.hero .stats .stat strong');if(statsEls.length>=3){statsEls[0].textContent=productCount;statsEls[1].textContent=imageCount;statsEls[2].textContent=Object.keys(categories).length;statsEls[3].textContent=Object.keys(sources).length}var __filterRow=document.querySelector('.filter-row');if(__filterRow){var __html='<button class="filter-btn active" data-category="all">全部 <span class="count">'+productCount+'</span></button>';Object.keys(categories).sort((a,b)=>categories[b]-categories[a]).forEach(function(c){__html+='<button class="filter-btn" data-category="'+c+'">'+c+' <span class="count">'+categories[c]+'</span></button>'});__filterRow.innerHTML=__html;document.querySelectorAll('.filter-btn').forEach(btn=>btn.onclick=()=>{document.querySelectorAll('.filter-btn').forEach(b=>b.classList.remove('active'));btn.classList.add('active');activeCategory=btn.dataset.category;applyGalleryFilters();setActiveNav('gallery')})}}
function updatePortalDate(dateText){var __eyebrow=document.getElementById('heroEyebrow')||document.querySelector('.hero .eyebrow');if(__eyebrow)__eyebrow.textContent=dateText+' · DAILY IMAGE INTELLIGENCE';var __rail=document.getElementById('railDate')||document.querySelectorAll('.side-rail.right .rail-label')[0];if(__rail)__rail.textContent=dateText;document.body.setAttribute('data-report-date',dateText)}
function showGalleryCards(filterIds=null,dateLabel=null){const active=filterIds?new Set(filterIds.map(String)):null;const visibleItems=[];document.querySelectorAll('.card').forEach((card,index)=>{const item=PORTAL_PRODUCTS[Number(card.dataset.index)]||PORTAL_PRODUCTS[index],id=String(item?.id??'');const isVisible=active?active.has(id):true;card.hidden=!isVisible;card.classList.remove('selected-only-hidden');if(isVisible&&item)visibleItems.push(item)});galleryContent.hidden=false;workbench.hidden=true;if(active){updateHeroStats(visibleItems)}else{updateHeroStats(PORTAL_PRODUCTS)}if(dateLabel){updatePortalDate(dateLabel)}else if(!active){updatePortalDate(PORTAL_REPORT_DATE)}}
function boardIds(){try{return JSON.parse(localStorage.getItem(boardKey)||'[]').map(String)}catch(e){return []}}
function setBoard(ids){localStorage.setItem(boardKey,JSON.stringify([...new Set(ids.map(String))]))}
function syncBoardChecks(){const ids=new Set(boardIds());document.querySelectorAll('.select input').forEach(input=>{if(input.checked)ids.add(String(input.dataset.id));else ids.delete(String(input.dataset.id))});setBoard([...ids])}
document.querySelectorAll('.select input').forEach(input=>{if(boardIds().includes(String(input.dataset.id)))input.checked=true;input.addEventListener('change',syncBoardChecks)});
function localDate(value){return new Date(String(value).slice(0,10)+'T00:00:00')}
function isoDate(value){return value.getFullYear()+'-'+String(value.getMonth()+1).padStart(2,'0')+'-'+String(value.getDate()).padStart(2,'0')}
function startOfWeek(value){const d=new Date(value),offset=(d.getDay()+6)%7;d.setDate(d.getDate()-offset);return d}
function periodHierarchy(){const reference=localDate(PORTAL_LATEST_DATE||PORTAL_REPORT_DATE),map=new Map();PORTAL_PRODUCTS.forEach(item=>{const d=localDate(item.added_date),age=Math.floor((reference-d)/86400000);let group,key,label,sort;if(age<=6){group='近七日 · 按天';key='day:'+item.added_date;label=item.added_date;sort=item.added_date}else if(age<=30){const start=startOfWeek(d),end=new Date(start);end.setDate(end.getDate()+6);group='八至三十日 · 周报';key='week:'+isoDate(start);label='周报 '+isoDate(start).slice(5)+'—'+isoDate(end).slice(5);sort=isoDate(start)}else if(age<=182){group='一至六个月 · 月报';key='month:'+item.added_date.slice(0,7);label='月报 '+item.added_date.slice(0,7);sort=item.added_date.slice(0,7)}else if(age<=365){group='六至十二个月 · 年报';key='year:'+item.added_date.slice(0,4);label='年报 '+item.added_date.slice(0,4);sort=item.added_date.slice(0,4)}else{group='历史归档';key='history';label='历史归档';sort='0000'}if(!map.has(key))map.set(key,{group,label,sort,ids:[]});map.get(key).ids.push(String(item.id))});const order=['近七日 · 按天','八至三十日 · 周报','一至六个月 · 月报','六至十二个月 · 年报','历史归档'];return order.map(name=>({name,rows:[...map.values()].filter(x=>x.group===name).sort((a,b)=>b.sort.localeCompare(a.sort))})).filter(x=>x.rows.length)}
function renderPeriodView(){portalState.periodBuckets=[];title.textContent='按入库周期浏览';const sections=periodHierarchy();list.innerHTML=`<p class="period-intro">近七日保留每日入口；第 8–30 日合并为周报；第 31–182 日合并为月报；第 183–365 日进入年报。</p><div class="period-section"><div class="period-grid"><button class="portal-item period-btn" data-period-all><b>全部产品</b><small>${PORTAL_PRODUCTS.length} 项</small></button></div></div>`+sections.map(section=>`<section class="period-section"><h2>${escapePortal(section.name)}</h2><div class="period-grid">${section.rows.map(row=>{const index=portalState.periodBuckets.push(row)-1;return `<button class="portal-item period-btn" data-period-index="${index}"><b>${escapePortal(row.label)}</b><small>${row.ids.length} 项</small></button>`}).join('')}</div></section>`).join('');galleryContent.hidden=true;workbench.hidden=false;document.querySelector('[data-period-all]').onclick=()=>{showGalleryCards(null,PORTAL_REPORT_DATE);setPortalNav('gallery')};document.querySelectorAll('[data-period-index]').forEach(button=>button.onclick=()=>{const bucket=portalState.periodBuckets[Number(button.dataset.periodIndex)];showGalleryCards(bucket.ids,bucket.label);setPortalNav('gallery');if(typeof showToast==='function')showToast(bucket.label+' · '+bucket.ids.length+' 项')})}
function compareSelectionHtml(){const selected=PORTAL_PRODUCTS.filter(x=>portalState.compareIds.has(String(x.id)));return selected.length?`<div class="compare-selection">${selected.map(x=>`<article class="compare-selected-card"><img src="${escapePortal(x.image)}" alt=""><div><b>${escapePortal(x.title)}</b><small>${escapePortal(x.brand)} · ${escapePortal(x.category)}</small></div></article>`).join('')}</div>`:'<p class="period-intro">按品牌浏览并勾选产品，最多同时选择 6 项。</p>'}
function brandProductHtml(item){return `<label class="brand-product-row"><img src="${escapePortal(item.image)}" alt=""><span class="brand-product-copy"><b>${escapePortal(item.title)}</b><small>${escapePortal(item.added_date)}</small><i class="release-badge ${item.official?'official':''}">${item.official?'官方新品':'媒体新稿'}</i></span><input type="checkbox" data-brand-compare="${escapePortal(item.id)}" ${portalState.compareIds.has(String(item.id))?'checked':''}></label>`}
function brandCategoryHtml(items){const categories=new Map();items.forEach(item=>{const key=item.category||'其他产品';if(!categories.has(key))categories.set(key,[]);categories.get(key).push(item)});return [...categories.entries()].sort((a,b)=>b[1].length-a[1].length||a[0].localeCompare(b[0])).map(([category,rows])=>`<section class="brand-category-block"><h3 class="brand-category-title"><span>${escapePortal(category)}</span><small>${rows.length} 项</small></h3><div class="brand-product-list">${rows.map(brandProductHtml).join('')}</div></section>`).join('')}
function renderCompareView(){title.textContent='品牌新品对比';const grouped=new Map();PORTAL_PRODUCTS.filter(item=>item.compare_visible!==false).sort((a,b)=>(b.added_date||'').localeCompare(a.added_date||'')).forEach(item=>{const key=item.brand;if(!grouped.has(key))grouped.set(key,[]);grouped.get(key).push(item)});const groups=[...grouped.entries()].sort((a,b)=>b[1].length-a[1].length||a[0].localeCompare(b[0]));list.innerHTML=`<div class="brand-compare-toolbar"><p><b>品牌新品清单</b> · 仅展示明确品牌，并按产品品类分组</p><button id="clearPortalCompare">清空选择</button></div><div id="portalCompareSelection">${compareSelectionHtml()}</div><div class="brand-release-list">${groups.map(([maker,items])=>`<section class="brand-release-group"><header class="brand-release-head"><h2>${escapePortal(maker)}</h2><span>${items.length} 项</span></header>${brandCategoryHtml(items)}</section>`).join('')||'<p class="period-intro">当前没有可确认品牌的新品。</p>'}</div>`;document.querySelectorAll('[data-brand-compare]').forEach(input=>input.onchange=()=>{const id=String(input.dataset.brandCompare);if(input.checked&&portalState.compareIds.size>=6){input.checked=false;if(typeof showToast==='function')showToast('最多同时选择 6 项产品');return}input.checked?portalState.compareIds.add(id):portalState.compareIds.delete(id);document.getElementById('portalCompareSelection').innerHTML=compareSelectionHtml()});document.getElementById('clearPortalCompare').onclick=()=>{portalState.compareIds.clear();renderCompareView()}}
function renderBoardView(){syncBoardChecks();const items=PORTAL_PRODUCTS.filter(item=>boardIds().includes(String(item.id)));title.textContent='项目板';list.innerHTML=items.length?`<div class="board-list">${items.map(item=>`<article class="portal-item board-product"><img src="${escapePortal(item.image)}" alt=""><div><b>${escapePortal(item.title)}</b><button data-remove-board="${escapePortal(item.id)}">移除</button></div></article>`).join('')}</div>`:'<p class="period-intro">在“今日”或画廊卡片勾选“保留”，产品会加入项目板。</p>';document.querySelectorAll('[data-remove-board]').forEach(button=>button.onclick=()=>{setBoard(boardIds().filter(id=>id!==String(button.dataset.removeBoard)));const input=document.querySelector(`.select input[data-id="${CSS.escape(button.dataset.removeBoard)}"]`);if(input)input.checked=false;renderBoardView()})}
function showTodayView(){if(PORTAL_REPORT_DATE!==PORTAL_LATEST_DATE&&PORTAL_LATEST_URL){window.location.href=PORTAL_LATEST_URL;return}if(PORTAL_ISSUE_IDS&&PORTAL_ISSUE_IDS.length){showGalleryCards(PORTAL_ISSUE_IDS,PORTAL_REPORT_DATE)}else{const todayIds=PORTAL_PRODUCTS.filter(x=>x.added_date===PORTAL_REPORT_DATE).map(x=>String(x.id));showGalleryCards(todayIds.length?todayIds:null,PORTAL_REPORT_DATE)}}
function setPortalView(name,{updateHash=true}={}){portalState.view=name;setPortalNav(name);if(name==='gallery'&&PORTAL_REPORT_DATE!==PORTAL_LATEST_DATE&&PORTAL_GLOBAL_GALLERY_URL){window.location.href=PORTAL_GLOBAL_GALLERY_URL;return}if(updateHash)setPortalHash(name);if(name==='today'){showTodayView();return}if(name==='gallery'){renderPeriodView();return}if(name==='selected'){galleryContent.hidden=true;workbench.hidden=false;renderBoardView();return}if(name==='compare'){galleryContent.hidden=true;workbench.hidden=false;renderCompareView();return}if(name==='trends'){galleryContent.hidden=true;workbench.hidden=false;window.trendView();return}showGalleryCards(null,PORTAL_REPORT_DATE)}
const archiveButton=document.querySelector('.nav button[data-nav="archive"]');if(archiveButton)archiveButton.remove();const boardButton=document.querySelector('.nav button[data-nav="board"]');if(boardButton)boardButton.remove();const selectedButton=document.querySelector('.nav button[data-nav="selected"]');if(selectedButton){selectedButton.title='项目板';const label=selectedButton.querySelector('.nav-label');if(label)label.textContent='项目板'}
document.querySelectorAll('.nav button').forEach(button=>button.onclick=()=>setPortalView(button.dataset.nav));window.addEventListener('hashchange',()=>setPortalView(location.hash.slice(1)||'today',{updateHash:false}));const headerSearch=document.getElementById('globalSearch');if(headerSearch)headerSearch.addEventListener('input',()=>{portalState.view='gallery';setPortalNav('gallery');galleryContent.hidden=false;workbench.hidden=true});
const initialView=location.hash.slice(1);if(initialView)setPortalView(initialView,{updateHash:false});else if(PORTAL_REPORT_DATE===PORTAL_LATEST_DATE)setPortalView('today',{updateHash:false});else{showGalleryCards(null,PORTAL_REPORT_DATE);portalState.view='gallery';setPortalNav('gallery')}
</script>
'''
    output = canonical.replace(
        '</body>',
        f'<style>{panel_css}{TREND_CSS}</style>'
        + panel
        + constants
        + f'<script>{TREND_JS}</script>'
        + controller
        + '<div hidden data-view="gallery"></div><div hidden data-view="explore"></div><div hidden data-view="compare"></div><div hidden data-view="board"></div><div hidden data-view="topics"></div><div hidden data-view="trends"></div></body>',
        1,
    )
    return output.replace(
        "return d.toISOString().slice(0,10)",
        "return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')",
    )


def detail_document(product: dict, index: int, report_date: str) -> str:
    pid = product_id(product, index)
    title = str(product.get('title') or '产品详情')
    desc = chinese_description(product)
    img = image_path(product)
    page_url = str(product.get('page_url') or product.get('url') or '')
    tags = ''.join(f'<span class="tag">{esc(x)}</span>' for x in materials(product))
    return f'''<!doctype html><html lang="zh-CN" data-detail-template="phase1-v3.4"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(title)}</title><style>{CSS}{GALLERY_STYLE}.detail-wrap{{max-width:1040px;margin:auto;padding:58px clamp(18px,4vw,56px) 90px}}.detail-wrap img{{width:100%;height:auto;border-radius:var(--radius);box-shadow:0 0 0 1px var(--line)}}.detail-wrap h1{{font-size:clamp(34px,5vw,64px);line-height:1.02;letter-spacing:-.055em}}.detail-wrap .panel{{margin-top:24px}}.back{{display:inline-block;margin-bottom:28px;color:var(--muted);text-decoration:none;font-size:12px;border-bottom:1px solid var(--line);padding-bottom:4px}}.back:hover{{color:var(--text)}}</style></head><body><main class="detail-wrap"><a class="back" href="../{PORTAL_NAME}#gallery">← 返回设计情报工作台</a><img src="../{esc(img, True)}" alt="{esc(title, True)}"><div class="panel"><div class="meta"><span>{esc(category(product))}</span><span>{esc(brand(product))}</span></div><h1>{esc(title)}</h1><p>{esc(desc)}</p><div>{tags}</div>{f'<p><a href="{esc(page_url, True)}" target="_blank" rel="noopener">查看原文 ↗</a></p>' if page_url else ''}</div></main></body></html>'''


def latest_daily_target(output_dir: Path, fallback_date: str) -> tuple[str, str]:
    """Return the latest top-level daily portal date and a relative URL to it."""
    output_root = Path(__file__).resolve().parents[1] / 'output'
    candidates: list[tuple[str, Path]] = []
    if output_root.exists():
        for child in output_root.iterdir():
            if child.is_dir() and re.fullmatch(r'\d{4}-\d{2}-\d{2}', child.name):
                portal = child / PORTAL_NAME
                if portal.exists():
                    candidates.append((child.name, portal))
    if not candidates:
        return fallback_date, PORTAL_NAME
    latest_date, latest_path = max(candidates, key=lambda item: item[0])
    relative = os.path.relpath(latest_path, output_dir).replace('\\', '/')
    return latest_date, relative


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', required=True)
    parser.add_argument('--issue-input', default='')
    parser.add_argument('--output-dir', required=True)
    parser.add_argument('--date', default='')
    args = parser.parse_args()
    raw = json.loads(Path(args.input).read_text(encoding='utf-8'))
    products = raw.get('products', raw) if isinstance(raw, dict) else raw
    out = Path(args.output_dir)
    details = out / 'details'
    details.mkdir(parents=True, exist_ok=True)
    report_date = args.date or str(raw.get('date') or raw.get('report_date') or '') if isinstance(raw, dict) else args.date
    issue_product_ids = None
    if args.issue_input:
        issue_raw = json.loads(Path(args.issue_input).read_text(encoding='utf-8'))
        issue_products = issue_raw.get('products', issue_raw) if isinstance(issue_raw, dict) else issue_raw
        issue_product_ids = [str(product.get('product_id') or index) for index, product in enumerate(issue_products)]
    latest_date, latest_url = latest_daily_target(out, report_date)
    if report_date > latest_date:
        latest_date, latest_url = report_date, PORTAL_NAME
    (out / PORTAL_NAME).write_text(
        portal_document(
            products,
            report_date,
            latest_date=latest_date,
            latest_url=latest_url,
            issue_product_ids=issue_product_ids,
        ),
        encoding='utf-8',
    )
    for i, product in enumerate(products):
        (details / f'{product_id(product, i)}.html').write_text(detail_document(product, i, report_date), encoding='utf-8')
    # explore.html remains as a compatibility redirect for old shared links;
    # the visible navigation now uses the top-right inline search field.
    redirects = {'daily_gallery.html': 'gallery', 'explore.html': 'explore', 'compare.html': 'compare', 'board.html': 'board', 'topics.html': 'topics', 'trends.html': 'trends'}
    for filename, anchor in redirects.items():
        (out / filename).write_text(redirect_page(anchor), encoding='utf-8')
    print(json.dumps({'portal': PORTAL_NAME, 'redirects': redirects, 'detail_count': len(products)}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
