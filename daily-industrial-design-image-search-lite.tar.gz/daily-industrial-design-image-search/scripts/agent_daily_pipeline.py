#!/usr/bin/env python3
"""
Agent-assisted daily pipeline for industrial design intelligence.
Parses RSS feeds, extracts product articles with images, downloads/verifies images,
generates HTML gallery, portable preview, and download manifest.
"""
import argparse, json, os, re, hashlib, sys, time
from datetime import datetime, date
from pathlib import Path
from urllib.parse import urlparse, quote as url_quote
import xml.etree.ElementTree as ET
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
from bs4 import BeautifulSoup

# Some Windows terminals still default to GBK. RSS titles can contain non-GBK
# punctuation, so make status output non-fatal for the daily job.
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')

TODAY = date.today().isoformat()
SKILL_ROOT = Path(__file__).resolve().parents[1]
OUTPUT_DIR = SKILL_ROOT / "output" / TODAY
IMAGES_DIR = OUTPUT_DIR / "images"
DATA_DIR = SKILL_ROOT / "data" / TODAY

# Categories
CATEGORIES = {
    "consumer_electronics": "消费电子",
    "furniture_lighting": "家具照明",
    "transportation": "交通工具",
    "home_appliances": "家用电器",
    "tools_equipment": "工具设备",
    "sustainable_design": "可持续设计",
    "wearable_tech": "可穿戴设备",
    "kitchen_tableware": "厨房餐厨",
    "medical_health": "医疗健康",
    "sports_outdoors": "户外运动",
    "commercial_equipment": "工业设备",
    "other": "其他"
}

# Known reliable RSS URLs for design media sources that may not be
# discovered by the generic /feed/ pattern guessing below.
KNOWN_VALID_RSS = {
    "dezeen": "https://www.dezeen.com/feed/",
    "designboom": "https://www.designboom.com/feed/",
    "yanko_design": "https://www.yankodesign.com/feed/",
    "engadget": "https://www.engadget.com/rss.xml",
    "techcrunch": "https://techcrunch.com/feed/",
    "core77": "https://www.core77.com/rss.xml",
    "the_verge": "https://www.theverge.com/rss/index.xml",
    "design_milk": "https://design-milk.com/feed/",
    "new_atlas": "https://newatlas.com/feed/",
    "wallpaper": "https://www.wallpaper.com/feed",
    # New known-valid RSS sources
    "apple_newsroom": "https://www.apple.com/newsroom/rss-feed.rss",
    "samsung_global_newsroom": "https://news.samsung.com/global/feed",
    "lenovo_storyhub": "https://news.lenovo.com/feed/",
    "garmin_newsroom": "https://www.garmin.com/en-US/newsroom/feed/",
    "google_blog_products": "https://blog.google/rss/",
    "microsoft_surface_blog": "https://blogs.windows.com/feed",
    "meta_newsroom": "https://about.fb.com/news/feed/",
    "leica_camera": "https://leica-camera.com/rss.xml",
    "nikon_news": "https://www.nikon.com/company/rss/feeds/news.rss",
    "panasonic_newsroom": "https://news.panasonic.com/global/rss/all/index.xml",
    "steelcase": "https://www.steelcase.com/feed/",
    "bmw_group_pressclub": "https://www.press.bmwgroup.com/global/rss",
}

def load_feeds_from_config():
    """从config/sources.json动态加载所有源"""
    import json
    from urllib.parse import quote as url_quote
    config_path = Path(__file__).resolve().parents[1] / "config" / "sources.json"
    with open(config_path) as f:
        config = json.load(f)
    sources = config.get("sources", config) if isinstance(config, dict) else config
    # 排除materials_manufacturing和event，排除disabled
    sources = [s for s in sources
               if s.get("source_type", "") not in ("materials_manufacturing", "event")
               and s.get("enabled", True)]

    feeds = []
    for s in sources:
        url = s.get("url", "")
        if not url:
            continue
        sid = s.get("id", "")
        publisher = s.get("name", "") or s.get("publisher", "") or sid

        # 构建RSS候选URL
        rss_candidates = []
        rss_url = s.get("rss_url", "")
        if rss_url:
            rss_candidates.append(rss_url)
        # Prepend known reliable RSS URL if available for this source ID
        known_rss = KNOWN_VALID_RSS.get(sid)
        if known_rss and known_rss not in rss_candidates:
            rss_candidates.insert(0, known_rss)
        if any(url.rstrip("/").endswith(x) for x in ["/feed", "/feed/", "/rss", "/rss.xml", "/atom.xml", "/feed.xml"]):
            rss_candidates.append(url)
        for pattern in ["/feed/", "/feed", "/rss", "/rss.xml", "/feed.xml", "/atom.xml", "/news/feed/", "/blog/feed/", "/blogs/news.atom"]:
            candidate = url.rstrip("/") + pattern
            if candidate not in rss_candidates:
                rss_candidates.append(candidate)

        # fallback URL
        search_term = publisher or sid
        fallback_baidu = f"https://news.baidu.com/ns?word={url_quote(search_term)}+新品&tn=newsrss&rn=10"

        feeds.append({
            "id": sid,
            "publisher": publisher,
            "url": rss_candidates[0] if rss_candidates else url,
            "trust": s.get("trust_level", 1.0),
            "official": s.get("source_type", "") == "official_brand",
            "rss_candidates": rss_candidates,
            "fallback_baidu": fallback_baidu,
            "fallback_ithome": "https://www.ithome.com/rss/",
            "fallback_36kr": "https://36kr.com/feed",
            "source_name": publisher,
        })
    return feeds

# RSS feeds loaded dynamically from config/sources.json
RSS_FEEDS = load_feeds_from_config()

# Keywords to identify product articles (vs architecture/editorial)
PRODUCT_KEYWORDS = [
    'product', 'gadget', 'device', 'tool', 'headphone', 'speaker', 'camera',
    'lamp', 'light', 'chair', 'table', 'desk', 'sofa', 'bottle', 'cup',
    'watch', 'wearable', 'keyboard', 'mouse', 'charger', 'power', 'battery',
    'bike', 'e-bike', 'scooter', 'motorcycle', 'car', 'vehicle', 'drone',
    'robot', 'vacuum', 'cleaner', 'appliance', 'kitchen', 'cookware',
    'titanium', 'aluminum', 'carbon fiber', '3d print', 'pen', 'knife',
    'backpack', 'bag', 'tent', 'flashlight', 'ebike', 'monitor',
    'phone', 'tablet', 'laptop', 'earbuds', 'earphone', 'power bank',
    'fan', 'purifier', 'humidifier', 'grill', 'blender', 'coffee',
    'printer', 'scanner', 'projector', 'display', 'screen',
    'sustainable', 'eco', 'recycle', 'biodegradable', 'solar',
    # Chinese keywords
    '扫地机器人', '扫地机', '洗烘一体机', '洗衣机', '净水器', '智能锁', '吸尘器', '洗地机',
    '新品', '发布', '上市', '首发', '开售',
    '石头', '科沃斯', 'roborock', 'ecovacs', 'deebot',
    '机器人', '智能门锁', '空气净化器', '加湿器', '电饭煲', '破壁机', '咖啡机',
    '智能音箱', '耳机', '手表', '手机', '平板', '笔记本', '显示器',
    '台灯', '落地灯', '充电器', '移动电源',
]
TITLE_PRODUCT_TERMS = [
    'phone', 'tablet', 'laptop', 'watch', 'headphone', 'earbud', 'speaker', 'camera', 'display', 'monitor',
    'washer', 'dryer', 'vacuum', 'purifier', 'mower', 'bike', 'scooter', 'car', 'vehicle', 'robot', 'drone',
    'glasses', 'ring', 'chair', 'table', 'lamp', 'light', 'sofa', 'furniture', 'tool', 'knife', 'pen',
    'bottle', 'backpack', 'tent', 'grill', 'blender', 'printer', 'projector', 'keyboard', 'mouse', 'charger',
    # Chinese terms
    '扫地机器人', '扫地机', '洗烘一体机', '洗衣机', '净水器', '智能锁', '吸尘器', '洗地机',
    '石头', '科沃斯', 'roborock', 'ecovacs', 'deebot',
    '机器人', '新品', '发布', '上市',
]

# Keywords to reject
REJECT_KEYWORDS = [
    'architecture', 'pavilion', 'building', 'museum', 'gallery',
    'exhibition', 'renovation', 'loft', 'apartment', 'interior',
    'office', 'studio tour', 'restaurant', 'hotel', 'resort',
    'subscription', 'funding', 'investment', 'partnership',
    'layoff', 'acquisition', 'earnings', 'revenue',
    'artwork', 'artist', 'art exhibition', 'sculpture', 'installation', 'fashion',
    'festival', 'award winner', 'competition', 'interview', 'opinion', 'podcast',
    'real estate', 'workplace', 'masterplan', 'skyscraper',
    'samsung account', 'red dot award', 'design concept', 'sustainability report', 'corporate citizenship',
    'patent', 'infographic', 'opens the fold inn', 'annual report', 'procurement teams',
    'fifa', 'customers, media, and employees', 'agentic ai', 'cartograph',
]

def fetch_rss(url, feed=None, timeout=10):
    """Fetch RSS feed via curl, fixing common XML issues"""
    try:
        cmd = ['curl', '-sL', '--max-time', str(timeout),
               '-H', 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
               url]
        result = subprocess.run(
            cmd, capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=timeout + 5
        )
        xml_text = result.stdout or ''
        if result.returncode != 0:
            print(f"  [WARN] RSS request failed for {url}: {result.stderr.strip()[:200]}")
            return ''
        # Fix leading whitespace before XML declaration
        xml_text = xml_text.lstrip()
        # Fix BOM
        if xml_text.startswith('\ufeff'):
            xml_text = xml_text[1:]
        # Strip everything before <?xml
        idx = xml_text.find('<?xml')
        if idx > 0:
            xml_text = xml_text[idx:]
        # Remove invalid XML characters
        xml_text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', xml_text)
        return xml_text
    except Exception as e:
        print(f"  [WARN] Failed to fetch {url}: {e}")
        return ""

def fetch_feed_with_fallback(feed):
    """尝试所有候选URL和fallback"""
    # 1. 尝试所有rss_candidates
    for candidate_url in feed.get("rss_candidates", []):
        items = parse_rss(fetch_rss(candidate_url, feed), feed['id'], feed['publisher'], feed['trust'])
        if items:
            return items, candidate_url

    # 2. fallback: 百度新闻RSS
    baidu_url = feed.get("fallback_baidu", "")
    if baidu_url:
        items = parse_rss(fetch_rss(baidu_url, feed), feed['id'], feed['publisher'], feed['trust'])
        if items:
            brand = feed.get("publisher", "")
            items = [item for item in items if any(kw in item.get("title", "") for kw in [brand, feed.get("id", "")])]
            if items:
                return items, baidu_url

    # 3. fallback: IT之家RSS（按品牌过滤）
    ithome_url = feed.get("fallback_ithome", "")
    if ithome_url:
        items = parse_rss(fetch_rss(ithome_url, feed), feed['id'], feed['publisher'], feed['trust'])
        if items:
            brand = feed.get("publisher", "")
            brand_kws = [brand, feed.get("id", "")]
            if '石头' in brand or 'roborock' in brand.lower():
                brand_kws.extend(['石头', 'roborock', 'Roborock', '洗烘', '扫地'])
            elif '科沃斯' in brand or 'ecovacs' in brand.lower():
                brand_kws.extend(['科沃斯', 'ecovacs', 'Ecovacs', 'deebot', 'Deebot', '扫地'])
            items = [item for item in items if any(kw in item.get("title", "") for kw in brand_kws)]
            if items:
                return items, ithome_url

    # 4. fallback: 36kr
    kr_url = feed.get("fallback_36kr", "")
    if kr_url:
        items = parse_rss(fetch_rss(kr_url, feed), feed['id'], feed['publisher'], feed['trust'])
        if items:
            brand = feed.get("publisher", "")
            items = [item for item in items if any(kw in item.get("title", "") for kw in [brand, feed.get("id", "")])]
            if items:
                return items, kr_url

    return [], None

def parse_rss(xml_text, source_id, publisher, trust):
    """Parse RSS XML and extract items"""
    items = []
    if not xml_text.strip():
        return items
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError as e:
        print(f"  [WARN] XML parse error for {source_id}: {e}")
        return items
    
    ns = {
        'content': 'http://purl.org/rss/1.0/modules/content/',
        'dc': 'http://purl.org/dc/elements/1.1/',
        'media': 'http://search.yahoo.com/mrss/',
        'atom': 'http://www.w3.org/2005/Atom',
    }
    
    # Try RSS format first (<item> elements)
    rss_items = root.findall('.//item')
    for item in rss_items:
        title = item.findtext('title', '')
        link = item.findtext('link', '')
        pub_date = item.findtext('pubDate', '')
        if not pub_date:
            pub_date = item.findtext('dc:date', '', ns)
        desc = item.findtext('description', '')
        content = item.findtext('content:encoded', '', ns) or desc
        cats = [c.text for c in item.findall('category') if c.text]
        img_url = extract_first_image(content) or extract_first_image(desc)
        items.append({
            'title': title,
            'link': link,
            'pub_date': pub_date,
            'description': strip_html(desc)[:500],
            'content': content,
            'categories': cats,
            'image_url': img_url,
            'source_id': source_id,
            'publisher': publisher,
            'trust_level': trust,
        })
    
    # If RSS items found, return them
    if items:
        return items
    
    # Try Atom format (<entry> elements)
    atom_entries = root.findall('.//{http://www.w3.org/2005/Atom}entry')
    if not atom_entries:
        # Also try without namespace (some feeds have atom elements without NS)
        atom_entries = root.findall('.//entry')
    for entry in atom_entries:
        title = entry.findtext('title', '') or entry.findtext('{http://www.w3.org/2005/Atom}title', '')
        # Atom link is in href attribute
        link = ''
        link_el = entry.find('{http://www.w3.org/2005/Atom}link')
        if link_el is None:
            link_el = entry.find('link')
        if link_el is not None:
            link = link_el.get('href', '') or (link_el.text or '')
        # Atom date: published or updated
        pub_date = (entry.findtext('{http://www.w3.org/2005/Atom}published', '')
                    or entry.findtext('published', '')
                    or entry.findtext('{http://www.w3.org/2005/Atom}updated', '')
                    or entry.findtext('updated', ''))
        desc = (entry.findtext('{http://www.w3.org/2005/Atom}summary', '')
                or entry.findtext('summary', '')
                or entry.findtext('{http://www.w3.org/2005/Atom}content', '')
                or entry.findtext('content', ''))
        content = desc
        cats = [c.text for c in entry.findall('{http://www.w3.org/2005/Atom}category') if c.text]
        cats += [c.get('term', '') for c in entry.findall('{http://www.w3.org/2005/Atom}category') if c.get('term')]
        img_url = extract_first_image(content) or extract_first_image(desc)
        items.append({
            'title': title,
            'link': link,
            'pub_date': pub_date,
            'description': strip_html(desc)[:500],
            'content': content,
            'categories': cats,
            'image_url': img_url,
            'source_id': source_id,
            'publisher': publisher,
            'trust_level': trust,
        })
    
    return items

def strip_html(text):
    """Remove HTML tags"""
    clean = re.sub(r'<[^>]+>', '', text)
    clean = re.sub(r'\s+', ' ', clean)
    return clean.strip()

def extract_first_image(html_text):
    """Extract first real image URL from HTML content"""
    if not html_text:
        return None
    # Find img tags
    pattern = r'<img[^>]+src=["\']([^"\']+)["\']'
    matches = re.findall(pattern, html_text, re.IGNORECASE)
    for url in matches:
        # Skip tracking pixels, placeholders, etc.
        if any(x in url.lower() for x in ['pixel', 'tracking', 'placeholder', 'blank.gif', '1x1']):
            continue
        if url.startswith('http'):
            return url
    return None

def is_product_article(item):
    """Accept only traceable physical products; reject editorial/design-culture news."""
    text = (item['title'] + ' ' + item['description']).lower()
    cats = ' '.join(item.get('categories', [])).lower()
    # Substring match so that e.g. 'earbud' also matches 'earbuds'.
    def has_term(haystack, term):
        return term.lower() in haystack

    if any(has_term(text, kw) or has_term(cats, kw) for kw in REJECT_KEYWORDS):
        return False, 0
    product_match = sum(1 for kw in PRODUCT_KEYWORDS if has_term(text, kw))
    title = item['title'].lower()
    physical_title_match = sum(1 for kw in TITLE_PRODUCT_TERMS if has_term(title, kw))
    # image_url may be missing for some RSS feeds (e.g. TechCrunch);
        # still process the article – image will be fetched later or skipped.
    if product_match == 0 or physical_title_match == 0:
        return False, 0
    score = product_match * 10
    if not item.get('image_url'):
        score = score // 2
    if item.get('official'):
        score += 25
    if any(has_term(text, kw) for kw in ('introduces', 'introduced', 'launches', 'launched', 'unveils', 'unveiled', 'announces', 'available')):
        score += 15
    
    # Check categories for product-related terms
    product_cats = ['product design', 'product', 'industrial design', 'technology',
                    'gadgets', 'gear', 'everyday carry', 'edc', 'tools',
                    'consumer electronics', 'smartphone', 'wearable', 'audio',
                    'camera', 'automotive', 'design', 'tech', 'gear']
    for cat in product_cats:
        if cat in cats:
            score += 15
    
    return score >= 10, score


def is_current_release(item, report_date, max_age_days=7):
    """Keep the daily edition to items published within the last *max_age_days* days."""
    raw = str(item.get('pub_date') or '').strip()
    if not raw:
        return True
    try:
        from email.utils import parsedate_to_datetime
        from datetime import date as _date, timedelta
        pub = parsedate_to_datetime(raw).date()
        ref = _date.fromisoformat(report_date)
        age = (ref - pub).days
        return 0 <= age <= max_age_days
    except Exception:
        return True


def fetch_article_text(url, timeout=5):
    """Retrieve the original article body for a source-grounded card/lightbox summary."""
    try:
        result = subprocess.run(
            ['curl', '-sL', '--max-time', str(timeout), '-H', 'User-Agent: Mozilla/5.0', url],
            capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=timeout + 5,
        )
        if result.returncode != 0 or not result.stdout:
            return ''
        soup = BeautifulSoup(result.stdout, 'html.parser')
        for node in soup(['script', 'style', 'nav', 'footer', 'header', 'aside']):
            node.decompose()
        root = soup.find('article') or soup.find('main') or soup.body
        return strip_html(root.get_text(' ', strip=True) if root else '')[:9000]
    except Exception:
        return ''


def source_summary(title, body_text):
    """Keep the highest-signal original sentences instead of repeating a category fallback."""
    sentences = re.split(r'(?<=[.!?])\s+', body_text or '')
    terms = ('designed', 'features', 'includes', 'uses', 'made', 'available', 'launch', 'introduc', 'battery', 'display', 'camera', 'material')
    ranked = [s.strip() for s in sentences if 45 <= len(s.strip()) <= 360 and any(term in s.lower() for term in terms)]
    selected = ranked[:2] or [s.strip() for s in sentences if len(s.strip()) >= 45][:1]
    return ' '.join(selected)[:420] or title

def categorize_product(item):
    """Categorize product based on title and description"""
    text = (item['title'] + ' ' + item['description']).lower()
    cats = ' '.join(item.get('categories', [])).lower()
    
    if any(kw in text for kw in ['headphone', 'speaker', 'earbud', 'audio', 'sound']):
        return 'consumer_electronics'
    if any(kw in text for kw in ['bike', 'e-bike', 'scooter', 'motorcycle', 'car', 'vehicle']):
        return 'transportation'
    if any(kw in text for kw in ['chair', 'table', 'desk', 'sofa', 'lamp', 'light', 'furniture']):
        return 'furniture_lighting'
    if any(kw in text for kw in ['vacuum', 'cleaner', 'appliance', 'fan', 'purifier']):
        return 'home_appliances'
    if any(kw in text for kw in ['pen', 'knife', 'tool', 'flashlight', 'multitool', 'titanium']):
        return 'tools_equipment'
    if any(kw in text for kw in ['watch', 'wearable', 'fitness']):
        return 'wearable_tech'
    if any(kw in text for kw in ['cup', 'bottle', 'coffee', 'kitchen', 'cookware', 'grill']):
        return 'kitchen_tableware'
    if any(kw in text for kw in ['phone', 'laptop', 'tablet', 'monitor', 'display']):
        return 'consumer_electronics'
    if any(kw in text for kw in ['sustainable', 'eco', 'recycle', 'biodegradable']):
        return 'sustainable_design'
    if any(kw in text for kw in ['medical', 'health']):
        return 'medical_health'
    if any(kw in text for kw in ['backpack', 'tent', 'outdoor', 'sport']):
        return 'sports_outdoors'
    if any(kw in text for kw in ['robot', 'drone', 'printer', 'industrial']):
        return 'commercial_equipment'
    return 'other'

def download_image(url, filepath, timeout=5):
    """Download image with curl"""
    try:
        cmd = ['curl', '-sL', '--max-time', str(timeout),
               '-H', 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
               '-o', str(filepath), url]
        subprocess.run(cmd, capture_output=True, timeout=timeout+5)
        
        if filepath.exists() and filepath.stat().st_size > 5000:
            return True
        return False
    except Exception:
        return False

def verify_image(filepath):
    """Verify image meets quality standards"""
    if not filepath.exists():
        return False
    size = filepath.stat().st_size
    if size < 20480:  # 20KB minimum
        return False
    try:
        from PIL import Image
        with Image.open(filepath) as img:
            w, h = img.size
            if w < 500 or h < 300:
                return False
            # Check for solid color
            colors = img.convert('RGB').getcolors(maxcolors=4)
            if colors and len(colors) == 1:
                return False  # Solid color
            return True
    except ImportError:
        # PIL not available, just check file size
        return size > 20480
    except Exception:
        return False

def generate_product_id(title, source_id):
    """Generate stable product ID"""
    raw = f"{source_id}:{title[:80]}"
    return hashlib.md5(raw.encode('utf-8')).hexdigest()[:12]

def _canonical_products(products):
    """Normalize RSS records for the one canonical gallery generator."""
    normalized = []
    for item in products:
        p = dict(item)
        p["source"] = p.get("source") or p.get("publisher") or p.get("source_id") or "Unknown source"
        p["summary"] = p.get("summary") or p.get("description") or ""
        p["first_seen_date"] = p.get("first_seen_date") or TODAY
        p["ai_analysis"] = dict(p.get("ai_analysis") or {})
        p["ai_analysis"].setdefault("category", p.get("category") or "other")
        p["ai_analysis"].setdefault("features", p.get("description") or p.get("summary") or "")
        local = p.get("local_image_path")
        if local:
            p["local_image_path"] = f"images/{Path(local).name}"
        normalized.append(p)
    return normalized


def generate_html(products, output_path, images_dir):
    """Delegate to the canonical editorial gallery. Legacy inline templates are forbidden."""
    from generate_html import HTMLGenerator
    normalized = _canonical_products(products)
    HTMLGenerator(date=TODAY, use_local_images=True).generate(normalized, output_path=str(output_path))
    validate_generated_html(output_path)
    print(f"  [OK] Generated canonical HTML: {output_path}")


def validate_generated_html(html_path):
    """Fail closed when a legacy or malformed gallery/portal is produced."""
    text = Path(html_path).read_text(encoding="utf-8")
    is_portal = 'data-portal-template="phase1-v3.4"' in text
    required = (
        ('class="topbar"', 'data-view="gallery"', 'data-view="explore"', 'data-view="compare"', 'data-portal-template="phase1-v3.4"')
        if is_portal else
        ('class="shell"', 'class="topbar"', 'class="gallery" id="gallery"', 'data-gallery-template="canonical-v3.4"')
    )
    missing = [marker for marker in required if marker not in text]
    legacy = ('class="header"', 'class="section-title"') if is_portal else ('class="header"', 'class="section-title"', 'class="grid"')
    found_legacy = [marker for marker in legacy if marker in text]
    if missing or found_legacy:
        raise RuntimeError(f"gallery template validation failed; missing={missing}, legacy={found_legacy}")
    if '@media(max-width:' not in text:
        raise RuntimeError("gallery template validation failed: responsive mobile CSS missing")


def generate_portable_preview(html_path, images_dir, output_path):
    """Use the canonical compressed, size-limited portable preview builder."""
    from build_portable_preview import build
    result = build(Path(html_path), Path(output_path), Path(html_path).parent.resolve(), False, 1100, 72, 15.0)
    validate_generated_html(output_path)
    print(f"  [OK] Generated portable preview: {output_path} ({result['embedded_images']} images)")


def generate_download_manifest(html_path, portable_path, images_dir, output_path):
    """Use the canonical offline-package manifest builder."""
    cmd = [sys.executable, str(SKILL_ROOT / 'scripts' / 'build_download_manifest.py'),
           '--date', TODAY, '--html', str(html_path), '--portable-preview', str(portable_path),
           '--images-dir', str(images_dir), '--output', str(output_path)]
    subprocess.run(cmd, cwd=SKILL_ROOT, check=True)

def generate_summary_md(products, output_path):
    """Generate daily summary markdown"""
    cat_counts = {}
    source_counts = {}
    for p in products:
        cat = CATEGORIES.get(p['category'], p['category'])
        cat_counts[cat] = cat_counts.get(cat, 0) + 1
        source_counts[p['publisher']] = source_counts.get(p['publisher'], 0) + 1
    
    lines = [
        f"# 工业设计图片日报摘要 {TODAY}",
        "",
        f"**合格产品数量**: {len(products)}",
        f"**来源数量**: {len(source_counts)}",
        f"**品类数量**: {len(cat_counts)}",
        "",
        "## 品类分布",
        ""
    ]
    for cat, count in sorted(cat_counts.items(), key=lambda x: -x[1]):
        lines.append(f"- {cat}: {count}")
    lines.extend(["", "## 来源分布", ""])
    for src, count in sorted(source_counts.items(), key=lambda x: -x[1]):
        lines.append(f"- {src}: {count}")
    lines.extend(["", "## 产品列表", ""])
    for i, p in enumerate(products, 1):
        lines.append(f"{i}. **{p['title']}** - {p['publisher']} [{CATEGORIES.get(p['category'], p['category'])}]")
    
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines))
    print(f"  [OK] Generated summary: {output_path}")

def main():
    global TODAY, OUTPUT_DIR, IMAGES_DIR, DATA_DIR
    parser = argparse.ArgumentParser()
    parser.add_argument('--date', default=TODAY)
    parser.add_argument('--max-sources', type=int, default=20)
    parser.add_argument('--limit-per-source', type=int, default=8)
    parser.add_argument('--max-products', type=int, help='Global cap for a small test run')
    parser.add_argument('--include-media', action='store_true', help='Include curated design media after official brand feeds')
    args = parser.parse_args()
    
    report_date = args.date
    TODAY = report_date
    OUTPUT_DIR = SKILL_ROOT / "output" / report_date
    IMAGES_DIR = OUTPUT_DIR / "images"
    DATA_DIR = SKILL_ROOT / "data" / report_date
    for directory in (OUTPUT_DIR, IMAGES_DIR, DATA_DIR):
        directory.mkdir(parents=True, exist_ok=True)
    print(f"\n{'='*60}")
    print(f"  Industrial Design Daily Pipeline - {report_date}")
    print(f"{'='*60}\n")
    
    # Step 1: Fetch and parse RSS feeds (parallel)
    print("[Step 1] Fetching RSS feeds...")
    all_candidates = []
    
    feeds = RSS_FEEDS if args.include_media else [feed for feed in RSS_FEEDS if feed.get('official')]
    feeds = feeds[:args.max_sources]
    
    def _fetch_one(feed):
        """Fetch a single feed with fallback, return (feed, items)."""
        print(f"  Fetching: {feed['publisher']} ({feed['url']})")
        items, used_url = fetch_feed_with_fallback(feed)
        if used_url and used_url != feed['url']:
            print(f"    -> fallback used: {used_url}")
        return feed, items

    feed_items = {}
    with ThreadPoolExecutor(max_workers=min(len(feeds), 16)) as pool:
        futures = {pool.submit(_fetch_one, feed): feed for feed in feeds}
        for future in as_completed(futures):
            feed = futures[future]
            try:
                _, items = future.result()
            except Exception as e:
                print(f"  [WARN] {feed['publisher']} raised: {e}")
                items = []
            feed_items[feed['id']] = (feed, items)
    
    for feed in feeds:
        items = feed_items.get(feed['id'], (feed, []))[1]
        for item in items:
            item['official'] = bool(feed.get('official'))
        print(f"  {feed['publisher']}: {len(items)} items parsed")
        
        # Filter for product articles
        for item in items:
            is_prod, score = is_product_article(item)
            if is_prod and is_current_release(item, report_date):
                item['product_score'] = score
                item['category'] = categorize_product(item)
                all_candidates.append(item)
    
    print(f"\n  Total product candidates: {len(all_candidates)}")
    
    # Deduplicate by title similarity
    seen_titles = set()
    unique = []
    for c in all_candidates:
        title_key = c['title'].lower()[:60]
        if title_key not in seen_titles:
            seen_titles.add(title_key)
            unique.append(c)
    
    # Sort by score and limit per source
    unique.sort(key=lambda x: x.get('product_score', 0), reverse=True)
    
    # Limit per source
    source_counts = {}
    final_products = []
    for p in unique:
        sid = p['source_id']
        if source_counts.get(sid, 0) >= args.limit_per_source:
            continue
        source_counts[sid] = source_counts.get(sid, 0) + 1
        final_products.append(p)
    if args.max_products is not None:
        # A failed image must not reduce a requested test set below its cap.
        # Download a bounded reserve, then retain only verified products below.
        final_products = final_products[:args.max_products * 3]
    for product in final_products:
        body = fetch_article_text(product['link'])
        product['body_text'] = body
        product['source_summary'] = source_summary(product['title'], body)
        product['page_url'] = product['link']
    
    print(f"  After dedup and limit: {len(final_products)} products")
    
    # Step 2: Download and verify images
    print(f"\n[Step 2] Downloading and verifying images...")
    verified_products = []
    seen_image_hashes = set()
    
    for i, p in enumerate(final_products):
        if not p.get('image_url'):
            continue
        
        pid = generate_product_id(p['title'], p['source_id'])
        ext = '.jpg'
        img_url = p['image_url']
        if '.png' in img_url.lower():
            ext = '.png'
        elif '.webp' in img_url.lower():
            ext = '.webp'
        elif '.gif' in img_url.lower():
            ext = '.gif'
        
        img_filename = f"{pid}{ext}"
        img_filepath = IMAGES_DIR / img_filename
        
        print(f"  [{i+1}/{len(final_products)}] {p['title'][:50]}...")
        
        if download_image(img_url, img_filepath):
            if verify_image(img_filepath):
                image_hash = hashlib.sha256(img_filepath.read_bytes()).hexdigest()
                if image_hash in seen_image_hashes:
                    # Different RSS posts often reuse the same hero image. Keep
                    # only the first traceable product card for a visual asset.
                    print("    -> SKIPPED duplicate image")
                    continue
                seen_image_hashes.add(image_hash)
                p['product_id'] = pid
                p['local_image_path'] = str(img_filepath)
                p['image_sha256'] = image_hash
                p['page_url'] = p['link']
                p['image_verified'] = True
                verified_products.append(p)
                print(f"    -> VERIFIED ({img_filepath.stat().st_size // 1024}KB)")
            else:
                print(f"    -> FAILED verification")
                if img_filepath.exists():
                    img_filepath.unlink()
        else:
            print(f"    -> FAILED download")
    
    print(f"\n  Verified products with images: {len(verified_products)}")
    
    if len(verified_products) < 5:
        print("  [WARNING] Too few products, attempting to include all candidates with images...")
        for p in final_products:
            if p not in verified_products and p.get('image_url'):
                pid = generate_product_id(p['title'], p['source_id'])
                ext = '.jpg'
                img_url = p['image_url']
                if '.png' in img_url.lower(): ext = '.png'
                elif '.webp' in img_url.lower(): ext = '.webp'
                img_filename = f"{pid}{ext}"
                img_filepath = IMAGES_DIR / img_filename
                if download_image(img_url, img_filepath):
                    if verify_image(img_filepath):
                        p['product_id'] = pid
                        p['local_image_path'] = str(img_filepath)
                        p['page_url'] = p['link']
                        p['image_verified'] = True
                        verified_products.append(p)

    if args.max_products is not None:
        verified_products = verified_products[:args.max_products]
    
    # Step 3: Generate outputs
    print(f"\n[Step 3] Generating outputs...")
    
    gallery_path = OUTPUT_DIR / "gallery_canonical_source.html"
    html_path = OUTPUT_DIR / "design_intelligence_portal.html"
    portable_path = OUTPUT_DIR / f"{report_date}_工业设计图片日报_预览版.html"
    manifest_path = OUTPUT_DIR / "download_manifest.json"
    summary_path = OUTPUT_DIR / "日报摘要.md"
    
    generate_html(verified_products, gallery_path, IMAGES_DIR)
    gallery_input = OUTPUT_DIR / 'gallery_input.json'
    portal_products = []
    for product in verified_products:
        item = dict(product)
        item['local_image_path'] = f"images/{Path(item['local_image_path']).name}"
        item['first_seen_date'] = report_date
        portal_products.append(item)
    gallery_input.write_text(json.dumps(portal_products, ensure_ascii=False, indent=2), encoding='utf-8')
    # Persist the current issue separately, then rebuild the global catalog.
    # The Today view uses this issue manifest while Gallery uses all history.
    subprocess.run([sys.executable, str(SKILL_ROOT / 'scripts' / 'build_gallery_hierarchy.py'), '--root', str(SKILL_ROOT / 'output'), '--date', report_date], cwd=SKILL_ROOT, check=True)
    # Generate the dynamic portal (fetches data from /api/portal-data at runtime)
    subprocess.run([sys.executable, str(SKILL_ROOT / 'scripts' / 'create_dynamic_portal.py')], cwd=SKILL_ROOT, check=True)
    generate_portable_preview(html_path, IMAGES_DIR, portable_path)
    generate_download_manifest(html_path, portable_path, IMAGES_DIR, manifest_path)
    generate_summary_md(verified_products, summary_path)
    
    # Save collected data
    collected_path = DATA_DIR / "collected_data.json"
    with open(collected_path, 'w', encoding='utf-8') as f:
        json.dump(verified_products, f, ensure_ascii=False, indent=2, default=str)
    
    # Save source health
    source_health = {
        "report_date": report_date,
        "sources_checked": len(feeds[:args.max_sources]),
        "sources_succeeded": len(set(p['source_id'] for p in verified_products)),
        "total_candidates": len(all_candidates),
        "verified_products": len(verified_products),
        "min_target": 24,
        "meets_minimum": len(verified_products) >= 24,
    }
    health_path = DATA_DIR / "source_health.json"
    with open(health_path, 'w', encoding='utf-8') as f:
        json.dump(source_health, f, ensure_ascii=False, indent=2)
    
    print(f"\n{'='*60}")
    print(f"  Pipeline Complete!")
    print(f"  Products: {len(verified_products)}")
    print(f"  Output: {OUTPUT_DIR}")
    print(f"{'='*60}\n")
    
    return verified_products

if __name__ == '__main__':
    main()
