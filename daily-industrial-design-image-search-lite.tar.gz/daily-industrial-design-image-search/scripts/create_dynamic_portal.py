#!/usr/bin/env python3
"""Create a dynamic version of the portal HTML that fetches data from API.

Replaces the inline PORTAL_PRODUCTS JSON (128K) with a synchronous XHR fetch
from /api/portal-data. All downstream scripts (IIFEs referencing PORTAL_PRODUCTS)
continue to work because the variables are populated synchronously before they run.
"""
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUTPUT_DIR = ROOT / "output"

FETCH_BLOCK = """var PORTAL_PRODUCTS=[],PORTAL_ISSUE_IDS=[],PORTAL_REPORT_DATE='',PORTAL_LATEST_DATE='',PORTAL_LATEST_URL='',PORTAL_GLOBAL_GALLERY_URL='';
var __xhr=new XMLHttpRequest();__xhr.open('GET','/api/portal-data',false);
try{__xhr.send();if(__xhr.status===200){var __d=JSON.parse(__xhr.responseText);PORTAL_PRODUCTS=__d.PORTAL_PRODUCTS||[];PORTAL_ISSUE_IDS=__d.PORTAL_ISSUE_IDS||[];PORTAL_REPORT_DATE=__d.PORTAL_REPORT_DATE||'';PORTAL_LATEST_DATE=__d.PORTAL_LATEST_DATE||'';PORTAL_LATEST_URL=__d.PORTAL_LATEST_URL||'';PORTAL_GLOBAL_GALLERY_URL=__d.PORTAL_GLOBAL_GALLERY_URL||'';}}catch(e){console.error('Failed to load portal data:',e);}"""


def get_latest_date_dir() -> Path | None:
    if not OUTPUT_DIR.exists():
        return None
    date_dirs = sorted(
        [d for d in OUTPUT_DIR.iterdir() if d.is_dir() and re.match(r'\d{4}-\d{2}-\d{2}', d.name)],
        reverse=True,
    )
    return date_dirs[0] if date_dirs else None


def main():
    latest_dir = get_latest_date_dir()
    if not latest_dir:
        raise RuntimeError("No date directory found in output/")
    source_html = latest_dir / "design_intelligence_portal.html"
    target_html = latest_dir / "design_intelligence_portal_dynamic.html"
    date_str = latest_dir.name

    content = source_html.read_text(encoding="utf-8")
    print(f"Source HTML: {len(content)} bytes ({source_html})")

    # 1. Find the const block in Script 2
    script2_tag_start = content.find("<script>const PORTAL_PRODUCTS=")
    if script2_tag_start < 0:
        raise RuntimeError("Could not find PORTAL_PRODUCTS script tag")

    # Find the end of const declarations (before 'const galleryContent=')
    const_end = content.find("const galleryContent=", script2_tag_start)
    if const_end < 0:
        raise RuntimeError("Could not find const galleryContent=")

    replacement = "<script>" + FETCH_BLOCK + ";"
    new_content = content[:script2_tag_start] + replacement + content[const_end:]

    # 4. Update the title to reflect dynamic nature
    new_content = new_content.replace(
        f"工业设计图片日报 · {date_str}",
        "工业设计情报画廊",
        1,
    )

    target_html.write_text(new_content, encoding="utf-8")
    print(f"Dynamic HTML written: {target_html} ({len(new_content)} bytes)")
    print(f"Size reduction: {len(content) - len(new_content)} bytes ({(1 - len(new_content)/len(content))*100:.1f}%)")


if __name__ == "__main__":
    main()
