"""Industrial Editorial Gallery HTML generator.

The gallery keeps image browsing as the primary experience while preserving
filtering, lightbox, selection export and Feishu review links.  Theme defaults
to the operating-system preference and can be overridden by the visitor.
"""
from __future__ import annotations

import argparse
import html
import json
import os
import re
import html as html_module
from datetime import datetime
from pathlib import Path
from typing import Any



CHINESE_FALLBACK = "该条资讯已完成来源核验，但公开资料中的产品功能、结构与设计细节仍不足，建议打开原文继续查看。"

_PRODUCT_TERMS = [
    (("lawn mower", "robot mower", "smart mower"), "该资讯聚焦电动或智能割草设备，重点涉及自动作业、草坪维护效率与户外使用规范，并提示用户根据设备类型和场地条件调整操作方式。"),
    (("battery", "charging", "energy storage"), "该资讯聚焦电池与能源技术创新，重点关注续航、安全、充电效率及面向消费产品的应用潜力，并展示相关技术成果或行业认可。"),
    (("speaker", "audio", "sound"), "该产品围绕音频体验展开设计，通过造型、材料与交互方式强化使用仪式感，同时兼顾空间陈设与日常聆听需求。"),
    (("chair", "sofa", "table", "furniture"), "该产品属于家具设计，重点关注人体工学、结构比例、材料触感与空间适配性，以提升长期使用的舒适度和视觉协调性。"),
    (("lamp", "lighting", "light"), "该产品属于照明设计，重点处理光线控制、结构形态与环境氛围之间的关系，并兼顾安装、操作和空间适配需求。"),
    (("watch", "wearable"), "该产品属于可穿戴设备，重点整合佩戴舒适性、传感功能、交互效率与耐用性，以适应日常和户外使用场景。"),
    (("phone", "smartphone", "tablet", "laptop", "computer"), "该产品属于消费电子设备，重点关注机身结构、显示与交互体验、便携性及性能配置之间的平衡。"),
    (("car", "vehicle", "mobility", "bike", "bicycle"), "该产品属于交通与出行设计，重点关注造型空气动力学、乘坐或操控体验、安全性以及能源效率。"),
    (("medical", "health", "ultrasound"), "该产品面向医疗健康场景，重点关注操作清晰度、使用安全、设备便携性与医护工作流程之间的适配。"),
    (("kitchen", "cook", "coffee", "appliance"), "该产品面向厨房或家电场景，重点关注操作便利性、清洁维护、空间占用以及日常使用效率。"),
]

def _clean_text(value: Any) -> str:
    text = html_module.unescape(str(value or ""))
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

def _is_chinese_primary(text: str) -> bool:
    text = _clean_text(text)
    if not text:
        return False
    zh = len(re.findall(r"[\u4e00-\u9fff]", text))
    latin = len(re.findall(r"[A-Za-z]", text))
    return zh >= 6 and zh >= latin * 0.35

def _derived_chinese_description(product: dict[str, Any]) -> str:
    ai = product.get("ai_analysis") or {}
    title = _clean_text(product.get("title"))
    raw = " ".join(_clean_text(x) for x in (product.get("description"), product.get("summary"), product.get("body_text"), ai.get("description")))
    haystack = f"{title} {raw}".lower()
    for terms, text in _PRODUCT_TERMS:
        if any(term in haystack for term in terms):
            return text
    category = str(ai.get("category_label") or ai.get("category") or product.get("category") or "").strip()
    brand = str(product.get("brand") or product.get("source") or product.get("publisher") or "").strip()
    prefix = f"{brand}的这项资讯" if brand else "该条资讯"
    if category and category not in {"other", "其他"}:
        return f"{prefix}属于{category}领域，重点呈现产品定位、外观形态与使用场景；现有公开资料尚不足以确认更多结构、材料和功能细节。"
    return CHINESE_FALLBACK

def _description_zh(product: dict[str, Any]) -> str:
    ai = product.get("ai_analysis") or {}
    candidates = [ai.get("description_zh"), product.get("description_zh"), product.get("summary_zh"), ai.get("description"), product.get("description"), product.get("summary")]
    for value in candidates:
        cleaned = _clean_text(value)
        if _is_chinese_primary(cleaned):
            return cleaned
    # Agent-assisted runs may only have an English source page. Prefer the
    # extracted evidence sentence over repeating a generic category description.
    evidence_summary = _clean_text(product.get("source_summary"))
    if evidence_summary:
        return evidence_summary
    return _derived_chinese_description(product)

CATEGORY_LABELS = {
    "consumer_electronics": "消费电子",
    "furniture_lighting": "家具照明",
    "transportation": "交通工具",
    "home_appliances": "家用电器",
    "tools_equipment": "工具设备",
    "sustainable_design": "可持续设计",
    "wearable_tech": "可穿戴设备",
    "kitchen_tableware": "厨房餐厨",
    "medical_health": "医疗健康",
    "sports_outdoors": "户外运动",
    "commercial_equipment": "工业设备",
    "other_product": "其他产品",
    "other": "其他",
}


class HTMLGenerator:
    def __init__(self, date: str | None = None, use_local_images: bool = False):
        self.date = date or datetime.now().strftime("%Y-%m-%d")
        try:
            self.date_display = datetime.strptime(self.date, "%Y-%m-%d").strftime("%Y年%m月%d日")
        except ValueError:
            self.date_display = self.date
        self.use_local_images = use_local_images

    @staticmethod
    def _css() -> str:
        return r"""
:root{
  color-scheme:light dark;
  --bg:#f3f1ec;--surface:#fff;--surface-2:#ebe8e1;--text:#11110f;--muted:#72716c;
  --line:rgba(17,17,15,.13);--glass:rgba(243,241,236,.82);--overlay:rgba(5,5,5,.72);
  --accent:#11110f;--accent-text:#fff;--shadow:0 22px 65px rgba(28,24,18,.13);
  --rail:78px;--header:76px;--gap:30px;--radius:13px;
}
@media(prefers-color-scheme:dark){:root{
  --bg:#080909;--surface:#111212;--surface-2:#171919;--text:#f2f1ec;--muted:#93938d;
  --line:rgba(255,255,255,.11);--glass:rgba(8,9,9,.84);--overlay:rgba(0,0,0,.82);
  --accent:#f2f1ec;--accent-text:#090a0a;--shadow:0 25px 70px rgba(0,0,0,.4);
}}
html[data-theme="light"]{color-scheme:light;--bg:#f3f1ec;--surface:#fff;--surface-2:#ebe8e1;--text:#11110f;--muted:#72716c;--line:rgba(17,17,15,.13);--glass:rgba(243,241,236,.82);--overlay:rgba(5,5,5,.72);--accent:#11110f;--accent-text:#fff;--shadow:0 22px 65px rgba(28,24,18,.13)}
html[data-theme="dark"]{color-scheme:dark;--bg:#080909;--surface:#111212;--surface-2:#171919;--text:#f2f1ec;--muted:#93938d;--line:rgba(255,255,255,.11);--glass:rgba(8,9,9,.84);--overlay:rgba(0,0,0,.82);--accent:#f2f1ec;--accent-text:#090a0a;--shadow:0 25px 70px rgba(0,0,0,.4)}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:var(--bg);color:var(--text);font-family:Inter,"Noto Sans SC",system-ui,sans-serif;-webkit-font-smoothing:antialiased}
button,a{font:inherit}button{color:inherit}.shell{min-height:100vh}.topbar{position:fixed;z-index:80;left:var(--rail);right:var(--rail);top:0;height:var(--header);display:grid;grid-template-columns:1fr auto 1fr;align-items:center;padding:0 30px;background:var(--glass);backdrop-filter:blur(18px) saturate(125%);border-bottom:1px solid var(--line)}
.brand{display:flex;align-items:center;gap:14px;font-weight:800;letter-spacing:-.04em}.brand-mark{width:40px;height:40px;display:grid;place-items:center;color:var(--text)}.brand-mark svg{width:100%;height:100%;display:block}.brand-mark .frame,.brand-mark .axis{fill:none;stroke:currentColor;stroke-width:1.35;vector-effect:non-scaling-stroke}.brand-mark .node{fill:currentColor}.brand-mark .ghost{opacity:.34}
.nav{display:flex;gap:28px;align-items:center}.nav button{border:0;background:none;padding:26px 0 23px;text-transform:uppercase;font:650 12px/1 Inter,"Noto Sans SC",system-ui,sans-serif;letter-spacing:.12em;cursor:pointer;position:relative}.nav button.active:after{content:"";position:absolute;left:25%;right:25%;bottom:13px;height:2px;background:var(--text)}.nav button:focus-visible{outline:1px solid var(--text);outline-offset:5px}.nav button[aria-disabled="true"]{opacity:.38;cursor:not-allowed}.toast{position:fixed;z-index:260;left:50%;top:94px;transform:translate(-50%,-18px);opacity:0;pointer-events:none;background:var(--text);color:var(--bg);padding:11px 16px;border-radius:999px;font-size:12px;transition:.25s}.toast.show{opacity:1;transform:translate(-50%,0)}.gallery.compact{columns:4 250px}.card.selected-only-hidden{display:none}
.top-actions{justify-self:end;display:flex;gap:9px}.icon-btn{width:40px;height:40px;border:1px solid var(--line);background:var(--surface);display:grid;place-items:center;cursor:pointer;border-radius:50%;transition:.2s}.icon-btn:hover{transform:translateY(-2px);box-shadow:var(--shadow)}
.side-rail{position:fixed;z-index:90;top:0;bottom:0;width:var(--rail);background:var(--surface);display:flex;align-items:center;justify-content:center;border-color:var(--line)}.side-rail.left{left:0;border-right:1px solid var(--line)}.side-rail.right{right:0;border-left:1px solid var(--line)}
.vertical-stack{display:flex;align-items:center;gap:13px;writing-mode:vertical-rl;transform:rotate(180deg)}.rail-label{font:650 10px/1 Inter,"Noto Sans SC",system-ui,sans-serif;letter-spacing:.16em;text-transform:uppercase;color:var(--muted)}
.theme-switch{display:flex;flex-direction:column;border:1px solid var(--line);border-radius:99px;overflow:hidden;background:var(--surface-2);writing-mode:initial;transform:rotate(180deg)}.theme-switch button{border:0;background:transparent;padding:12px 9px;font:650 10px/1 Inter,"Noto Sans SC",system-ui,sans-serif;letter-spacing:.08em;cursor:pointer;color:var(--muted)}.theme-switch button.active{background:var(--accent);color:var(--accent-text)}
.content{padding:calc(var(--header) + 42px) calc(var(--rail) + 36px) 90px}.hero{max-width:1340px;margin:0 auto 34px;display:grid;grid-template-columns:1.4fr .6fr;gap:30px;align-items:end}.eyebrow{font:600 11px/1.2 Inter,"Noto Sans SC",system-ui,sans-serif;letter-spacing:.18em;color:var(--muted);text-transform:uppercase}.hero h1{font-size:clamp(38px,6vw,88px);line-height:.98;letter-spacing:-.068em;margin:18px 0 16px;max-width:900px;font-weight:760}.hero h1 span{display:block}.hero h1 span+span{margin-top:.01em}.hero-copy{color:var(--muted);max-width:620px;font-size:14px}.stats{display:grid;grid-template-columns:repeat(2,1fr);border-top:1px solid var(--line);border-left:1px solid var(--line)}.stat{padding:18px;border-right:1px solid var(--line);border-bottom:1px solid var(--line)}.stat strong{font-size:27px;display:block}.stat span{font:650 10px/1.5 Inter,"Noto Sans SC",system-ui,sans-serif;letter-spacing:.12em;color:var(--muted);text-transform:uppercase}
.filter-row{max-width:1340px;margin:0 auto 31px;display:flex;gap:8px;flex-wrap:wrap;align-items:center}.filter-btn{border:1px solid var(--line);background:var(--surface);border-radius:99px;padding:9px 15px;font-size:12px;cursor:pointer}.filter-btn.active{background:var(--accent);color:var(--accent-text);border-color:var(--accent)}.filter-btn .count{opacity:.55;margin-left:5px}
.gallery{max-width:1340px;margin:0 auto;columns:3 330px;column-gap:var(--gap)}.card{break-inside:avoid;margin:0 0 var(--gap);position:relative;border-radius:var(--radius);overflow:hidden;background:var(--surface);box-shadow:0 0 0 1px var(--line);opacity:0;transform:translateY(24px);transition:opacity .55s,transform .55s,box-shadow .25s}.card.visible{opacity:1;transform:none}.card:hover{box-shadow:var(--shadow)}.media{position:relative;background:var(--surface-2);cursor:zoom-in}.media img{width:100%;height:auto;min-height:230px;display:block;object-fit:cover;transition:transform .65s cubic-bezier(.2,.8,.2,1),filter .25s}.card:hover .media img{transform:scale(1.025)}.media:after{content:"";position:absolute;inset:0;background:linear-gradient(to top,rgba(0,0,0,.72),transparent 48%);opacity:0;transition:.25s}.card:hover .media:after{opacity:1}.media-actions{position:absolute;z-index:3;left:15px;right:15px;bottom:14px;display:flex;align-items:end;justify-content:space-between;opacity:0;transform:translateY(8px);transition:.25s}.card:hover .media-actions{opacity:1;transform:none}.quick-title{color:#fff;font-weight:700;max-width:72%;text-shadow:0 2px 20px #000;font-size:15px}.round-action{width:38px;height:38px;border-radius:50%;border:1px solid rgba(255,255,255,.35);background:rgba(0,0,0,.4);color:#fff;backdrop-filter:blur(8px);cursor:pointer}.card-body{padding:17px 17px 16px}.meta{display:flex;justify-content:space-between;gap:15px;margin-bottom:8px;font:600 10px/1.4 Inter,"Noto Sans SC",system-ui,sans-serif;text-transform:uppercase;letter-spacing:.08em;color:var(--muted)}.card h2{font-size:17px;line-height:1.25;letter-spacing:-.025em;margin:0 0 9px}.summary{font-size:12px;line-height:1.65;color:var(--muted);margin:0 0 13px}.actions{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.link{font-size:11px;text-decoration:none;color:var(--text);border-bottom:1px solid var(--line);padding:3px 0}.review-link{display:inline-flex;align-items:center;gap:6px;border:1px solid var(--line);border-radius:999px;padding:6px 9px;text-decoration:none;font-size:10px;font-weight:700;letter-spacing:.04em}.review-link:before{content:"";width:6px;height:6px;border-radius:50%;background:#44b97a}.review-link.disabled{opacity:.42;pointer-events:none}.review-link.disabled:before{background:var(--muted)}.select{margin-left:auto;display:flex;align-items:center;gap:5px;font-size:11px;color:var(--muted);cursor:pointer}.select input{accent-color:var(--accent)}
.lightbox{display:none;position:fixed;z-index:200;inset:0;background:var(--overlay);backdrop-filter:blur(20px);padding:30px;align-items:center;justify-content:center}.lightbox.active{display:flex}.lightbox img{max-width:min(1240px,90vw);max-height:82vh;object-fit:contain;border-radius:10px}.lightbox-close{position:absolute;right:30px;top:25px;width:45px;height:45px;border-radius:50%;border:1px solid rgba(255,255,255,.25);background:rgba(0,0,0,.38);color:#fff;font-size:24px;cursor:pointer}.lightbox-caption{position:absolute;left:50%;bottom:22px;transform:translateX(-50%);color:#fff;font-weight:700;text-shadow:0 2px 20px #000}
.action-bar{position:fixed;z-index:120;left:50%;bottom:24px;transform:translate(-50%,100px);display:flex;align-items:center;gap:12px;background:var(--surface);border:1px solid var(--line);box-shadow:var(--shadow);padding:10px 12px 10px 18px;border-radius:99px;transition:.3s}.action-bar.show{transform:translate(-50%,0)}.action-bar button{border:0;border-radius:99px;padding:9px 14px;cursor:pointer}.primary{background:var(--accent);color:var(--accent-text)}.secondary{background:var(--surface-2)}
.backtop{position:fixed;right:17px;bottom:24px;z-index:99;width:44px;height:44px;border-radius:50%;border:1px solid var(--line);background:var(--surface);cursor:pointer}.footer{max-width:1340px;margin:55px auto 0;padding-top:24px;border-top:1px solid var(--line);color:var(--muted);font:600 10px/1.6 Inter,"Noto Sans SC",system-ui,sans-serif;text-transform:uppercase;letter-spacing:.1em}
@media(max-width:900px){:root{--rail:0px}.side-rail{display:none}.topbar{left:0;right:0;grid-template-columns:1fr auto;padding:0 17px}.nav{display:none}.content{padding-left:18px;padding-right:18px}.hero{grid-template-columns:1fr}.gallery{columns:2 270px}.brand span:last-child{display:none}}
@media(max-width:580px){.gallery{columns:1}.hero h1{font-size:48px;line-height:1.02;letter-spacing:-.055em}.stats{grid-template-columns:repeat(4,1fr)}.stat{padding:10px}.stat strong{font-size:20px}.stat span{font-size:8px}.content{padding-top:105px}.topbar{height:66px}.card-body{padding:14px}}
@media(prefers-reduced-motion:reduce){*{scroll-behavior:auto!important;animation:none!important;transition:none!important}}
"""

    def _image_src(self, product: dict[str, Any]) -> str:
        if self.use_local_images:
            return str(product.get("local_image_path") or product.get("filename") or "")
        return str(product.get("local_image_path") or product.get("image_url") or product.get("original_url") or product.get("filename") or "")

    def _card(self, product: dict[str, Any], index: int, archive: bool = False) -> str:
        ai = product.get("ai_analysis") or {}
        category = ai.get("category") or product.get("ai_category") or product.get("category") or "other"
        label = ai.get("category_label") or CATEGORY_LABELS.get(category, category)
        title = html.escape(str(product.get("title") or "Untitled"))
        source = html.escape(str(product.get("source") or product.get("publisher") or product.get("source_id") or "Unknown source"))
        img = html.escape(self._image_src(product), quote=True)
        page = html.escape(str(product.get("page_url") or product.get("canonical_url") or product.get("url") or ""), quote=True)
        original = html.escape(str(product.get("original_url") or product.get("image_url") or ""), quote=True)
        lightbox_src = html.escape(self._image_src(product), quote=True)
        lightbox_title = html.escape(str(product.get("title") or "Untitled"), quote=True)
        summary_raw = _description_zh(product)
        summary = html.escape(summary_raw)
        lightbox_description = html.escape(summary_raw, quote=True)
        style = html.escape(str(ai.get("style") or ""))
        pid = html.escape(str(product.get("product_id") or index), quote=True)
        file_token = html.escape(str(product.get("feishu_file_token") or ""), quote=True)
        review = html.escape(str(product.get("review_status") or "待审核"), quote=True)
        date = html.escape(str(product.get("first_seen_date") or self.date))
        search_text = html.escape(
            " ".join(
                str(value or "")
                for value in (
                    product.get("title"),
                    product.get("brand"),
                    product.get("publisher"),
                    product.get("source"),
                    label,
                    category,
                    summary_raw,
                )
            ).lower(),
            quote=True,
        )
        links = []
        if page:
            links.append(f'<a class="link" href="{page}" target="_blank" rel="noopener">原文 ↗</a>')
        if original:
            links.append(f'<a class="link" href="{original}" target="_blank" rel="noopener">原图 ↗</a>')
        links.append(f'<a class="link" href="details/{pid}.html">详情 →</a>')
        return f'''<article class="card" data-category="{html.escape(category, quote=True)}" data-brand="{html.escape(str(product.get('brand') or source), quote=True)}" data-materials="{html.escape(','.join(product.get('materials') or ai.get('materials') or []), quote=True)}" data-search="{search_text}" data-index="{index}">
  <div class="media" data-lightbox-src="{lightbox_src}" data-lightbox-title="{lightbox_title}" data-lightbox-description="{lightbox_description}" role="button" tabindex="0" aria-label="放大查看 {lightbox_title}">
    <img src="{img}" alt="{title}" loading="lazy">
    <div class="media-actions"><span class="quick-title">{title}</span><button class="round-action" aria-label="放大">↗</button></div>
  </div>
  <div class="card-body">
    <div class="meta"><span>{label}{' · '+style if style else ''}</span><span>{date if archive else source}</span></div>
    <h2>{title}</h2>
    {f'<p class="summary">{summary}</p>' if summary else ''}
    <div class="actions">{''.join(links)}
      <label class="select"><input type="checkbox" {'checked' if bool(product.get('keep', product.get('retained', False))) else ''} data-id="{pid}" data-title="{title}" data-img="{original}" data-page="{page}" data-file-token="{file_token}" data-review-status="{review}"> 保留</label>
    </div>
  </div>
</article>'''

    @staticmethod
    def _js() -> str:
        return r"""
const root=document.documentElement, saved=localStorage.getItem('gallery-theme')||'system';
function setTheme(mode){root.dataset.theme=mode==='system'?'':mode;localStorage.setItem('gallery-theme',mode);document.querySelectorAll('[data-theme-choice]').forEach(b=>b.classList.toggle('active',b.dataset.themeChoice===mode));}
setTheme(saved);document.querySelectorAll('[data-theme-choice]').forEach(b=>b.onclick=()=>setTheme(b.dataset.themeChoice));
const observer=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){setTimeout(()=>e.target.classList.add('visible'),Math.min(Number(e.target.dataset.index)*45,450));observer.unobserve(e.target)}}),{threshold:.06});document.querySelectorAll('.card').forEach(c=>observer.observe(c));
function setActiveNav(name){document.querySelectorAll('.nav button').forEach(b=>b.classList.toggle('active',b.dataset.nav===name));}
function showToast(message){const t=document.getElementById('toast');t.textContent=message;t.classList.add('show');clearTimeout(window.__toastTimer);window.__toastTimer=setTimeout(()=>t.classList.remove('show'),1800);}
document.querySelectorAll('.filter-btn').forEach(btn=>btn.onclick=()=>{document.querySelectorAll('.filter-btn').forEach(b=>b.classList.remove('active'));btn.classList.add('active');const cat=btn.dataset.category;document.querySelectorAll('.card').forEach(c=>{c.hidden=cat!=='all'&&c.dataset.category!==cat;c.classList.remove('selected-only-hidden')});setActiveNav('gallery')});
const lb=document.getElementById('lightbox');function openLightbox(src,title,description){document.getElementById('lightbox-img').src=src;document.getElementById('lightbox-title').textContent=title;document.getElementById('lightbox-description').textContent=description||'';lb.classList.add('active');document.body.style.overflow='hidden'}window.openLightbox=openLightbox;function closeLightbox(){lb.classList.remove('active');document.body.style.overflow=''}document.getElementById('lightbox-close').onclick=closeLightbox;lb.onclick=e=>{if(e.target===lb)closeLightbox()};addEventListener('keydown',e=>{if(e.key==='Escape')closeLightbox()});
let selected=[];const bar=document.getElementById('actionBar'),counter=document.getElementById('actionCount');function refreshSelected(){document.querySelectorAll('.select input').forEach(cb=>{const card=cb.closest('.card');card.dataset.selected=cb.checked?'true':'false'});counter.textContent=`已选 ${selected.length} 项`;bar.classList.toggle('show',selected.length>0)}document.querySelectorAll('.select input').forEach(cb=>cb.onchange=()=>{const row={id:cb.dataset.id,title:cb.dataset.title,img:cb.dataset.img,page:cb.dataset.page,feishu_file_token:cb.dataset.fileToken||'',review_status:cb.dataset.reviewStatus||'待审核'};selected=cb.checked?[...selected.filter(x=>x.id!==row.id),row]:selected.filter(x=>x.id!==row.id);refreshSelected()});
document.querySelectorAll('.nav button').forEach(btn=>btn.onclick=()=>{const name=btn.dataset.nav;if(name==='today'){document.querySelectorAll('.card').forEach(c=>c.classList.remove('selected-only-hidden'));scrollTo({top:0,behavior:'smooth'});setActiveNav(name)}else if(name==='gallery'){document.querySelectorAll('.card').forEach(c=>c.classList.remove('selected-only-hidden'));document.getElementById('gallery').scrollIntoView({behavior:'smooth',block:'start'});setActiveNav(name)}else if(name==='archive'){window.location.href=btn.dataset.href||'../archive/index.html'}else if(['explore','compare','board','trends'].includes(name)){window.location.href=btn.dataset.href}else if(name==='selected'){if(!selected.length){showToast('请先勾选需要保留的图片');return}document.querySelectorAll('.card').forEach(c=>c.classList.toggle('selected-only-hidden',c.dataset.selected!=='true'));document.getElementById('gallery').scrollIntoView({behavior:'smooth',block:'start'});setActiveNav(name)}});
document.getElementById('exportBtn').onclick=()=>{const blob=new Blob([JSON.stringify(selected,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`selected_${new Date().toISOString().slice(0,10)}.json`;a.click();URL.revokeObjectURL(a.href)};document.getElementById('clearBtn').onclick=()=>{document.querySelectorAll('.select input').forEach(x=>x.checked=false);selected=[];refreshSelected();document.querySelectorAll('.card').forEach(c=>c.classList.remove('selected-only-hidden'));setActiveNav('gallery')};document.getElementById('backtop').onclick=()=>scrollTo({top:0,behavior:'smooth'});
document.getElementById('gridToggle').onclick=()=>{document.getElementById('gallery').classList.toggle('compact');showToast(document.getElementById('gallery').classList.contains('compact')?'紧凑视图':'标准视图')};
document.getElementById('fullscreenBtn').onclick=async()=>{try{if(!document.fullscreenElement)await document.documentElement.requestFullscreen?.();else await document.exitFullscreen?.()}catch(e){showToast('当前浏览器不支持全屏')};};
"""


    def generate(self, products: list[dict[str, Any]], ai_data: dict[str, Any] | None = None,
                 output_path: str | None = None, is_incremental: bool = False,
                 new_count: int | None = None, archive_href: str = "../archive/index.html") -> str:
        if ai_data:
            for p in products:
                if p.get("product_id") in ai_data:
                    p["ai_analysis"] = ai_data[p["product_id"]]
        counts: dict[str, int] = {}
        for p in products:
            ai = p.get("ai_analysis") or {}
            cat = ai.get("category") or p.get("ai_category") or p.get("category") or "other"
            counts[cat] = counts.get(cat, 0) + 1
        filters = [f'<button class="filter-btn active" data-category="all">全部 <span class="count">{len(products)}</span></button>']
        filters += [f'<button class="filter-btn" data-category="{html.escape(k)}">{html.escape(CATEGORY_LABELS.get(k,k))} <span class="count">{v}</span></button>' for k,v in sorted(counts.items(),key=lambda x:-x[1])]
        cards = "\n".join(self._card(p,i) for i,p in enumerate(products))
        sources = len({p.get('source','') for p in products})
        images = sum(1+len(p.get('thumbnails',[])) for p in products)
        template_root = Path(__file__).resolve().parents[1] / "templates"
        doc = (template_root / "daily_gallery.html.j2").read_text(encoding="utf-8")
        values = {
            "{{DATE}}": html.escape(self.date),
            "{{DATE_DISPLAY}}": html.escape(self.date_display),
            "{{CSS}}": (template_root / "assets" / "gallery.css").read_text(encoding="utf-8"),
            "{{JS}}": (template_root / "assets" / "gallery.js").read_text(encoding="utf-8"),
            "{{PRODUCT_COUNT}}": str(len(products)),
            "{{IMAGE_COUNT}}": str(images),
            "{{CATEGORY_COUNT}}": str(len(counts)),
            "{{SOURCE_COUNT}}": str(sources),
            "{{FILTERS}}": "".join(filters),
            "{{CARDS}}": cards,
            "{{ARCHIVE_HREF}}": html.escape(archive_href, quote=True),
        }
        for token, value in values.items():
            doc = doc.replace(token, value)
        if output_path:
            Path(output_path).parent.mkdir(parents=True, exist_ok=True)
            Path(output_path).write_text(doc, encoding="utf-8")
        return doc

    def generate_archive(self, history_products: list[dict[str, Any]], output_path: str | None = None, archive_href: str = "index.html") -> str:
        normalized=[]
        for p in history_products:
            p=dict(p)
            p.setdefault("ai_analysis", {"category":p.get("ai_category","other"),"style":p.get("ai_style",""),"confidence":p.get("ai_confidence",0)})
            normalized.append(p)
        return self.generate(normalized, output_path=output_path, archive_href=archive_href)


def main() -> None:
    ap=argparse.ArgumentParser()
    ap.add_argument("--manifest")
    ap.add_argument("--ai-data")
    ap.add_argument("--output")
    ap.add_argument("--local",action="store_true")
    ap.add_argument("--archive",action="store_true")
    ap.add_argument("--history")
    ap.add_argument("--archive-href")
    args=ap.parse_args()
    source=args.history if args.archive else args.manifest
    if not source: ap.error("--manifest or --history is required")
    raw=json.loads(Path(source).read_text(encoding="utf-8"))
    products=raw.get("products",raw.get("manifest",raw)) if isinstance(raw,dict) else raw
    ai_data=json.loads(Path(args.ai_data).read_text(encoding="utf-8")) if args.ai_data else None
    out=args.output or "output/gallery.html"
    gen=HTMLGenerator(use_local_images=args.local)
    archive_href = args.archive_href or ("index.html" if args.archive else "../archive/index.html")
    (gen.generate_archive(products,out,archive_href) if args.archive else gen.generate(products,ai_data,out,archive_href=archive_href))
    print(f"HTML generated: {out}")

if __name__=="__main__": main()
