#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, subprocess, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
from scripts import agent_daily_pipeline as daily

PHYSICAL=('display','furniture','chair','table','lamp','light','phone','watch','speaker','camera','appliance','tool','device','projector','headphone','earbud','bike','vehicle','robot','bottle','laptop','computer','keyboard','jacket','clothing','wearable')
REJECT=('patent','plugin','software','google maps','sport stops','exhibition','architecture','artwork','concept')
MEDIA_RELEASE_SIGNALS=('launches','launched','unveils','unveiled','introduces','introduced','announces','announced','debuts','debuted','new product')

def main():
 p=argparse.ArgumentParser();p.add_argument('--date',required=True);a=p.parse_args()
 source=ROOT/'data'/a.date/'tiered'/'merged_data.json'; payload=json.loads(source.read_text(encoding='utf-8'))
 out=ROOT/'output'/a.date; images=out/'images';images.mkdir(parents=True,exist_ok=True)
 products=[];seen_images=set();historical_urls=set();historical_titles=set();historical_images=set()
 for history_path in (ROOT/'output').glob('*/portal_input.json'):
  if history_path.parent.name == a.date:continue
  try: history=json.loads(history_path.read_text(encoding='utf-8'))
  except Exception: continue
  for old in history:
   old_url=str(old.get('page_url') or old.get('canonical_url') or '').split('?',1)[0].rstrip('/').lower()
   old_title=''.join(ch.lower() for ch in str(old.get('title') or '') if ch.isalnum())
   if old_url:historical_urls.add(old_url)
   if old_title:historical_titles.add(old_title)
   if old.get('image_sha256'):historical_images.add(str(old['image_sha256']))
 for x in payload.get('products',[]):
  title=str(x.get('title','')).lower()
  if any(k in title for k in REJECT) or not any(k in title for k in PHYSICAL):continue
  evidence=(title+' '+str(x.get('summary') or '')+' '+str(x.get('body_text') or '')[:1400]).lower()
  # A media post published today is only a release when the article itself
  # contains an explicit launch/debut signal. This prevents old products from
  # resurfacing merely because an editorial site covered them today.
  if x.get('source_type')=='design_media' and not any(k in evidence for k in MEDIA_RELEASE_SIGNALS):continue
  if any(k in evidence for k in ('conceptual garment','not selling these','not a product pitch')):continue
  page_key=str(x.get('page_url') or x.get('canonical_url') or '').split('?',1)[0].rstrip('/').lower()
  title_key=''.join(ch.lower() for ch in str(x.get('title') or '') if ch.isalnum())
  if (page_key and page_key in historical_urls) or (title_key and title_key in historical_titles):continue
  url=x.get('image_url');
  if not url:continue
  pid=str(x.get('product_id') or hashlib.sha1((x.get('page_url') or title).encode()).hexdigest()[:12]).replace('prod_','')
  path=images/f'{pid}.jpg'
  if not daily.download_image(url,path) or not daily.verify_image(path):continue
  digest=hashlib.sha256(path.read_bytes()).hexdigest()
  if digest in seen_images or digest in historical_images:continue
  seen_images.add(digest);item=dict(x);item.update({'product_id':pid,'local_image_path':f'images/{path.name}','page_url':x.get('page_url') or x.get('canonical_url'),'publisher':x.get('publisher') or x.get('source'),'category':daily.categorize_product({'title':x.get('title',''),'description':x.get('body_text','')}),'image_sha256':digest,'first_seen_date':a.date,'image_verified':True});products.append(item)
 (out/'portal_input.json').write_text(json.dumps(products,ensure_ascii=False,indent=2),encoding='utf-8')
 daily.TODAY=a.date;daily.generate_html(products,out/'gallery_canonical_source.html',images)
 subprocess.run([sys.executable,str(ROOT/'scripts'/'build_gallery_hierarchy.py'),'--root',str(ROOT/'output'),'--date',a.date],cwd=ROOT,check=True)
 daily.generate_portable_preview(out/'design_intelligence_portal.html',images,out/f'{a.date}_工业设计图片日报_预览版.html')
 print(json.dumps({'date':a.date,'qualified_products':len(products),'portal':str(out/'design_intelligence_portal.html'),'preview':str(out/f'{a.date}_工业设计图片日报_预览版.html')},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
