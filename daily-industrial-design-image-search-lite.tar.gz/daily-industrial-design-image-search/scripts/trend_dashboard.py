"""Trend metadata inference and the dependency-free interactive dashboard."""
from __future__ import annotations

import re


def _unique(values):
    return list(dict.fromkeys(value for value in values if value))


def _brand(title: str, product: dict) -> str:
    explicit = str(product.get("brand") or "").strip()
    if explicit:
        return explicit
    rules = (
        ("samsung", "Samsung"), ("sony", "Sony"), ("rx10", "Sony"),
        ("kindle", "Amazon"), ("openai", "OpenAI"), ("librem", "Purism"),
        ("purism", "Purism"), ("cmf", "CMF by Nothing"), ("nothing", "Nothing"),
        ("tan france", "Castlery"), ("meld", "Meld"),
    )
    for term, value in rules:
        if term in title:
            return value
    return str(product.get("publisher") or product.get("source") or "未知品牌")


def _region(brand: str, title: str, body: str) -> str:
    regions = {
        "Samsung": "韩国", "Sony": "日本", "Amazon": "美国", "OpenAI": "美国",
        "Purism": "美国", "CMF by Nothing": "英国", "Nothing": "英国",
        "Castlery": "新加坡", "Meld": "北美",
    }
    if brand in regions:
        return regions[brand]
    if "japanese" in title or "japan" in body:
        return "日本"
    if "korea" in body:
        return "韩国"
    if "china" in body:
        return "中国"
    if "europe" in body:
        return "欧洲"
    return "全球/未标注"


def enrich_trend_record(product: dict, base: dict) -> dict:
    title = str(product.get("title") or "").lower()
    body = " ".join(str(product.get(key) or "") for key in ("summary", "body_text", "description")).lower()
    text = f"{title} {body}"
    brand = _brand(title, product)
    source = str(product.get("publisher") or product.get("source") or brand)

    styles, drivers, colors, materials, finishes = [], [], [], [], []

    if "librem" in title or "cuts the wire" in title:
        styles += ["隐私硬件", "功能主义", "极简"]
        drivers += ["隐私保护", "可维修性", "开放系统"]
        colors += ["曜石黑", "深灰"]
        materials += ["铝合金", "玻璃"]
        finishes += ["哑光", "阳极氧化"]
    elif "kindle scribe" in title:
        styles += ["数字极简", "柔和界面", "轻量化"]
        drivers += ["低干扰交互", "阅读体验", "数字书写"]
        colors += ["石墨黑", "纸白"]
        materials += ["再生塑料", "玻璃"]
        finishes += ["哑光", "防眩光"]
    elif "red craft collection" in title:
        styles += ["新工艺复兴", "雕塑感", "有机形态"]
        drivers += ["传统工艺再设计", "材料表达", "小批量制造"]
        colors += ["朱红", "自然棕", "墨黑"]
        materials += ["木材", "漆艺", "金属"]
        finishes += ["高光漆", "手工纹理"]
    elif "writing device" in title:
        styles += ["功能主义", "低成本开源", "复古科技"]
        drivers += ["专注交互", "可制造性", "开放硬件"]
        colors += ["深灰", "米白"]
        materials += ["工程塑料", "电子元件"]
        finishes += ["哑光", "裸露结构"]
    elif "rx10" in title or ("sony" in title and "camera" in text):
        styles += ["专业工具化", "一体化", "功能主义"]
        drivers += ["便携化", "全场景拍摄", "性能集成"]
        colors += ["曜石黑"]
        materials += ["镁铝合金", "工程塑料", "玻璃"]
        finishes += ["细砂纹", "哑光"]
    elif "smart speaker" in title:
        styles += ["无界面设计", "家居科技", "柔和几何"]
        drivers += ["自然语音交互", "环境智能", "AI 原生硬件"]
        colors += ["待官方确认"]
        materials += ["待官方确认"]
        finishes += ["待官方确认"]
    elif "magnetic display" in title:
        styles += ["低干扰交互", "桌面极简", "信息可视化"]
        drivers += ["数字健康", "专注体验", "模块化"]
        colors += ["暖白", "浅灰"]
        materials += ["工程塑料", "磁性材料", "显示面板"]
        finishes += ["哑光", "细砂纹"]
    elif "tan france" in title or "furniture range" in title:
        styles += ["柔和几何", "现代家居", "包容性设计"]
        drivers += ["空间适配", "舒适性", "易搭配"]
        colors += ["米白", "暖棕", "鼠尾草绿"]
        materials += ["织物", "木材", "泡棉"]
        finishes += ["织物肌理", "自然木纹"]
    elif "flex titanium" in title:
        styles += ["材料科技", "超薄结构", "未来主义"]
        drivers += ["耐久性", "轻量化", "折叠形态"]
        colors += ["钛灰", "曜石黑"]
        materials += ["钛合金", "超薄玻璃", "OLED"]
        finishes += ["金属原色", "微纹理"]
    elif "watch" in title:
        styles += ["运动科技", "功能主义", "未来主义"]
        drivers += ["全天候佩戴", "健康监测", "户外耐用"]
        colors += ["曜石黑", "银白", "活力橙"]
        materials += ["钛合金", "玻璃", "硅胶"]
        finishes += ["拉丝", "哑光"]
    elif "echo chair" in title or "chair" in title:
        styles += ["雕塑感", "有机形态", "数字制造"]
        drivers += ["3D 打印", "人体工学", "小批量制造"]
        colors += ["米白", "琥珀棕", "墨黑"]
        materials += ["3D 打印聚合物"]
        finishes += ["层积纹理", "半哑光"]
    elif "washer" in title or "dryer" in title:
        styles += ["嵌入式家居", "智能极简", "秩序感"]
        drivers += ["AI 织物护理", "家电互联", "空间整合"]
        colors += ["石墨灰", "曜石黑"]
        materials += ["涂层金属", "玻璃"]
        finishes += ["哑光", "高光玻璃"]
    elif "skincare" in title or "dispenser" in title:
        styles += ["模块化", "透明化", "实验室美学"]
        drivers += ["个性化配方", "可重复使用", "成分透明"]
        colors += ["透明", "暖白", "珊瑚橙"]
        materials += ["透明聚合物", "铝合金"]
        finishes += ["透明", "阳极氧化"]
    elif "earbud" in title or "headphone" in title:
        styles += ["轻量化", "穿戴式", "年轻化"]
        drivers += ["开放佩戴", "便携化", "价格普惠"]
        colors += ["暖白", "活力橙"]
        materials += ["工程塑料", "硅胶"]
        finishes += ["哑光", "亲肤纹理"]

    # Generic inference keeps archive backfills analytically useful without
    # pretending that every product shares the same style.  These labels are
    # deliberately conservative and only follow explicit words in the source.
    if not styles:
        generic_styles = (
            (("minimal", "reductive", "clean line"), "极简"),
            (("sculptural", "sculpture"), "雕塑感"),
            (("retro", "vintage", "y2k", "1960s", "1970s"), "复古科技"),
            (("transparent", "see-through"), "透明科技"),
            (("modular", "customiz"), "模块化"),
            (("playful", "toy-inspired", "colorful"), "趣味化"),
            (("organic", "grown", "nature-inspired"), "有机形态"),
            (("industrial", "tool", "steel"), "工业工具感"),
            (("portable", "compact", "fold"), "轻量便携"),
            (("smart", "ai ", "robot"), "智能极简"),
            (("recycled", "reclaimed", "waste"), "可持续表达"),
        )
        for terms, label in generic_styles:
            if any(term in text for term in terms):
                styles.append(label)
        if not styles:
            styles = ["功能主义"]
    if not drivers:
        generic_drivers = (
            (("portable", "compact", "fold"), "便携与收纳"),
            (("recycled", "reclaimed", "waste", "sustainable"), "循环设计"),
            (("modular", "customiz"), "模块化适配"),
            (("ergonomic", "comfort"), "人体工学"),
            (("ai ", "smart", "robot"), "智能自动化"),
            (("battery", "charging", "wireless"), "能源与连接"),
            (("durable", "rugged", "waterproof"), "耐用性"),
            (("3d print", "3d-print"), "数字制造"),
            (("low-cost", "affordable", "$") , "价格普惠"),
        )
        for terms, label in generic_drivers:
            if any(term in text for term in terms):
                drivers.append(label)
        if not drivers:
            drivers = ["使用体验"]

    if not colors:
        color_rules = (
            (("black", "graphite"), "曜石黑"), (("white", "ivory"), "暖白"),
            (("silver", "aluminum", "aluminium"), "银白"), (("red",), "朱红"),
            (("blue",), "深海蓝"), (("green",), "自然绿"),
            (("orange",), "活力橙"), (("transparent", "see-through"), "透明"),
        )
        for terms, label in color_rules:
            if any(term in text for term in terms):
                colors.append(label)
    if not materials:
        material_rules = (
            (("aluminum", "aluminium"), "铝合金"), (("titanium",), "钛合金"),
            (("steel",), "钢材"), (("wood", "oak", "timber"), "木材"),
            (("cork",), "软木"), (("ceramic", "porcelain"), "陶瓷"),
            (("glass",), "玻璃"), (("plastic", "polymer"), "工程塑料"),
            (("fabric", "textile", "wool"), "织物"), (("leather",), "皮革"),
            (("recycled", "reclaimed"), "再生材料"),
        )
        for terms, label in material_rules:
            if any(term in text for term in terms):
                materials.append(label)
    if not finishes:
        finish_rules = (
            (("matte", "matt"), "哑光"), (("polished", "gloss"), "高光"),
            (("brushed",), "拉丝"), (("anodized", "anodised"), "阳极氧化"),
            (("texture", "woven"), "纹理表面"), (("transparent",), "透明"),
        )
        for terms, label in finish_rules:
            if any(term in text for term in terms):
                finishes.append(label)

    news_type = str(product.get("news_type") or base.get("news_type") or "媒体新稿")
    explicit_status = str(product.get("release_status") or "").lower()
    if explicit_status in {"announced", "preorder", "crowdfunding", "on_sale", "concept"}:
        maturity = explicit_status
    elif "reportedly" in title or "待官方确认" in colors:
        maturity = "needs_review"
    elif "launch" in title or "introduc" in title or "unveil" in title or "官方新品" in news_type:
        maturity = "announced"
    elif "媒体" in news_type:
        maturity = "media_coverage"
    else:
        maturity = "archived"

    source_type = str(product.get("source_type") or "")
    if not source_type:
        official_publishers = {"Samsung", "Sony", "Apple", "Google", "Meta", "Purism", "Nothing"}
        source_type = "official_brand" if source in official_publishers else "design_media"

    base.update({
        "brand": brand,
        "source": source,
        "source_type": source_type,
        "region": str(product.get("region") or _region(brand, title, body)),
        "verification_status": str(product.get("verification_status") or "needs_review"),
        "maturity": maturity,
        "style_keywords": _unique(styles),
        "design_drivers": _unique(drivers),
        "cmf_colors": _unique(colors),
        "cmf_materials": _unique(materials),
        "cmf_finishes": _unique(finishes),
    })
    return base


TREND_CSS = r'''
.portal-panel:has(.trend-dashboard){padding:0;background:transparent;border:0}.trend-dashboard{display:grid;gap:18px}.trend-toolbar{position:sticky;top:86px;z-index:12;background:color-mix(in srgb,var(--bg) 88%,transparent);backdrop-filter:blur(16px);border:1px solid var(--line);border-radius:16px;padding:14px}.trend-toolbar-row{display:flex;gap:9px;flex-wrap:wrap;align-items:center}.trend-periods{display:flex;gap:7px;flex-wrap:wrap;margin-bottom:10px}.trend-control,.trend-period,.trend-action{appearance:none;border:1px solid var(--line);background:var(--surface);color:var(--text);border-radius:999px;padding:9px 12px;font:600 12px/1.2 inherit}.trend-period.active,.trend-action.primary{background:var(--text);color:var(--bg)}.trend-control{min-width:132px}.trend-compare{display:flex;gap:7px;align-items:center;color:var(--muted);font-size:12px}.trend-kpis{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}.trend-kpi,.trend-card{background:var(--surface);border:1px solid var(--line);border-radius:16px;padding:18px}.trend-kpi b{display:block;font-size:30px;letter-spacing:-.05em}.trend-kpi span,.trend-card small{color:var(--muted);font-size:11px}.trend-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px}.trend-card.span-2{grid-column:1/-1}.trend-card h2{margin:0 0 4px;font-size:20px}.trend-card-head{display:flex;justify-content:space-between;gap:12px;align-items:start;margin-bottom:18px}.trend-chart-list{display:grid;gap:9px}.trend-bar{position:relative;display:grid;grid-template-columns:minmax(100px,1fr) 3fr auto;gap:12px;align-items:center;width:100%;border:0;background:transparent;color:var(--text);text-align:left;padding:4px 0;cursor:pointer}.trend-bar-track{height:9px;background:var(--surface-2);border-radius:99px;overflow:hidden}.trend-bar-fill{display:block;height:100%;background:var(--text);border-radius:99px}.trend-delta{font-size:11px;color:var(--muted);min-width:50px;text-align:right}.trend-delta.up{color:#72c998}.trend-delta.down{color:#e98787}.trend-tags{display:flex;gap:8px;flex-wrap:wrap}.trend-tag{border:1px solid var(--line);background:var(--surface-2);color:var(--text);border-radius:999px;padding:8px 11px;cursor:pointer}.trend-tag b{margin-left:6px}.trend-cmf{display:grid;grid-template-columns:1.05fr 1fr 1fr;gap:16px}.trend-swatches{display:flex;flex-wrap:wrap;gap:9px}.trend-swatch{border:1px solid var(--line);background:var(--surface-2);color:var(--text);border-radius:12px;padding:7px 9px;display:flex;align-items:center;gap:7px;cursor:pointer}.trend-swatch i{width:23px;height:23px;border-radius:8px;border:1px solid var(--line)}.trend-funnel{display:flex;min-height:54px;align-items:stretch;border-radius:12px;overflow:hidden}.trend-funnel button{border:0;border-right:1px solid var(--bg);background:var(--surface-2);color:var(--text);min-width:68px;padding:8px;cursor:pointer}.trend-funnel button:last-child{border:0}.trend-note{padding:12px 14px;border:1px dashed var(--line);border-radius:12px;color:var(--muted);font-size:12px}.trend-empty{color:var(--muted);padding:20px 0}.trend-card button:hover{opacity:.72}@media(max-width:900px){.trend-kpis{grid-template-columns:repeat(2,1fr)}.trend-grid{grid-template-columns:1fr}.trend-card.span-2{grid-column:auto}.trend-cmf{grid-template-columns:1fr}.trend-toolbar{top:10px}}@media(max-width:560px){.trend-kpis{grid-template-columns:1fr 1fr}.trend-control{min-width:calc(50% - 6px);max-width:calc(50% - 6px)}.trend-bar{grid-template-columns:100px 1fr auto}}
'''


TREND_JS = r'''
(() => {
const COLOR_HEX={'曜石黑':'#171819','深灰':'#4b4d50','石墨黑':'#343536','纸白':'#e9e5d9','朱红':'#b22d23','自然棕':'#8a5b3f','墨黑':'#1e1b1a','米白':'#ded5c4','钛灰':'#777b7d','银白':'#c6c8c8','活力橙':'#ef6c25','琥珀棕':'#9b5e2e','石墨灰':'#555a5d','透明':'#dce8ea','暖白':'#eee7d8','珊瑚橙':'#ed7658','浅灰':'#b8bab8','鼠尾草绿':'#8fa08b','待官方确认':'#555'};
const MATURITY_LABEL={announced:'已发布',preorder:'预售',crowdfunding:'众筹',on_sale:'已上市',concept:'概念',needs_review:'待核验',media_coverage:'媒体报道',archived:'已入库',unknown:'未知'};
const state={days:7,category:'all',brand:'all',source:'all',region:'all',type:'all',compare:true};
const periods=[[7,'周'],[31,'月'],[183,'半年'],[366,'年度']];
const localKey=d=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
const escTrend=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
function bounds(previous=false){const end=new Date(PORTAL_REPORT_DATE+'T12:00:00');if(previous)end.setDate(end.getDate()-state.days);const start=new Date(end);start.setDate(start.getDate()-state.days+1);return {start,end};}
function common(items){return items.filter(x=>(state.category==='all'||x.category===state.category)&&(state.brand==='all'||x.brand===state.brand)&&(state.source==='all'||x.source===state.source)&&(state.region==='all'||x.region===state.region)&&(state.type==='all'||(state.type==='official'?x.source_type==='official_brand':x.source_type!=='official_brand')));}
function periodData(previous=false){const {start,end}=bounds(previous);return common(PORTAL_PRODUCTS).filter(x=>{const d=new Date(x.added_date+'T12:00:00');return d>=start&&d<=end});}
function counts(items,field){const out={};items.forEach(x=>{const values=Array.isArray(x[field])?x[field]:[x[field]];values.filter(Boolean).forEach(v=>out[v]=(out[v]||0)+1)});return out;}
function entries(cur,prev,limit=10){const keys=new Set([...Object.keys(cur),...Object.keys(prev)]);return [...keys].map(key=>({key,value:cur[key]||0,previous:prev[key]||0,delta:(cur[key]||0)-(prev[key]||0)})).sort((a,b)=>b.value-a.value||b.delta-a.delta).slice(0,limit);}
function option(values,label){return `<option value="all">${label}</option>${[...new Set(values.filter(Boolean))].sort().map(v=>`<option value="${escTrend(v)}">${escTrend(v)}</option>`).join('')}`;}
function deltaText(item){if(!state.compare)return `${item.value}`;const cls=item.delta>0?'up':item.delta<0?'down':'';return `<span class="trend-delta ${cls}">${item.value} · ${item.delta>0?'+':''}${item.delta}</span>`;}
function barList(rows,kind){if(!rows.length)return '<div class="trend-empty">当前筛选范围暂无数据</div>';const max=Math.max(1,...rows.map(x=>x.value));return `<div class="trend-chart-list">${rows.map(x=>`<button class="trend-bar" data-filter-kind="${kind}" data-filter-value="${escTrend(x.key)}"><span>${escTrend(x.key)}</span><span class="trend-bar-track"><i class="trend-bar-fill" style="width:${x.value/max*100}%"></i></span>${deltaText(x)}</button>`).join('')}</div>`;}
function growthList(rows){if(!rows.length)return '<div class="trend-empty">当前筛选范围暂无可比较信号</div>';const max=Math.max(1,...rows.map(x=>Math.max(0,x.delta)));return `<div class="trend-chart-list">${rows.map(x=>`<button class="trend-bar" data-filter-kind="${x.kind}" data-filter-value="${escTrend(x.key)}"><span>${escTrend(x.key)}</span><span class="trend-bar-track"><i class="trend-bar-fill" style="width:${Math.max(4,Math.max(0,x.delta)/max*100)}%"></i></span>${deltaText(x)}</button>`).join('')}</div>`;}
function tags(rows,kind){return `<div class="trend-tags">${rows.map(x=>`<button class="trend-tag" data-filter-kind="${kind}" data-filter-value="${escTrend(x.key)}">${escTrend(x.key)} <b>${x.value}</b>${state.compare?` <small>${x.delta>0?'+':''}${x.delta}</small>`:''}</button>`).join('')}</div>`;}
function swatches(rows){return `<div class="trend-swatches">${rows.map(x=>`<button class="trend-swatch" data-filter-kind="color" data-filter-value="${escTrend(x.key)}"><i style="background:${COLOR_HEX[x.key]||'#777'}"></i><span>${escTrend(x.key)} ${x.value}${state.compare?` · ${x.delta>0?'+':''}${x.delta}`:''}</span></button>`).join('')}</div>`;}
function matchesMetric(x,kind,value){if(kind==='style')return x.style_keywords.includes(value);if(kind==='driver')return x.design_drivers.includes(value);if(kind==='color')return x.cmf_colors.includes(value);if(kind==='material')return x.cmf_materials.includes(value);if(kind==='finish')return x.cmf_finishes.includes(value);if(kind==='brand')return x.brand===value;if(kind==='maturity')return x.maturity===value;if(kind==='category')return x.category===value;return true;}
function linkGallery(kind,value){const active=new Set(periodData(false).filter(x=>matchesMetric(x,kind,value)).map(x=>String(x.id)));document.querySelectorAll('.card').forEach((card,index)=>{const checkbox=card.querySelector('.select input');const id=checkbox?.dataset.id||PORTAL_PRODUCTS[index]?.id||card.dataset.id;card.hidden=!active.has(String(id))});galleryContent.hidden=false;workbench.hidden=true;search.style.display='';document.getElementById('gallery').scrollIntoView({behavior:'smooth',block:'start'});if(typeof showToast==='function')showToast(`${value} · ${active.size} 项`);}
function filteredRows(){return periodData(false);}
function exportCSV(){const items=filteredRows();const cols=['added_date','title','brand','source','region','category','news_type','maturity','style_keywords','design_drivers','cmf_colors','cmf_materials','cmf_finishes'];const quote=v=>'"'+String(Array.isArray(v)?v.join('|'):v??'').replaceAll('"','""')+'"';const csv='\ufeff'+[cols.join(','),...items.map(x=>cols.map(k=>quote(x[k])).join(','))].join('\r\n');const blob=new Blob([csv],{type:'text/csv;charset=utf-8'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`design_trends_${PORTAL_REPORT_DATE}_${state.days}d.csv`;a.click();URL.revokeObjectURL(a.href);}
function exportPNG(){const items=filteredRows(),styles=entries(counts(items,'style_keywords'),{},6),cmf=entries(counts(items,'cmf_materials'),{},6),brands=entries(counts(items,'brand'),{},6);const canvas=document.createElement('canvas');canvas.width=1600;canvas.height=1050;const c=canvas.getContext('2d');c.fillStyle='#090a0a';c.fillRect(0,0,1600,1050);c.fillStyle='#f2f1ec';c.font='700 54px "Microsoft YaHei",sans-serif';c.fillText('工业设计趋势情报',80,100);c.fillStyle='#969994';c.font='24px "Microsoft YaHei",sans-serif';c.fillText(`${PORTAL_REPORT_DATE} · ${state.days} 天 · ${items.length} 项`,80,145);const blocks=[['设计风格',styles],['CMF 材料',cmf],['品牌活跃度',brands]];blocks.forEach((block,bi)=>{const x=80+bi*500;c.fillStyle='#f2f1ec';c.font='700 30px "Microsoft YaHei",sans-serif';c.fillText(block[0],x,235);block[1].forEach((r,i)=>{c.fillStyle='#a5a7a3';c.font='22px "Microsoft YaHei",sans-serif';c.fillText(`${r.key}  ${r.value}`,x,295+i*58);c.fillStyle='#e7e6e1';c.fillRect(x,312+i*58,Math.max(8,r.value/Math.max(1,...block[1].map(v=>v.value))*360),8)})});c.fillStyle='#777';c.font='20px "Microsoft YaHei",sans-serif';c.fillText('由画廊当前筛选结果生成 · 小样本仅代表观察信号',80,990);const a=document.createElement('a');a.href=canvas.toDataURL('image/png');a.download=`design_trends_${PORTAL_REPORT_DATE}_${state.days}d.png`;a.click();}
function bind(){document.querySelectorAll('[data-period]').forEach(b=>b.onclick=()=>{state.days=Number(b.dataset.period);render()});[['trendCategory','category'],['trendBrand','brand'],['trendSource','source'],['trendRegion','region'],['trendType','type']].forEach(([id,key])=>{const el=document.getElementById(id);el.value=state[key];el.onchange=()=>{state[key]=el.value;render()}});const compare=document.getElementById('trendCompare');compare.checked=state.compare;compare.onchange=()=>{state.compare=compare.checked;render()};document.getElementById('trendExportCsv').onclick=exportCSV;document.getElementById('trendExportPng').onclick=exportPNG;document.querySelectorAll('[data-filter-kind]').forEach(b=>b.onclick=()=>linkGallery(b.dataset.filterKind,b.dataset.filterValue));}
function render(){const current=periodData(false),previous=state.compare?periodData(true):[];const styleRows=entries(counts(current,'style_keywords'),counts(previous,'style_keywords'),14);const driverRows=entries(counts(current,'design_drivers'),counts(previous,'design_drivers'),10);const colorRows=entries(counts(current,'cmf_colors'),counts(previous,'cmf_colors'),10);const materialRows=entries(counts(current,'cmf_materials'),counts(previous,'cmf_materials'),8);const finishRows=entries(counts(current,'cmf_finishes'),counts(previous,'cmf_finishes'),8);const brandRows=entries(counts(current,'brand'),counts(previous,'brand'),10);const maturityRows=entries(counts(current,'maturity'),counts(previous,'maturity'),10).map(x=>({...x,label:MATURITY_LABEL[x.key]||x.key}));const growthPool=[...entries(counts(current,'style_keywords'),counts(previous,'style_keywords'),30).map(x=>({...x,kind:'style'})),...entries(counts(current,'category'),counts(previous,'category'),20).map(x=>({...x,kind:'category'})),...entries(counts(current,'cmf_materials'),counts(previous,'cmf_materials'),20).map(x=>({...x,kind:'material'}))].filter(x=>x.value>0).sort((a,b)=>b.delta-a.delta||b.value-a.value).slice(0,12);const official=current.filter(x=>x.source_type==='official_brand').length;const media=current.length-official;title.textContent='设计趋势情报';search.style.display='none';list.innerHTML=`<div class="trend-dashboard"><div class="trend-toolbar"><div class="trend-periods">${periods.map(([d,l])=>`<button class="trend-period ${state.days===d?'active':''}" data-period="${d}">${l}</button>`).join('')}</div><div class="trend-toolbar-row"><select class="trend-control" id="trendCategory">${option(PORTAL_PRODUCTS.map(x=>x.category),'全部品类')}</select><select class="trend-control" id="trendBrand">${option(PORTAL_PRODUCTS.map(x=>x.brand),'全部品牌')}</select><select class="trend-control" id="trendSource">${option(PORTAL_PRODUCTS.map(x=>x.source),'全部来源')}</select><select class="trend-control" id="trendRegion">${option(PORTAL_PRODUCTS.map(x=>x.region),'全部地区')}</select><select class="trend-control" id="trendType"><option value="all">全部资讯</option><option value="official">官方新品</option><option value="media">媒体新稿</option></select><label class="trend-compare"><input type="checkbox" id="trendCompare"> 对比上一周期</label><button class="trend-action" id="trendExportPng">导出 PNG</button><button class="trend-action primary" id="trendExportCsv">导出 CSV</button></div></div><div class="trend-kpis"><div class="trend-kpi"><b>${current.length}</b><span>当前周期产品</span></div><div class="trend-kpi"><b>${state.compare?(current.length-previous.length>=0?'+':'')+(current.length-previous.length):'—'}</b><span>相比上一周期</span></div><div class="trend-kpi"><b>${official}</b><span>官方来源</span></div><div class="trend-kpi"><b>${media}</b><span>媒体来源</span></div></div>${current.length<20?'<div class="trend-note">当前样本少于 20 项，以下结果标记为“设计信号”，不作为长期趋势预测。</div>':''}<div class="trend-grid"><section class="trend-card span-2"><div class="trend-card-head"><div><h2>设计风格关键词</h2><small>点击关键词联动筛选画廊</small></div><small>${styleRows.length} 个信号</small></div>${tags(styleRows,'style')}<div style="height:18px"></div><h3>设计驱动力</h3>${barList(driverRows,'driver')}</section><section class="trend-card span-2"><div class="trend-card-head"><div><h2>CMF 趋势</h2><small>颜色、材料与表面处理</small></div></div><div class="trend-cmf"><div><h3>色彩</h3>${swatches(colorRows)}</div><div><h3>材料</h3>${barList(materialRows,'material')}</div><div><h3>表面处理</h3>${barList(finishRows,'finish')}</div></div></section><section class="trend-card"><div class="trend-card-head"><div><h2>品牌活跃度</h2><small>当前周期报道数量</small></div></div>${barList(brandRows,'brand')}</section><section class="trend-card"><div class="trend-card-head"><div><h2>新品成熟度</h2><small>官方发布与媒体信号分层</small></div></div><div class="trend-funnel">${maturityRows.map(x=>`<button style="flex:${Math.max(1,x.value)}" data-filter-kind="maturity" data-filter-value="${x.key}"><b>${x.value}</b><br><small>${x.label}</small></button>`).join('')}</div></section><section class="trend-card span-2"><div class="trend-card-head"><div><h2>趋势增速榜</h2><small>风格、品类与材料相对上一周期的净变化</small></div></div>${growthList(growthPool)}</section></div></div>`;galleryContent.hidden=true;workbench.hidden=false;bind();}
function decorateMaturityComparison(){
  document.querySelectorAll('.trend-funnel button').forEach(button=>{
    const key=button.dataset.filterValue;
    const small=button.querySelector('small');
    if(!small)return;
    const current=periodData(false).filter(x=>x.maturity===key).length;
    const previous=periodData(true).filter(x=>x.maturity===key).length;
    const delta=current-previous;
    const next=(MATURITY_LABEL[key]||key)+(state.compare?` \u00b7 ${delta>0?'+':''}${delta}`:'');
    if(small.textContent!==next)small.textContent=next;
  });
}
const trendListObserver=new MutationObserver(decorateMaturityComparison);
trendListObserver.observe(list,{childList:true,subtree:true});
window.trendView=render;
window.__trendDashboard={render,state,periodData};
})();
'''
