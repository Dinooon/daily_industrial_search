#!/usr/bin/env python3
"""Backfill a historical month from configured WordPress archives.

The regular collector is optimized for a live daily run.  This companion
collector queries date-bounded WordPress APIs exposed by configured sources,
so older posts do not disappear behind a current homepage or short RSS feed.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date, datetime, timedelta, timezone
import hashlib
import html
import json
from pathlib import Path
import re
import sys
from urllib.parse import urlparse

import requests
from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from pipeline.dedupe import dedupe
from pipeline.source_loader import load_sources
from scripts import agent_daily_pipeline as daily

PHYSICAL_TITLE_TERMS = tuple(dict.fromkeys(daily.TITLE_PRODUCT_TERMS + [
    "powerbank", "power bank", "rangefinder", "faucet", "scissors", "ratchet",
    "ashtray", "vase", "cooler", "container", "cabinet", "shelf", "stool",
    "bench", "bed", "storage", "cooktop", "oven", "fridge", "refrigerator",
    "washing machine", "controller", "console", "microphone", "synth",
    "turntable", "dock", "case", "wallet", "eyewear", "helmet", "shoe",
    "sneaker", "jacket", "faucet", "tap", "range", "collection",
]))
REJECT_TITLE_TERMS = (
    "architecture", "architect", "house", "apartment", "hotel", "restaurant",
    "museum", "pavilion", "installation", "exhibition", "festival", "garden",
    "interior", "workspace", "headquarters", "building", "tower", "resort",
    "landscape", "award", "competition", "roundup", "best of", "guide",
    "interview", "opinion", "student work", "concept", "imagines", "could be",
    "patent", "rumor", "reportedly", "render", "prototype", "housing",
)
LAUNCH_TERMS = (
    "launch", "introduc", "unveil", "debut", "release", "available", "new ",
    "collection", "collaboration", "collab", "redesign", "update",
)
CATEGORY_ZH = {
    "consumer_electronics": "消费电子",
    "furniture_lighting": "家具与照明",
    "transportation": "交通出行",
    "home_appliances": "家用电器",
    "tools_equipment": "工具设备",
    "sustainable_design": "可持续产品",
    "wearable_tech": "可穿戴设备",
    "kitchen_tableware": "厨房餐厨",
    "medical_health": "医疗健康",
    "sports_outdoors": "户外运动",
    "commercial_equipment": "专业设备",
    "other": "实体产品设计",
}
FEATURES = (
    (("3d-print", "3d print"), "采用 3D 打印或增材制造方式塑造结构"),
    (("recycl", "waste", "reclaimed"), "强调再生材料与资源循环"),
    (("aluminum", "aluminium"), "使用铝材兼顾轻量化与结构强度"),
    (("wood", "oak", "ash timber", "cork"), "通过木材或软木呈现自然触感"),
    (("ceramic", "porcelain"), "以陶瓷材料强化器物感与表面质感"),
    (("titanium",), "以钛材提升轻量化与耐用表现"),
    (("fold", "compact", "portable"), "重点处理折叠、便携与收纳效率"),
    (("modular", "customiz"), "通过模块化结构适配不同使用场景"),
    (("electric", "battery"), "围绕电动化、续航与能源效率展开"),
    (("wireless", "charging"), "整合无线连接或充电体验"),
    (("transparent", "see-through"), "以透明结构展示内部构造与工作状态"),
    (("ergonomic", "comfort"), "关注人体工学与长期使用舒适度"),
    (("ai ", "artificial intelligence"), "把智能功能融入日常操作流程"),
)


def strip_markup(value: str) -> str:
    soup = BeautifulSoup(html.unescape(value or ""), "html.parser")
    return re.sub(r"\s+", " ", soup.get_text(" ", strip=True)).strip()


def has_term(text: str, term: str) -> bool:
    return bool(re.search(r"(?<![a-z0-9])" + re.escape(term) + r"(?![a-z0-9])", text))


def category_for(title: str, excerpt: str) -> str:
    item = {"title": title, "description": excerpt, "categories": []}
    return daily.categorize_product(item)


def chinese_summary(title: str, body: str, category: str, publisher: str) -> str:
    text = f"{title} {body}".lower()
    details = [label for terms, label in FEATURES if any(term in text for term in terms)][:2]
    detail = "；".join(details) if details else "重点呈现产品形态、功能配置与实际使用场景"
    focus = re.sub(r"\s+", " ", title).strip()[:88]
    return f"{publisher}的原文聚焦“{focus}”这项{CATEGORY_ZH.get(category, '实体产品设计')}产品；{detail}。具体规格、上市状态与材料信息以原文为准。"


def api_candidates(source: dict) -> list[str]:
    parsed = urlparse(source["url"])
    origin = f"{parsed.scheme}://{parsed.netloc}"
    roots = [origin]
    path = parsed.path.rstrip("/")
    if path:
        roots.append(origin + path)
    return list(dict.fromkeys(root.rstrip("/") + "/wp-json/wp/v2/posts" for root in roots))


def fetch_source(source: dict, start: date, end: date, timeout: float) -> tuple[list[dict], dict]:
    health = {
        "source_id": source["id"], "publisher": source["publisher"],
        "source_type": source["source_type"], "status": "not_wordpress",
        "api_url": "", "pages": 0, "discovered": 0, "accepted": 0, "errors": [],
    }
    headers = {"User-Agent": "IndustrialDesignIntelligence/2.1 (+historical archive audit)"}
    after = f"{start.isoformat()}T00:00:00"
    before = f"{(end + timedelta(days=1)).isoformat()}T00:00:00"
    session = requests.Session()
    posts: list[dict] = []
    endpoint = ""
    total_pages = 1
    for candidate in api_candidates(source):
        try:
            response = session.get(candidate, params={"after": after, "before": before, "per_page": 100, "page": 1, "_embed": 1}, headers=headers, timeout=timeout)
            if response.status_code == 200 and isinstance(response.json(), list):
                endpoint = candidate
                posts.extend(response.json())
                total_pages = min(8, int(response.headers.get("X-WP-TotalPages", "1") or 1))
                health["api_url"] = candidate
                health["status"] = "ok"
                health["pages"] = 1
                break
        except Exception as exc:
            health["errors"].append(str(exc)[:240])
    if not endpoint:
        return [], health
    for page in range(2, total_pages + 1):
        try:
            response = session.get(endpoint, params={"after": after, "before": before, "per_page": 100, "page": page, "_embed": 1}, headers=headers, timeout=timeout)
            if response.status_code != 200:
                break
            posts.extend(response.json())
            health["pages"] += 1
        except Exception as exc:
            health["errors"].append(str(exc)[:240])
            break
    health["discovered"] = len(posts)
    records: list[dict] = []
    for post in posts:
        title = strip_markup((post.get("title") or {}).get("rendered", ""))
        excerpt = strip_markup((post.get("excerpt") or {}).get("rendered", ""))
        body = strip_markup((post.get("content") or {}).get("rendered", ""))[:12000]
        lower_title = title.lower()
        evidence = f"{lower_title} {excerpt.lower()}"
        if not title or any(term in lower_title for term in REJECT_TITLE_TERMS):
            continue
        physical = [term for term in PHYSICAL_TITLE_TERMS if has_term(lower_title, term)]
        if not physical:
            continue
        if source["source_type"] == "official_brand" and not any(term in evidence for term in LAUNCH_TERMS):
            continue
        embedded = post.get("_embedded") or {}
        media = embedded.get("wp:featuredmedia") or []
        image = ""
        if media and isinstance(media[0], dict):
            image = str(media[0].get("source_url") or "")
        if not image:
            match = re.search(r'<img[^>]+src=["\']([^"\']+)', (post.get("content") or {}).get("rendered", ""), re.I)
            image = match.group(1) if match else ""
        if not image:
            continue
        raw_date = str(post.get("date_gmt") or post.get("date") or "")
        try:
            published = datetime.fromisoformat(raw_date.replace("Z", "+00:00"))
            if published.tzinfo is None:
                published = published.replace(tzinfo=timezone.utc)
        except ValueError:
            continue
        local_day = published.date()
        if not (start <= local_day <= end):
            continue
        category = category_for(title, excerpt)
        link = str(post.get("link") or post.get("guid", {}).get("rendered") or "")
        pid = hashlib.sha1(link.encode("utf-8", "ignore")).hexdigest()[:16]
        official = source["source_type"] == "official_brand"
        records.append({
            "product_id": pid,
            "title": title,
            "product_name": title,
            "brand": source.get("brand") or (source["publisher"] if official else ""),
            "publisher": source["publisher"],
            "source": source["publisher"],
            "source_id": source["id"],
            "source_type": source["source_type"],
            "page_url": link,
            "canonical_url": link,
            "image_url": image,
            "published_at": published.isoformat(),
            "published_local_date": local_day.isoformat(),
            "announcement_date": local_day.isoformat() if official else "",
            "first_seen_date": local_day.isoformat(),
            "body_text": body,
            "summary": excerpt,
            "source_summary": excerpt[:500],
            "description_zh": chinese_summary(title, f"{excerpt} {body[:1800]}", category, source["publisher"]),
            "category": category,
            "news_type": "官方新品" if official else "媒体新稿",
            "verification_status": "confirmed" if official else "needs_review",
            "verification_confidence": "high" if official else "medium",
            "release_status": "announced" if official else "media_coverage",
            "content_type": "physical_product",
            "archive_discovery": "wordpress_api",
        })
    health["accepted"] = len(records)
    return records, health


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--start", required=True)
    parser.add_argument("--end", required=True)
    parser.add_argument("--workers", type=int, default=20)
    parser.add_argument("--timeout", type=float, default=12)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()
    start, end = date.fromisoformat(args.start), date.fromisoformat(args.end)
    sources = [s for s in load_sources() if s.get("source_type") in {"official_brand", "design_media"}]
    records: list[dict] = []
    health: list[dict] = []
    with ThreadPoolExecutor(max_workers=max(1, args.workers)) as pool:
        futures = {pool.submit(fetch_source, source, start, end, args.timeout): source for source in sources}
        for future in as_completed(futures):
            try:
                found, status = future.result()
            except Exception as exc:
                source = futures[future]
                found, status = [], {"source_id": source["id"], "publisher": source["publisher"], "source_type": source["source_type"], "status": "failed", "errors": [str(exc)[:300]], "discovered": 0, "accepted": 0}
            records.extend(found)
            health.append(status)
    clean, duplicates = dedupe(records)
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    payload = {"schema_version": "2.1", "period_start": args.start, "period_end": args.end, "market_scope": "global", "products": clean}
    (output / "collected_data.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    (output / "duplicates.json").write_text(json.dumps(duplicates, ensure_ascii=False, indent=2), encoding="utf-8")
    (output / "source_health.json").write_text(json.dumps(sorted(health, key=lambda x: x.get("source_id", "")), ensure_ascii=False, indent=2), encoding="utf-8")
    summary = {
        "configured_product_sources": len(sources),
        "wordpress_sources": sum(1 for row in health if row.get("status") == "ok"),
        "discovered_posts": sum(int(row.get("discovered", 0)) for row in health),
        "accepted_products": len(clean),
        "duplicates": len(duplicates),
    }
    (output / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
