#!/usr/bin/env python3
"""Review a historical month and generate weekly/monthly gallery reports."""
from __future__ import annotations

import argparse
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date, timedelta
from difflib import SequenceMatcher
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

import requests
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from pipeline.dedupe import dedupe
from pipeline.source_loader import load_sources
from scripts.collect_monthly_archives import chinese_summary
from scripts import agent_daily_pipeline as daily

PRODUCT_TERMS = (
    "phone", "smartphone", "tablet", "laptop", "computer", "keyboard", "mouse",
    "monitor", "display", "displays", "camera", "projector", "printer", "speaker", "earbud",
    "headphone", "microphone", "controller", "console", "charger", "charging",
    "power bank", "powerbank", "watch", "smart ring", "glasses", "eyewear",
    "chair", "stool", "sofa", "table", "desk", "furniture", "lamp", "light",
    "shelf", "cabinet", "bed", "rug", "vase", "candle", "mirror", "faucet",
    "car", "vehicle", "ev ", "bike", "bicycle", "scooter", "drone", "robot",
    "shoe", "sneaker", "boot", "backpack", "bag", "tent", "luggage", "case",
    "pen", "pencil", "knife", "tool", "ratchet", "scissors", "rangefinder",
    "bottle", "grill", "bbq", "fridge", "refrigerator", "washer", "dryer",
    "microwave", "range", "vacuum", "purifier", "cooler", "container", "dock",
    "ultrasound", "sonar", "flight deck", "turntable", "synth", "player", "clock",
)
REJECT_TERMS = (
    "architecture", "architect", "apartment", "hotel", "restaurant", "museum",
    "pavilion", "exhibition", "festival", "interior", "headquarters", "building",
    "tower", "resort", "landscape", "garden", "chapel", "cocktail lounge", "cafe",
    "award", "competition", "roundup", "best of", "the outline", "interview",
    "opinion", "student work", "concept", "imagined", "imagines", "could transform",
    "leak", "rumor", "reportedly", "patent", "render", "tiny home", "housing",
    "collection hides easter eggs", "packaging refresh", "earnings", "data center",
    "strategic venture", "code of practice", "grant recipients", "web calling",
    "google earth", "street view", "demand gen", "waze", "sustainable technology easier",
    "ai infrastructure", "motogp", "renewable gasoline", "exit reveals",
)
MANUAL_BRANDS = (
    "Samsung", "Google", "Apple", "Lenovo", "Motorola", "Huawei", "Xiaomi",
    "Sony", "Polaroid", "Kodak", "Bang & Olufsen", "IKEA", "ASUS", "Belkin",
    "DJI", "Garmin", "Philips", "Bosch", "Rimowa", "adidas", "New Balance",
    "Nothing", "CMF", "Nanoleaf", "Leatherman", "MSI", "REDMAGIC", "nubia",
    "Narwal", "BYD", "XPENG", "Polestar", "Tesla", "Honor", "Godox", "Bigme",
    "Dimplex", "Flos", "MB&F", "Moser", "Lomography", "xTool", "Beatbot",
    "Rocco", "Nordic Knots", "Staud", "Kokuyo", "King Jim", "Aulumu",
)


def term(text: str, value: str) -> bool:
    return bool(re.search(r"(?<![a-z0-9])" + re.escape(value) + r"(?![a-z0-9])", text))


def acceptable(item: dict) -> tuple[bool, str]:
    title = str(item.get("title") or "").strip()
    lower = title.lower()
    if not title:
        return False, "标题为空"
    if any(value in lower for value in REJECT_TERMS):
        return False, "非实物产品、传闻、概念或编辑内容"
    if re.match(r"^\s*\d+\s+(best|cordless|essential)", lower) or " best " in f" {lower} ":
        return False, "榜单或合集"
    if not any(term(lower, value) for value in PRODUCT_TERMS):
        return False, "标题未识别为具体实物产品"
    if not str(item.get("page_url") or item.get("canonical_url") or ""):
        return False, "缺少原文链接"
    if not str(item.get("image_url") or item.get("_existing_image") or ""):
        return False, "缺少产品图片"
    raw_date = str(item.get("published_local_date") or item.get("first_seen_date") or item.get("published_at") or "")[:10]
    if not re.match(r"^2026-07-\d{2}$", raw_date):
        return False, "不在 2026 年 7 月"
    return True, ""


def category(item: dict) -> str:
    title = str(item.get("title") or "").lower()
    rules = (
        (("watch", "smart ring", "glasses", "eyewear", "wearable"), "wearable_tech"),
        (("car", "vehicle", "ev ", "bike", "bicycle", "scooter"), "transportation"),
        (("chair", "stool", "sofa", "table", "desk", "furniture", "lamp", "light", "shelf", "cabinet", "bed", "rug", "vase", "candle", "mirror"), "furniture_lighting"),
        (("washer", "dryer", "fridge", "refrigerator", "microwave", "range", "vacuum", "purifier"), "home_appliances"),
        (("ultrasound", "medical"), "medical_health"),
        (("shoe", "sneaker", "boot", "backpack", "tent", "outdoor"), "sports_outdoors"),
        (("bottle", "grill", "bbq", "container", "faucet"), "kitchen_tableware"),
        (("pen", "pencil", "knife", "tool", "ratchet", "scissors", "rangefinder"), "tools_equipment"),
        (("phone", "tablet", "laptop", "computer", "keyboard", "mouse", "monitor", "display", "camera", "projector", "printer", "speaker", "earbud", "headphone", "microphone", "controller", "charger", "power bank", "powerbank", "turntable", "player", "clock"), "consumer_electronics"),
        (("drone", "robot", "sonar", "flight deck"), "commercial_equipment"),
    )
    for words, label in rules:
        if any(term(title, word) for word in words):
            return label
    return "other_product"


def brand(item: dict) -> str:
    if item.get("source_type") == "official_brand":
        return str(item.get("brand") or item.get("publisher") or "官方品牌")
    title = str(item.get("title") or "")
    for name in sorted(MANUAL_BRANDS, key=len, reverse=True):
        if re.search(r"(?<![A-Za-z0-9])" + re.escape(name) + r"(?![A-Za-z0-9])", title, re.I):
            return "CMF by Nothing" if name == "CMF" else name
    match = re.match(r"^([A-Z][A-Za-z0-9&.+-]+(?:\s+[A-Z][A-Za-z0-9&.+-]+){0,2})(?:['’]s|\s+(?:launches|introduces|unveils|built|made|has))", title)
    if match and match.group(1).lower() not in {"this", "the", "someone", "when", "meet", "get ready"}:
        return match.group(1)
    return "独立设计/未标注"


def existing_samsung() -> list[dict]:
    source = ROOT / "output" / "2026-08-05" / "portal_input.json"
    if not source.exists():
        return []
    dates = {
        "Samsung Introduces Flex Titanium Technology To Advance Foldable Displays": "2026-07-15",
        "Samsung Galaxy Watch Ultra2 and Watch9: Your Health Companion on the Wrist": "2026-07-22",
        "Samsung Launches New Bespoke AI Washer and Dryer Lineup With AI-Enhanced Fabric Care and Seamless Connectivity": "2026-07-14",
    }
    result = []
    for item in json.loads(source.read_text(encoding="utf-8")):
        title = str(item.get("title") or "")
        if title not in dates:
            continue
        record = dict(item)
        local = source.parent / str(record.get("local_image_path") or "").replace("/", "\\")
        record.update({
            "published_local_date": dates[title], "first_seen_date": dates[title],
            "announcement_date": dates[title], "published_at": dates[title] + "T00:00:00+00:00",
            "publisher": "Samsung", "source": "Samsung", "brand": "Samsung",
            "source_type": "official_brand", "news_type": "官方新品",
            "verification_status": "confirmed", "verification_confidence": "high",
            "release_status": "announced", "_existing_image": str(local) if local.exists() else "",
        })
        record["canonical_url"] = str(record.get("page_url") or record.get("link") or "")
        result.append(record)
    return result


def normalize(item: dict) -> dict:
    record = dict(item)
    day = str(record.get("published_local_date") or record.get("first_seen_date") or record.get("published_at") or "")[:10]
    cat = category(record)
    record.update({
        "first_seen_date": day,
        "published_local_date": day,
        "category": cat,
        "brand": brand(record),
        "publisher": record.get("publisher") or record.get("source") or "未知来源",
        "source": record.get("publisher") or record.get("source") or "未知来源",
        "news_type": record.get("news_type") or ("官方新品" if record.get("source_type") == "official_brand" else "媒体新稿"),
        "verification_status": record.get("verification_status") or ("confirmed" if record.get("source_type") == "official_brand" else "needs_review"),
        "release_status": record.get("release_status") or ("announced" if record.get("source_type") == "official_brand" else "media_coverage"),
    })
    body = " ".join(str(record.get(key) or "") for key in ("summary", "source_summary", "body_text"))
    record["description_zh"] = chinese_summary(str(record.get("title") or ""), body, cat, str(record["publisher"]))
    return record


def semantic_dedupe(items: list[dict]) -> tuple[list[dict], list[dict]]:
    stop = {"the", "this", "that", "with", "from", "into", "your", "just", "made", "built", "new", "and", "for", "its", "has", "have", "turns", "design", "product"}

    def tokens(item: dict) -> set[str]:
        return {word for word in re.findall(r"[a-z0-9]+", str(item.get("title") or "").lower()) if len(word) > 2 and word not in stop}

    def model_key(item: dict) -> str:
        title = str(item.get("title") or "").lower()
        if "mcdonald" in title and "backpack" in title:
            return "mcdonalds-backpack"
        if "range rover" in title and any(value in title for value in (" gt", "grand tourer")):
            return "range-rover-gt"
        return ""

    kept, duplicate_rows = [], []
    for item in sorted(items, key=lambda row: row.get("source_type") != "official_brand"):
        title = re.sub(r"[^a-z0-9]+", " ", str(item.get("title") or "").lower()).strip()
        current_tokens, current_key = tokens(item), model_key(item)
        match = None
        for old in kept:
            old_title = re.sub(r"[^a-z0-9]+", " ", str(old.get("title") or "").lower()).strip()
            old_tokens = tokens(old)
            overlap = len(current_tokens & old_tokens)
            if current_key and current_key == model_key(old):
                match = old
            elif SequenceMatcher(None, title, old_title).ratio() >= 0.78:
                match = old
            elif overlap >= 4 and overlap / max(1, min(len(current_tokens), len(old_tokens))) >= 0.55:
                match = old
            if match:
                break
        if match:
            duplicate_rows.append({"reason": "cross_source_same_product", "duplicate": item, "kept": match})
        else:
            kept.append(item)
    return kept, duplicate_rows


def stage_image(item: dict, image_dir: Path, timeout: float) -> tuple[dict, str | None]:
    pid = str(item.get("product_id") or hashlib.sha1(str(item.get("page_url") or item.get("title")).encode("utf-8", "ignore")).hexdigest()[:16])
    target = image_dir / f"{pid}.jpg"
    try:
        existing = str(item.get("_existing_image") or "")
        if existing and Path(existing).exists():
            with Image.open(existing) as im:
                image = im.convert("RGB")
        else:
            response = requests.get(str(item.get("image_url")), timeout=timeout, headers={"User-Agent": "Mozilla/5.0"})
            response.raise_for_status()
            from io import BytesIO
            with Image.open(BytesIO(response.content)) as im:
                image = im.convert("RGB")
        if image.width < 400 or image.height < 250:
            return item, "图片尺寸不足"
        image.thumbnail((1800, 1800))
        image.save(target, "JPEG", quality=88, optimize=True)
        if target.stat().st_size < 20_000:
            target.unlink(missing_ok=True)
            return item, "图片文件过小"
        out = dict(item)
        out["product_id"] = pid
        out["local_image_path"] = f"images/{target.name}"
        out["image_sha256"] = hashlib.sha256(target.read_bytes()).hexdigest()
        out["image_verified"] = True
        return out, None
    except Exception as exc:
        target.unlink(missing_ok=True)
        return item, f"图片下载失败：{str(exc)[:160]}"


def build_portal(products: list[dict], target: Path, report_date: str, preview_name: str) -> dict:
    target.mkdir(parents=True, exist_ok=True)
    image_dir = target / "images"
    details_dir = target / "details"
    if image_dir.exists():
        shutil.rmtree(image_dir)
    if details_dir.exists():
        shutil.rmtree(details_dir)
    image_dir.mkdir(exist_ok=True)
    rows = []
    for product in products:
        source_image = MONTHLY_IMAGE_DIR / Path(str(product["local_image_path"])).name
        target_image = image_dir / source_image.name
        if source_image.resolve() != target_image.resolve():
            shutil.copy2(source_image, target_image)
        row = dict(product)
        row["local_image_path"] = f"images/{target_image.name}"
        rows.append(row)
    manifest = target / "gallery_input.json"
    manifest.write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
    subprocess.run([sys.executable, str(ROOT / "scripts" / "build_portal_pages.py"), "--input", str(manifest), "--output-dir", str(target), "--date", report_date], cwd=ROOT, check=True)
    preview = target / preview_name
    daily.generate_portable_preview(target / "design_intelligence_portal.html", image_dir, preview)
    return {"products": len(rows), "portal": str(target / "design_intelligence_portal.html"), "portable_preview": str(preview)}


def natural_weeks(start: date, end: date):
    cursor = start
    while cursor <= end:
        week_end = min(end, cursor + timedelta(days=6 - cursor.weekday()))
        yield cursor, week_end
        cursor = week_end + timedelta(days=1)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--start", required=True)
    parser.add_argument("--end", required=True)
    parser.add_argument("--workers", type=int, default=16)
    parser.add_argument("--timeout", type=float, default=20)
    args = parser.parse_args()
    start, end = date.fromisoformat(args.start), date.fromisoformat(args.end)
    base = ROOT / "data" / args.end
    raw_sources = [
        base / "weekly" / "merged_data.json",
        base / "monthly_backfill" / "collected_data.json",
        base / "monthly_backfill" / "designboom_retry.json",
    ]
    candidates = []
    for path in raw_sources:
        if path.exists():
            payload = json.loads(path.read_text(encoding="utf-8"))
            candidates.extend(payload.get("products", payload if isinstance(payload, list) else []))
    candidates.extend(existing_samsung())
    candidates = [normalize(item) for item in candidates]
    candidates, duplicates = dedupe(candidates)
    reviewed, rejected = [], []
    for item in candidates:
        ok, reason = acceptable(item)
        if ok:
            reviewed.append(item)
        else:
            rejected.append({"title": item.get("title"), "source": item.get("publisher"), "reason": reason})
    reviewed, semantic_duplicates = semantic_dedupe(reviewed)
    duplicates.extend(semantic_duplicates)

    global MONTHLY_IMAGE_DIR
    report_root = ROOT / "output" / args.end / "galleries" / "2026-07"
    monthly_target = report_root / "monthly"
    MONTHLY_IMAGE_DIR = base / "monthly" / "image_cache"
    if MONTHLY_IMAGE_DIR.exists():
        shutil.rmtree(MONTHLY_IMAGE_DIR)
    MONTHLY_IMAGE_DIR.mkdir(parents=True, exist_ok=True)
    staged = []
    with ThreadPoolExecutor(max_workers=max(1, args.workers)) as pool:
        futures = [pool.submit(stage_image, item, MONTHLY_IMAGE_DIR, args.timeout) for item in reviewed]
        for future in as_completed(futures):
            item, error = future.result()
            if error:
                rejected.append({"title": item.get("title"), "source": item.get("publisher"), "reason": error})
            else:
                staged.append(item)
    staged.sort(key=lambda item: (item["first_seen_date"], item.get("source_type") == "official_brand", item.get("title", "")), reverse=True)
    unique, seen_images = [], set()
    for item in staged:
        digest = item["image_sha256"]
        if digest in seen_images:
            (MONTHLY_IMAGE_DIR / Path(item["local_image_path"]).name).unlink(missing_ok=True)
            rejected.append({"title": item.get("title"), "source": item.get("publisher"), "reason": "图片与其他产品重复"})
            continue
        seen_images.add(digest)
        unique.append(item)

    month_data = base / "monthly"
    month_data.mkdir(parents=True, exist_ok=True)
    (month_data / "collected_data.json").write_text(json.dumps({"schema_version": "2.1", "period_start": args.start, "period_end": args.end, "products": unique}, ensure_ascii=False, indent=2), encoding="utf-8")
    (month_data / "duplicates.json").write_text(json.dumps(duplicates, ensure_ascii=False, indent=2), encoding="utf-8")
    (month_data / "rejected.json").write_text(json.dumps(rejected, ensure_ascii=False, indent=2), encoding="utf-8")

    health = []
    for path in (base / "weekly" / "batches").glob("*/source_health.json"):
        rows = json.loads(path.read_text(encoding="utf-8"))
        for row in rows if isinstance(rows, list) else [rows]:
            health.append({**row, "collection_channel": "rss_sitemap_html"})
    archive_health = base / "monthly_backfill" / "source_health.json"
    if archive_health.exists():
        for row in json.loads(archive_health.read_text(encoding="utf-8")):
            health.append({**row, "collection_channel": "wordpress_archive"})
    retry_health = base / "monthly_backfill" / "designboom_retry.json"
    if retry_health.exists():
        retry_payload = json.loads(retry_health.read_text(encoding="utf-8"))
        if retry_payload.get("health"):
            health.append({**retry_payload["health"], "collection_channel": "wordpress_archive_retry"})
    (month_data / "source_health.json").write_text(json.dumps(health, ensure_ascii=False, indent=2), encoding="utf-8")

    month_report = build_portal(unique, monthly_target, args.end, "2026-07_工业设计月报_预览版.html")
    trend_redirect = monthly_target / "2026-07_月度趋势报告.html"
    trend_redirect.write_text('<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="0;url=design_intelligence_portal.html?period=month#trends"><title>2026年7月工业设计趋势报告</title><a href="design_intelligence_portal.html?period=month#trends">打开月度趋势报告</a>', encoding="utf-8")

    weekly_reports = []
    for index, (week_start, week_end) in enumerate(natural_weeks(start, end), 1):
        rows = [item for item in unique if week_start.isoformat() <= item["first_seen_date"] <= week_end.isoformat()]
        target = report_root / f"week_{index:02d}_{week_start.isoformat()}_{week_end.isoformat()}"
        result = build_portal(rows, target, week_end.isoformat(), f"{week_start.isoformat()}_{week_end.isoformat()}_工业设计周报_预览版.html")
        result.update({"week": index, "start": week_start.isoformat(), "end": week_end.isoformat()})
        weekly_reports.append(result)

    by_week = {f"{row['start']}_{row['end']}": row["products"] for row in weekly_reports}
    summary = {
        "market_scope": "global", "timezone": "Asia/Shanghai",
        "period_start": args.start, "period_end": args.end,
        "accepted_products": len(unique), "rejected_candidates": len(rejected),
        "duplicates": len(duplicates), "sources_with_products": len({item["publisher"] for item in unique}),
        "official_products": sum(item.get("source_type") == "official_brand" for item in unique),
        "media_products": sum(item.get("source_type") != "official_brand" for item in unique),
        "by_week": by_week,
        "by_category": dict(Counter(item["category"] for item in unique).most_common()),
        "by_source": dict(Counter(item["publisher"] for item in unique).most_common()),
        "month_report": month_report,
        "trend_report": str(trend_redirect),
        "weekly_reports": weekly_reports,
        "source_health_entries": len(health),
    }
    (month_data / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    (report_root / "report_index.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
