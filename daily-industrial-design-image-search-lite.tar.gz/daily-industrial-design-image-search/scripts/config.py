"""Runtime configuration for Daily Industrial Design Intelligence.

No machine-specific absolute paths are allowed. All paths are resolved from the
package root or supplied through CLI/environment variables.
"""
from __future__ import annotations
import os
from pathlib import Path
from datetime import datetime

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = Path(os.getenv("DID_DATA_DIR", PACKAGE_ROOT / "data")).resolve()
OUTPUT_DIR = Path(os.getenv("DID_OUTPUT_DIR", PACKAGE_ROOT / "output")).resolve()
CACHE_DIR = Path(os.getenv("DID_CACHE_DIR", PACKAGE_ROOT / ".cache")).resolve()
SOURCE_CONFIG_PATH = Path(os.getenv("DID_SOURCE_CONFIG", PACKAGE_ROOT / "config" / "sources.json")).resolve()
HISTORY_DB_PATH = Path(os.getenv("DID_HISTORY_DB", DATA_DIR / "history" / "products.json")).resolve()
SOURCE_STATE_PATH = Path(os.getenv("DID_SOURCE_STATE", DATA_DIR / "state" / "source_state.json")).resolve()
TODAY = datetime.now().astimezone().date().isoformat()
DEFAULT_MAX_AGE_DAYS = int(os.getenv("DID_MAX_AGE_DAYS", "14"))
DEFAULT_TIMEOUT = float(os.getenv("DID_HTTP_TIMEOUT", "25"))
DAILY_SOURCE_BUDGET = int(os.getenv("DID_DAILY_SOURCE_BUDGET", "40"))
DAILY_DETAIL_BUDGET = int(os.getenv("DID_DAILY_DETAIL_BUDGET", "60"))
MIN_DAILY_PRODUCTS = int(os.getenv("DID_MIN_DAILY_PRODUCTS", "24"))
MAX_DAILY_PRODUCTS = int(os.getenv("DID_MAX_DAILY_PRODUCTS", "40"))
USER_AGENT = os.getenv("DID_USER_AGENT", "DailyIndustrialDesignIntelligence/2.1 (+internal-research)")

CATEGORIES = {
    "consumer_electronics": "消费电子", "furniture_lighting": "家具照明",
    "transportation": "交通工具", "home_appliances": "家用电器",
    "tools_equipment": "工具设备", "sustainable_design": "可持续设计",
    "wearable_tech": "可穿戴设备", "kitchen_tableware": "厨房餐厨",
    "medical_health": "医疗健康", "sports_outdoors": "户外运动",
    "commercial_equipment": "工业设备", "other": "其他"
}

PROTECTED_HUMAN_FIELDS = {"review_status", "is_retained", "internal_notes", "owner", "human_category", "human_tags"}
