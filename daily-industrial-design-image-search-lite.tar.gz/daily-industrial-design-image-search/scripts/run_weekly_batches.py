#!/usr/bin/env python3
"""Collect a China-timezone weekly slice from all configured source tiers."""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date, datetime, timedelta
import json
import os
from pathlib import Path
import re
import sys
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from pipeline.dedupe import dedupe
from pipeline.run import run_pipeline
from scripts.run_tiered_batches import TIERS, source_queue, write_source_config

TZ = ZoneInfo("Asia/Shanghai")
LAUNCH_SIGNALS = (
    "launch", "unveil", "introduc", "announce", "debut", "release",
    "preorder", "pre-order", "on sale", "available now",
)


def local_date(item: dict) -> date | None:
    raw = str(item.get("published_at") or "").strip()
    if not raw:
        return None
    try:
        moment = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        if moment.tzinfo is None:
            return moment.date()
        return moment.astimezone(TZ).date()
    except ValueError:
        try:
            return date.fromisoformat(raw[:10])
        except ValueError:
            return None


def in_window(item: dict, start: date, end: date) -> bool:
    published = local_date(item)
    return bool(published and start <= published <= end)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--end", required=True)
    parser.add_argument("--start")
    parser.add_argument("--workers", type=int, default=16)
    parser.add_argument("--timeout", type=float, default=3.5)
    parser.add_argument("--attempts", type=int, default=1)
    parser.add_argument("--max-items", type=int, default=6)
    parser.add_argument("--reset", action="store_true")
    args = parser.parse_args()

    end_day = date.fromisoformat(args.end)
    start_day = date.fromisoformat(args.start) if args.start else end_day - timedelta(days=end_day.weekday())
    run_dir = ROOT / "data" / args.end / "weekly"
    batch_dir = run_dir / "batches"
    batch_dir.mkdir(parents=True, exist_ok=True)
    progress_path = run_dir / "progress.json"
    progress = {"completed_indexes": [], "failed": []}
    if progress_path.exists() and not args.reset:
        progress.update(json.loads(progress_path.read_text(encoding="utf-8")))
    if args.reset:
        progress = {"completed_indexes": [], "failed": []}

    queue = source_queue(detail_budget=args.max_items, candidate_budget=36)
    completed = {int(x) for x in progress.get("completed_indexes", [])}
    indexes = [i for i in range(len(queue)) if i not in completed]
    os.environ["DID_HTTP_TIMEOUT"] = str(args.timeout)
    os.environ["DID_HTTP_ATTEMPTS"] = str(args.attempts)

    def collect(index: int) -> dict:
        tier_id, tier_label, source = queue[index]
        source = dict(source)
        # Historical weekly/monthly backfills must not inherit the normal
        # fourteen-day freshness gate.  Keep the source's stricter value for
        # live runs, but widen it just enough to cover the requested window.
        history_days = max(1, (date.today() - start_day).days + 2)
        source["max_age_days"] = max(int(source.get("max_age_days", 14)), history_days)
        safe_id = re.sub(r"[^A-Za-z0-9._-]+", "-", source["id"])
        target = batch_dir / f"{index:04d}_{tier_id}_{safe_id}"
        target.mkdir(parents=True, exist_ok=True)
        config = target / "source.json"
        write_source_config(config, source)
        try:
            payload = run_pipeline(
                target,
                config,
                max_sources=1,
                max_items_per_source=args.max_items,
                force=True,
                state_path=target / "state.json",
            )
            products = []
            for record in payload.get("products", []):
                if not in_window(record, start_day, end_day):
                    continue
                item = dict(record)
                published = local_date(item)
                evidence = " ".join(str(item.get(k) or "") for k in ("title", "summary", "body_text")).lower()
                official = source.get("source_type") == "official_brand"
                has_launch_signal = any(signal in evidence for signal in LAUNCH_SIGNALS)
                item.update({
                    "published_local_date": published.isoformat() if published else "",
                    "first_seen_date": published.isoformat() if published else args.end,
                    "collection_tier": tier_id,
                    "collection_tier_label": tier_label,
                    "verification_status": "confirmed" if official and has_launch_signal else "needs_review",
                    "verification_confidence": "high" if official and has_launch_signal else "medium",
                    "news_type": "官方新品" if official and has_launch_signal else "媒体新稿",
                    "release_status": "announced" if has_launch_signal else "unknown",
                })
                products.append(item)
            (target / "weekly_products.json").write_text(
                json.dumps(products, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            return {"ok": True, "index": index, "products": len(products)}
        except Exception as exc:
            return {"ok": False, "index": index, "error": str(exc)[:500]}

    if indexes:
        with ThreadPoolExecutor(max_workers=max(1, args.workers)) as executor:
            futures = [executor.submit(collect, index) for index in indexes]
            for future in as_completed(futures):
                result = future.result()
                if result["ok"]:
                    completed.add(result["index"])
                else:
                    progress.setdefault("failed", []).append(result)
                progress["completed_indexes"] = sorted(completed)
                progress["total_sources"] = len(queue)
                progress_path.write_text(json.dumps(progress, ensure_ascii=False, indent=2), encoding="utf-8")

    merged = []
    for path in batch_dir.glob("*/weekly_products.json"):
        merged.extend(json.loads(path.read_text(encoding="utf-8")))
    clean, duplicates = dedupe(merged)
    counts = {"官方新品": 0, "媒体新稿": 0}
    for item in clean:
        counts[item.get("news_type", "媒体新稿")] = counts.get(item.get("news_type", "媒体新稿"), 0) + 1
    payload = {
        "schema_version": "2.1",
        "market_scope": "global",
        "timezone": "Asia/Shanghai",
        "week_start": start_day.isoformat(),
        "week_end": end_day.isoformat(),
        "products": clean,
    }
    (run_dir / "merged_data.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    (run_dir / "duplicates.json").write_text(json.dumps(duplicates, ensure_ascii=False, indent=2), encoding="utf-8")
    summary = {
        "week_start": start_day.isoformat(),
        "week_end": end_day.isoformat(),
        "processed_entries": len(completed),
        "total_entries": len(queue),
        "candidates": len(clean),
        "official_launches": counts.get("官方新品", 0),
        "media_posts": counts.get("媒体新稿", 0),
        "duplicates": len(duplicates),
        "complete": len(completed) == len(queue),
    }
    (run_dir / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
