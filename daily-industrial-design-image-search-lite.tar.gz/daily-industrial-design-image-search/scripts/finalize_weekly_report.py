#!/usr/bin/env python3
"""Review weekly candidates, stage images, and build a weekly gallery."""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import date, timedelta
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts import agent_daily_pipeline as daily

PHYSICAL = (
    "display", "furniture", "chair", "sofa", "table", "lamp", "light", "phone", "watch",
    "speaker", "camera", "appliance", "tool", "device", "projector", "headphone", "earbud",
    "bike", "bicycle", "vehicle", "robot", "bottle", "laptop", "computer", "keyboard",
    "jacket", "clothing", "wearable", "washer", "dryer", "skincare", "dispenser", "synth",
)
REJECT = (
    "architecture", "architectural", "apartment", "building", "exhibition", "museum", "artwork",
    "festival", "competition", "award", "roundup", "guide", "job", "plugin",
)
NON_PRODUCT_HEADLINE = (
    "google wallet", "ask maps", "whatsapp", "group chats", "employee roi", "design director",
    "degree show", "round-up", "press roundup", "everything you need to know",
)
CONCEPT_REJECT = ("conceptual garment", "not selling these", "not a product pitch")


def identity(item: dict) -> tuple[str, str]:
    url = str(item.get("page_url") or item.get("canonical_url") or item.get("url") or "")
    url = url.split("?", 1)[0].rstrip("/").lower()
    title = "".join(ch.lower() for ch in str(item.get("title") or "") if ch.isalnum())
    return url, title


def weekly_category(item: dict) -> str:
    title = str(item.get("title") or "").lower()
    if any(term in title for term in ("watch", "wearable")):
        return "wearable_tech"
    if any(term in title for term in ("washer", "dryer", "appliance")):
        return "home_appliances"
    if any(term in title for term in ("chair", "furniture", "sofa", "table", "domestic objects", "craft collection")):
        return "furniture_lighting"
    if any(term in title for term in ("skincare", "medical", "healthcare")):
        return "healthcare_product"
    if any(term in title for term in ("display", "phone", "laptop", "kindle", "camera", "speaker", "earbud", "writing device")):
        return "consumer_electronics"
    return "other_product"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--end", required=True)
    args = parser.parse_args()
    end_day = date.fromisoformat(args.end)
    start_day = end_day - timedelta(days=end_day.weekday())
    source = ROOT / "data" / args.end / "weekly" / "merged_data.json"
    raw = json.loads(source.read_text(encoding="utf-8"))
    target = ROOT / "output" / args.end / "galleries" / "current_week"
    image_dir = target / "images"
    image_dir.mkdir(parents=True, exist_ok=True)

    products: list[dict] = []
    seen_urls: set[str] = set()
    seen_titles: set[str] = set()
    seen_images: set[str] = set()
    rejected: list[dict] = []

    def add_product(item: dict, source_image: Path | None = None) -> None:
        url_key, title_key = identity(item)
        if (url_key and url_key in seen_urls) or (title_key and title_key in seen_titles):
            return
        pid = str(item.get("product_id") or hashlib.sha1((url_key or title_key).encode()).hexdigest()[:16]).replace("prod_", "")
        staged = image_dir / f"{pid}{source_image.suffix.lower() if source_image else '.jpg'}"
        if source_image:
            if not source_image.exists():
                return
            shutil.copy2(source_image, staged)
        else:
            image_url = str(item.get("image_url") or "")
            if not image_url or not daily.download_image(image_url, staged):
                return
        if not daily.verify_image(staged):
            return
        digest = hashlib.sha256(staged.read_bytes()).hexdigest()
        if digest in seen_images:
            staged.unlink(missing_ok=True)
            return
        seen_images.add(digest)
        if url_key:
            seen_urls.add(url_key)
        if title_key:
            seen_titles.add(title_key)
        record = dict(item)
        record.update({
            "product_id": pid,
            "local_image_path": f"images/{staged.name}",
            "image_sha256": digest,
            "image_verified": True,
            "first_seen_date": str(item.get("published_local_date") or item.get("first_seen_date") or args.end)[:10],
            "publisher": item.get("publisher") or item.get("source") or "",
            "page_url": item.get("page_url") or item.get("canonical_url") or item.get("url") or "",
            "category": weekly_category(item),
        })
        products.append(record)

    # Preserve already reviewed daily products from this week.
    for offset in range((end_day - start_day).days + 1):
        run_day = start_day + timedelta(days=offset)
        manifest = ROOT / "output" / run_day.isoformat() / "portal_input.json"
        if not manifest.exists():
            continue
        for item in json.loads(manifest.read_text(encoding="utf-8")):
            copy = dict(item)
            title = str(copy.get("title") or "").lower()
            evidence = " ".join(str(copy.get(k) or "") for k in ("title", "summary", "body_text")).lower()
            if any(term in title for term in REJECT) or "concept" in title or any(term in evidence for term in CONCEPT_REJECT):
                rejected.append({"title": copy.get("title"), "reason": "历史卡片不符合本周实体产品范围"})
                continue
            copy["first_seen_date"] = run_day.isoformat()
            copy["published_local_date"] = run_day.isoformat()
            copy["news_type"] = copy.get("news_type") or "已入库资讯"
            local_path = manifest.parent / str(copy.get("local_image_path") or "").replace("/", os.sep)
            add_product(copy, local_path)

    # Add newly collected weekly media/official candidates after scope review.
    for item in raw.get("products", []):
        title = str(item.get("title") or "").lower()
        evidence = " ".join(str(item.get(k) or "") for k in ("title", "summary", "body_text")).lower()
        if any(term in title for term in REJECT):
            rejected.append({"title": item.get("title"), "reason": "非产品资讯"})
            continue
        if any(term in title for term in NON_PRODUCT_HEADLINE):
            rejected.append({"title": item.get("title"), "reason": "软件服务、人物或综述内容"})
            continue
        if "software" in title and not any(term in title for term in PHYSICAL):
            rejected.append({"title": item.get("title"), "reason": "软件内容"})
            continue
        if any(term in evidence for term in CONCEPT_REJECT) or ("concept" in title and "launch" not in title):
            rejected.append({"title": item.get("title"), "reason": "概念或不可售作品"})
            continue
        if not any(term in evidence[:2400] for term in PHYSICAL):
            rejected.append({"title": item.get("title"), "reason": "未识别为具体实物产品"})
            continue
        add_product(item)

    products.sort(key=lambda item: (str(item.get("first_seen_date") or ""), item.get("verification_status") == "confirmed"), reverse=True)
    manifest = target / "gallery_input.json"
    manifest.write_text(json.dumps(products, ensure_ascii=False, indent=2), encoding="utf-8")
    subprocess.run([
        sys.executable, str(ROOT / "scripts" / "build_portal_pages.py"),
        "--input", str(manifest), "--output-dir", str(target), "--date", args.end,
    ], cwd=ROOT, check=True)
    preview = target / f"{start_day.isoformat()}_{args.end}_工业设计周报_预览版.html"
    daily.generate_portable_preview(target / "design_intelligence_portal.html", image_dir, preview)

    by_day = Counter(str(item.get("first_seen_date") or "")[:10] for item in products)
    by_category = Counter(str(item.get("category") or "其他") for item in products)
    by_type = Counter(str(item.get("news_type") or "媒体新稿") for item in products)
    summary = {
        "market_scope": "global",
        "timezone": "Asia/Shanghai",
        "week_start": start_day.isoformat(),
        "week_end": args.end,
        "products": len(products),
        "by_day": dict(sorted(by_day.items())),
        "by_category": dict(by_category.most_common()),
        "by_type": dict(by_type.most_common()),
        "rejected": rejected,
        "gallery": str(target / "design_intelligence_portal.html"),
        "portable_preview": str(preview),
    }
    (target / "weekly_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
