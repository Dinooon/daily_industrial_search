#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))
from pipeline.release_gate import require_healthy_priority_sources, require_minimum_products
from scripts.config import MIN_DAILY_PRODUCTS
def run(cmd):subprocess.run([sys.executable,*cmd],cwd=ROOT,check=True)
def main():
 p=argparse.ArgumentParser();p.add_argument('--date',required=True);p.add_argument('--publish',action='store_true');p.add_argument('--acquisition-mode',choices=['auto','native_http','agent_assisted','offline'],default='auto');p.add_argument('--agent-manifest');p.add_argument('--offline-products');a=p.parse_args()
 mode=a.acquisition_mode
 cap=ROOT/f'data/{a.date}/network_capability.json';cap.parent.mkdir(parents=True,exist_ok=True)
 if mode=='auto':
  run(['scripts/detect_network_capability.py','--output',str(cap)])
  mode=json.loads(cap.read_text())['recommended_mode']
 if mode=='native_http':
  run(['scripts/run_daily_pipeline.py','--date',a.date]);raw=f'data/{a.date}/collected_data.json'
  health_path=ROOT/f'data/{a.date}/source_health.json'
  require_healthy_priority_sources(json.loads(health_path.read_text(encoding='utf-8')))
  source=f'data/{a.date}/materialized_data.json';run(['scripts/materialize_product_images.py','--input',raw,'--output',source,'--images-dir',f'output/{a.date}/source_images'])
 elif mode=='agent_assisted':
  if not a.agent_manifest:raise SystemExit('--agent-manifest is required when native HTTP is unavailable. Do not fabricate products or images.')
  run(['scripts/validate_tool_manifest.py',a.agent_manifest]);source=f'data/{a.date}/agent_collected_data.json';run(['scripts/import_agent_acquisition.py','--manifest',a.agent_manifest,'--output',source])
 elif mode=='offline':
  if not a.offline_products:raise SystemExit('--offline-products is required for offline mode')
  source=a.offline_products
 else:raise SystemExit(f'unsupported mode: {mode}')
 verified=f'data/{a.date}/image_verified_data.json'
 run(['scripts/validate_product_images.py','--products',source,'--output',verified,'--review-queue',f'data/{a.date}/image_review_queue.json'])
 verified_payload=json.loads((ROOT/verified).read_text(encoding='utf-8'))
 require_minimum_products(verified_payload.get('products', []), MIN_DAILY_PRODUCTS)
 publishable=f'data/{a.date}/gallery_input.json';run(['scripts/build_verified_gallery_input.py','--input',verified,'--output',publishable])
 run(['scripts/analyze_products.py','--input',publishable])
 staged=f'output/{a.date}/gallery_input.json';run(['scripts/stage_verified_images.py','--input',publishable,'--output',staged,'--images-dir',f'output/{a.date}/images'])
 canonical=f'output/{a.date}/gallery_canonical_source.html';run(['scripts/generate_html.py','--manifest',staged,'--output',canonical,'--local']);run(['scripts/validate_generated_html.py','--html',canonical,'--kind','gallery'])
 run(['scripts/build_gallery_hierarchy.py','--root','output','--date',a.date])
 run(['scripts/create_dynamic_portal.py'])
 out=f'output/{a.date}/design_intelligence_portal.html';run(['scripts/validate_generated_html.py','--html',out,'--kind','portal'])
 preview=f'output/{a.date}/{a.date}_设计情报工作台_预览版.html';run(['scripts/build_portable_preview.py','--input',out,'--images-root',f'output/{a.date}','--output',preview,'--max-width','1100','--quality','72','--max-total-mb','15']);run(['scripts/validate_generated_html.py','--html',preview,'--max-mb','20','--kind','portal'])
 download_manifest=f'output/{a.date}/download_manifest.json';run(['scripts/build_download_manifest.py','--date',a.date,'--html',out,'--portable-preview',preview,'--images-dir',f'output/{a.date}/images','--details-dir',f'output/{a.date}/details','--output',download_manifest])
 if a.publish:
  internal=[publishable,f'data/{a.date}/image_review_queue.json',f'data/{a.date}/source_health.json',str(cap)]
  existing=[x for x in internal if (ROOT/x).is_file()]
  compat=[f'output/{a.date}/daily_gallery.html',f'output/{a.date}/explore.html',f'output/{a.date}/compare.html',f'output/{a.date}/board.html',f'output/{a.date}/topics.html',f'output/{a.date}/trends.html']
  cmd=['scripts/publish_to_feishu.py','--products',publishable,'--date',a.date,'--html',out,'--portable-preview',preview,'--images',f'output/{a.date}/images','--detail-pages',f'output/{a.date}/details','--portal-pages',*compat,'--download-manifest',download_manifest]
  if existing:cmd+=['--internal-artifacts',*existing]
  run(cmd)
 print(json.dumps({'date':a.date,'acquisition_mode':mode,'gallery':out,'preview':preview,'download_manifest':download_manifest},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
