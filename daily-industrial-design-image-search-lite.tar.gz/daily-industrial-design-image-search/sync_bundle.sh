#!/bin/bash
set -e
# 同步所有文件到 .manus/bundle/（跟随符号链接，确保实体文件）
SRC=/home/ubuntu/workdir/daily-industrial-design-image-search
BUNDLE=$SRC/.manus/bundle
PUBLISH=/home/ubuntu/app/projects/f37290c91f5b44a0

echo "=== 1. 同步到 .manus/bundle/ ==="
# 清理旧文件（保留Dockerfile和.manus/）
rm -rf $BUNDLE/backend $BUNDLE/frontend $BUNDLE/run.py $BUNDLE/start.sh $BUNDLE/manifest.json
# 创建目录结构
mkdir -p $BUNDLE/backend/app $BUNDLE/backend/scripts $BUNDLE/backend/config $BUNDLE/backend/templates $BUNDLE/backend/db $BUNDLE/backend/output $BUNDLE/frontend/dist
# 用cp -L复制实体文件（跟随符号链接）
cp -L $SRC/main.py $BUNDLE/backend/main.py
cp -L $SRC/app/routes.py $BUNDLE/backend/app/routes.py
cp -L $SRC/app/database.py $BUNDLE/backend/app/database.py
cp -L $SRC/app/scheduler.py $BUNDLE/backend/app/scheduler.py
cp -L $SRC/app/__init__.py $BUNDLE/backend/app/__init__.py
cp -rL $SRC/scripts/* $BUNDLE/backend/scripts/
cp -rL $SRC/config/* $BUNDLE/backend/config/
cp -rL $SRC/templates/* $BUNDLE/backend/templates/
cp -L $SRC/db/gallery.db $BUNDLE/backend/db/gallery.db
cp -rL $SRC/output/ $BUNDLE/backend/output/
cp -L $SRC/run.py $BUNDLE/run.py
cp -L $SRC/start.sh $BUNDLE/backend/start.sh
cp -L $SRC/frontend/dist/index.html $BUNDLE/frontend/dist/index.html
# requirements
cp -L $SRC/requirements_app.txt $BUNDLE/backend/requirements_app.txt 2>/dev/null || true
cp -L $SRC/requirements_runtime.txt $BUNDLE/backend/requirements_runtime.txt 2>/dev/null || true
cat $SRC/requirements_app.txt $SRC/requirements_runtime.txt > $BUNDLE/backend/requirements.txt 2>/dev/null || true

echo "=== 2. 同步到发布目录 ==="
rm -rf $PUBLISH/backend $PUBLISH/.manus/bundle $PUBLISH/frontend
mkdir -p $PUBLISH/.manus/bundle $PUBLISH/frontend/dist $PUBLISH/backend
cp -rL $BUNDLE/ $PUBLISH/.manus/bundle/
cp -rL $BUNDLE/backend/ $PUBLISH/backend/

echo "=== 3. 验证无符号链接 ==="
LINKS=$(find $BUNDLE -type l 2>/dev/null | wc -l)
if [ "$LINKS" -gt 0 ]; then
    echo "WARNING: Found $LINKS symlinks in bundle:"
    find $BUNDLE -type l
    exit 1
fi

echo "=== 4. 验证关键文件 ==="
for f in backend/main.py backend/app/routes.py backend/app/database.py backend/app/scheduler.py backend/scripts/agent_daily_pipeline.py backend/db/gallery.db run.py frontend/dist/index.html; do
    if [ -f "$BUNDLE/$f" ]; then
        SIZE=$(stat -c%s "$BUNDLE/$f" 2>/dev/null || stat -f%z "$BUNDLE/$f" 2>/dev/null)
        echo "  OK: $f ($SIZE bytes)"
    else
        echo "  MISSING: $f"
        exit 1
    fi
done

JPG_COUNT=$(find $BUNDLE/backend/output/ -name "*.jpg" 2>/dev/null | wc -l)
echo "  JPG count: $JPG_COUNT"
if [ "$JPG_COUNT" -lt 100 ]; then
    echo "  WARNING: Less than 100 jpg files!"
fi

echo "=== 5. 验证Dockerfile COPY源 ==="
# 检查Dockerfile中所有COPY指令的源文件是否存在
if [ -f "$BUNDLE/Dockerfile" ]; then
    grep "^COPY" $BUNDLE/Dockerfile | while read line; do
        SRC_PATH=$(echo $line | awk '{print $2}' | sed 's:/$::')
        if [ -e "$BUNDLE/$SRC_PATH" ]; then
            echo "  COPY OK: $SRC_PATH"
        else
            echo "  COPY MISSING: $SRC_PATH"
        fi
    done
fi

echo ""
echo "=== Sync complete! ==="
echo "Bundle: $BUNDLE"
echo "Publish: $PUBLISH"

