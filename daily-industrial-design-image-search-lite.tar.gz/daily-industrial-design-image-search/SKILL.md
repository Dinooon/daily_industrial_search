---
name: daily-industrial-design-intelligence-gallery
description: End-to-end industrial-design intelligence workflow with lightweight source monitoring, evidence-based product analysis, Editorial Gallery generation, and Feishu publishing.
---

# Daily Industrial Design Intelligence Gallery 3.1

This skill performs discovery, validation, analysis, gallery generation and Feishu publishing. It must use the supplied source catalog, scheduler, state store, scoring rules and canonical templates. It must not invent products, bypass quality gates, recursively upload run directories, or use email newsletters as a source.

## Mandatory workflow

1. Import the newest selection manifest and preserve protected human fields.
2. Load the machine-readable catalog from `config/source_catalog.json`.
3. Select only sources due for checking according to priority, frequency and saved source state.
4. Respect the global source and detail-page budgets.
5. Discover candidates in this order: RSS/Atom, Sitemap, then HTML entrance page.
6. Reuse ETag, Last-Modified, response cache and entrance-page content hashes.
7. Score candidates from title, URL, summary, date and source trust before fetching details.
8. Fetch details only for candidates above the configured threshold and within the source detail budget.
9. Extract canonical URL, JSON-LD, OpenGraph, title, image, body, brand and dates.
10. Reject non-product editorial, corporate news, applications, submissions and stale content.
11. Prefer official brand pages as evidence when the same product is reported by multiple sources.
12. Deduplicate and assign stable product IDs.
13. Produce structured analysis with verified facts, design observations and evidence.
14. Generate the canonical Editorial Gallery and portable Feishu preview.
15. Publish only files permitted by the Feishu manifest and upsert Bitable records.

## Prohibited source method

Email newsletters and mailbox ingestion are explicitly disabled. Do not subscribe, read email, or create mailbox-based discovery. The allowed discovery methods are:

- RSS / Atom
- Sitemap and `lastmod`
- Conditional HTTP requests with ETag / Last-Modified
- Lightweight HTML entrance-page discovery
- Explicit official product/news URLs

## Lightweight monitoring policy

The catalog contains more than 200 sites from the provided industrial-design source list. This does not mean all sites are deeply crawled every day.

Default limits:

```text
Daily source budget: 40 sources
Daily detail-page budget: 60 pages
```

Default frequencies:

- Core design media: daily
- Official brands: every two days
- Awards, studios, materials and manufacturing: weekly
- Events: weekly outside active-event configurations; event-window sources may be promoted separately

Each source controls:

```text
check_frequency
candidate_budget
detail_fetch_budget
candidate_score_threshold
max_age_days
trust_level
```

The state file `data/state/source_state.json` stores last check time, last success, entrance hash and recent counts. Sources are rotated by due state and priority, preventing the first run from performing unlimited detail crawling.

## Product-description provenance

HTML product descriptions are not written by the HTML generator. They come from `pipeline/analyze.py`.

Model mode outputs:

- verified facts
- design observations
- field-level evidence
- a 60–120 Chinese-character description

The model must not invent materials, dimensions, availability or release facts. In fallback mode, `pipeline/description.py` selects evidence-bearing sentences from the body instead of copying the first paragraph. Fallback output is marked `analysis_mode=heuristic_evidence`.

HTML uses `ai_analysis.description` or `ai_analysis.features`. The two values are kept identical for compatibility.

## Commands

```bash
python -m pip install -r requirements.txt
python scripts/run_full_workflow.py --date YYYY-MM-DD
```

Reduced test:

```bash
python scripts/run_daily_pipeline.py --date YYYY-MM-DD --max-sources 5 --limit-per-source 2
```

Force sources regardless of schedule:

```bash
python scripts/run_daily_pipeline.py --date YYYY-MM-DD --force --max-sources 5
```

Regenerate the source catalog from the maintained Markdown list:

```bash
python scripts/build_source_catalog.py /path/to/工业设计新品资讯网站清单.md --output config/source_catalog.json
cp config/source_catalog.json config/sources.json
```

## Required checks

```bash
python -m pytest -q
python -m compileall collectors pipeline scripts integrations
```

Always review `source_health.json`. Do not claim a complete daily report when high-priority sources failed or were not checked.

## v2.2 质量与数量强制规则

- HTML 卡片必须同时具备有效 `page_url` 与非占位 `image_url`；缺一不可进入公开画廊。
- `page_url` 必须回退到 `canonical_url` 或详情页最终 URL，禁止只保留图片 API 地址。
- `placehold.co`、`placeholder.com`、`via.placeholder.com` 等占位图片禁止进入日报。
- 租赁计划、订阅、融资、会员、软件更新、企业合作和服务公告不得作为实体新品。
- 默认每天检查最多 80 个到期来源，最多抓取 120 个高分详情页。
- 日报目标为至少 24 个合格实体产品，最多 40 个；不足时必须在 `source_health.json` 中报告原因，不得用占位或低质量内容凑数。
- “原文”按钮必须指向产品详情页或媒体文章页；“原图”按钮仅指向图片资源，两者不可混用。

## 飞书云盘目录结构是强制要求（v2.5）

发布不得把 HTML、JSON 和日志平铺到同一文件夹。每次正式发布必须先调用 `DriveStructureManager.ensure_standard_structure(report_date)`，以 `FEISHU_WORKSPACE_ROOT_FOLDER_TOKEN` 为父目录创建或复用以下结构：

```text
资源图库/
├── 今日资讯/YYYY-MM-DD/
│   ├── daily_gallery.html
│   ├── YYYY-MM-DD_工业设计图片日报_预览版.html
│   ├── 日报摘要.md（如生成）
│   ├── download_manifest.json
│   └── images/
│       └── 仅包含正式 HTML 实际引用的已验证产品图片
├── 历史归档/
├── 月度画廊/
└── 半年度报告/
工业设计情报数据库/
工业设计情报系统_内部/
├── raw-data/YYYY-MM-DD/
├── processed-data/YYYY-MM-DD/
├── selection-manifests/
├── logs/YYYY-MM-DD/
└── manifests/YYYY-MM-DD/
```

角色路由不可更改：日报 HTML、飞书预览版、摘要与 `download_manifest.json` 进入 `今日资讯/日期`；所有最终验证图片进入 `今日资讯/日期/images`；归档索引进入 `历史归档`；`collected_data.json` 与 `duplicates.json` 进入 `processed-data/日期`；`source_health.json` 与日志进入 `logs/日期`；发布清单进入 `manifests/日期`；选择清单进入 `selection-manifests`。

目录创建或定位失败时必须中止发布。禁止退回到单个 folder token，禁止把内部 JSON 上传到公开日期目录。

# v2.4 强制采集与图片真实性规范

## 多通道采集

每次运行必须先判断 Python 原生 HTTP 能力：

```bash
python scripts/detect_network_capability.py
```

支持四种模式：`auto`、`native_http`、`agent_assisted`、`offline`。

- 原生 HTTP 可用：运行标准 RSS、Sitemap、详情页管线。
- 原生 HTTP 不可用但 Agent 具备网页/图片工具：必须进入 `agent_assisted`。
- 两者均不可用：只可使用已有本地真实图片运行 `offline`，否则停止正式日报。
- 严禁为了“完成任务”手写虚构产品、图片 URL 或占位数据。

## Agent 辅助模式

Python 脚本不能直接调用对话中的网页工具。调用本 SKILL 的 Agent 必须先使用网页搜索、页面阅读或图片搜索能力完成验证，再生成符合 `schemas/tool_acquisition_manifest.schema.json` 的清单。

### 沙盒环境直接使用 curl 采集 RSS

当沙盒有网络但 `source_catalog.json` 中的来源缺少 RSS feed URL 字段时，使用 `scripts/agent_daily_pipeline.py` 直接通过 curl 采集 RSS。该脚本内置已验证的 RSS feed 列表，完整执行 RSS 采集 → 产品过滤 → 图片下载验证 → HTML 生成 → 便携预览 → 下载清单 → 摘要 的全流程。

```bash
python scripts/agent_daily_pipeline.py --date YYYY-MM-DD --max-sources 11 --limit-per-source 8
```

### 沙盒环境已验证可达的 RSS Feed

以下 feed 在沙盒环境中通过 curl 验证可达（截至 2026-08-03），可直接用于 `agent_daily_pipeline.py`：

| 来源 | Feed URL | Trust |
|------|----------|-------|
| designboom | `https://www.designboom.com/feed/` | 0.8 |
| designboom/design | `https://www.designboom.com/design/feed/` | 0.8 |
| designboom/technology | `https://www.designboom.com/technology/feed/` | 0.8 |
| Dezeen | `https://www.dezeen.com/feed/` | 0.8 |
| Yanko Design | `https://www.yankodesign.com/feed/` | 0.8 |
| Engadget | `https://www.engadget.com/rss.xml` | 0.8 |
| TechCrunch | `https://techcrunch.com/feed/` | 0.8 |
| Samsung | `https://news.samsung.com/global/feed` | 1.0 |
| Lenovo | `https://news.lenovo.com/feed/` | 1.0 |
| Garmin | `https://www.garmin.com/en-US/newsroom/feed/` | 1.0 |
| SlashGear | `https://www.slashgear.com/feed/` | 0.8 |

使用 `scripts/test_extended_feeds.py` 可验证更多 feed 的可达性。RSS 解析需处理前导空白、BOM、非法 XML 字符等问题（脚本已内置修复逻辑）。

### 标准 agent_acquisition_manifest 流程

每条产品必须包括：

- 真实产品名称；
- 官方或可信媒体详情页 `page_url`；
- 可追溯的真实产品图 `image_url`；
- 已保存的本地位图 `local_image_path`；
- 来源、发现方式和证据数组。

随后必须执行：

```bash
python scripts/validate_tool_manifest.py incoming/tool_acquisition_manifest.json
python scripts/import_agent_acquisition.py --manifest incoming/tool_acquisition_manifest.json --output data/YYYY-MM-DD/agent_collected_data.json
python scripts/validate_product_images.py --products data/YYYY-MM-DD/agent_collected_data.json --output data/YYYY-MM-DD/image_verified_data.json
```

## 正式日报图片门槛

正式 HTML 中每个产品必须同时满足：

- `image_verified == true`
- `local_image_path` 存在且能被 Pillow 读取
- 图片宽度至少 500px、高度至少 300px
- 文件不小于 20KB
- 图片不是低方差纯色标题卡
- `page_url` 存在并可追溯

正式日报禁止：

- Unsplash、Pexels 等无关图库替代图；
- 拼写异常或人工编造的图片 URL；
- SVG 文字占位图、纯色块或品牌 Logo 代替产品图；
- AI 生成的产品图片；
- 无来源页面的孤立图片。

图片失败时只能更换为另一个真实来源或剔除该产品。不得降级为占位图。

## 飞书预览

先将真实图片保存到本地，再生成标准 HTML，最后由 `build_portable_preview.py` 将本地位图嵌入 Base64。任何一张图片无法嵌入时，预览构建必须失败并停止发布，不得保留断裂的远程路径。

## 标准完整命令

```bash
python scripts/run_full_workflow.py \
  --date YYYY-MM-DD \
  --acquisition-mode auto
```

当自动探测切换到 Agent 辅助模式时，必须先准备 `--agent-manifest`，不能绕过验证直接生成日报。

### 沙盒 Agent 辅助模式命令

当沙盒有网络但缺少完整标准管线依赖时，使用以下命令完成采集到发布的全流程：

```bash
# 1. 检测网络能力
python scripts/detect_network_capability.py

# 2. 采集 RSS + 生成 HTML/便携版/清单/摘要
python scripts/agent_daily_pipeline.py --date YYYY-MM-DD --max-sources 11 --limit-per-source 8

# 3. 上传到飞书云盘（需先获取 user access token）
python scripts/upload_to_feishu.py
```

`upload_to_feishu.py` 使用 user access token，创建 v2.5 要求的完整目录结构并上传所有公开文件、图片和内部数据文件。使用前需通过 `feishu_user_info` 获取 token 并保存到 `/home/ubuntu/workspace/.credentials/feishu_user_access_token`。

## 完整离线资源包强制规则（v2.5）

标准版 `daily_gallery.html` 使用 `images/...` 相对路径，因此正式发布必须同时上传 `output/YYYY-MM-DD/images/`，不得只上传 HTML。飞书内直接预览使用 Base64 便携版；下载日期目录后本地浏览使用标准 HTML 与 images 子目录。

每次生成 HTML 后必须执行：

```bash
python scripts/build_download_manifest.py \
  --date YYYY-MM-DD \
  --html output/YYYY-MM-DD/daily_gallery.html \
  --portable-preview output/YYYY-MM-DD/YYYY-MM-DD_工业设计图片日报_预览版.html \
  --images-dir output/YYYY-MM-DD/images \
  --output output/YYYY-MM-DD/download_manifest.json
```

该脚本必须验证标准 HTML 中每个本地相对图片引用真实存在，并记录文件大小和 SHA-256。任何引用缺失时必须停止发布。`run_full_workflow.py --publish` 必须显式传入 `--images output/YYYY-MM-DD/images` 与 `--download-manifest output/YYYY-MM-DD/download_manifest.json`。

禁止：

- 将最终图片只放在内部 raw-data；
- 仅上传便携 HTML 而省略标准版资源；
- 将图片平铺在日期目录；
- 在缺少图片时继续发布标准 HTML；
- 假设飞书单文件预览会自动解析相邻 images 文件夹。


## v2.8.0 唯一画廊模板与排版质量闸门

- 正式日报唯一入口为 `scripts/run_full_workflow.py`。
- `agent_daily_pipeline.py` 只负责采集，HTML 必须委托 `generate_html.py` 和 `build_portable_preview.py`。
- 正式 HTML 必须包含 `data-gallery-template="canonical-v3.4"`，检测到旧 `.header/.section-title/.grid` 模板立即停止发布。
- 标准版使用保留图片原比例的响应式瀑布流；不再固定裁切为 240px。
- 便携预览采用最长边 1100px、JPEG 质量 72、嵌入图片上限 15MB；超限直接失败，不生成残缺或卡顿文件。
- 所有标题、说明、来源和 URL 均由 canonical 生成器统一 HTML 转义。


## v3.0.0 飞书目录幂等与中文灯箱描述

- 飞书目录查询必须遍历全部分页，并对全角空格、Unicode 兼容字符及多余空白做名称归一化。
- `create_folder` 属于非幂等操作，禁止因超时自动重试；创建结果必须通过重新列目录确认，避免“服务端已创建但客户端重试”产生同名目录。
- 若历史上已有同名目录，固定选择排序后的 canonical token 继续发布，并在发布结果中输出 `duplicate_folder_conflicts`，不再新建第三份。
- 所有正式画廊输出统一采用 `canonical-v3.4`。灯箱描述只读取 `description_zh` / `ai_analysis.description_zh` 优先链路，并与卡片中文说明保持一致。


## v3.0 第一阶段设计情报工作台（强制）
- 正式工作流除日报外必须生成：产品详情、高级检索、产品对比、收藏项目板、品牌材料专题、基础趋势看板。
- 卡片与灯箱只能展示通过中文占比校验的 `description_zh`；英文摘要不得作为公开回退。
- 每张卡片必须显示飞书同步状态：已同步、待同步或失败，不允许隐藏状态。
- 当前静态项目板使用 localStorage；多人协作、账号权限和云端实时收藏属于后端部署阶段。


## v3.2.0 单入口第一阶段门户（强制）

- 第一阶段一级功能必须集成到 `design_intelligence_portal.html`：今日画廊、高级检索、产品对比、项目板、品牌与材料专题、基础趋势看板。
- 顶部导航使用 URL hash（`#gallery`、`#explore`、`#compare`、`#board`、`#topics`、`#trends`）在同一 HTML 内切换分区，不重新加载页面。
- 产品详情继续生成到 `details/*.html`，用于独立分享、搜索引擎索引和后续扩展；详情页必须返回主门户。
- `daily_gallery.html`、`explore.html`、`compare.html`、`board.html`、`topics.html`、`trends.html` 仅作为兼容跳转页，不再包含重复业务页面。
- 飞书便携预览以 `design_intelligence_portal.html` 为源文件，生成单文件 `YYYY-MM-DD_设计情报工作台_预览版.html`。
- 完整下载包必须包含：主门户、`details/`、`images/`、兼容跳转页及 `download_manifest.json`。
- 飞书结构化发布增加 `details/` 子目录，产品详情页不得平铺到日期根目录。
- 主门户必须包含 `data-portal-template="phase1-v3.4"`，并通过 portal 排版质量闸门。

## v3.2 飞书门户发布强制规则

- 飞书日期目录必须上传 `design_intelligence_portal.html` 作为正式入口。
- 同步上传 `daily_gallery.html`、`explore.html`、`compare.html`、`board.html`、`topics.html`、`trends.html` 六个兼容入口文件。
- `details/` 和 `images/` 必须作为日期目录子文件夹发布。
- 正式发布器拒绝把旧 `daily_gallery.html` 作为主入口。
- 门户导航必须使用原生 `#gallery`、`#explore` 等锚点；即使飞书预览禁用 JavaScript，也必须能跳到并查看各分区。
- JavaScript 仅用于增强分区切换、检索、收藏和动态对比，不得成为查看分区内容的唯一方式。
- 禁止再使用 `scripts/upload_to_feishu.py` 中的历史硬编码上传逻辑；该入口只允许委托标准发布器。

## v3.4.0 公开界面描述与状态规则（强制）

- 正式画廊、灯箱、单入口门户、检索结果和产品详情页均不得展示飞书同步状态、同步数量、失败数量或“待同步飞书”等内部工作流信息。
- 飞书同步字段可以继续保留在内部 JSON、发布清单和多维表格写回流程中，但不得渲染到公开 HTML。
- 公开产品说明优先使用经校验的 `description_zh` / `ai_analysis.description_zh`。
- 仅有英文资料时，必须依据标题、品类和可验证关键词生成有信息量的中文归纳；不得直接展示英文摘要，也不得统一使用空泛的“资料有限、待补充”作为常规说明。
- 无法形成可靠中文说明时，才允许使用保守兜底，并应保留原文入口供继续核验。
- 正式画廊模板指纹为 `canonical-v3.4`，第一阶段门户指纹为 `phase1-v3.4`。


## v3.4 图标中文导航规范
- 日报画廊与单入口门户的主导航统一采用“线性 SVG 图标在上、中文标签在下”的排版。
- 禁止主导航继续使用 Today、Gallery、Archive 等纯英文标签。
- 图标必须以内联 SVG 提供，不依赖外部字体或图标 CDN，确保飞书预览与离线包可用。
- 导航保留 title 与 aria-label 语义，移动端允许横向滚动，不隐藏主要功能入口。

## v3.5 全局画廊与当期日报（强制）

- 正式日报唯一入口仍为 `python scripts/run_full_workflow.py --date YYYY-MM-DD`。
- 当期产品必须保存为 `output/YYYY-MM-DD/gallery_input.json`，不得只写入临时清单。
- 完成采集、分析和图片落盘后，必须运行 `scripts/build_gallery_hierarchy.py --root output --date YYYY-MM-DD`；不得直接以当期清单调用 `build_portal_pages.py` 作为最终发布页。
- `build_gallery_hierarchy.py` 必须生成 `global_gallery_input.json`，合并历史日报、周报和月报产品，并按稳定产品 ID 去重。
- `design_intelligence_portal.html#gallery` 显示全局目录；`#today` 只读取 `PORTAL_ISSUE_IDS`，显示当期日报产品。
- 历史周报和月报的“画廊”入口必须跳转最新全局画廊，保证 UI、日期层级、筛选逻辑和产品总数一致。
- 全局产品图片必须统一复制到当期 `history_images/`，清单中禁止出现 `..` 父目录路径。
- 最终必须重建便携预览，并执行 `python -m pytest -q`；任何图片嵌入失败或回归测试失败都不得交付。

## v3.6 趋势与品牌对比视觉规则（强制）

- CMF“材料 → 表面”关系线必须使用随主题变化的高对比颜色；浅色主题不得使用接近背景的白色低透明连线。
- 品牌活跃度使用不重叠的品牌活跃度排名横条，分别标注官方新品、媒体新稿和总量；禁止重新使用会堆叠标签的气泡象限图。
- 品牌统计和品牌新品对比必须排除“独立设计/未标注”“未知品牌”等占位品牌。
- 品牌新品对比按“品牌 → 产品品类”两级组织，产品卡采用图片优先布局，图片占卡片主要面积，文字只保留标题、日期和发布类型。
- 修改 `scripts/trend_dashboard_v2.py` 或 `scripts/build_portal_pages.py` 后，必须重新生成正式入口和便携预览。
