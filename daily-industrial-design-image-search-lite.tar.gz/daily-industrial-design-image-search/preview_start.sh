#!/bin/bash
set -e

PROJECT_DIR="/home/ubuntu/workdir/daily-industrial-design-image-search"
NGINX_CONF="/home/ubuntu/.preview/gateway.conf"
DIST_DIR="/home/ubuntu/app/projects/f37290c91f5b44a0/frontend/dist"

echo "=== 1. 杀掉旧uvicorn进程 ==="
pkill -f "uvicorn main:app" 2>/dev/null || true
sleep 1

echo "=== 2. 启动uvicorn ==="
cd $PROJECT_DIR
nohup uvicorn main:app --host 0.0.0.0 --port 8000 > /tmp/uvicorn.log 2>&1 &
sleep 3

echo "=== 3. 确保最新portal HTML在nginx静态目录 ==="
# 找最新的动态门户HTML
LATEST_HTML=$(ls -t $PROJECT_DIR/output/20*/design_intelligence_portal_dynamic.html 2>/dev/null | head -1)
if [ -z "$LATEST_HTML" ]; then
    LATEST_HTML=$(ls -t $PROJECT_DIR/output/20*/design_intelligence_portal.html 2>/dev/null | head -1)
fi
if [ -n "$LATEST_HTML" ]; then
    mkdir -p $DIST_DIR
    cp "$LATEST_HTML" $DIST_DIR/index.html
    cp "$LATEST_HTML" $PROJECT_DIR/frontend/dist/index.html
    echo "  Copied: $LATEST_HTML -> index.html"
fi

echo "=== 4. 修复nginx配置（确保有图片代理规则）==="
# 检查gateway.conf是否有images代理规则
if ! grep -q "/images/" "$NGINX_CONF" 2>/dev/null; then
    echo "  Adding image proxy rules to gateway.conf"
    # 在location /之前插入图片代理规则
    sed -i '/location \/ {/i \
    location /images/ {\
        proxy_pass http://127.0.0.1:8000;\
        proxy_set_header Host $host;\
    }\
    location /history_images/ {\
        proxy_pass http://127.0.0.1:8000;\
        proxy_set_header Host $host;\
    }\
    location /details/ {\
        proxy_pass http://127.0.0.1:8000;\
        proxy_set_header Host $host;\
    }' "$NGINX_CONF" 2>/dev/null || true
fi

# 同时修复preview-nginx-render.sh模板
RENDER_SCRIPT="/usr/local/bin/preview-nginx-render.sh"
if [ -f "$RENDER_SCRIPT" ] && ! grep -q "/images/" "$RENDER_SCRIPT" 2>/dev/null; then
    sed -i '/location \/ {/i \
    location /images/ {\
        proxy_pass http://127.0.0.1:8000;\
        proxy_set_header Host $host;\
    }\
    location /history_images/ {\
        proxy_pass http://127.0.0.1:8000;\
        proxy_set_header Host $host;\
    }\
    location /details/ {\
        proxy_pass http://127.0.0.1:8000;\
        proxy_set_header Host $host;\
    }' "$RENDER_SCRIPT" 2>/dev/null || true
    echo "  Fixed preview-nginx-render.sh template"
fi

echo "=== 5. 重启nginx ==="
nginx -s reload 2>/dev/null || nginx -c "$NGINX_CONF" 2>/dev/null || true
sleep 1

echo "=== 6. 验证 ==="
echo -n "  API stats: "
curl -s http://localhost:8000/api/stats | python3 -c "import sys,json;d=json.load(sys.stdin);print(f'products={d.get(\"total_products\")}, latest={d.get(\"latest_date\")}')" 2>/dev/null || echo "FAILED"
echo -n "  图片: "
curl -s -o /dev/null -w "%{http_code}" "http://localhost:9080/images/ba0d7a6090d4.jpg" 2>/dev/null
echo ""
echo -n "  周期分类代码: "
curl -s http://localhost:9080/ | grep -c 'periodHierarchy' 2>/dev/null
echo -n "  石头科技产品: "
curl -s http://localhost:9080/api/portal-data | python3 -c "import sys,json;d=json.load(sys.stdin);pp=d.get('PORTAL_PRODUCTS',[]);matches=[p for p in pp if '石头' in p.get('title','')];print(f'{len(matches)} found')" 2>/dev/null || echo "FAILED"

echo ""
echo "=== Preview ready! ==="
echo "Preview URL: https://beta.ecouser.net/api/v1/sessions/f37290c91f5b44a0/proxy/9080/"
