#!/usr/bin/env python3
"""Database initialization and seed data import.

Usage:
    python db/init_db.py [--seed] [--json output/2026-08-09/global_gallery_input.json] [--sources config/source_catalog.json]

Without --seed, only creates tables from schema.sql.
With --seed, imports products from global_gallery_input.json and sources from source_catalog.json.
"""
from __future__ import annotations
import argparse
import json
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "db" / "gallery.db"
SCHEMA_PATH = ROOT / "db" / "schema.sql"
DEFAULT_JSON = ROOT / "output" / "2026-08-09" / "global_gallery_input.json"
DEFAULT_SOURCES = ROOT / "config" / "source_catalog.json"


def get_conn(db_path: Path | None = None) -> sqlite3.Connection:
    path = db_path or DB_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def init_schema(conn: sqlite3.Connection):
    schema = SCHEMA_PATH.read_text(encoding="utf-8")
    conn.executescript(schema)
    conn.commit()


def seed_sources(conn: sqlite3.Connection, sources_path: Path):
    data = json.loads(sources_path.read_text(encoding="utf-8"))
    sources = data.get("sources", [])
    count = 0
    for s in sources:
        discovery = json.dumps(s.get("discovery", []), ensure_ascii=False)
        conn.execute(
            """INSERT OR REPLACE INTO sources
               (id, publisher, source_type, priority, url, enabled, check_frequency,
                discovery, candidate_budget, detail_fetch_budget, candidate_score_threshold,
                max_age_days, trust_level, mail_subscription)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                s["id"],
                s.get("publisher", ""),
                s.get("source_type", "design_media"),
                s.get("priority", "P2"),
                s.get("url", ""),
                1 if s.get("enabled", True) else 0,
                s.get("check_frequency", "daily"),
                discovery,
                s.get("candidate_budget", 30),
                s.get("detail_fetch_budget", 6),
                s.get("candidate_score_threshold", 42),
                s.get("max_age_days", 14),
                s.get("trust_level", 0.8),
                1 if s.get("mail_subscription", False) else 0,
            ),
        )
        count += 1
    conn.commit()
    print(f"  Sources imported: {count}")


def _json_field(val) -> str:
    """Serialize list/dict to JSON string, pass through strings."""
    if val is None:
        return "[]"
    if isinstance(val, str):
        return val
    return json.dumps(val, ensure_ascii=False)


def seed_products(conn: sqlite3.Connection, json_path: Path):
    data = json.loads(json_path.read_text(encoding="utf-8"))
    count = 0
    for item in data:
        pid = item.get("product_id") or item.get("id", "")
        if not pid:
            continue
        image_local = item.get("local_image_path", "")
        # Extract just the filename from path for detail and image
        detail_path = f"details/{pid}.html"
        if not image_local:
            image_local = f"history_images/{pid}_{pid}.jpg"

        conn.execute(
            """INSERT OR REPLACE INTO products
               (id, title, brand, publisher, source, source_type, category,
                description, page_url, image_local_path, detail_path,
                news_type, region, verification_status, maturity,
                style_keywords, design_drivers, cmf_colors, cmf_materials, cmf_finishes,
                ai_analysis, first_seen_date, date_collected,
                compare_visible, official)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                pid,
                item.get("title", ""),
                item.get("brand", ""),
                item.get("publisher", ""),
                item.get("source", ""),
                item.get("source_type", "design_media"),
                item.get("category", "其他产品"),
                item.get("description_zh", ""),
                item.get("page_url", ""),
                image_local,
                detail_path,
                item.get("news_type", "媒体新稿"),
                item.get("region", "全球/未标注"),
                item.get("verification_status", "needs_review"),
                item.get("maturity", "media_coverage"),
                _json_field(item.get("style_keywords")),
                _json_field(item.get("design_drivers")),
                _json_field(item.get("cmf_colors")),
                _json_field(item.get("cmf_materials")),
                _json_field(item.get("cmf_finishes")),
                _json_field(item.get("ai_analysis")),
                item.get("first_seen_date", ""),
                item.get("first_seen_date", ""),
                1 if item.get("compare_visible", True) else 0,
                1 if item.get("source_type") == "official_brand" else 0,
            ),
        )
        count += 1
    conn.commit()
    print(f"  Products imported: {count}")
    return count


def seed_product_images(conn: sqlite3.Connection, json_path: Path, images_dir: Path):
    """Insert image records for each product's local image."""
    data = json.loads(json_path.read_text(encoding="utf-8"))
    count = 0
    for item in data:
        pid = item.get("product_id") or item.get("id", "")
        if not pid:
            continue
        image_local = item.get("local_image_path", "")
        if not image_local:
            image_local = f"history_images/{pid}_{pid}.jpg"
        full_path = ROOT / image_local
        file_size = full_path.stat().st_size if full_path.exists() else None
        filename = Path(image_local).name
        conn.execute(
            """INSERT OR REPLACE INTO product_images
               (product_id, filename, local_path, original_url, verified, file_size)
               VALUES (?,?,?,?,?,?)""",
            (pid, filename, image_local, item.get("image_url", ""), 1 if full_path.exists() else 0, file_size),
        )
        count += 1
    conn.commit()
    print(f"  Product images imported: {count}")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--seed", action="store_true", help="Import seed data after creating schema")
    p.add_argument("--json", type=Path, default=DEFAULT_JSON, help="Path to global_gallery_input.json")
    p.add_argument("--sources", type=Path, default=DEFAULT_SOURCES, help="Path to source_catalog.json")
    p.add_argument("--db", type=Path, default=DB_PATH, help="Database file path")
    args = p.parse_args()

    print(f"Database: {args.db}")
    conn = get_conn(args.db)
    print("Creating schema...")
    init_schema(conn)
    print("  Schema created.")

    if args.seed:
        print("Importing seed data...")
        if args.sources.exists():
            seed_sources(conn, args.sources)
        else:
            print(f"  Sources file not found: {args.sources}")

        if args.json.exists():
            seed_products(conn, args.json)
            images_dir = ROOT / "output" / "2026-08-09" / "history_images"
            seed_product_images(conn, args.json, images_dir)
        else:
            print(f"  Products JSON not found: {args.json}")

    # Verify
    for table in ("sources", "products", "pipeline_runs", "product_images"):
        n = conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
        print(f"  {table}: {n} rows")

    conn.close()
    print("Done.")


if __name__ == "__main__":
    main()
