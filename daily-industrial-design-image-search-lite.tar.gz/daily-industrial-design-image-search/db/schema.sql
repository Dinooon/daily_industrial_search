-- Industrial Design Intelligence Gallery - Database Schema
-- SQLite database for product, source, pipeline_run, product_image tables

PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

-- ============================================================
-- sources: 来源配置 (from config/source_catalog.json)
-- ============================================================
CREATE TABLE IF NOT EXISTS sources (
    id          TEXT PRIMARY KEY,
    publisher   TEXT NOT NULL,
    source_type TEXT NOT NULL DEFAULT 'design_media',  -- official_brand / design_media / award / event
    priority    TEXT NOT NULL DEFAULT 'P2',            -- P0 / P1 / P2
    url         TEXT,
    enabled     INTEGER NOT NULL DEFAULT 1,
    check_frequency TEXT NOT NULL DEFAULT 'daily',
    discovery       TEXT,  -- JSON array: ["rss","sitemap","html"]
    candidate_budget INTEGER DEFAULT 30,
    detail_fetch_budget INTEGER DEFAULT 6,
    candidate_score_threshold INTEGER DEFAULT 42,
    max_age_days INTEGER DEFAULT 14,
    trust_level REAL DEFAULT 0.8,
    mail_subscription INTEGER DEFAULT 0,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ============================================================
-- products: 产品信息 (from global_gallery_input.json)
-- ============================================================
CREATE TABLE IF NOT EXISTS products (
    id                  TEXT PRIMARY KEY,           -- product_id: prod_xxx
    title               TEXT NOT NULL,
    brand               TEXT,
    publisher           TEXT,
    source              TEXT,                       -- = publisher (redundant but kept for compatibility)
    source_id           TEXT,                       -- FK -> sources.id (nullable, may not exist in sources table)
    source_type         TEXT,                       -- official_brand / design_media
    category            TEXT,
    description         TEXT,                       -- description_zh from JSON
    page_url            TEXT,
    image_url           TEXT,                       -- original remote image URL (if available)
    image_local_path    TEXT,                       -- relative path: history_images/xxx.jpg
    detail_path         TEXT,                       -- relative path: details/xxx.html
    news_type           TEXT,                       -- 媒体新稿 / 已入库资讯 / 官方新品
    region              TEXT,
    verification_status TEXT DEFAULT 'needs_review', -- needs_review / confirmed
    maturity            TEXT,                       -- media_coverage / announced / archived
    style_keywords      TEXT,                       -- JSON array
    design_drivers      TEXT,                       -- JSON array
    cmf_colors           TEXT,                       -- JSON array
    cmf_materials        TEXT,                       -- JSON array
    cmf_finishes         TEXT,                       -- JSON array
    ai_analysis         TEXT,                       -- JSON object (pipeline/analyze.py output)
    score               REAL DEFAULT 0,            -- quality score 0.0-1.0
    first_seen_date     TEXT,                       -- ISO date: 2026-07-09
    date_collected      TEXT,                       -- ISO date when collected
    compare_visible     INTEGER DEFAULT 1,           -- boolean: visible in brand compare view
    official            INTEGER DEFAULT 0,           -- boolean: official brand source
    created_at          TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at          TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (source_id) REFERENCES sources(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);
CREATE INDEX IF NOT EXISTS idx_products_source_type ON products(source_type);
CREATE INDEX IF NOT EXISTS idx_products_brand ON products(brand);
CREATE INDEX IF NOT EXISTS idx_products_date ON products(date_collected);
CREATE INDEX IF NOT EXISTS idx_products_first_seen ON products(first_seen_date);

-- ============================================================
-- pipeline_runs: 采集运行记录
-- ============================================================
CREATE TABLE IF NOT EXISTS pipeline_runs (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    run_date        TEXT NOT NULL,                   -- ISO date being collected
    started_at      TEXT NOT NULL,                   -- ISO datetime
    finished_at     TEXT,
    status          TEXT NOT NULL DEFAULT 'pending', -- pending / running / success / failed
    mode            TEXT,                            -- auto / native_http / agent_assisted / offline
    products_found  INTEGER DEFAULT 0,
    products_new    INTEGER DEFAULT 0,
    products_updated INTEGER DEFAULT 0,
    images_downloaded INTEGER DEFAULT 0,
    error_message   TEXT,
    log_file        TEXT,                            -- path to log file if any
    created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_pipeline_runs_date ON pipeline_runs(run_date);
CREATE INDEX IF NOT EXISTS idx_pipeline_runs_status ON pipeline_runs(status);

-- ============================================================
-- product_images: 图片信息
-- ============================================================
CREATE TABLE IF NOT EXISTS product_images (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id      TEXT NOT NULL,
    filename        TEXT NOT NULL,                   -- just the filename
    local_path      TEXT NOT NULL,                   -- relative path from project root
    original_url    TEXT,                            -- remote URL if available
    sha256         TEXT,
    verified        INTEGER DEFAULT 0,               -- boolean: Pillow verified
    file_size       INTEGER,                         -- bytes
    width           INTEGER,
    height          INTEGER,
    created_at      TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_product_images_product ON product_images(product_id);
CREATE INDEX IF NOT EXISTS idx_product_images_filename ON product_images(filename);
