#!/usr/bin/env python3
"""Import all historical collection data into the SQLite database.

Merges products from multiple JSON files, deduplicates by product_id
(falling back to page_url), normalizes image paths, and UPSERTs into
the products and product_images tables.

Usage:
    python db/import_history.py [--dry-run]
"""
from __future__ import annotations
import argparse
import json
import re
import sqlite3
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "db" / "gallery.db"

# All historical data files to merge.
# gallery_input.json files contain the original RSS feed data including image_url;
# global_gallery_input.json files contain the merged product catalog (which may
# lack image_url for older items). Including both ensures image_url is preserved.
HISTORY_FILES = [
    # gallery_input.json — has image_url from RSS feeds (primary source for remote URLs)
    ROOT / "output" / "2026-08-09" / "gallery_input.json",
    ROOT / "output" / "2026-08-12" / "gallery_input.json",
    ROOT / "output" / "2026-08-12" / "galleries" / "daily" / "gallery_input.json",
    ROOT / "output" / "2026-08-12" / "galleries" / "weekly" / "gallery_input.json",
    ROOT / "output" / "2026-08-12" / "galleries" / "monthly" / "gallery_input.json",
    ROOT / "output" / "2026-08-13" / "gallery_input.json",
    ROOT / "output" / "2026-08-13" / "galleries" / "daily" / "gallery_input.json",
    ROOT / "output" / "2026-08-14" / "gallery_input.json",
    ROOT / "output" / "2026-08-14" / "galleries" / "daily" / "gallery_input.json",
    # global_gallery_input.json — merged catalog (has product_id + enriched metadata)
    ROOT / "output" / "2026-08-09" / "global_gallery_input.json",
    ROOT / "output" / "2026-08-12" / "global_gallery_input.json",
    ROOT / "output" / "2026-08-13" / "global_gallery_input.json",
    ROOT / "output" / "2026-08-14" / "global_gallery_input.json",
    # Collected data (if present)
    ROOT / "data" / "2026-08-12" / "collected_data.json",
]


def get_conn(db_path: Path | None = None) -> sqlite3.Connection:
    path = db_path or DB_PATH
    conn = sqlite3.connect(str(path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def _json_field(val) -> str:
    if val is None:
        return "[]"
    if isinstance(val, str):
        return val
    return json.dumps(val, ensure_ascii=False)


def normalize_image_path(raw: str) -> str:
    """Normalize local_image_path to a consistent relative path from project root."""
    if not raw:
        return ""
    p = raw.replace("\\", "/")
    # Strip absolute prefix pointing to project root
    prefix = str(ROOT).replace("\\", "/")
    if p.startswith(prefix + "/"):
        p = p[len(prefix) + 1:]
    # Strip leading ./ or ../ sequences
    p = re.sub(r"^(\.\./)+", "", p)
    p = re.sub(r"^\./", "", p)
    return p


def parse_date_from_pub(pub_date: str) -> str:
    """Extract ISO date (YYYY-MM-DD) from an RFC 2822 pub_date string."""
    if not pub_date:
        return ""
    try:
        dt = datetime.strptime(pub_date[:25], "%a, %d %b %Y %H:%M:%S")
        return dt.strftime("%Y-%m-%d")
    except (ValueError, IndexError):
        return ""


def load_history_files() -> dict[str, dict]:
    """Load and merge all history JSON files into a single dict keyed by product_id."""
    merged: dict[str, dict] = {}

    for fpath in HISTORY_FILES:
        if not fpath.exists():
            print(f"  SKIP (not found): {fpath}")
            continue

        raw = json.loads(fpath.read_text(encoding="utf-8"))
        items = raw if isinstance(raw, list) else raw.get("products", [])
        count_new = 0
        count_update = 0

        for item in items:
            pid = item.get("product_id", "")
            page_url = item.get("page_url", "") or item.get("link", "")

            # If no product_id, try to find an existing entry by page_url
            if not pid and page_url:
                for existing_pid, existing_item in merged.items():
                    if existing_item.get("page_url") == page_url:
                        pid = existing_pid
                        break
            if not pid:
                continue

            # Normalize image path
            raw_path = item.get("local_image_path", "")
            norm_path = normalize_image_path(raw_path)
            if norm_path:
                item["local_image_path"] = norm_path

            # For "collected" format items (no first_seen_date), derive from pub_date
            if not item.get("first_seen_date") and item.get("pub_date"):
                item["first_seen_date"] = parse_date_from_pub(item["pub_date"])

            # Ensure product_id is set on the item
            item["product_id"] = pid

            if pid not in merged:
                merged[pid] = item
                count_new += 1
            else:
                # Merge: fill in missing fields from this file's version
                existing = merged[pid]
                for k, v in item.items():
                    if (k not in existing or not existing[k]) and v:
                        existing[k] = v
                count_update += 1

        print(f"  {fpath.relative_to(ROOT)}: {len(items)} items ({count_new} new, {count_update} merged)")

    return merged


def upsert_product(conn: sqlite3.Connection, item: dict) -> bool:
    """UPSERT a single product into the products table."""
    pid = item["product_id"]
    image_local = item.get("local_image_path", "")
    if not image_local:
        image_local = f"history_images/{pid}_{pid}.jpg"

    detail_path = f"details/{pid}.html"

    # Determine first_seen_date and date_collected
    fsd = item.get("first_seen_date", "")
    dc = item.get("date_collected", "") or fsd

    # source_id from item or derive from publisher; validate against sources table
    source_id = item.get("source_id", "")
    if not source_id:
        publisher = item.get("publisher", "")
        if publisher:
            source_id = publisher.lower().replace(" ", "_").replace(".", "")
    # Only set source_id if it exists in sources table (FK constraint)
    if source_id:
        exists = conn.execute("SELECT 1 FROM sources WHERE id = ?", (source_id,)).fetchone()
        if not exists:
            source_id = None

    # 27 columns (updated_at uses datetime('now') in SQL), 27 params
    conn.execute(
        """INSERT INTO products
           (id, title, brand, publisher, source, source_id, source_type, category,
            description, page_url, image_url, image_local_path, detail_path,
            news_type, region, verification_status, maturity,
            style_keywords, design_drivers, cmf_colors, cmf_materials, cmf_finishes,
            ai_analysis, first_seen_date, date_collected,
            compare_visible, official, updated_at)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,datetime('now'))
           ON CONFLICT(id) DO UPDATE SET
            title=excluded.title, brand=excluded.brand, publisher=excluded.publisher,
            source=excluded.source, source_id=COALESCE(excluded.source_id, products.source_id), source_type=excluded.source_type,
            category=excluded.category, description=excluded.description,
            page_url=excluded.page_url,
            image_url=COALESCE(NULLIF(excluded.image_url, ''), products.image_url),
            image_local_path=excluded.image_local_path,
            news_type=excluded.news_type, region=excluded.region,
            verification_status=excluded.verification_status, maturity=excluded.maturity,
            style_keywords=excluded.style_keywords, design_drivers=excluded.design_drivers,
            cmf_colors=excluded.cmf_colors, cmf_materials=excluded.cmf_materials,
            cmf_finishes=excluded.cmf_finishes, ai_analysis=excluded.ai_analysis,
            first_seen_date=COALESCE(NULLIF(excluded.first_seen_date, ''), products.first_seen_date),
            date_collected=COALESCE(NULLIF(excluded.date_collected, ''), products.date_collected),
            compare_visible=excluded.compare_visible, official=excluded.official,
            updated_at=datetime('now')""",
        (
            pid,
            item.get("title", ""),
            item.get("brand", ""),
            item.get("publisher", ""),
            item.get("source", item.get("publisher", "")),
            source_id or None,
            item.get("source_type", "design_media"),
            item.get("category", "其他产品"),
            item.get("description_zh", item.get("description", "")),
            item.get("page_url", ""),
            item.get("image_url", "") or None,
            image_local,
            detail_path,
            item.get("news_type", "媒体新稿"),
            item.get("region", "全球/未标注"),
            item.get("verification_status", "needs_review"),
            item.get("maturity", "media_coverage"),
            _json_field(item.get("style_keywords")),
            _json_field(item.get("design_drivers")),
            _json_field(item.get("cmf_colors")),
            _json_field(item.get("cmf_materials")),
            _json_field(item.get("cmf_finishes")),
            _json_field(item.get("ai_analysis")),
            fsd,
            dc,
            1 if item.get("compare_visible", True) else 0,
            1 if item.get("source_type") == "official_brand" or item.get("official") else 0,
        ),
    )
    return True


def upsert_product_images(conn: sqlite3.Connection, item: dict) -> bool:
    """UPSERT product_images record for a product (delete-then-insert to avoid dups)."""
    pid = item["product_id"]
    image_local = item.get("local_image_path", "")
    if not image_local:
        image_local = f"history_images/{pid}_{pid}.jpg"

    # Resolve full path to check file existence
    full_path = ROOT / image_local
    file_size = None
    verified = 0
    if full_path.exists():
        file_size = full_path.stat().st_size
        verified = 1

    filename = Path(image_local).name
    original_url = item.get("image_url", "")
    sha256 = item.get("image_sha256", "")

    # Delete existing rows for this product_id, then insert fresh
    conn.execute("DELETE FROM product_images WHERE product_id = ?", (pid,))
    conn.execute(
        """INSERT INTO product_images
           (product_id, filename, local_path, original_url, sha256, verified, file_size)
           VALUES (?,?,?,?,?,?,?)""",
        (pid, filename, image_local, original_url or None, sha256 or None, verified, file_size),
    )
    return True


def main():
    parser = argparse.ArgumentParser(description="Import historical data into gallery.db")
    parser.add_argument("--dry-run", action="store_true", help="Print stats without writing to DB")
    parser.add_argument("--db", type=Path, default=DB_PATH, help="Database file path")
    args = parser.parse_args()

    print(f"Database: {args.db}")
    conn = get_conn(args.db)

    # Show pre-import stats
    pre_products = conn.execute("SELECT COUNT(*) FROM products").fetchone()[0]
    pre_images = conn.execute("SELECT COUNT(*) FROM product_images").fetchone()[0]
    print(f"Pre-import: {pre_products} products, {pre_images} product_images")

    # Load and merge all history files
    print("\nLoading history files...")
    merged = load_history_files()
    print(f"\nMerged unique products: {len(merged)}")

    if args.dry_run:
        print("\n[DRY RUN] No changes written.")
        for pid, item in sorted(merged.items()):
            print(f"  {pid}: {item.get('title', '')[:50]} | img={item.get('local_image_path', '')} | iu={'Y' if item.get('image_url') else 'N'}")
        conn.close()
        return

    # UPSERT all products
    print("\nUpserting products...")
    product_count = 0
    for pid, item in sorted(merged.items()):
        upsert_product(conn, item)
        product_count += 1
    conn.commit()
    print(f"  Products upserted: {product_count}")

    # UPSERT product_images
    print("\nUpserting product_images...")
    image_count = 0
    for pid, item in sorted(merged.items()):
        upsert_product_images(conn, item)
        image_count += 1
    conn.commit()
    print(f"  Product images upserted: {image_count}")

    # Post-import verification
    print("\n=== Post-import verification ===")
    post_products = conn.execute("SELECT COUNT(*) FROM products").fetchone()[0]
    post_images = conn.execute("SELECT COUNT(*) FROM product_images").fetchone()[0]
    print(f"Products: {pre_products} -> {post_products}")
    print(f"Product images: {pre_images} -> {post_images}")

    distinct_categories = conn.execute("SELECT COUNT(DISTINCT category) FROM products").fetchone()[0]
    print(f"Distinct categories: {distinct_categories}")

    print("\nFirst seen date distribution:")
    for row in conn.execute(
        "SELECT first_seen_date, COUNT(*) FROM products GROUP BY first_seen_date ORDER BY first_seen_date"
    ):
        print(f"  {row[0] or '(empty)'}: {row[1]}")

    print("\nCategory distribution:")
    for row in conn.execute(
        "SELECT category, COUNT(*) FROM products GROUP BY category ORDER BY COUNT(*) DESC"
    ):
        print(f"  {row[0]}: {row[1]}")

    # Check image_url coverage
    with_url = conn.execute(
        'SELECT COUNT(*) FROM products WHERE image_url IS NOT NULL AND image_url != ""'
    ).fetchone()[0]
    print(f"\nProducts with image_url: {with_url}")

    # Check image path normalization
    print("\nImage path prefixes:")
    for row in conn.execute(
        "SELECT CASE WHEN instr(image_local_path, '/') > 0 THEN substr(image_local_path, 1, instr(image_local_path, '/') - 1) ELSE '(root)' END AS prefix, COUNT(*) FROM products GROUP BY prefix ORDER BY COUNT(*) DESC"
    ):
        print(f"  {row[0]}: {row[1]}")

    conn.close()
    print("\nDone.")


if __name__ == "__main__":
    main()
