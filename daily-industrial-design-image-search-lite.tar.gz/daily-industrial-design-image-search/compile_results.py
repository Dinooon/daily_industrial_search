#!/usr/bin/env python3
"""
Final compilation of RSS feed URL results for 50 target brands.
Combines all verified results from rounds 1-8.
"""
import json

# Verified RSS feeds (strictly validated: starts with <?xml/<rss/<feed and contains RSS/Atom elements)
VERIFIED_FEEDS = {
    # From Round 1 (initially found, re-verified in Round 6/7)
    "apple_newsroom": "https://www.apple.com/newsroom/rss-feed.rss",  # Found via HTML <link> tag, Atom format
    "google_blog_products": "https://blog.google/rss/",  # Verified: starts with <?xml, has <feed>
    "meta_newsroom": "https://about.fb.com/news/feed/",  # Verified: starts with <?xml
    "leica_camera": "https://leica-camera.com/rss.xml",  # Verified: starts with <?xml, has <rss>
    "the_verge": "https://www.theverge.com/rss/index.xml",  # Verified: starts with <?xml, has <feed>
    "wallpaper": "https://www.wallpaper.com/rss/",  # Re-verified in Round 7: starts with <?xml, valid RSS
    "steelcase": "https://www.steelcase.com/feed/",  # Verified: starts with <?xml
    "bmw_group_pressclub": "https://www.press.bmwgroup.com/global/rss",  # Verified: starts with <?xml
    "nikon_news": "https://www.nikon.com/company/rss/feeds/news.rss",  # Found via HTML <link> tag
    "philips_news_center": "https://www.philips.com/content/corporate/en_AA/feed.rss.xml?pageSize=15&startIndex=0&src=/content/corporate/en_AA/about/news/archive&sortMode=createdDate",  # Found via HTML <link> tag
    "panasonic_newsroom": "https://news.panasonic.com/global/rss/all/index.xml",  # Found from RSS page listing
    "microsoft_surface_blog": "https://blogs.windows.com/feed",  # Verified: starts with <?xml, has <rss> (intermittent Cloudflare)
}

# Already known valid RSS from task context (not part of the 50 to find)
KNOWN_VALID = {
    "samsung_global_newsroom": "https://news.samsung.com/global/feed",
    "lenovo_storyhub": "https://news.lenovo.com/feed/",
    "garmin_newsroom": "https://www.garmin.com/en-US/newsroom/feed/",
    "dezeen": "https://www.dezeen.com/feed/",
    "designboom": "https://www.designboom.com/feed/",
    "yanko_design": "https://www.yankodesign.com/feed/",
    "ithome": "https://www.ithome.com/rss/",
    "core77": "https://www.core77.com/rss.xml",
    "engadget": "https://www.engadget.com/rss.xml",
    "techcrunch": "https://techcrunch.com/feed/",
}

# Brands where no RSS feed was found after exhaustive testing
# Many of these sites are behind Cloudflare/firewall (403/000 errors) or simply don't offer RSS
NO_RSS_FOUND = [
    "sony_design",          # sony.com returns 403, presscentre.sony.eu returns 403
    "nothing_newsroom",     # Shopify-based, no RSS feed; all patterns return HTML or 404
    "teenage_engineering",   # No RSS found on any page
    "bang_olufsen",          # Next.js site, no RSS; ?feed=rss2 returns HTML
    "bose_press_room",       # Press room page has no RSS link
    "sonos_newsroom",        # newsroom.sonos.com returns custom XML (company info, not RSS feed)
    "logitech_newsroom",     # news.logitech.com returns 429 (rate limited); blog.logitech.com returns HTML
    "gopro_news",            # gopro.com returns 403 for all feed patterns
    "canon_global_news",     # global.canon has no RSS; canon-europe.com returns 403
    "fujifilm_news",         # fujifilm.com returns HTML for all feed paths
    "framework_blog",        # frame.work returns 403 for all feed patterns (Ghost CMS but blocked)
    "consumer",              # consumer.huawei.com returns HTML for all feed paths
    "mi",                    # blog.mi.com returns HTML for all feed paths (WordPress but returns HTML)
    "honor",                 # honor.com returns 1-byte response for .rss.xml/.atom.xml
    "oppo_newsroom",         # oppo.com returns HTML for all feed paths
    "vivo_news",             # vivo.com returns HTML for all feed paths
    "realme_newsroom",       # realme.com returns 404 for all feed paths
    "dji_media_center",      # dji.com returns 404 for all feed paths
    "insta360_blog",         # insta360.com/blog returns 404; blog.insta360.com returns HTML
    "anker_news",            # anker.com/blogs/news returns 404 for all feed patterns
    "dyson_newsroom",        # dyson.com returns 403 for all feed paths
    "braun",                 # braun.com returns HTML for all feed paths (Next.js site)
    "bosch_press_portal",    # bosch-presse.de times out (000); bosch.com returns 404
    "lg_newsroom",           # lgnewsroom.com times out (000) or returns 500
    "ikea_newsroom",         # IKEA uses Astro (static site), no RSS feed
    "design_milk",           # design-milk.com: TLS connection reset by peer (Cloudflare blocking)
    "fast_company_design",   # fastcompany.com: TLS connection reset / 403
    "new_atlas",             # newatlas.com: TLS connection reset / 404
    "herman_miller",         # hermanmiller.com: no RSS found on any page
    "vitra",                 # vitra.com: returns 403 for all feed paths
    "mercedes_benz_media",   # media.mercedes-benz.com: times out (000)
    "audi_mediacenter",      # audi-mediacenter.com: times out (000)
    "porsche_newsroom",      # newsroom.porsche.com: times out (000)
    "volvo_cars_media",      # media.volvocars.com: times out (000)
    "tesla",                 # tesla.com: times out (000) for all feed paths
    "toyota_global_newsroom", # global.toyota: 404 for all feed paths
    "honda_global_newsroom", # global.honda: 404 for all feed paths
]

# Build the output JSON list
# The 50 target brands from the task
TARGET_BRANDS = [
    "apple_newsroom", "sony_design", "google_blog_products", "microsoft_surface_blog",
    "meta_newsroom", "nothing_newsroom", "teenage_engineering", "bang_olufsen",
    "bose_press_room", "sonos_newsroom", "logitech_newsroom", "gopro_news",
    "leica_camera", "canon_global_news", "nikon_news", "fujifilm_news",
    "framework_blog", "consumer", "mi", "honor", "oppo_newsroom", "vivo_news",
    "realme_newsroom", "dji_media_center", "insta360_blog", "anker_news",
    "dyson_newsroom", "braun", "philips_news_center", "bosch_press_portal",
    "lg_newsroom", "panasonic_newsroom", "ikea_newsroom", "the_verge",
    "wallpaper", "design_milk", "fast_company_design", "new_atlas",
    "herman_miller", "vitra", "steelcase", "bmw_group_pressclub",
    "mercedes_benz_media", "audi_mediacenter", "porsche_newsroom",
    "volvo_cars_media", "tesla", "toyota_global_newsroom", "honda_global_newsroom",
]

output = []
for brand_id in TARGET_BRANDS:
    if brand_id in VERIFIED_FEEDS:
        output.append({
            "id": brand_id,
            "rss_url": VERIFIED_FEEDS[brand_id]
        })
    elif brand_id in NO_RSS_FOUND:
        output.append({
            "id": brand_id,
            "rss_url": "no_rss"
        })
    else:
        output.append({
            "id": brand_id,
            "rss_url": "no_rss"
        })

# Write the output JSON
output_path = "/home/ubuntu/workdir/daily-industrial-design-image-search/rss_feed_urls.json"
with open(output_path, "w") as f:
    json.dump(output, f, indent=2)

# Print summary
found_count = sum(1 for item in output if item["rss_url"] != "no_rss")
no_rss_count = sum(1 for item in output if item["rss_url"] == "no_rss")

print(f"Total brands: {len(output)}")
print(f"RSS feeds found: {found_count}")
print(f"No RSS found: {no_rss_count}")
print(f"\nResults saved to: {output_path}")
print(f"\n--- Found RSS Feeds ---")
for item in output:
    if item["rss_url"] != "no_rss":
        print(f"  {item['id']}: {item['rss_url']}")
print(f"\n--- No RSS Found ---")
for item in output:
    if item["rss_url"] == "no_rss":
        print(f"  {item['id']}")
