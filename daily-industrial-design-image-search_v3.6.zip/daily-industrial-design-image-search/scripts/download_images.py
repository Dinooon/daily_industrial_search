"""
Daily Industrial Design Image Search - Image Download Module (V2)
==================================================================
Handles downloading images from URLs to the cloud sandbox and generating
the Playwright script for local image transfer via screenshot method.

V2 Changes:
- Integrates HistoryManager for cross-run deduplication
- Only downloads products NOT already in history manifest
- Records new downloads to history manifest after successful download
- Supports both incremental mode (default) and full refresh mode

Usage:
    from download_images import ImageDownloader
    
    downloader = ImageDownloader(date="2026-07-15")
    
    # V2: Filter through history first
    new_products, dupes = downloader.filter_new_products(all_products)
    
    # Download only new products to cloud
    downloader.download_to_cloud(new_products)
    
    # Update history manifest
    downloader.update_history(new_products)
    
    # Generate local download script
    scripts = downloader.generate_local_download_script(local_dir)
"""

import os
import json
import requests
from datetime import datetime
from PIL import Image
from io import BytesIO
from urllib.parse import urlparse

# Add scripts directory to path for imports
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from history_manager import HistoryManager


class ImageDownloader:
    """Download images to cloud sandbox and generate local transfer scripts.
    
    V2: Includes history-based deduplication for incremental updates.
    """
    
    def __init__(self, date=None, base_dir="/home/ubuntu/daily_industrial_search", 
                 incremental=True):
        """
        Initialize the ImageDownloader.
        
        Args:
            date: Date string (YYYY-MM-DD). If None, uses today.
            base_dir: Base working directory.
            incremental: If True, use history dedup (only download new products).
                         If False, download all products (full refresh).
        """
        self.date = date or datetime.now().strftime("%Y-%m-%d")
        self.base_dir = base_dir
        self.temp_dir = os.path.join(base_dir, "temp_images", self.date)
        self.manifest = []
        self.incremental = incremental
        os.makedirs(self.temp_dir, exist_ok=True)
        
        # Initialize history manager
        self.history_manager = HistoryManager(base_dir=base_dir)
        if self.incremental:
            self.history_manager.load_history()
    
    def filter_new_products(self, product_list):
        """
        V2 NEW: Filter product list through history manifest.
        Returns only products not previously collected.
        
        Args:
            product_list: List of product dicts with 'page_url' key.
        
        Returns:
            Tuple of (new_products, duplicate_count)
        """
        if not self.incremental:
            print("  ⚠️ Incremental mode OFF — processing all products")
            return product_list, 0
        
        return self.history_manager.filter_new(product_list)
    
    def download_to_cloud(self, image_list):
        """
        Download images to cloud sandbox.
        
        Args:
            image_list: List of dicts with keys:
                - url: Image URL
                - product_id: Product identifier (e.g., "001")
                - image_index: Image number for this product (e.g., 1)
                - title: Product title
                - source: Source website name
                - page_url: Original article URL
        
        Returns:
            Path to download manifest JSON
        """
        for item in image_list:
            filename = f"{item['product_id']}_{item.get('image_index', 1)}.jpg"
            filepath = os.path.join(self.temp_dir, filename)
            
            try:
                headers = {
                    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
                }
                response = requests.get(item['url'], headers=headers, timeout=30)
                response.raise_for_status()
                
                img = Image.open(BytesIO(response.content))
                if img.mode in ('CMYK', 'RGBA', 'P'):
                    img = img.convert('RGB')
                img.save(filepath, 'JPEG', quality=90)
                
                self.manifest.append({
                    "filename": filename,
                    "product_id": item['product_id'],
                    "image_index": item.get('image_index', 1),
                    "title": item.get('title', ''),
                    "source": item.get('source', ''),
                    "original_url": item['url'],
                    "page_url": item.get('page_url', ''),
                    "cloud_path": filepath,
                    "size_bytes": os.path.getsize(filepath),
                    "status": "success"
                })
                print(f"  ✅ {filename} ({os.path.getsize(filepath) // 1024}KB)")
                
            except Exception as e:
                print(f"  ❌ {filename}: {e}")
                self.manifest.append({
                    "filename": filename,
                    "product_id": item['product_id'],
                    "image_index": item.get('image_index', 1),
                    "title": item.get('title', ''),
                    "source": item.get('source', ''),
                    "original_url": item['url'],
                    "page_url": item.get('page_url', ''),
                    "cloud_path": None,
                    "size_bytes": 0,
                    "status": "failed",
                    "error": str(e)
                })
        
        # Save manifest
        manifest_path = os.path.join(self.temp_dir, "download_manifest.json")
        with open(manifest_path, 'w', encoding='utf-8') as f:
            json.dump(self.manifest, f, ensure_ascii=False, indent=2)
        
        success_count = sum(1 for m in self.manifest if m["status"] == "success")
        print(f"\nDownload complete: {success_count}/{len(self.manifest)} images saved to {self.temp_dir}")
        return manifest_path
    
    def update_history(self, products, ai_data=None):
        """
        V2 NEW: Update the history manifest with newly processed products.
        Should be called after images are downloaded and AI analysis is complete.
        
        Args:
            products: List of product dicts that were processed.
            ai_data: Optional dict mapping product_id to AI analysis results.
        
        Returns:
            Number of products added to history.
        """
        if not self.incremental:
            print("  ⚠️ Incremental mode OFF — skipping history update")
            return 0
        
        # Merge AI data into products if provided
        if ai_data:
            for product in products:
                pid = product.get("product_id", "")
                if pid in ai_data:
                    product["ai_analysis"] = ai_data[pid]
        
        added = self.history_manager.add_products(products, run_date=self.date)
        self.history_manager.save_history()
        return added
    
    def generate_local_download_script(self, local_dir, batch_size=8):
        """
        Generate a JavaScript file for Playwright browser_run_code_unsafe
        to download images to the user's local machine via screenshot method.
        
        Args:
            local_dir: Local directory path
            batch_size: Number of images per batch
        
        Returns:
            List of JavaScript code strings (one per batch)
        """
        successful_items = [m for m in self.manifest if m["status"] == "success"]
        
        batches = []
        for i in range(0, len(successful_items), batch_size):
            batch = successful_items[i:i + batch_size]
            batches.append(batch)
        
        js_batches = []
        for batch_idx, batch in enumerate(batches):
            items_js = json.dumps([
                {"url": item["original_url"], "filename": item["filename"]}
                for item in batch
            ], indent=2)
            
            escaped_dir = local_dir.replace("\\", "\\\\")
            
            js_code = f"""async (page) => {{
  const items = {items_js};
n  const localDir = "{escaped_dir}";
  n  const results = [];
  for (const item of items) {{
    try {{
      await page.goto(item.url, {{ waitUntil: 'networkidle', timeout: 30000 }});
      await page.waitForTimeout(500);
      n      const imgElement = await page.$('img');
      if (imgElement) {{
        const fullPath = localDir + "\\\\" + item.filename;
        await imgElement.screenshot({{ path: fullPath }});
        results.push({{ filename: item.filename, success: true }});
      }} else {{
        results.push({{ filename: item.filename, success: false, error: 'No img element found' }});
      }}
    }} catch(e) {{
      results.push({{ filename: item.filename, success: false, error: e.message }});
    }}
  }}
  return JSON.stringify(results, null, 2);
}}"""
            js_batches.append(js_code)
        
        print(f"Generated {len(js_batches)} batch scripts ({len(successful_items)} images, {batch_size} per batch)")
        return js_batches
    
    def generate_local_html(self, html_template_path, local_dir):
        """
        Generate an HTML file that uses local relative image paths.
        
        Args:
            html_template_path: Path to the generated HTML file
            local_dir: Local directory where images are stored
        
        Returns:
            Path to the local HTML file
        """
        with open(html_template_path, 'r', encoding='utf-8') as f:
            html_content = f.read()
        
        for item in self.manifest:
            if item["status"] == "success":
                html_content = html_content.replace(item["original_url"], item["filename"])
        
        local_html_path = html_template_path.replace(".html", "_local.html")
        with open(local_html_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        print(f"Local HTML generated: {local_html_path} ({len(html_content)} bytes)")
        return local_html_path
    
    def get_history_stats(self):
        """V2 NEW: Return history statistics for display in HTML/report."""
        return self.history_manager.get_stats()


def transfer_html_to_local(html_content, local_path, chunk_size=13000):
    """
    Transfer HTML content to local machine via MCP write_file/edit_file.
    
    Args:
        html_content: Full HTML string
        local_path: Target local file path
        chunk_size: Max bytes per write operation
    
    Returns:
        List of (operation, content) tuples for sequential execution
    """
    chunks = []
    for i in range(0, len(html_content), chunk_size):
        chunks.append(html_content[i:i + chunk_size])
    
    operations = []
    for i, chunk in enumerate(chunks):
        if i == 0:
            operations.append(("write_file", local_path, chunk))
        else:
            operations.append(("edit_file", local_path, chunk))
    
    return operations


def load_subscription_sources():
    """
    V2 NEW: Load the subscription sources configuration.
    
    Returns:
        List of enabled subscription source dicts.
    """
    config_path = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "data", "subscription_sources.json"
    )
    
    if not os.path.exists(config_path):
        # Try alternate path (for cloud sandbox execution)
        config_path = "/home/ubuntu/skills/daily-industrial-design-image-search/data/subscription_sources.json"
    
    with open(config_path, 'r', encoding='utf-8') as f:
        config = json.load(f)
    
    enabled = [s for s in config["sources"] if s.get("enabled", True)]
    print(f"  📡 Loaded {len(enabled)} enabled subscription sources from {config_path}")
    return enabled, config.get("fallback_keywords", [])


if __name__ == "__main__":
    # Self-test
    print("=== ImageDownloader V2 Self-Test ===\n")
    
    # Test subscription sources loading
    sources, fallback_kw = load_subscription_sources()
    print(f"Enabled sources: {len(sources)}")
    for s in sources:
        print(f"  [{s['priority']}] {s['name']}: {s['url']}")
    print(f"Fallback keywords: {fallback_kw}")
    print()
    
    # Test history manager
    downloader = ImageDownloader(date="2026-07-15", incremental=True)
    
    # Test dedup
    test_products = [
        {"page_url": "https://test.com/product1", "title": "Test 1"},
        {"page_url": "https://test.com/product2", "title": "Test 2"},
        {"page_url": "https://test.com/product1", "title": "Duplicate"},  # Intra-batch dup
    ]
    new, dupes = downloader.filter_new_products(test_products)
    print(f"\nDedup test: {len(test_products)} input → {len(new)} new, {dupes} dupes")
    
    # History stats
    stats = downloader.get_history_stats()
    print(f"\nHistory stats: {stats['total_products']} products, {stats['total_runs']} runs")

