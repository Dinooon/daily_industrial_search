#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from integrations.feishu.publish_policy import build_publish_plan, plan_as_dict


def copy_unique(src: Path, dst_dir: Path) -> Path:
    dst_dir.mkdir(parents=True, exist_ok=True)
    target = dst_dir / src.name
    if target.exists() and target.resolve() != src.resolve():
        target = dst_dir / f'{src.stem}_{abs(hash(str(src))) & 0xffff:04x}{src.suffix}'
    shutil.copy2(src, target)
    return target


def main() -> int:
    parser = argparse.ArgumentParser(description='Build a clean Feishu release directory using a strict upload whitelist')
    parser.add_argument('--date', required=True)
    parser.add_argument('--html', required=True)
    parser.add_argument('--images', nargs='*', default=[])
    parser.add_argument('--summary')
    parser.add_argument('--archive-index')
    parser.add_argument('--internal-artifacts', nargs='*', default=[])
    parser.add_argument('--selection-manifests', nargs='*', default=[])
    parser.add_argument('--output-root', default='release/feishu')
    args = parser.parse_args()

    plan = build_publish_plan(
        daily_html=args.html,
        final_images=args.images,
        summary=args.summary,
        archive_index=args.archive_index,
        internal_artifacts=args.internal_artifacts,
        selection_manifests=args.selection_manifests,
    )

    root = Path(args.output_root).resolve()
    public_day = root / 'public' / '今日资讯' / args.date
    public_archive = root / 'public' / '历史归档'
    internal_day = root / 'internal' / args.date
    selection_dir = root / 'internal' / 'selection-manifests'
    if root.exists():
        shutil.rmtree(root)

    staged = []
    for item in plan:
        src = Path(item.path)
        if item.role == 'selection_manifest':
            dst = copy_unique(src, selection_dir)
        elif item.visibility == 'internal':
            dst = copy_unique(src, internal_day)
        elif item.role == 'final_image':
            dst = copy_unique(src, public_day / 'images')
        elif item.role == 'archive_index':
            dst = copy_unique(src, public_archive)
        else:
            dst = copy_unique(src, public_day)
        staged.append({**item.__dict__, 'staged_path': str(dst)})

    manifest = {
        'schema_version': '1.0',
        'date': args.date,
        'policy': 'strict_whitelist',
        'public_root': str(root / 'public'),
        'internal_root': str(root / 'internal'),
        'items': staged,
        'forbidden_recursive_upload': True,
    }
    root.mkdir(parents=True, exist_ok=True)
    (root / 'publish_manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
