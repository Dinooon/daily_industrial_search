from __future__ import annotations
import argparse, html, json
from pathlib import Path

LOGO='''<span class="brand-mark" aria-hidden="true"><svg viewBox="0 0 44 44"><rect class="frame ghost" x="5" y="5" width="24" height="24" rx="1"/><rect class="frame" x="15" y="15" width="24" height="24" rx="1"/><path class="axis" d="M10 34L34 10M22 8v28M8 22h28"/><circle class="node" cx="34" cy="10" r="2.2"/><circle class="node" cx="10" cy="34" r="2.2"/></svg></span>'''

CSS=r'''
:root{color-scheme:light dark;--bg:#f3f1ec;--surface:#fff;--surface2:#e9e6df;--text:#11110f;--muted:#73716b;--line:rgba(17,17,15,.13);--glass:rgba(243,241,236,.86);--shadow:0 22px 60px rgba(25,20,14,.13)}
@media(prefers-color-scheme:dark){:root{--bg:#080909;--surface:#111212;--surface2:#181a1a;--text:#f2f1ec;--muted:#96958f;--line:rgba(255,255,255,.11);--glass:rgba(8,9,9,.86);--shadow:0 24px 70px rgba(0,0,0,.42)}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font-family:Inter,"Noto Sans SC",system-ui,sans-serif}.topbar{position:fixed;inset:0 0 auto;height:76px;display:grid;grid-template-columns:1fr auto 1fr;align-items:center;padding:0 32px;background:var(--glass);backdrop-filter:blur(18px);border-bottom:1px solid var(--line);z-index:10}.brand{display:flex;align-items:center;gap:14px;font-weight:800;letter-spacing:-.04em}.brand-mark{width:40px;height:40px}.brand-mark svg{width:100%;height:100%}.frame,.axis{fill:none;stroke:currentColor;stroke-width:1.35}.node{fill:currentColor}.ghost{opacity:.34}.back{justify-self:center;color:inherit;text-decoration:none;text-transform:uppercase;font-size:11px;font-weight:700;letter-spacing:.12em}.page{max-width:1180px;margin:auto;padding:132px 28px 80px}.head{display:grid;grid-template-columns:1.35fr .65fr;gap:32px;align-items:end;margin-bottom:48px}.eyebrow{font-size:11px;font-weight:700;letter-spacing:.16em;color:var(--muted)}h1{font-size:clamp(54px,8vw,104px);line-height:.9;letter-spacing:-.07em;margin:16px 0 0}.copy{color:var(--muted);line-height:1.75;font-size:14px}.grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:24px}.card{color:inherit;text-decoration:none;background:var(--surface);border:1px solid var(--line);border-radius:14px;overflow:hidden;transition:.25s}.card:hover{transform:translateY(-5px);box-shadow:var(--shadow)}.cover{aspect-ratio:4/3;background:var(--surface2);overflow:hidden}.cover img{width:100%;height:100%;object-fit:cover;display:block;transition:.5s}.card:hover img{transform:scale(1.025)}.meta{display:flex;justify-content:space-between;align-items:center;padding:17px}.meta span{font-size:17px;font-weight:750}.meta strong{font-size:10px;letter-spacing:.12em;color:var(--muted)}.note{margin-top:42px;padding-top:22px;border-top:1px solid var(--line);font-size:11px;letter-spacing:.06em;color:var(--muted)}@media(max-width:760px){.topbar{grid-template-columns:1fr auto}.brand span:last-child{display:none}.topbar>div:last-child{display:none}.head{grid-template-columns:1fr}.grid{grid-template-columns:1fr}}
'''

def generate(rows:list[dict], output:Path):
    cards=[]
    for row in rows:
        month=html.escape(str(row.get('month','Unknown')))
        href=html.escape(str(row.get('href','#')),quote=True)
        cover=html.escape(str(row.get('cover','')),quote=True)
        count=int(row.get('count',0))
        img=f'<img src="{cover}" alt="{month}" loading="lazy">' if cover else ''
        cards.append(f'<a class="card" href="{href}"><div class="cover">{img}</div><div class="meta"><span>{month}</span><strong>{count} ITEMS</strong></div></a>')
    root=Path(__file__).resolve().parents[1]
    doc=(root/'templates'/'archive_index.html.j2').read_text(encoding='utf-8')
    values={'{{CSS}}':CSS,'{{LOGO}}':LOGO,'{{TODAY_HREF}}':'../demo/daily_gallery.html' if 'demo' not in output.parts else '../daily_gallery.html','{{CARDS}}':''.join(cards)}
    for token,value in values.items(): doc=doc.replace(token,value)
    output.parent.mkdir(parents=True,exist_ok=True); output.write_text(doc,encoding='utf-8')

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--months',required=True);ap.add_argument('--output',required=True);a=ap.parse_args()
    generate(json.loads(Path(a.months).read_text(encoding='utf-8')),Path(a.output))
