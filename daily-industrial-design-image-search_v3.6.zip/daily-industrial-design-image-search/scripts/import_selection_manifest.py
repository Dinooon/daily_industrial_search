#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from integrations.feishu.bitable_sync import upsert_products
from integrations.feishu.client import FeishuClient
from integrations.feishu.selection_sync import apply_selection_manifest, choose_latest_manifest, load_selection_manifest


def load_products(path: Path):
    payload = json.loads(path.read_text(encoding="utf-8"))
    return payload, payload.get("products", payload) if isinstance(payload, dict) else payload


def main() -> int:
    ap = argparse.ArgumentParser(description="Import the latest browser-exported selection manifest and update product state/Bitable")
    ap.add_argument("--products", required=True)
    ap.add_argument("--selection-manifest", nargs="+", required=True, help="One or more manifests downloaded from Feishu Drive; newest exported_at wins")
    ap.add_argument("--output", required=True)
    ap.add_argument("--sync-feishu", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    latest = choose_latest_manifest(args.selection_manifest)
    manifest = load_selection_manifest(latest)
    raw, products = load_products(Path(args.products))
    result = apply_selection_manifest(products, manifest)
    output_payload = dict(raw) if isinstance(raw, dict) else {"products": result.products}
    output_payload["products"] = result.products
    output_payload["selection_sync"] = {
        "manifest": str(latest), "report_id": manifest["report_id"], "mode": result.mode,
        "selected_ids": result.selected_ids, "changed_ids": result.changed_ids, "missing_ids": result.missing_ids,
    }

    if args.dry_run:
        print(json.dumps(output_payload["selection_sync"], ensure_ascii=False, indent=2))
        return 0

    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    Path(args.output).write_text(json.dumps(output_payload, ensure_ascii=False, indent=2), encoding="utf-8")

    sync = None
    if args.sync_feishu:
        client = FeishuClient(os.getenv("FEISHU_APP_ID", ""), os.getenv("FEISHU_APP_SECRET", ""))
        sync = upsert_products(
            client,
            os.getenv("FEISHU_BITABLE_APP_TOKEN", ""),
            os.getenv("FEISHU_PRODUCT_TABLE_ID", ""),
            result.products,
            selection_only=True,
        )
    print(json.dumps({"output": args.output, "selection_sync": output_payload["selection_sync"], "bitable_sync": sync}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
