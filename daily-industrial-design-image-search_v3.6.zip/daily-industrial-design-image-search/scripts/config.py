"""
Daily Industrial Design Image Search - Configuration (V2 - Subscription + Incremental)
======================================================================================
Centralized configuration for the daily industrial design image search workflow.
V2 adds: Fixed URL subscription sources, history manifest for incremental updates,
and archive HTML generation.

Key Changes from V1:
- SEARCH_KEYWORDS replaced by SUBSCRIPTION_SOURCES (fixed URLs)
- New: HISTORY_MANIFEST_PATH for cross-run deduplication
- New: ARCHIVE_HTML output (cumulative product archive)
- New: INCREMENTAL_MODE flag (can be disabled for full refresh)
"""

import os
from datetime import datetime

# ============================================================
# PATHS
# ============================================================

# Cloud sandbox base paths (5-partition architecture)
SANDBOX_BASE = "/home/ubuntu/daily_industrial_search"

# Partition 1: scripts/ — execution scripts (per-date subdirectories)
SCRIPTS_DIR = os.path.join(SANDBOX_BASE, "scripts")

# Partition 2: data/ — collected data, manifests, history (per-date subdirectories)
DATA_DIR = os.path.join(SANDBOX_BASE, "data")

# Partition 3: temp_images/ — downloaded images for AI analysis (per-date subdirectories)
TEMP_IMAGES_DIR = os.path.join(SANDBOX_BASE, "temp_images")

# Partition 4: output/ — generated HTML reports (per-date subdirectories)
OUTPUT_DIR = os.path.join(SANDBOX_BASE, "output")

# Partition 5: screenshots/ — verification screenshots (per-date subdirectories)
SCREENSHOTS_DIR = os.path.join(SANDBOX_BASE, "screenshots")

# SKILL package paths (source scripts, configs, references)
SKILL_BASE = "/home/ubuntu/skills/daily-industrial-design-image-search"
SKILL_SCRIPTS_DIR = os.path.join(SKILL_BASE, "scripts")
SKILL_DATA_DIR = os.path.join(SKILL_BASE, "data")
SKILL_REFERENCES_DIR = os.path.join(SKILL_BASE, "references")

# Local paths (discovered at runtime via mcp_beta_local_list_allowed_directories)
# Typical: C:\Users\{username}\DJ_Beta\daly image search\{date}\
LOCAL_BASE_NAME = "daly image search"

# ============================================================
# SUBSCRIPTION & HISTORY PATHS (V2 NEW)
# ============================================================

# Subscription sources config (fixed URL list to visit each run)
SUBSCRIPTION_SOURCES_PATH = os.path.join(SKILL_DATA_DIR, "subscription_sources.json")

# History manifest (persistent record of all collected products)
HISTORY_MANIFEST_PATH = os.path.join(DATA_DIR, "history_manifest.json")

# Archive HTML (cumulative product archive, appended each run)
ARCHIVE_HTML_PATH = os.path.join(OUTPUT_DIR, "archive_master.html")

# ============================================================
# DATE
# ============================================================

TODAY = datetime.now().strftime("%Y-%m-%d")
TODAY_DISPLAY = datetime.now().strftime("%Y年%m月%d日")
TODAY_COMPACT = datetime.now().strftime("%Y%m%d")

# ============================================================
# INCREMENTAL MODE (V2 NEW)
# ============================================================

# When True: only process new products not in history
# When False: process all products (full refresh, ignores history)
INCREMENTAL_MODE = True

# When True: if subscription sources yield zero new products,
# fall back to keyword search as discovery mechanism
FALLBACK_TO_KEYWORD_SEARCH = True

# ============================================================
# SUBSCRIPTION SOURCES (V2 NEW - replaces SEARCH_KEYWORDS)
# ============================================================

# Fixed URL subscription sources are loaded from subscription_sources.json
# See SUBSCRIPTION_SOURCES_PATH above.
# 
# Fallback keywords (only used when all subscription sources return 0 new products)
FALLBACK_SEARCH_KEYWORDS = [
    "industrial design product 2026",
    f"product design innovation {datetime.now().strftime('%B')} 2026",
    "industrial design award 2026",
    "consumer electronics design 2026",
    "furniture design new 2026",
    "sustainable product design 2026",
]

# Legacy search keywords (kept for backward compatibility / full refresh mode)
SEARCH_KEYWORDS = [
    "industrial design product 2026",
    "product design innovation July 2026",
    "industrial design award 2026",
    "consumer electronics design 2026",
    "furniture design new 2026",
    "transportation design 2026",
    "sustainable product design 2026",
    "smart home device design 2026",
]

# ============================================================
# INFORMATION SOURCES (for reference / fallback)
# ============================================================

SOURCES = {
    "P0": [
        {"name": "Core77", "url": "https://core77.com", "type": "articles"},
        {"name": "Yanko Design", "url": "https://yankodesign.com", "type": "js_rendered"},
    ],
    "P1": [
        {"name": "Designboom", "url": "https://designboom.com", "type": "articles"},
        {"name": "LeManoosh", "url": "https://lemanoosh.com", "type": "gallery"},
    ],
    "P2": [
        {"name": "Red Dot", "url": "https://red-dot.org", "type": "awards"},
        {"name": "iF Design", "url": "https://ifdesign.com", "type": "awards"},
        {"name": "Behance", "url": "https://behance.net", "type": "gallery"},
    ],
}

# ============================================================
# IMAGE CLASSIFICATION CATEGORIES
# ============================================================

CATEGORIES = {
    "consumer_electronics": {
        "label": "消费电子",
        "label_en": "Consumer Electronics",
        "icon": "📱",
        "subcategories": ["Smartphones", "Audio", "Wearables", "Cameras", "Gaming"]
    },
    "furniture_lighting": {
        "label": "家具照明",
        "label_en": "Furniture & Lighting",
        "icon": "🪑",
        "subcategories": ["Seating", "Tables", "Lighting", "Storage", "Outdoor"]
    },
    "transportation": {
        "label": "交通工具",
        "label_en": "Transportation",
        "icon": "🚗",
        "subcategories": ["Automotive", "Bicycles", "Micro-mobility", "Marine", "Aero"]
    },
    "home_appliances": {
        "label": "家用电器",
        "label_en": "Home Appliances",
        "icon": "🏠",
        "subcategories": ["Kitchen", "Cleaning", "Climate", "Personal Care"]
    },
    "tools_equipment": {
        "label": "工具设备",
        "label_en": "Tools & Equipment",
        "icon": "🔧",
        "subcategories": ["Power Tools", "Hand Tools", "Medical", "Industrial"]
    },
    "sustainable_design": {
        "label": "可持续设计",
        "label_en": "Sustainable Design",
        "icon": "🌱",
        "subcategories": ["Recycled", "Biodegradable", "Energy", "Water"]
    },
    "wearable_tech": {
        "label": "可穿戴设备",
        "label_en": "Wearable Tech",
        "icon": "⌚",
        "subcategories": ["Smartwatches", "Health Monitors", "AR/VR", "Fashion Tech"]
    },
    "kitchen_tableware": {
        "label": "厨房餐厨",
        "label_en": "Kitchen & Tableware",
        "icon": "🍽️",
        "subcategories": ["Cookware", "Tableware", "Small Appliances", "Storage"]
    },
    "medical_health": {
        "label": "医疗健康",
        "label_en": "Medical & Health",
        "icon": "⚕️",
        "subcategories": ["Diagnostic", "Therapeutic", "Rehabilitation", "Wellness"]
    },
    "sports_outdoors": {
        "label": "户外运动",
        "label_en": "Sports & Outdoors",
        "icon": "⚽",
        "subcategories": ["Camping", "Fitness", "Water Sports", "Winter Sports"]
    },
    "commercial_equipment": {
        "label": "工业设备",
        "label_en": "Commercial Equipment",
        "icon": "🏭",
        "subcategories": ["Industrial", "Lab Equipment", "Retail", "Hospitality"]
    },
}

# ============================================================
# AI ANALYSIS
# ============================================================

AI_CONFIDENCE_THRESHOLD = 0.60  # Below this, mark as "pending"

AI_ANALYSIS_PROMPT = """Analyze this industrial design product image. Provide:
1. Product category (from: consumer_electronics, furniture_lighting, transportation, 
   home_appliances, tools_equipment, sustainable_design, wearable_tech, 
   kitchen_tableware, medical_health, sports_outdoors, commercial_equipment)
2. Subcategory
3. Design style (e.g., minimalist, retro-futuristic, biomimetic, brutalist)
4. Key materials (e.g., aluminum, bamboo, recycled plastic)
5. Notable design features (1-2 sentences)
6. Target user profile
7. Confidence score (0.0-1.0)

Return as JSON:
{"category": "...", "subcategory": "...", "style": "...", "materials": "...", 
 "features": "...", "target_user": "...", "confidence": 0.0}
"""

# ============================================================
# DEDUPLICATION
# ============================================================

PHASH_THRESHOLD = 5  # Hamming distance threshold for perceptual hash dedup

# ============================================================
# HTML TEMPLATE (V2)
# ============================================================

# Design system constants
DESIGN_SYSTEM = {
    "bg_primary": "#0a0b0e",
    "bg_secondary": "#13151a",
    "bg_card": "#16181e",
    "bg_card_hover": "#1c1f26",
    "accent_gold": "#c8a96a",
    "accent_gold_dim": "#8a7449",
    "accent_gold_light": "#d4b87a",
    "text_primary": "#e8e6e1",
    "text_secondary": "#9a958c",
    "text_tertiary": "#5c5852",
    "border_subtle": "rgba(200, 169, 106, 0.12)",
    "border_active": "rgba(200, 169, 106, 0.4)",
    "font_heading": "'Space Grotesk', sans-serif",
    "font_body": "'Noto Sans SC', sans-serif",
    "font_mono": "'JetBrains Mono', monospace",
    "radius_large": "20px",
    "radius_medium": "14px",
    "radius_small": "8px",
    "shadow_card": "0 8px 32px rgba(0, 0, 0, 0.4)",
    "shadow_hover": "0 12px 48px rgba(200, 169, 106, 0.15)",
    "transition": "cubic-bezier(0.22, 1, 0.36, 1)",
    "transition_fast": "cubic-bezier(0.4, 0, 0.2, 1)",
}

# Google Fonts URL
GOOGLE_FONTS_URL = "https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=Noto+Sans+SC:wght@300;400;500;700&family=JetBrains+Mono:wght@400;500&display=swap"

# ============================================================
# PLAYWRIGHT DOWNLOAD CONFIG
# ============================================================

DOWNLOAD_BATCH_SIZE = 8
DOWNLOAD_TIMEOUT = 30000
SCREENSHOT_DELAY = 500

# ============================================================
# PATH HELPER FUNCTIONS (V2)
# ============================================================

def get_date_path(partition, date=None):
    """
    Get the date-specific path for a given partition.
    
    Args:
        partition: One of 'scripts', 'data', 'temp_images', 'output', 'screenshots'
        date: Date string (YYYY-MM-DD). If None, uses today.
    
    Returns:
        Full path string
    """
    date = date or TODAY
    partition_map = {
        "scripts": SCRIPTS_DIR,
        "data": DATA_DIR,
        "temp_images": TEMP_IMAGES_DIR,
        "output": OUTPUT_DIR,
        "screenshots": SCREENSHOTS_DIR,
    }
    base = partition_map.get(partition, DATA_DIR)
    return os.path.join(base, date)


def ensure_directory(path):
    """Ensure a directory exists, create if needed."""
    os.makedirs(path, exist_ok=True)
    return path


def ensure_all_directories(date=None):
    """Ensure all 5 partition directories + date subdirectories exist."""
    date = date or TODAY
    for partition in ["scripts", "data", "temp_images", "output", "screenshots"]:
        ensure_directory(get_date_path(partition, date))
    # Also ensure base data dir exists (for history_manifest.json)
    ensure_directory(DATA_DIR)
    print(f"  ✅ All directories ensured for {date}")


def get_subscription_sources_path():
    """Return path to subscription_sources.json."""
    return SUBSCRIPTION_SOURCES_PATH


def get_history_manifest_path():
    """Return path to history_manifest.json."""
    return HISTORY_MANIFEST_PATH


def get_archive_html_path():
    """Return path to archive_master.html (cumulative product archive)."""
    return ARCHIVE_HTML_PATH


def get_daily_html_path(date=None):
    """Return path to the daily review HTML for a given date."""
    date = date or TODAY
    return os.path.join(get_date_path("output", date), f"daily_review_{date}.html")


def get_download_manifest_path(date=None):
    """Return path to the download manifest for a given date."""
    date = date or TODAY
    return os.path.join(get_date_path("temp_images", date), "download_manifest.json")


def get_ai_data_path(date=None):
    """Return path to the AI analysis data JSON for a given date."""
    date = date or TODAY
    return os.path.join(get_date_path("data", date), "ai_analysis.json")


def get_collected_data_path(date=None):
    """Return path to the collected raw data markdown for a given date."""
    date = date or TODAY
    return os.path.join(get_date_path("data", date), "collected_data.md")


# ============================================================
# SELF-TEST
# ============================================================

if __name__ == "__main__":
    print("=== Configuration V2 Self-Test ===\n")
    
    print(f"TODAY: {TODAY}")
    print(f"INCREMENTAL_MODE: {INCREMENTAL_MODE}")
    print(f"FALLBACK_TO_KEYWORD_SEARCH: {FALLBACK_TO_KEYWORD_SEARCH}")
    print()
    
    print("Path Configuration:")
    print(f"  SANDBOX_BASE: {SANDBOX_BASE}")
    print(f"  SUBSCRIPTION_SOURCES_PATH: {SUBSCRIPTION_SOURCES_PATH}")
    print(f"  HISTORY_MANIFEST_PATH: {HISTORY_MANIFEST_PATH}")
    print(f"  ARCHIVE_HTML_PATH: {ARCHIVE_HTML_PATH}")
    print(f"  Daily HTML: {get_daily_html_path()}")
    print(f"  Download manifest: {get_download_manifest_path()}")
    print(f"  AI data: {get_ai_data_path()}")
    print(f"  Collected data: {get_collected_data_path()}")
    print()
    
    print("Categories:")
    for cat_id, cat_info in CATEGORIES.items():
        print(f"  {cat_id}: {cat_info['label']} ({cat_info['label_en']}) {cat_info['icon']}")
    print()
    
    # Test directory creation
    print("Directory Creation Test:")
    ensure_all_directories()
    for partition in ["scripts", "data", "temp_images", "output", "screenshots"]:
        path = get_date_path(partition)
        exists = os.path.exists(path)
        print(f"  {partition}/{TODAY}: {'✅' if exists else '❌'} {path}")

