#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from integrations.feishu import FeishuClient, FeishuPublisher
from integrations.feishu.publish_policy import build_publish_plan, plan_as_dict
from integrations.feishu.selection_sync import apply_selection_manifest, load_selection_manifest


def load_json(path: str | Path):
    with Path(path).open('r', encoding='utf-8') as f:
        return json.load(f)


def main() -> int:
    parser = argparse.ArgumentParser(description='Publish final image-search outputs to Feishu with a strict whitelist')
    parser.add_argument('--products', required=True, help='Product JSON or download manifest')
    parser.add_argument('--date', required=True)
    parser.add_argument('--html', required=True, help='Final daily HTML gallery; required')
    parser.add_argument('--images', nargs='*', default=[], help='Final image files or a final-images directory')
    parser.add_argument('--summary', help='Public daily summary (.md/.txt)')
    parser.add_argument('--archive-index', help='Public archive index HTML')
    parser.add_argument('--internal-artifacts', nargs='*', default=[], help='Explicit audit JSON/log files only')
    parser.add_argument('--selection-manifest', help='Latest selection manifest downloaded from Feishu Drive')
    parser.add_argument('--gallery-url', default='')
    parser.add_argument('--bitable-url', default='')
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()

    raw = load_json(args.products)
    products = raw.get('products', raw) if isinstance(raw, dict) else raw
    config = {
        'root_folder_token': os.getenv('FEISHU_ROOT_FOLDER_TOKEN', ''),
        'daily_folder_token': os.getenv('FEISHU_PUBLIC_DAILY_FOLDER_TOKEN', '') or os.getenv('FEISHU_DAILY_FOLDER_TOKEN', ''),
        'archive_folder_token': os.getenv('FEISHU_PUBLIC_ARCHIVE_FOLDER_TOKEN', '') or os.getenv('FEISHU_ARCHIVE_FOLDER_TOKEN', ''),
        'internal_folder_token': os.getenv('FEISHU_INTERNAL_FOLDER_TOKEN', ''),
        'selection_folder_token': os.getenv('FEISHU_SELECTION_FOLDER_TOKEN', ''),
        'bitable_app_token': os.getenv('FEISHU_BITABLE_APP_TOKEN', ''),
        'product_table_id': os.getenv('FEISHU_PRODUCT_TABLE_ID', ''),
    }

    if args.selection_manifest:
        selection = load_selection_manifest(args.selection_manifest)
        products = apply_selection_manifest(products, selection).products

    plan = build_publish_plan(
        daily_html=args.html,
        final_images=args.images,
        summary=args.summary,
        archive_index=args.archive_index,
        internal_artifacts=args.internal_artifacts,
        selection_manifests=[args.selection_manifest] if args.selection_manifest else [],
    )

    if args.dry_run:
        from integrations.feishu.schemas import product_to_fields, remove_empty_fields
        preview = {
            'date': args.date,
            'policy': 'strict_whitelist',
            'product_count': len(products),
            'records': [remove_empty_fields(product_to_fields(p, args.gallery_url)) for p in products[:3]],
            'publish_plan': plan_as_dict(plan),
            'explicitly_forbidden': ['scripts/', 'templates/', 'tests/', 'temp_images/', 'screenshots/', '.env', 'history_manifest.json'],
        }
        print(json.dumps(preview, ensure_ascii=False, indent=2))
        return 0

    client = FeishuClient(os.getenv('FEISHU_APP_ID', ''), os.getenv('FEISHU_APP_SECRET', ''))
    publisher = FeishuPublisher(client, config)
    uploaded = publisher.upload_publish_plan(plan)
    sync = publisher.sync_products(products, args.gallery_url)
    doc = publisher.create_daily_doc(args.date, products, args.gallery_url, args.bitable_url)
    print(json.dumps({'uploaded': uploaded, 'sync': sync, 'doc': doc}, ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
