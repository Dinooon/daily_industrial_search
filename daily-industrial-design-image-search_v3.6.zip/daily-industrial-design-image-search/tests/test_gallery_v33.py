from pathlib import Path


def test_v34_canonical_demo_features():
    root=Path(__file__).resolve().parents[1]
    text=(root/'output/demo/daily_gallery.html').read_text(encoding='utf-8')
    assert 'INDUSTRIAL DESIGN DAILY' in text
    assert 'Industrial' in text and 'Design Gallery' in text
    assert 'data-nav="archive"' in text
    assert 'archive/index.html' in text
    assert 'data-theme-choice="system"' in text
    assert 'archive_master.html' not in text


def test_legacy_outputs_removed():
    root=Path(__file__).resolve().parents[1]
    assert not (root/'output/archive_master.html').exists()
    assert not list((root/'output').glob('industrial_editorial_gallery_demo*.html'))
