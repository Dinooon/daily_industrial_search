import json
from pathlib import Path

from integrations.feishu.selection_sync import apply_selection_manifest, choose_latest_manifest, validate_selection_manifest


def sample(exported_at="2026-07-29T08:00:00+00:00"):
    return {
        "schema_version": "1.0",
        "report_id": "daily-2026-07-29",
        "report_date": "2026-07-29",
        "exported_at": exported_at,
        "mode": "merge_selected",
        "report_product_ids": ["p1", "p2"],
        "selected_products": [{"product_id": "p1", "retained": True}],
    }


def test_apply_merge_selected_preserves_absent():
    products = [{"product_id": "p1", "keep": False}, {"product_id": "p2", "keep": True}]
    result = apply_selection_manifest(products, sample())
    by_id = {p["product_id"]: p for p in result.products}
    assert by_id["p1"]["keep"] is True
    assert by_id["p2"]["keep"] is True
    assert result.selected_ids == ["p1"]


def test_latest_manifest_uses_exported_at(tmp_path: Path):
    old = tmp_path / "old_selection_manifest.json"
    new = tmp_path / "new_selection_manifest.json"
    old.write_text(json.dumps(sample("2026-07-28T08:00:00+00:00")), encoding="utf-8")
    new.write_text(json.dumps(sample("2026-07-29T08:00:00+00:00")), encoding="utf-8")
    assert choose_latest_manifest([old, new]) == new


def test_manifest_validation():
    validate_selection_manifest(sample())
