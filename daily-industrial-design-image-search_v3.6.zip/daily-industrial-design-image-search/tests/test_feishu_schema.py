from integrations.feishu.schemas import product_to_fields, remove_empty_fields


def test_product_to_fields_keeps_image_and_review_metadata():
    product = {
        "product_id": "p-1",
        "title": "Lamp",
        "page_url": "https://example.com/article",
        "original_url": "https://example.com/image.jpg",
        "source": "Example",
        "ai_analysis": {"category_label": "家具照明", "confidence": 0.8},
    }
    fields = remove_empty_fields(product_to_fields(product, "https://example.com/report"))
    assert fields["产品ID"] == "p-1"
    assert fields["图片链接"]["link"].endswith("image.jpg")
    assert fields["审核状态"] == "待审核"
    assert fields["日报链接"]["link"].endswith("report")
