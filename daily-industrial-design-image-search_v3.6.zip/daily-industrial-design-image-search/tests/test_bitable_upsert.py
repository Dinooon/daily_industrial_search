from integrations.feishu.bitable_sync import upsert_products


class FakeClient:
    def __init__(self):
        self.created=[]; self.updated=[]
    def list_bitable_records(self, app_token, table_id, page_size=100, page_token=""):
        return {"data":{"items":[{"record_id":"rec1","fields":{"产品ID":"p1","审核状态":"已确认","是否保留":True,"内部点评":"人工"}}],"has_more":False}}
    def batch_create_bitable_records(self, app_token, table_id, records):
        self.created.extend(records); return {"ok":True}
    def batch_update_bitable_records(self, app_token, table_id, records):
        self.updated.extend(records); return {"ok":True}


def test_upsert_preserves_human_fields():
    client=FakeClient()
    result=upsert_products(client,"app","table",[{"product_id":"p1","title":"New","keep":False,"selection_state_source":"selection_manifest"},{"product_id":"p2","title":"Second"}])
    assert result["created"] == 1
    assert result["updated"] == 1
    fields=client.updated[0]["fields"]
    assert "审核状态" not in fields
    assert "内部点评" not in fields
    assert "是否保留" not in fields
