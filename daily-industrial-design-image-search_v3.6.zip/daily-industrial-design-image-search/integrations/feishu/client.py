from __future__ import annotations

import json
import mimetypes
import time
from pathlib import Path
from typing import Any, Dict, Iterable, Optional

import requests


class FeishuAPIError(RuntimeError):
    pass


class FeishuClient:
    """Small Feishu Open Platform client with token caching and retries."""

    BASE_URL = "https://open.feishu.cn/open-apis"

    def __init__(self, app_id: str, app_secret: str, timeout: int = 30, max_retries: int = 3):
        if not app_id or not app_secret:
            raise ValueError("FEISHU_APP_ID and FEISHU_APP_SECRET are required")
        self.app_id = app_id
        self.app_secret = app_secret
        self.timeout = timeout
        self.max_retries = max_retries
        self._token: Optional[str] = None
        self._token_expiry = 0.0
        self.session = requests.Session()

    def tenant_access_token(self) -> str:
        if self._token and time.time() < self._token_expiry - 120:
            return self._token
        response = self.session.post(
            f"{self.BASE_URL}/auth/v3/tenant_access_token/internal",
            json={"app_id": self.app_id, "app_secret": self.app_secret},
            timeout=self.timeout,
        )
        payload = response.json()
        if response.status_code >= 400 or payload.get("code", 0) != 0:
            raise FeishuAPIError(f"token request failed: {response.status_code} {payload}")
        self._token = payload["tenant_access_token"]
        self._token_expiry = time.time() + int(payload.get("expire", 7200))
        return self._token

    def request(self, method: str, path: str, *, params=None, json_body=None, files=None, data=None) -> Dict[str, Any]:
        url = path if path.startswith("http") else f"{self.BASE_URL}{path}"
        last_error: Optional[Exception] = None
        for attempt in range(self.max_retries):
            try:
                headers = {"Authorization": f"Bearer {self.tenant_access_token()}"}
                response = self.session.request(
                    method,
                    url,
                    headers=headers,
                    params=params,
                    json=json_body,
                    files=files,
                    data=data,
                    timeout=self.timeout,
                )
                try:
                    payload = response.json()
                except ValueError:
                    payload = {"raw": response.text}
                if response.status_code == 429 or response.status_code >= 500:
                    time.sleep(min(2 ** attempt, 8))
                    continue
                if response.status_code >= 400 or payload.get("code", 0) != 0:
                    raise FeishuAPIError(f"{method} {path} failed: {response.status_code} {payload}")
                return payload
            except (requests.RequestException, FeishuAPIError) as exc:
                last_error = exc
                if attempt + 1 < self.max_retries:
                    time.sleep(min(2 ** attempt, 8))
                    continue
                raise
        raise FeishuAPIError(str(last_error))

    def upload_file(self, file_path: str | Path, parent_node: str, parent_type: str = "explorer") -> Dict[str, Any]:
        path = Path(file_path)
        mime = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        with path.open("rb") as stream:
            files = {"file": (path.name, stream, mime)}
            data = {
                "file_name": path.name,
                "parent_type": parent_type,
                "parent_node": parent_node,
                "size": str(path.stat().st_size),
            }
            return self.request("POST", "/drive/v1/files/upload_all", files=files, data=data)

    def create_doc(self, title: str, folder_token: Optional[str] = None) -> Dict[str, Any]:
        body: Dict[str, Any] = {"title": title}
        if folder_token:
            body["folder_token"] = folder_token
        return self.request("POST", "/docx/v1/documents", json_body=body)

    def append_doc_blocks(self, document_id: str, parent_block_id: str, children: Iterable[Dict[str, Any]]) -> Dict[str, Any]:
        return self.request(
            "POST",
            f"/docx/v1/documents/{document_id}/blocks/{parent_block_id}/children",
            json_body={"children": list(children), "index": -1},
        )

    def list_bitable_records(self, app_token: str, table_id: str, page_size: int = 100, page_token: str = "") -> Dict[str, Any]:
        params = {"page_size": page_size}
        if page_token:
            params["page_token"] = page_token
        return self.request(
            "GET",
            f"/bitable/v1/apps/{app_token}/tables/{table_id}/records",
            params=params,
        )

    def batch_create_bitable_records(self, app_token: str, table_id: str, records: Iterable[Dict[str, Any]]) -> Dict[str, Any]:
        return self.request(
            "POST",
            f"/bitable/v1/apps/{app_token}/tables/{table_id}/records/batch_create",
            json_body={"records": list(records)},
        )

    def batch_update_bitable_records(self, app_token: str, table_id: str, records: Iterable[Dict[str, Any]]) -> Dict[str, Any]:
        return self.request(
            "POST",
            f"/bitable/v1/apps/{app_token}/tables/{table_id}/records/batch_update",
            json_body={"records": list(records)},
        )
