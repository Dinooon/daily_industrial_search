from __future__ import annotations

import json
from copy import deepcopy
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping


class SelectionManifestError(ValueError):
    pass


@dataclass(frozen=True)
class SelectionResult:
    products: List[Dict[str, Any]]
    selected_ids: List[str]
    changed_ids: List[str]
    missing_ids: List[str]
    mode: str


def load_selection_manifest(path: str | Path) -> Dict[str, Any]:
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    validate_selection_manifest(payload)
    return payload


def validate_selection_manifest(payload: Mapping[str, Any]) -> None:
    required = {"schema_version", "report_id", "report_date", "exported_at", "mode", "selected_products"}
    missing = sorted(required - set(payload))
    if missing:
        raise SelectionManifestError(f"选择清单缺少字段: {', '.join(missing)}")
    if payload.get("schema_version") != "1.0":
        raise SelectionManifestError("仅支持 selection manifest schema_version=1.0")
    if payload.get("mode") not in {"merge_selected", "replace_report"}:
        raise SelectionManifestError("mode 必须是 merge_selected 或 replace_report")
    selected = payload.get("selected_products")
    if not isinstance(selected, list):
        raise SelectionManifestError("selected_products 必须是数组")
    ids = []
    for item in selected:
        if not isinstance(item, dict) or not item.get("product_id"):
            raise SelectionManifestError("每个选择项必须包含 product_id")
        if item.get("retained") is not True:
            raise SelectionManifestError("selected_products 中 retained 必须为 true")
        ids.append(str(item["product_id"]))
    if len(ids) != len(set(ids)):
        raise SelectionManifestError("selected_products 中存在重复 product_id")
    if payload.get("mode") == "replace_report" and not isinstance(payload.get("report_product_ids"), list):
        raise SelectionManifestError("replace_report 模式必须包含 report_product_ids")


def apply_selection_manifest(products: Iterable[Dict[str, Any]], manifest: Mapping[str, Any]) -> SelectionResult:
    validate_selection_manifest(manifest)
    rows = [deepcopy(p) for p in products]
    selected_ids = {str(x["product_id"]) for x in manifest["selected_products"]}
    report_ids = {str(x) for x in manifest.get("report_product_ids", [])}
    by_id = {str(p.get("product_id", "")): p for p in rows if p.get("product_id")}
    changed: List[str] = []
    exported_at = str(manifest["exported_at"])

    for pid in selected_ids:
        product = by_id.get(pid)
        if not product:
            continue
        if not bool(product.get("keep", False)):
            changed.append(pid)
        product["keep"] = True
        product["retained"] = True
        product["selection_state_source"] = "selection_manifest"
        product["selection_manifest_updated_at"] = exported_at

    if manifest["mode"] == "replace_report":
        for pid in report_ids - selected_ids:
            product = by_id.get(pid)
            if not product:
                continue
            # Human-confirmed records are never downgraded by an exported browser selection.
            if product.get("selection_state_source") == "bitable_human" or product.get("review_status") in {"已确认", "已保留"}:
                continue
            if bool(product.get("keep", False)):
                changed.append(pid)
            product["keep"] = False
            product["retained"] = False
            product["selection_state_source"] = "selection_manifest"
            product["selection_manifest_updated_at"] = exported_at

    missing = sorted(selected_ids - set(by_id))
    return SelectionResult(rows, sorted(selected_ids), sorted(set(changed)), missing, str(manifest["mode"]))


def choose_latest_manifest(paths: Iterable[str | Path]) -> Path:
    candidates = [Path(p) for p in paths]
    if not candidates:
        raise SelectionManifestError("没有找到选择清单")
    parsed = []
    for path in candidates:
        payload = load_selection_manifest(path)
        stamp = str(payload.get("exported_at", ""))
        try:
            dt = datetime.fromisoformat(stamp.replace("Z", "+00:00"))
        except ValueError:
            dt = datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc)
        parsed.append((dt, path))
    return max(parsed, key=lambda x: x[0])[1]
