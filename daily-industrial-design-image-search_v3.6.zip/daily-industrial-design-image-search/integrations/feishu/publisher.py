from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from .client import FeishuClient
from .schemas import product_to_fields, remove_empty_fields
from .publish_policy import PublishItem, build_publish_plan
from .bitable_sync import upsert_products


class FeishuPublisher:
    def __init__(self, client: FeishuClient, config: Dict[str, Any]):
        self.client = client
        self.config = config

    def upload_publish_plan(self, items: Iterable[PublishItem]) -> List[Dict[str, Any]]:
        """Upload only policy-approved files to preconfigured public/internal folders.

        This method never accepts directories and never recursively uploads a run folder.
        """
        public_folder = self.config.get("daily_folder_token") or self.config.get("root_folder_token")
        internal_folder = self.config.get("internal_folder_token")
        archive_folder = self.config.get("archive_folder_token") or public_folder
        results = []
        for item in items:
            p = Path(item.path)
            if item.role == "selection_manifest":
                folder = self.config.get("selection_folder_token") or internal_folder
            elif item.visibility == "internal":
                folder = internal_folder
            elif item.role == "archive_index":
                folder = archive_folder
            else:
                folder = public_folder
            if not folder:
                raise ValueError(f"缺少 {item.visibility}/{item.role} 对应的飞书文件夹 token")
            results.append({
                "path": str(p),
                "visibility": item.visibility,
                "role": item.role,
                "response": self.client.upload_file(p, folder),
            })
        return results

    def upload_artifacts(self, paths: Iterable[str | Path]) -> List[Dict[str, Any]]:
        raise RuntimeError(
            "upload_artifacts 已禁用：禁止上传任意目录或未分类文件。"
            "请使用 build_publish_plan + upload_publish_plan。"
        )

    def sync_products(self, products: Iterable[Dict[str, Any]], report_url: str = "") -> Dict[str, Any]:
        """Upsert products by 产品ID. Never blindly append duplicate daily records."""
        return upsert_products(
            self.client,
            self.config["bitable_app_token"],
            self.config["product_table_id"],
            products,
            report_url=report_url,
            selection_only=False,
        )

    def create_daily_doc(self, date: str, products: List[Dict[str, Any]], gallery_url: str = "", bitable_url: str = "") -> Dict[str, Any]:
        folder = self.config.get("daily_folder_token") or self.config.get("root_folder_token")
        created = self.client.create_doc(f"工业设计图片日报｜{date}", folder)
        document = created.get("data", {}).get("document", {})
        document_id = document.get("document_id")
        if not document_id:
            return created
        blocks = self._daily_doc_blocks(date, products, gallery_url, bitable_url)
        self.client.append_doc_blocks(document_id, document_id, blocks)
        return created

    @staticmethod
    def _text_block(text: str, block_type: int = 2) -> Dict[str, Any]:
        key = "text" if block_type == 2 else "heading1"
        return {
            "block_type": block_type,
            key: {"elements": [{"text_run": {"content": text}}]},
        }

    def _daily_doc_blocks(self, date: str, products: List[Dict[str, Any]], gallery_url: str, bitable_url: str) -> List[Dict[str, Any]]:
        blocks = [self._text_block(f"工业设计图片日报｜{date}", 3)]
        blocks.append(self._text_block(f"今日新增 {len(products)} 项。HTML 图片画廊用于集中浏览，多维表格用于搜索、审核和长期管理。"))
        if gallery_url:
            blocks.append(self._text_block(f"图片画廊：{gallery_url}"))
        if bitable_url:
            blocks.append(self._text_block(f"产品数据库：{bitable_url}"))
        blocks.append(self._text_block("重点产品", 3))
        for product in products[:10]:
            ai = product.get("ai_analysis") or {}
            line = f"• {product.get('title', 'Untitled')}｜{ai.get('category_label', ai.get('category', '未分类'))}｜{product.get('source', '')}"
            blocks.append(self._text_block(line))
        blocks.append(self._text_block("内部分析区域", 3))
        blocks.append(self._text_block("此区域可由公司内部 Agent 或员工补充，后续自动更新不应覆盖。"))
        return blocks
