from __future__ import annotations

from typing import Any, Dict, Iterable, List, Mapping

from .client import FeishuClient
from .schemas import product_to_fields, remove_empty_fields

PROTECTED_HUMAN_FIELDS = {"审核状态", "是否保留", "内部点评", "负责人", "人工分类", "人工标签"}


def _items(payload: Mapping[str, Any]) -> List[Dict[str, Any]]:
    return list(payload.get("data", {}).get("items") or payload.get("data", {}).get("records") or [])


def list_all_records(client: FeishuClient, app_token: str, table_id: str) -> List[Dict[str, Any]]:
    records: List[Dict[str, Any]] = []
    page_token = ""
    while True:
        payload = client.list_bitable_records(app_token, table_id, page_size=500, page_token=page_token)
        records.extend(_items(payload))
        data = payload.get("data", {})
        if not data.get("has_more"):
            break
        page_token = data.get("page_token", "")
        if not page_token:
            break
    return records


def upsert_products(
    client: FeishuClient,
    app_token: str,
    table_id: str,
    products: Iterable[Dict[str, Any]],
    report_url: str = "",
    selection_only: bool = False,
) -> Dict[str, Any]:
    existing = list_all_records(client, app_token, table_id)
    by_pid = {
        str((r.get("fields") or {}).get("产品ID")): r
        for r in existing if (r.get("fields") or {}).get("产品ID")
    }
    creates: List[Dict[str, Any]] = []
    updates: List[Dict[str, Any]] = []
    for product in products:
        pid = str(product.get("product_id", ""))
        if not pid:
            continue
        incoming = remove_empty_fields(product_to_fields(product, report_url))
        current = by_pid.get(pid)
        if not current:
            creates.append({"fields": incoming})
            continue
        current_fields = current.get("fields") or {}
        if selection_only:
            update_fields = {"产品ID": pid}
            if "keep" in product or "retained" in product:
                update_fields["是否保留"] = bool(product.get("keep", product.get("retained", False)))
            if product.get("selection_manifest_updated_at"):
                update_fields["选择清单更新时间"] = product["selection_manifest_updated_at"]
        else:
            update_fields = {k: v for k, v in incoming.items() if k not in PROTECTED_HUMAN_FIELDS}
            # A selection manifest may update retained state, but it must not overwrite a human-reviewed decision.
            human_status = str(current_fields.get("审核状态", ""))
            if product.get("selection_state_source") == "selection_manifest" and human_status not in {"已确认", "已排除", "已保留"}:
                update_fields["是否保留"] = bool(product.get("keep", product.get("retained", False)))
                if product.get("selection_manifest_updated_at"):
                    update_fields["选择清单更新时间"] = product["selection_manifest_updated_at"]
        updates.append({"record_id": current.get("record_id"), "fields": remove_empty_fields(update_fields)})

    results: Dict[str, Any] = {"created": 0, "updated": 0, "create_batches": [], "update_batches": []}
    for start in range(0, len(creates), 500):
        batch = creates[start:start + 500]
        results["create_batches"].append(client.batch_create_bitable_records(app_token, table_id, batch))
        results["created"] += len(batch)
    for start in range(0, len(updates), 500):
        batch = updates[start:start + 500]
        results["update_batches"].append(client.batch_update_bitable_records(app_token, table_id, batch))
        results["updated"] += len(batch)
    return results
