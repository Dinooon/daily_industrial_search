from __future__ import annotations

from typing import Any, Dict


def product_to_fields(product: Dict[str, Any], report_url: str = "") -> Dict[str, Any]:
    ai = product.get("ai_analysis") or {}
    return {
        "产品ID": str(product.get("product_id", "")),
        "产品名称": product.get("title", "Untitled"),
        "品牌": product.get("brand", ai.get("brand", "")),
        "分类": ai.get("category_label", ai.get("category", "未分类")),
        "子分类": ai.get("subcategory", ""),
        "设计风格": ai.get("style", ""),
        "材料": ai.get("materials", ""),
        "设计亮点": ai.get("features", ""),
        "来源": product.get("source", ""),
        "原文链接": {"link": product.get("page_url", ""), "text": "查看原文"} if product.get("page_url") else None,
        "图片链接": {"link": product.get("original_url", product.get("image_url", "")), "text": "查看图片"} if product.get("original_url", product.get("image_url")) else None,
        "首次发现日期": product.get("first_seen_date", product.get("date", "")),
        "最后发现日期": product.get("last_seen_date", product.get("date", "")),
        "AI置信度": ai.get("confidence", 0),
        "审核状态": product.get("review_status", "待审核"),
        "是否保留": bool(product.get("keep", product.get("retained", False))),
        "选择清单更新时间": product.get("selection_manifest_updated_at", ""),
        "内部点评": product.get("internal_comment", ""),
        "日报链接": {"link": report_url, "text": "打开图片日报"} if report_url else None,
    }


def remove_empty_fields(fields: Dict[str, Any]) -> Dict[str, Any]:
    return {k: v for k, v in fields.items() if v not in (None, "", [])}
