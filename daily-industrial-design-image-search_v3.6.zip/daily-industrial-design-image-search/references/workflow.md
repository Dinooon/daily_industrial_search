# Workflow — Editorial Gallery V3.4

1. 从订阅源增量发现产品并抓取详情页。
2. URL 与历史记录去重，下载产品图片并执行 AI 分析。
3. 将产品记录同步到飞书多维表格，保存返回的 `feishu_record_url`。
4. 必须调用 `scripts/generate_html.py` 生成当天 HTML；禁止 Agent 自行设计替代页面。
5. 调用 `scripts/generate_archive_index.py` 更新按月归档索引。
6. 上传 HTML、图片和 JSON 到飞书云盘。
7. 用户在 HTML 中浏览和临时保留；在飞书记录中完成正式审核。

## Output contract

Daily output: `output/YYYY-MM-DD/daily_gallery.html`

Archive index: `output/archive/index.html`

Monthly archive: `output/archive/YYYY-MM.html`

Never create `output/archive_master.html`.
