# Changelog

## 3.6.0

- 新增方案一：HTML 导出标准 selection manifest，用户手动上传飞书云盘。
- 新增选择清单校验、最新清单选择和产品状态合并。
- 新增多维表格按产品ID upsert，不再每日盲目新增。
- 保护人工审核、点评、负责人和人工分类字段。
- 新增飞书多维表格结构定义与 selection manifest JSON Schema。
- 新增 `FEISHU_SELECTION_FOLDER_TOKEN` 和内部 selection-manifests 目录。
- HTML 选择状态按 report_id 保存在 localStorage，并可导出标准清单。
- 飞书发布白名单支持经过校验的 `_selection_manifest.json`。
