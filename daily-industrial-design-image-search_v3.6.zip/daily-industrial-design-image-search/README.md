# Daily Industrial Design Image Search v3.6

工业设计图片日报 SKILL：Canonical Editorial Gallery、飞书云盘严格发布白名单、多维表格 upsert，以及“导出选择清单 → 上传云盘 → 下次运行同步”的无服务端保留状态闭环。

## 关键文件

- `SKILL.md`：其他 Agent 必须遵守的完整工作流
- `templates/`：唯一 HTML 视觉模板
- `schemas/selection_manifest.schema.json`：选择清单格式
- `config/feishu_bitable_schema.json`：多维表格定义
- `scripts/import_selection_manifest.py`：读取上次选择并同步数据
- `scripts/build_feishu_release.py`：生成严格白名单发布包
- `scripts/publish_to_feishu.py`：上传云盘并 upsert 多维表格

## 选择状态闭环

```text
HTML 勾选保留
→ 导出 YYYY-MM-DD_selection_manifest.json
→ 用户上传到飞书 selection-manifests 文件夹
→ 下次 Agent 下载最新清单
→ import_selection_manifest.py
→ 产品实体表 upsert
→ 新 HTML 继承保留状态
```

静态 HTML 不会修改云盘中的原文件，因此不得通过读取旧 HTML 推断用户选择。

## 本地验证

```bash
python -m pytest -q
python scripts/generate_html.py --manifest examples/gallery_demo_products.json --output output/demo/daily_gallery.html
```
