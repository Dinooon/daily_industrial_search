---
name: daily-industrial-design-gallery
description: Create daily industrial-design image galleries, portable Feishu Drive-preview HTML, archives, and Feishu Bitable review artifacts. Use when turning curated product/image records into a browseable daily gallery, publishing a gallery to Feishu Drive, preserving browser selections, or maintaining a design-image archive.
---

# Daily Industrial Design Gallery

Generate two explicit variants from the same reviewed product dataset:

- **Canonical gallery**: full-resolution HTML plus image assets for local viewing, static hosting, or Feishu 妙搭.
- **Portable preview**: one self-contained HTML file for direct Feishu Drive preview. It embeds the rendered images and contains no local asset paths.

Never hand-write a replacement gallery. Use `scripts/generate_html.py` and the templates under `templates/`.

## Inputs and quality gate

Use products with at least `product_id`, `title`, `image_url` or local image path, `page_url`, `source`, and `review_status`.

Before gallery generation, remove duplicate URLs and non-product editorial content. Keep `needs_review` items visibly distinct from confirmed releases. Do not include tokens, private URLs, or internal notes in the public HTML.

## Build the canonical gallery

```bash
python scripts/generate_html.py \
  --manifest data/YYYY-MM-DD/collected_data.json \
  --ai-data data/YYYY-MM-DD/ai_analysis.json \
  --output output/YYYY-MM-DD/daily_gallery.html
```

The default archive link is `../archive/index.html`, suitable for a daily file at `output/YYYY-MM-DD/`. Pass `--archive-href` when using another layout. Generate the archive index separately with `scripts/generate_archive_index.py`.

## Build the Feishu Drive preview

First create the canonical gallery, then make a portable preview from it:

```bash
python scripts/build_portable_preview.py \
  --input output/YYYY-MM-DD/daily_gallery.html \
  --images-root output/YYYY-MM-DD \
  --output output/YYYY-MM-DD/YYYY-MM-DD_工业设计图片日报_预览版.html
```

Use `--fetch-remote` only when image URLs are trusted and the user authorizes fetching them. With Pillow installed, the script compresses raster images as JPEG data URIs; otherwise it embeds supported JPEG, PNG, and WebP files at their original size. It always stops when embedded images exceed `--max-total-mb` (default 15 MB). Inspect its JSON result and resolve every reported failure before upload.

Use the portable preview for internal cloud preview only. Use the canonical gallery with its image directory for full-resolution viewing, permanent web hosting, or Feishu 妙搭. Do not expect sibling-file paths to work in the portable preview.

## Feishu release and review loop

1. Upload the portable preview HTML to the public daily folder for direct cloud preview.
2. Upload the canonical gallery, final images, and `--portable-preview` only through `scripts/build_feishu_release.py` and `scripts/publish_to_feishu.py`.
3. Keep processed JSON, logs, and selection manifests in the restricted internal folder.
4. Import the newest `*_selection_manifest.json` before the next run with `scripts/import_selection_manifest.py`.
5. Upsert products by product ID; never overwrite protected human review fields.

Never recursively upload a run directory. The allowlist in `integrations/feishu/publish_policy.py` forbids code, templates, tests, credentials, caches, archives, and history manifests.

## Validation

```bash
python -m pytest -q
python scripts/generate_html.py --manifest examples/gallery_demo_products.json --output output/demo/daily_gallery.html
python scripts/build_portable_preview.py --input output/demo/daily_gallery.html --images-root . --output output/demo/daily_gallery_preview.html
```

Verify that the preview contains `gallery-preview`, has no unresolved local image paths, and that its archive link points to a valid destination for the chosen output layout.
