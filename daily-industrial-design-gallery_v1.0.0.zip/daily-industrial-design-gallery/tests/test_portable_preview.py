from pathlib import Path

from scripts.build_portable_preview import build


def test_portable_preview_embeds_local_image(tmp_path: Path):
    image_dir = tmp_path / "images"
    image_dir.mkdir()
    (image_dir / "sample.svg").write_text('<svg xmlns="http://www.w3.org/2000/svg" width="24" height="18"><rect width="24" height="18" fill="#336699"/></svg>', encoding="utf-8")
    source = tmp_path / "gallery.html"
    source.write_text('<html><head></head><body><img src="images/sample.svg"></body></html>', encoding="utf-8")
    output = tmp_path / "preview.html"

    result = build(source, output, tmp_path, False, 1280, 78, 1)

    text = output.read_text(encoding="utf-8")
    assert result["embedded_images"] == 1
    assert 'data:image/svg+xml;base64,' in text
    assert 'src="images/sample.svg"' not in text
    assert 'gallery-preview' in text
