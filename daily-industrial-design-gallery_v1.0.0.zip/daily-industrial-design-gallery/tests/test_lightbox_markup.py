from scripts.generate_html import HTMLGenerator


def test_lightbox_uses_data_attributes_not_inline_javascript():
    output = HTMLGenerator(date="2026-07-29").generate([{
        "product_id": "p1", "title": "Maker's \"quoted\" headphone", "source": "Test",
        "image_url": "https://example.test/image.jpg", "page_url": "https://example.test/product",
    }])
    assert 'data-lightbox-src="https://example.test/image.jpg"' in output
    assert 'data-lightbox-title="Maker&#x27;s &quot;quoted&quot; headphone"' in output
    assert 'onclick="openLightbox(' not in output
