from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Iterable, List

from .client import FeishuClient
from .publish_policy import PublishItem
from .bitable_sync import upsert_products
from .drive_structure import DriveStructureManager


class FeishuPublisher:
    def __init__(self, client: FeishuClient, config: Dict[str, Any]):
        self.client = client
        self.config = config
        root = config.get("workspace_root_folder_token") or config.get("root_folder_token")
        self.structure = DriveStructureManager(client, root) if root else None
        self._folders: Dict[str, str] = {}

    def ensure_drive_structure(self, report_date: str) -> Dict[str, str]:
        if not self.structure:
            raise ValueError("必须配置 FEISHU_WORKSPACE_ROOT_FOLDER_TOKEN，禁止把所有文件平铺上传到单个目录")
        self._folders = self.structure.ensure_standard_structure(report_date)
        return dict(self._folders)

    def upload_publish_plan(self, items: Iterable[PublishItem], report_date: str) -> List[Dict[str, Any]]:
        """Create the canonical folder tree, then upload each file by role.

        No directory token fallback is allowed because that caused public and
        internal files to be flattened into one folder in earlier versions.
        """
        folders = self.ensure_drive_structure(report_date)
        results = []
        for item in items:
            p = Path(item.path)
            folder = folders.get(item.target_key)
            if not folder:
                raise ValueError(f"发布项没有对应的标准目录: {item.role}/{item.target_key}")
            results.append({
                "path": str(p),
                "visibility": item.visibility,
                "role": item.role,
                "target_key": item.target_key,
                "folder_token": folder,
                "response": self.client.upload_file(p, folder),
            })
        return results

    def upload_artifacts(self, paths):
        raise RuntimeError("upload_artifacts 已禁用：必须通过标准目录结构与发布计划上传")

    def sync_products(self, products, report_url: str = "") -> Dict[str, Any]:
        return upsert_products(
            self.client,
            self.config["bitable_app_token"],
            self.config["product_table_id"],
            products,
            report_url=report_url,
            selection_only=False,
        )

    def create_daily_doc(self, date: str, products: List[Dict[str, Any]], gallery_url: str = "", bitable_url: str = "") -> Dict[str, Any]:
        folders = self._folders or self.ensure_drive_structure(date)
        created = self.client.create_doc(f"工业设计图片日报｜{date}", folders["public_daily"])
        document = created.get("data", {}).get("document", {})
        document_id = document.get("document_id")
        if not document_id:
            return created
        blocks = self._daily_doc_blocks(date, products, gallery_url, bitable_url)
        self.client.append_doc_blocks(document_id, document_id, blocks)
        return created

    @staticmethod
    def _text_block(text: str, block_type: int = 2) -> Dict[str, Any]:
        key = "text" if block_type == 2 else "heading1"
        return {"block_type": block_type, key: {"elements": [{"text_run": {"content": text}}]}}

    def _daily_doc_blocks(self, date: str, products: List[Dict[str, Any]], gallery_url: str, bitable_url: str) -> List[Dict[str, Any]]:
        blocks = [self._text_block(f"工业设计图片日报｜{date}", 3)]
        blocks.append(self._text_block(f"今日新增 {len(products)} 项。HTML 图片画廊用于集中浏览，多维表格用于搜索、审核和长期管理。"))
        if gallery_url:
            blocks.append(self._text_block(f"图片画廊：{gallery_url}"))
        if bitable_url:
            blocks.append(self._text_block(f"产品数据库：{bitable_url}"))
        blocks.append(self._text_block("重点产品", 3))
        for product in products[:10]:
            ai = product.get("ai_analysis") or {}
            line = f"• {product.get('title', 'Untitled')}｜{ai.get('category_label', ai.get('category', '未分类'))}｜{product.get('source', '')}"
            blocks.append(self._text_block(line))
        blocks.append(self._text_block("内部分析区域", 3))
        blocks.append(self._text_block("此区域可由公司内部 Agent 或员工补充，后续自动更新不应覆盖。"))
        return blocks
