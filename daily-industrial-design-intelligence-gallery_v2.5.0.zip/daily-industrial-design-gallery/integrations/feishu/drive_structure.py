from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Mapping, Sequence


PUBLIC_LIBRARY = "资源图库"
DATABASE_ROOT = "工业设计情报数据库"
INTERNAL_ROOT = "工业设计情报系统_内部"


@dataclass(frozen=True)
class FolderSpec:
    key: str
    parts: tuple[str, ...]


def standard_folder_specs(report_date: str) -> List[FolderSpec]:
    """Canonical Feishu Drive folder layout.

    Paths are relative to FEISHU_WORKSPACE_ROOT_FOLDER_TOKEN. Creating the same
    structure repeatedly is safe because folders are looked up by exact name
    before creation.
    """
    return [
        FolderSpec("public_daily", (PUBLIC_LIBRARY, "今日资讯", report_date)),
        FolderSpec("public_daily_images", (PUBLIC_LIBRARY, "今日资讯", report_date, "images")),
        FolderSpec("public_archive", (PUBLIC_LIBRARY, "历史归档")),
        FolderSpec("public_monthly", (PUBLIC_LIBRARY, "月度画廊")),
        FolderSpec("public_halfyear", (PUBLIC_LIBRARY, "半年度报告")),
        FolderSpec("database", (DATABASE_ROOT,)),
        FolderSpec("internal_raw", (INTERNAL_ROOT, "raw-data", report_date)),
        FolderSpec("internal_processed", (INTERNAL_ROOT, "processed-data", report_date)),
        FolderSpec("internal_selections", (INTERNAL_ROOT, "selection-manifests")),
        FolderSpec("internal_logs", (INTERNAL_ROOT, "logs", report_date)),
        FolderSpec("internal_manifests", (INTERNAL_ROOT, "manifests", report_date)),
    ]


class DriveStructureManager:
    def __init__(self, client: Any, root_folder_token: str):
        if not root_folder_token:
            raise ValueError("缺少 FEISHU_WORKSPACE_ROOT_FOLDER_TOKEN（或 FEISHU_ROOT_FOLDER_TOKEN）")
        self.client = client
        self.root_folder_token = root_folder_token
        self._children_cache: Dict[str, Dict[str, str]] = {}

    def _children(self, folder_token: str, *, refresh: bool = False) -> Dict[str, str]:
        if folder_token in self._children_cache and not refresh:
            return self._children_cache[folder_token]
        payload = self.client.list_folder_files(folder_token)
        data = payload.get("data", {}) if isinstance(payload, Mapping) else {}
        files = data.get("files") or data.get("items") or []
        result: Dict[str, str] = {}
        for item in files:
            if not isinstance(item, Mapping):
                continue
            item_type = str(item.get("type") or item.get("file_type") or "").lower()
            if item_type not in {"folder", "12"}:
                continue
            name = str(item.get("name") or "").strip()
            token = str(item.get("token") or item.get("file_token") or "").strip()
            if name and token:
                result[name] = token
        self._children_cache[folder_token] = result
        return result

    def ensure_child(self, parent_token: str, name: str) -> str:
        existing = self._children(parent_token).get(name)
        if existing:
            return existing
        payload = self.client.create_folder(name=name, parent_token=parent_token)
        data = payload.get("data", {}) if isinstance(payload, Mapping) else {}
        token = str(data.get("token") or data.get("folder_token") or data.get("file_token") or "")
        if not token:
            # Some API versions wrap folder metadata.
            folder = data.get("folder") or {}
            token = str(folder.get("token") or folder.get("folder_token") or "")
        if not token:
            raise RuntimeError(f"飞书文件夹创建成功但响应缺少 token: {name}: {payload}")
        self._children_cache.pop(parent_token, None)
        self._children(parent_token, refresh=True)
        return token

    def ensure_path(self, parts: Sequence[str]) -> str:
        token = self.root_folder_token
        for name in parts:
            token = self.ensure_child(token, name)
        return token

    def ensure_standard_structure(self, report_date: str) -> Dict[str, str]:
        return {spec.key: self.ensure_path(spec.parts) for spec in standard_folder_specs(report_date)}


def structure_as_dict(report_date: str) -> Dict[str, List[str]]:
    return {spec.key: list(spec.parts) for spec in standard_folder_specs(report_date)}
