from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable, List, Sequence

PUBLIC_ALLOWED_SUFFIXES = {'.html', '.htm', '.jpg', '.jpeg', '.png', '.webp', '.gif', '.svg', '.md', '.txt'}
INTERNAL_ALLOWED_SUFFIXES = {'.json', '.log', '.txt', '.csv'}
FORBIDDEN_PARTS = {
    'scripts', 'templates', 'tests', 'temp_images', 'screenshots', '__pycache__',
    '.pytest_cache', '.git', 'cache', '.cache', 'node_modules', 'references',
}
FORBIDDEN_NAMES = {
    '.env', '.env.local', 'history_manifest.json', 'requirements.txt', 'SKILL.md',
    'README.md', 'CHANGELOG.md', 'Dockerfile',
}
FORBIDDEN_SUFFIXES = {'.py', '.pyc', '.pyo', '.sh', '.bat', '.ps1', '.zip'}


class PublishPolicyError(ValueError):
    pass


@dataclass(frozen=True)
class PublishItem:
    path: str
    visibility: str
    role: str
    target_key: str


def _is_forbidden(path: Path) -> bool:
    lower_parts = {part.lower() for part in path.parts}
    if lower_parts & {part.lower() for part in FORBIDDEN_PARTS}:
        return True
    if path.name in FORBIDDEN_NAMES or path.suffix.lower() in FORBIDDEN_SUFFIXES:
        return True
    if path.name.startswith('.'):
        return True
    return False


def validate_file(path: str | Path, visibility: str) -> Path:
    p = Path(path).expanduser().resolve()
    if not p.is_file():
        raise PublishPolicyError(f'发布文件不存在或不是普通文件: {p}')
    if _is_forbidden(p):
        raise PublishPolicyError(f'发布策略禁止上传该文件: {p}')
    suffix = p.suffix.lower()
    allowed = PUBLIC_ALLOWED_SUFFIXES if visibility == 'public' else INTERNAL_ALLOWED_SUFFIXES
    if suffix not in allowed:
        raise PublishPolicyError(f'{visibility} 目录不允许上传 {suffix or "无扩展名"} 文件: {p}')
    return p


def expand_final_images(images: Iterable[str | Path]) -> List[Path]:
    result: List[Path] = []
    for value in images:
        p = Path(value).expanduser().resolve()
        if p.is_dir():
            for child in sorted(p.iterdir()):
                if child.is_file() and child.suffix.lower() in PUBLIC_ALLOWED_SUFFIXES and not _is_forbidden(child):
                    result.append(child)
        else:
            result.append(validate_file(p, 'public'))
    return result


def build_publish_plan(
    *,
    daily_html: str | Path,
    final_images: Sequence[str | Path] = (),
    summary: str | Path | None = None,
    portable_preview: str | Path | None = None,
    archive_index: str | Path | None = None,
    internal_artifacts: Sequence[str | Path] = (),
    selection_manifests: Sequence[str | Path] = (),
    download_manifest: str | Path | None = None,
) -> List[PublishItem]:
    items = [PublishItem(str(validate_file(daily_html, 'public')), 'public', 'daily_gallery', 'public_daily')]
    for image in expand_final_images(final_images):
        items.append(PublishItem(str(validate_file(image, 'public')), 'public', 'final_image', 'public_daily_images'))
    if summary:
        items.append(PublishItem(str(validate_file(summary, 'public')), 'public', 'daily_summary', 'public_daily'))
    if portable_preview:
        items.append(PublishItem(str(validate_file(portable_preview, 'public')), 'public', 'drive_preview', 'public_daily'))
    if archive_index:
        items.append(PublishItem(str(validate_file(archive_index, 'public')), 'public', 'archive_index', 'public_archive'))
    if download_manifest:
        p = Path(download_manifest).expanduser().resolve()
        if p.name != 'download_manifest.json':
            raise PublishPolicyError(f'公开下载清单文件名必须为 download_manifest.json: {p}')
        if not p.is_file() or _is_forbidden(p):
            raise PublishPolicyError(f'下载清单不存在或被禁止: {p}')
        items.append(PublishItem(str(p), 'public', 'download_manifest', 'public_daily'))
    for artifact in internal_artifacts:
        p = validate_file(artifact, 'internal')
        name = p.name.lower()
        if name in {'source_health.json'} or name.endswith('.log'):
            target_key, role = 'internal_logs', 'source_health_or_log'
        elif 'manifest' in name or name == 'upload_manifest.json':
            target_key, role = 'internal_manifests', 'system_manifest'
        elif name.startswith('raw_') or name in {'raw_data.json'}:
            target_key, role = 'internal_raw', 'raw_artifact'
        else:
            target_key, role = 'internal_processed', 'processed_artifact'
        items.append(PublishItem(str(p), 'internal', role, target_key))
    for manifest in selection_manifests:
        p = validate_file(manifest, 'internal')
        if not p.name.endswith('_selection_manifest.json'):
            raise PublishPolicyError(f'选择清单文件名必须以 _selection_manifest.json 结尾: {p}')
        items.append(PublishItem(str(p), 'internal', 'selection_manifest', 'internal_selections'))
    return items


def plan_as_dict(items: Sequence[PublishItem]):
    return [asdict(item) for item in items]
