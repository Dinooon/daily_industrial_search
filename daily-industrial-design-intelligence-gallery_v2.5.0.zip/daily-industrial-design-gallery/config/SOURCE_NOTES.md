# Source configuration notes

Official brand pages are evidence sources and must not be treated as automatically accepted product feeds. Corporate, finance, hiring, partnership and policy posts are rejected by the product gate. Source selectors may change; inspect `source_health.json` every run and disable unstable sources in `config/sources.json` until repaired.

The generic collector intentionally prefers public HTML, RSS and Sitemap endpoints. It does not bypass authentication, CAPTCHAs, robots restrictions or access controls.
