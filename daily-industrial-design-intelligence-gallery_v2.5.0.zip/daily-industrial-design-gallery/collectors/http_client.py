from __future__ import annotations
import hashlib, json, time
from pathlib import Path
from urllib.parse import urlparse
import requests
from scripts.config import CACHE_DIR, DEFAULT_TIMEOUT, USER_AGENT

class HttpClient:
    def __init__(self, timeout=DEFAULT_TIMEOUT, interval=1.0, cache_dir=CACHE_DIR):
        self.timeout=timeout; self.interval=interval; self.cache_dir=Path(cache_dir); self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.session=requests.Session(); self.session.headers.update({"User-Agent":USER_AGENT,"Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"})
        self._last={}
    def _wait(self,url):
        host=urlparse(url).netloc; elapsed=time.time()-self._last.get(host,0)
        if elapsed<self.interval: time.sleep(self.interval-elapsed)
        self._last[host]=time.time()
    def get(self,url,use_cache=True):
        key=hashlib.sha256(url.encode()).hexdigest(); body=self.cache_dir/f"{key}.body"; meta=self.cache_dir/f"{key}.json"
        headers={}
        if use_cache and meta.exists():
            try:
                m=json.loads(meta.read_text());
                if m.get('etag'): headers['If-None-Match']=m['etag']
                if m.get('last_modified'): headers['If-Modified-Since']=m['last_modified']
            except Exception: pass
        self._wait(url)
        last=None
        for attempt in range(4):
            try:
                r=self.session.get(url,headers=headers,timeout=self.timeout,allow_redirects=True)
                if r.status_code==304 and body.exists():
                    return {"url":url,"final_url":url,"status":200,"text":body.read_text(errors='replace'),"from_cache":True,"headers":{}}
                if r.status_code in (429,500,502,503,504):
                    time.sleep(min(2**attempt,12)); last=r; continue
                r.raise_for_status(); body.write_text(r.text,encoding='utf-8')
                meta.write_text(json.dumps({"etag":r.headers.get('ETag'),"last_modified":r.headers.get('Last-Modified')},ensure_ascii=False),encoding='utf-8')
                return {"url":url,"final_url":r.url,"status":r.status_code,"text":r.text,"from_cache":False,"headers":dict(r.headers)}
            except requests.RequestException as e:
                last=e; time.sleep(min(2**attempt,12))
        raise RuntimeError(f"request failed: {url}: {last}")
