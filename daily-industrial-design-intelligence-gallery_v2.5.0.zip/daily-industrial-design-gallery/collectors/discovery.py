from __future__ import annotations
import xml.etree.ElementTree as ET
from urllib.parse import urljoin,urlparse
from bs4 import BeautifulSoup
from dateutil import parser as dateparser

def _date(v):
    if not v:return None
    try:return dateparser.parse(str(v)).isoformat()
    except Exception:return None

def html_links(html,base_url,limit=80):
    soup=BeautifulSoup(html,'html.parser'); host=urlparse(base_url).netloc; out=[]
    for a in soup.find_all('a',href=True):
        u=urljoin(base_url,a['href']).split('#')[0]
        if urlparse(u).netloc!=host:continue
        t=' '.join(a.get_text(' ',strip=True).split())
        if len(t)<5:continue
        if any(x in u.lower() for x in ['/tag/','/category/','/author/','/search','/privacy','/contact','/login']):continue
        parent=a.find_parent(['article','li','div'])
        summary=' '.join(parent.get_text(' ',strip=True).split())[:500] if parent else ''
        time_node=parent.find('time') if parent else None
        published=_date(time_node.get('datetime') or time_node.get_text(strip=True)) if time_node else None
        img=''
        im=(parent.find('img') if parent else None)
        if im:img=urljoin(base_url,im.get('src') or im.get('data-src') or '')
        out.append({'url':u,'title':t,'summary':summary,'published_at':published,'image_url':img,'discovery_mode':'html'})
    seen=[]; keys=set()
    for x in out:
        if x['url'] not in keys:keys.add(x['url']);seen.append(x)
    return seen[:limit]

def feed_links(xml_text,base_url,limit=80):
    out=[]
    try:root=ET.fromstring(xml_text)
    except Exception:return out
    for item in root.findall('.//item'):
        link=item.findtext('link'); title=item.findtext('title') or ''
        pub=item.findtext('pubDate') or item.findtext('{*}date')
        desc=item.findtext('description') or ''
        if link:out.append({'url':urljoin(base_url,link.strip()),'title':title.strip(),'summary':BeautifulSoup(desc,'html.parser').get_text(' ',strip=True)[:500],'published_at':_date(pub),'discovery_mode':'rss'})
    ns={'a':'http://www.w3.org/2005/Atom'}
    for e in root.findall('.//a:entry',ns):
        l=e.find('a:link',ns); title=e.findtext('a:title','',ns);pub=e.findtext('a:published','',ns) or e.findtext('a:updated','',ns)
        summary=e.findtext('a:summary','',ns) or e.findtext('a:content','',ns)
        if l is not None and l.get('href'):out.append({'url':urljoin(base_url,l.get('href')),'title':title.strip(),'summary':BeautifulSoup(summary,'html.parser').get_text(' ',strip=True)[:500],'published_at':_date(pub),'discovery_mode':'rss'})
    return out[:limit]

def sitemap_links(xml_text,limit=200):
    try:root=ET.fromstring(xml_text)
    except Exception:return []
    out=[]
    for node in root.findall('.//{*}url'):
        loc=node.findtext('{*}loc');last=node.findtext('{*}lastmod')
        if loc:out.append({'url':loc.strip(),'title':'','summary':'','published_at':_date(last),'discovery_mode':'sitemap'})
    if out:return out[:limit]
    return [{'url':x.text.strip(),'title':'','summary':'','published_at':None,'discovery_mode':'sitemap_index'} for x in root.findall('.//{*}loc') if x.text][:limit]
