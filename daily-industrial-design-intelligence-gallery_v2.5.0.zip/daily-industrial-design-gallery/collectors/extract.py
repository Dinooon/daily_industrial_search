from __future__ import annotations
import json,re
from datetime import datetime,timezone
from urllib.parse import urljoin,urlparse
from bs4 import BeautifulSoup
from dateutil import parser as dateparser

DATE_KEYS=("datePublished","dateCreated","uploadDate","dateModified")

def _date(v):
    if not v:return None
    try:return dateparser.parse(str(v)).astimezone(timezone.utc).isoformat()
    except Exception:return None

def extract_article(html,url):
    s=BeautifulSoup(html,'html.parser'); canonical=url
    c=s.find('link',rel=lambda x:x and 'canonical' in x); canonical=urljoin(url,c.get('href')) if c and c.get('href') else url
    title=''
    for sel,attr in [("meta[property='og:title']",'content'),("meta[name='twitter:title']",'content'),('h1',None),('title',None)]:
        n=s.select_one(sel)
        if n: title=(n.get(attr) if attr else n.get_text(' ',strip=True)) or ''
        if title:break
    image=''
    for sel in ["meta[property='og:image']","meta[name='twitter:image']"]:
        n=s.select_one(sel)
        if n and n.get('content'): image=urljoin(url,n['content']);break
    published=modified=brand=product_name=''; ld=[]
    for n in s.select('script[type="application/ld+json"]'):
        try:
            obj=json.loads(n.string or n.get_text()); ld.extend(obj if isinstance(obj,list) else [obj])
        except Exception: continue
    stack=list(ld)
    while stack:
        o=stack.pop()
        if isinstance(o,list):stack.extend(o);continue
        if not isinstance(o,dict):continue
        if '@graph' in o:stack.extend(o['@graph'] if isinstance(o['@graph'],list) else [o['@graph']])
        typ=o.get('@type'); types=typ if isinstance(typ,list) else [typ]
        if any(t in ('Product','NewsArticle','Article','BlogPosting') for t in types):
            product_name=product_name or o.get('name') or o.get('headline') or ''
            for k in DATE_KEYS:
                if k in o:
                    if k=='dateModified': modified=modified or _date(o[k])
                    else: published=published or _date(o[k])
            b=o.get('brand')
            if isinstance(b,dict): brand=brand or b.get('name','')
            elif isinstance(b,str): brand=brand or b
            im=o.get('image')
            if not image and im:
                if isinstance(im,str):image=urljoin(url,im)
                elif isinstance(im,list) and im:image=urljoin(url,str(im[0]))
                elif isinstance(im,dict):image=urljoin(url,im.get('url',''))
    if not published:
        for key in ['article:published_time','date','pubdate','publish-date','datePublished']:
            n=s.find('meta',attrs={'property':key}) or s.find('meta',attrs={'name':key}) or s.find('meta',attrs={'itemprop':key})
            if n and n.get('content'): published=_date(n['content']);break
    text=' '.join(p.get_text(' ',strip=True) for p in s.select('article p, main p'))
    if len(text)<120:text=' '.join(p.get_text(' ',strip=True) for p in s.find_all('p'))
    text=re.sub(r'\s+',' ',text).strip()[:12000]
    return {'page_url':canonical,'canonical_url':canonical,'title':title.strip(),'product_name':str(product_name).strip(),'brand':str(brand).strip(),'image_url':image,'published_at':published,'modified_at':modified,'body_text':text,'domain':urlparse(canonical).netloc.lower()}
