---
name: daily-industrial-design-intelligence-gallery
description: End-to-end industrial-design intelligence workflow with lightweight source monitoring, evidence-based product analysis, Editorial Gallery generation, and Feishu publishing.
---

# Daily Industrial Design Intelligence Gallery 2.5

This skill performs discovery, validation, analysis, gallery generation and Feishu publishing. It must use the supplied source catalog, scheduler, state store, scoring rules and canonical templates. It must not invent products, bypass quality gates, recursively upload run directories, or use email newsletters as a source.

## Mandatory workflow

1. Import the newest selection manifest and preserve protected human fields.
2. Load the machine-readable catalog from `config/source_catalog.json`.
3. Select only sources due for checking according to priority, frequency and saved source state.
4. Respect the global source and detail-page budgets.
5. Discover candidates in this order: RSS/Atom, Sitemap, then HTML entrance page.
6. Reuse ETag, Last-Modified, response cache and entrance-page content hashes.
7. Score candidates from title, URL, summary, date and source trust before fetching details.
8. Fetch details only for candidates above the configured threshold and within the source detail budget.
9. Extract canonical URL, JSON-LD, OpenGraph, title, image, body, brand and dates.
10. Reject non-product editorial, corporate news, applications, submissions and stale content.
11. Prefer official brand pages as evidence when the same product is reported by multiple sources.
12. Deduplicate and assign stable product IDs.
13. Produce structured analysis with verified facts, design observations and evidence.
14. Generate the canonical Editorial Gallery and portable Feishu preview.
15. Publish only files permitted by the Feishu manifest and upsert Bitable records.

## Prohibited source method

Email newsletters and mailbox ingestion are explicitly disabled. Do not subscribe, read email, or create mailbox-based discovery. The allowed discovery methods are:

- RSS / Atom
- Sitemap and `lastmod`
- Conditional HTTP requests with ETag / Last-Modified
- Lightweight HTML entrance-page discovery
- Explicit official product/news URLs

## Lightweight monitoring policy

The catalog contains more than 200 sites from the provided industrial-design source list. This does not mean all sites are deeply crawled every day.

Default limits:

```text
Daily source budget: 40 sources
Daily detail-page budget: 60 pages
```

Default frequencies:

- Core design media: daily
- Official brands: every two days
- Awards, studios, materials and manufacturing: weekly
- Events: weekly outside active-event configurations; event-window sources may be promoted separately

Each source controls:

```text
check_frequency
candidate_budget
detail_fetch_budget
candidate_score_threshold
max_age_days
trust_level
```

The state file `data/state/source_state.json` stores last check time, last success, entrance hash and recent counts. Sources are rotated by due state and priority, preventing the first run from performing unlimited detail crawling.

## Product-description provenance

HTML product descriptions are not written by the HTML generator. They come from `pipeline/analyze.py`.

Model mode outputs:

- verified facts
- design observations
- field-level evidence
- a 60–120 Chinese-character description

The model must not invent materials, dimensions, availability or release facts. In fallback mode, `pipeline/description.py` selects evidence-bearing sentences from the body instead of copying the first paragraph. Fallback output is marked `analysis_mode=heuristic_evidence`.

HTML uses `ai_analysis.description` or `ai_analysis.features`. The two values are kept identical for compatibility.

## Commands

```bash
python -m pip install -r requirements.txt
python scripts/run_full_workflow.py --date YYYY-MM-DD
```

Reduced test:

```bash
python scripts/run_daily_pipeline.py --date YYYY-MM-DD --max-sources 5 --limit-per-source 2
```

Force sources regardless of schedule:

```bash
python scripts/run_daily_pipeline.py --date YYYY-MM-DD --force --max-sources 5
```

Regenerate the source catalog from the maintained Markdown list:

```bash
python scripts/build_source_catalog.py /path/to/工业设计新品资讯网站清单.md --output config/source_catalog.json
cp config/source_catalog.json config/sources.json
```

## Required checks

```bash
python -m pytest -q
python -m compileall collectors pipeline scripts integrations
```

Always review `source_health.json`. Do not claim a complete daily report when high-priority sources failed or were not checked.

## v2.2 质量与数量强制规则

- HTML 卡片必须同时具备有效 `page_url` 与非占位 `image_url`；缺一不可进入公开画廊。
- `page_url` 必须回退到 `canonical_url` 或详情页最终 URL，禁止只保留图片 API 地址。
- `placehold.co`、`placeholder.com`、`via.placeholder.com` 等占位图片禁止进入日报。
- 租赁计划、订阅、融资、会员、软件更新、企业合作和服务公告不得作为实体新品。
- 默认每天检查最多 80 个到期来源，最多抓取 120 个高分详情页。
- 日报目标为至少 24 个合格实体产品，最多 40 个；不足时必须在 `source_health.json` 中报告原因，不得用占位或低质量内容凑数。
- “原文”按钮必须指向产品详情页或媒体文章页；“原图”按钮仅指向图片资源，两者不可混用。

## 飞书云盘目录结构是强制要求（v2.5）

发布不得把 HTML、JSON 和日志平铺到同一文件夹。每次正式发布必须先调用 `DriveStructureManager.ensure_standard_structure(report_date)`，以 `FEISHU_WORKSPACE_ROOT_FOLDER_TOKEN` 为父目录创建或复用以下结构：

```text
资源图库/
├── 今日资讯/YYYY-MM-DD/
│   ├── daily_gallery.html
│   ├── YYYY-MM-DD_工业设计图片日报_预览版.html
│   ├── 日报摘要.md（如生成）
│   ├── download_manifest.json
│   └── images/
│       └── 仅包含正式 HTML 实际引用的已验证产品图片
├── 历史归档/
├── 月度画廊/
└── 半年度报告/
工业设计情报数据库/
工业设计情报系统_内部/
├── raw-data/YYYY-MM-DD/
├── processed-data/YYYY-MM-DD/
├── selection-manifests/
├── logs/YYYY-MM-DD/
└── manifests/YYYY-MM-DD/
```

角色路由不可更改：日报 HTML、飞书预览版、摘要与 `download_manifest.json` 进入 `今日资讯/日期`；所有最终验证图片进入 `今日资讯/日期/images`；归档索引进入 `历史归档`；`collected_data.json` 与 `duplicates.json` 进入 `processed-data/日期`；`source_health.json` 与日志进入 `logs/日期`；发布清单进入 `manifests/日期`；选择清单进入 `selection-manifests`。

目录创建或定位失败时必须中止发布。禁止退回到单个 folder token，禁止把内部 JSON 上传到公开日期目录。

# v2.4 强制采集与图片真实性规范

## 多通道采集

每次运行必须先判断 Python 原生 HTTP 能力：

```bash
python scripts/detect_network_capability.py
```

支持四种模式：`auto`、`native_http`、`agent_assisted`、`offline`。

- 原生 HTTP 可用：运行标准 RSS、Sitemap、详情页管线。
- 原生 HTTP 不可用但 Agent 具备网页/图片工具：必须进入 `agent_assisted`。
- 两者均不可用：只可使用已有本地真实图片运行 `offline`，否则停止正式日报。
- 严禁为了“完成任务”手写虚构产品、图片 URL 或占位数据。

## Agent 辅助模式

Python 脚本不能直接调用对话中的网页工具。调用本 SKILL 的 Agent 必须先使用网页搜索、页面阅读或图片搜索能力完成验证，再生成符合 `schemas/tool_acquisition_manifest.schema.json` 的清单。

每条产品必须包括：

- 真实产品名称；
- 官方或可信媒体详情页 `page_url`；
- 可追溯的真实产品图 `image_url`；
- 已保存的本地位图 `local_image_path`；
- 来源、发现方式和证据数组。

随后必须执行：

```bash
python scripts/validate_tool_manifest.py incoming/tool_acquisition_manifest.json
python scripts/import_agent_acquisition.py --manifest incoming/tool_acquisition_manifest.json --output data/YYYY-MM-DD/agent_collected_data.json
python scripts/validate_product_images.py --products data/YYYY-MM-DD/agent_collected_data.json --output data/YYYY-MM-DD/image_verified_data.json
```

## 正式日报图片门槛

正式 HTML 中每个产品必须同时满足：

- `image_verified == true`
- `local_image_path` 存在且能被 Pillow 读取
- 图片宽度至少 500px、高度至少 300px
- 文件不小于 20KB
- 图片不是低方差纯色标题卡
- `page_url` 存在并可追溯

正式日报禁止：

- Unsplash、Pexels 等无关图库替代图；
- 拼写异常或人工编造的图片 URL；
- SVG 文字占位图、纯色块或品牌 Logo 代替产品图；
- AI 生成的产品图片；
- 无来源页面的孤立图片。

图片失败时只能更换为另一个真实来源或剔除该产品。不得降级为占位图。

## 飞书预览

先将真实图片保存到本地，再生成标准 HTML，最后由 `build_portable_preview.py` 将本地位图嵌入 Base64。任何一张图片无法嵌入时，预览构建必须失败并停止发布，不得保留断裂的远程路径。

## 标准完整命令

```bash
python scripts/run_full_workflow.py \
  --date YYYY-MM-DD \
  --acquisition-mode auto
```

当自动探测切换到 Agent 辅助模式时，必须先准备 `--agent-manifest`，不能绕过验证直接生成日报。

## 完整离线资源包强制规则（v2.5）

标准版 `daily_gallery.html` 使用 `images/...` 相对路径，因此正式发布必须同时上传 `output/YYYY-MM-DD/images/`，不得只上传 HTML。飞书内直接预览使用 Base64 便携版；下载日期目录后本地浏览使用标准 HTML 与 images 子目录。

每次生成 HTML 后必须执行：

```bash
python scripts/build_download_manifest.py \
  --date YYYY-MM-DD \
  --html output/YYYY-MM-DD/daily_gallery.html \
  --portable-preview output/YYYY-MM-DD/YYYY-MM-DD_工业设计图片日报_预览版.html \
  --images-dir output/YYYY-MM-DD/images \
  --output output/YYYY-MM-DD/download_manifest.json
```

该脚本必须验证标准 HTML 中每个本地相对图片引用真实存在，并记录文件大小和 SHA-256。任何引用缺失时必须停止发布。`run_full_workflow.py --publish` 必须显式传入 `--images output/YYYY-MM-DD/images` 与 `--download-manifest output/YYYY-MM-DD/download_manifest.json`。

禁止：

- 将最终图片只放在内部 raw-data；
- 仅上传便携 HTML 而省略标准版资源；
- 将图片平铺在日期目录；
- 在缺少图片时继续发布标准 HTML；
- 假设飞书单文件预览会自动解析相邻 images 文件夹。
