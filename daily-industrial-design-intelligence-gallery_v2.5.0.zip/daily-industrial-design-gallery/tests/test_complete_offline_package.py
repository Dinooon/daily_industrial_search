import json
import subprocess
import sys
from pathlib import Path

from integrations.feishu.drive_structure import structure_as_dict
from integrations.feishu.publish_policy import build_publish_plan


def test_drive_structure_has_public_images_folder():
    layout = structure_as_dict('2026-07-30')
    assert layout['public_daily_images'] == ['资源图库', '今日资讯', '2026-07-30', 'images']


def test_final_images_route_to_images_subfolder(tmp_path: Path):
    html = tmp_path / 'daily_gallery.html'; html.write_text('<html></html>', encoding='utf-8')
    image = tmp_path / 'prod_1.jpg'; image.write_bytes(b'jpeg')
    manifest = tmp_path / 'download_manifest.json'; manifest.write_text('{}', encoding='utf-8')
    plan = build_publish_plan(daily_html=html, final_images=[image], download_manifest=manifest)
    by_role = {x.role: x.target_key for x in plan}
    assert by_role['final_image'] == 'public_daily_images'
    assert by_role['download_manifest'] == 'public_daily'


def test_download_manifest_detects_complete_relative_assets(tmp_path: Path):
    day = tmp_path / 'day'; images = day / 'images'; images.mkdir(parents=True)
    (images / 'prod.jpg').write_bytes(b'fake-jpeg-content')
    html = day / 'daily_gallery.html'
    html.write_text('<img src="images/prod.jpg"><div data-lightbox-src="images/prod.jpg"></div>', encoding='utf-8')
    preview = day / 'preview.html'; preview.write_text('<img src="data:image/jpeg;base64,AA==">', encoding='utf-8')
    out = day / 'download_manifest.json'
    subprocess.run([sys.executable, 'scripts/build_download_manifest.py', '--date', '2026-07-30', '--html', str(html), '--portable-preview', str(preview), '--images-dir', str(images), '--output', str(out)], check=True)
    payload = json.loads(out.read_text(encoding='utf-8'))
    assert payload['complete'] is True
    assert payload['image_count'] == 1
    assert payload['required_assets'][0]['path'] == 'images/prod.jpg'
