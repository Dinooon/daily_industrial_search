from collectors.extract import extract_article
from pipeline.quality import classify
from pipeline.dedupe import dedupe

def test_jsonld_product_extract_and_quality():
 html='''<html><head><link rel="canonical" href="https://brand.example/new-x"><script type="application/ld+json">{"@type":"Product","name":"New X","brand":{"name":"Example"},"image":"https://brand.example/x.jpg","datePublished":"2026-07-29"}</script></head><body><article><h1>Example introduces New X</h1><p>Example introduces a new product available now.</p></article></body></html>'''
 x=extract_article(html,'https://brand.example/news/x')
 assert x['product_name']=='New X' and x['brand']=='Example' and x['published_at']
 q=classify({**x,'source_type':'official_brand'},max_age_days=5000)
 assert q['accepted'] is True

def test_canonical_dedupe():
 x={'url':'https://a.test/p?utm_source=x','canonical_url':'https://a.test/p?utm_source=x','title':'P','brand':'B'}
 y={'url':'https://a.test/p','canonical_url':'https://a.test/p','title':'P','brand':'B'}
 clean,dups=dedupe([x,y]);assert len(clean)==1 and len(dups)==1
