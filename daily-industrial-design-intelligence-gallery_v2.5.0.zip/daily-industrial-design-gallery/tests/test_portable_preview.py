from pathlib import Path
from PIL import Image
from scripts.build_portable_preview import build

def test_portable_preview_embeds_local_image(tmp_path: Path):
    image_dir=tmp_path/'images';image_dir.mkdir()
    img=image_dir/'sample.jpg';Image.new('RGB',(640,480),(50,100,150)).save(img,quality=90)
    source=tmp_path/'gallery.html';source.write_text('<html><head></head><body><img src="images/sample.jpg"></body></html>',encoding='utf-8')
    output=tmp_path/'preview.html'
    result=build(source,output,tmp_path,False,1280,78,1)
    assert result['embedded_images']==1
    assert 'data:image/jpeg;base64,' in output.read_text(encoding='utf-8')
