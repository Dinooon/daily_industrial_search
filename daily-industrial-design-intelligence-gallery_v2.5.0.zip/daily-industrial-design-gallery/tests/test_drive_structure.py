from pathlib import Path

from integrations.feishu.drive_structure import DriveStructureManager, structure_as_dict
from integrations.feishu.publish_policy import build_publish_plan


class FakeClient:
    def __init__(self):
        self.children = {"root": []}
        self.created = []
        self.counter = 0

    def list_folder_files(self, folder_token):
        return {"data": {"files": list(self.children.get(folder_token, []))}}

    def create_folder(self, name, parent_token):
        self.counter += 1
        token = f"fld_{self.counter}"
        self.children.setdefault(parent_token, []).append({"name": name, "type": "folder", "token": token})
        self.children[token] = []
        self.created.append((parent_token, name, token))
        return {"data": {"token": token}}


def test_structure_is_created_and_idempotent():
    client = FakeClient()
    manager = DriveStructureManager(client, "root")
    first = manager.ensure_standard_structure("2026-07-30")
    count = len(client.created)
    second = manager.ensure_standard_structure("2026-07-30")
    assert first == second
    assert len(client.created) == count
    assert set(first) >= {"public_daily", "public_daily_images", "public_archive", "database", "internal_processed", "internal_logs"}


def test_structure_contains_required_business_roots():
    layout = structure_as_dict("2026-07-30")
    assert layout["public_daily"] == ["资源图库", "今日资讯", "2026-07-30"]
    assert layout["database"] == ["工业设计情报数据库"]
    assert layout["internal_selections"] == ["工业设计情报系统_内部", "selection-manifests"]


def test_publish_plan_routes_internal_files(tmp_path: Path):
    html = tmp_path / "daily_gallery.html"
    html.write_text("x")
    collected = tmp_path / "collected_data.json"
    collected.write_text("{}")
    health = tmp_path / "source_health.json"
    health.write_text("{}")
    manifest = tmp_path / "upload_manifest.json"
    manifest.write_text("{}")
    plan = build_publish_plan(daily_html=html, internal_artifacts=[collected, health, manifest])
    by_name = {Path(x.path).name: x.target_key for x in plan}
    assert by_name["daily_gallery.html"] == "public_daily"
    assert by_name["collected_data.json"] == "internal_processed"
    assert by_name["source_health.json"] == "internal_logs"
    assert by_name["upload_manifest.json"] == "internal_manifests"
