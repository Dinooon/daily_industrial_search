import json
from datetime import datetime,timezone,timedelta
from pathlib import Path
from pipeline.candidate_scoring import score_candidate
from pipeline.scheduler import is_due
from pipeline.description import evidence_summary

def test_catalog_is_large_and_mail_disabled():
    root=Path(__file__).resolve().parents[1]
    data=json.loads((root/'config/source_catalog.json').read_text(encoding='utf-8'))
    assert len(data['sources']) >= 200
    assert data['policy']['mail_subscriptions_enabled'] is False
    assert all(s.get('mail_subscription') is False for s in data['sources'])

def test_official_launch_scores_high():
    source={'source_type':'official_brand','include_terms':['introduces']}
    score,_=score_candidate({'title':'Brand introduces new modular camera','url':'https://example.com/news/camera'},source)
    assert score >= 60

def test_interview_scores_low():
    score,_=score_candidate({'title':'Interview: history of a design studio','url':'https://example.com/interview'}, {'source_type':'design_media'})
    assert score < 45

def test_scheduler_weekly_not_due():
    now=datetime.now(timezone.utc)
    due,_=is_due({'check_frequency':'weekly'},{'last_checked_at':(now-timedelta(days=1)).isoformat()},now)
    assert due is False

def test_evidence_summary_not_first_chars_only():
    item={'title':'Test Chair','brand':'Acme','body_text':'Welcome to our company. This chair is designed with a modular backrest. It uses recycled aluminum for the frame.','canonical_url':'https://example.com/chair','source_type':'official_brand'}
    desc,evidence=evidence_summary(item,'家具照明')
    assert 'modular backrest' in desc or 'recycled aluminum' in desc
    assert evidence
