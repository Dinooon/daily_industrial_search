import json
from pathlib import Path
from PIL import Image
from scripts.validate_tool_manifest import validate
from scripts.validate_product_images import inspect

def test_rejects_stock_placeholder():
 data={'products':[{'title':'X','page_url':'https://brand.example/x','source':'Brand','image_url':'https://images.unsplash.com/photo-x','discovery_method':'agent_web_search','evidence':[{'type':'product_page','url':'https://brand.example/x'}]}]}
 assert any('forbidden' in x for x in validate(data))

def test_valid_agent_manifest():
 data={'products':[{'title':'Real Product','page_url':'https://brand.example/x','source':'Brand','image_url':'https://brand.example/x.jpg','discovery_method':'agent_web_search','evidence':[{'type':'product_page','url':'https://brand.example/x'}]}]}
 assert validate(data)==[]

def test_svg_is_forbidden(tmp_path):
 p=tmp_path/'fake.svg';p.write_text('<svg/>')
 ok,reasons=inspect(p)
 assert not ok and 'svg_forbidden' in reasons

def test_real_bitmap_passes(tmp_path):
 p=tmp_path/'real.jpg';Image.new('RGB',(800,600),(120,80,30)).save(p,quality=95)
 # add variance to avoid placeholder-like rejection
 im=Image.open(p);pix=im.load()
 for x in range(400):
  for y in range(300):pix[x,y]=(x%255,y%255,(x+y)%255)
 im.save(p,quality=95)
 ok,reasons=inspect(p)
 assert ok, reasons
