from pathlib import Path
import pytest

from integrations.feishu.publish_policy import PublishPolicyError, build_publish_plan


def test_publish_plan_separates_public_and_internal(tmp_path: Path):
    html = tmp_path / 'daily.html'
    image = tmp_path / 'image.jpg'
    audit = tmp_path / 'source_health.json'
    preview = tmp_path / 'daily_preview.html'
    html.write_text('<html></html>', encoding='utf-8')
    image.write_bytes(b'jpg')
    audit.write_text('{}', encoding='utf-8')
    preview.write_text('<html></html>', encoding='utf-8')
    plan = build_publish_plan(daily_html=html, final_images=[image], portable_preview=preview, internal_artifacts=[audit])
    assert [(item.visibility, item.role) for item in plan] == [
        ('public', 'daily_gallery'), ('public', 'final_image'), ('public', 'drive_preview'), ('internal', 'source_health_or_log')
    ]


def test_policy_rejects_scripts_and_manifest(tmp_path: Path):
    scripts = tmp_path / 'scripts'
    scripts.mkdir()
    code = scripts / 'tool.py'
    code.write_text('pass', encoding='utf-8')
    with pytest.raises(PublishPolicyError):
        build_publish_plan(daily_html=code)

    html = tmp_path / 'daily.html'
    manifest = tmp_path / 'history_manifest.json'
    html.write_text('<html></html>', encoding='utf-8')
    manifest.write_text('{}', encoding='utf-8')
    with pytest.raises(PublishPolicyError):
        build_publish_plan(daily_html=html, internal_artifacts=[manifest])
