from pipeline.quality import classify
from scripts.generate_html import HTMLGenerator

def test_rejects_service_program_and_placeholder_image():
    item={
      "title":"Apple Upgrade — Product Leasing Program",
      "body_text":"A new product leasing program for customers.",
      "source_type":"official_brand",
      "page_url":"https://example.com/news/apple-upgrade",
      "image_url":"https://placehold.co/800x600/png?text=x",
      "published_at":"2099-01-01T00:00:00+00:00"
    }
    out=classify(item,99999)
    assert not out["accepted"]
    assert "service_or_program_not_physical_product" in out["exclude_reasons"]
    assert "missing_or_placeholder_image" in out["exclude_reasons"]

def test_html_uses_canonical_as_original_page():
    p={"title":"Chair X","canonical_url":"https://brand.example/chair-x","image_url":"https://brand.example/x.jpg","source":"Brand","product_id":"p1","ai_analysis":{"category":"furniture_lighting","features":"说明"}}
    html=HTMLGenerator(date="2026-07-30").generate([p])
    assert 'href="https://brand.example/chair-x"' in html
    assert '原文 ↗' in html
