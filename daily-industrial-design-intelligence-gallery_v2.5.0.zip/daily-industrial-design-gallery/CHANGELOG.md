# Changelog

## 2.2.0

- 将用户维护的网站清单转换为 241 条机器可读来源。
- 明确禁用邮件订阅和邮箱发现。
- 新增来源调度、持久化状态、入口哈希和全局抓取预算。
- RSS/Sitemap 优先于 HTML 页面发现。
- 新增候选评分，低分候选不抓详情页。
- 新增跨来源候选预去重与官方来源优先级。
- 新增证据驱动的产品说明和结构化 AI 输出。
- 新增相关自动测试和目录说明。

## 2.3.0 — Feishu Drive structured publishing

- Added idempotent creation of the canonical Feishu Drive folder tree.
- Publishing now requires `FEISHU_WORKSPACE_ROOT_FOLDER_TOKEN` and refuses flat-folder fallback.
- Public reports, archive files, internal data, logs, manifests, and selection manifests are routed to separate folders by role.
- The full workflow now publishes `collected_data.json`, `duplicates.json`, and `source_health.json` only into restricted internal folders.

## 2.4.0 - Multi-channel acquisition and verified images
- Added automatic native-network capability detection.
- Added `native_http`, `agent_assisted`, `offline`, and `auto` acquisition modes.
- Added strict agent acquisition manifest schema and validator.
- Added real-image validation and a rejected-image review queue.
- Formal reports now require a verified local bitmap and a traceable source page.
- Prohibited stock-photo substitutes, fabricated image URLs, text SVG placeholders, and AI-generated product images.
- Portable preview generation now fails closed when any image cannot be embedded.

## 2.5.0 — Complete offline gallery package

- Added `资源图库/今日资讯/YYYY-MM-DD/images/` as a mandatory public folder.
- Routed every verified final image to the public images subfolder instead of flattening files.
- Added `scripts/build_download_manifest.py` to validate every relative HTML asset and record SHA-256 checksums.
- `run_full_workflow.py --publish` now always publishes the standard HTML, portable HTML, verified images, and `download_manifest.json` together.
- Publishing fails when a standard HTML image reference is missing.
