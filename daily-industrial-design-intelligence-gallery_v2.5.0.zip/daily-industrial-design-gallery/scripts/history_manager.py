"""
Daily Industrial Design Image Search - History Manager
=======================================================
Manages the persistent history manifest that tracks all previously
collected products across daily runs. Enables incremental updates:
only new products (not in history) are downloaded and processed.

Usage:
    from history_manager import HistoryManager
    
    hm = HistoryManager()
    
    # Load existing history
    history = hm.load_history()
    
    # Check which products are new
    new_products = hm.filter_new(product_list)
    
    # After processing new products, update history
    hm.add_products(new_products)
    hm.save_history()
"""

import os
import json
from pathlib import Path
from datetime import datetime


class HistoryManager:
    """Manages the history manifest for incremental deduplication."""
    
    def __init__(self, history_path=None, base_dir=None):
        """
        Initialize the HistoryManager.
        
        Args:
            history_path: Custom path to history manifest JSON.
                          If None, uses default path in data/ partition.
            base_dir: Base working directory for the SKILL.
        """
        base_dir = base_dir or str(Path(__file__).resolve().parents[1])
        self.base_dir = base_dir
        self.data_dir = os.path.join(base_dir, "data")
        
        if history_path:
            self.history_path = history_path
        else:
            self.history_path = os.path.join(self.data_dir, "history_manifest.json")
        
        self.history = None  # Lazy load
    
    def _default_structure(self):
        """Return the default structure for a new history manifest."""
        return {
            "version": "2.0",
            "created_date": datetime.now().strftime("%Y-%m-%d"),
            "last_updated": datetime.now().strftime("%Y-%m-%d"),
            "total_products_archived": 0,
            "total_runs": 0,
            "run_history": [],  # List of {date, new_count, total_after}
            "products": [],  # List of product records
            "url_index": {}   # Fast lookup: page_url -> product_id
        }
    
    def load_history(self):
        """
        Load the history manifest from disk.
        If it doesn't exist, create a new empty structure.
        
        Returns:
            History manifest dict
        """
        if self.history is not None:
            return self.history
        
        if os.path.exists(self.history_path):
            with open(self.history_path, 'r', encoding='utf-8') as f:
                self.history = json.load(f)
            print(f"  📂 History loaded: {self.history.get('total_products_archived', 0)} products archived, "
                  f"last updated {self.history.get('last_updated', 'unknown')}")
        else:
            # Ensure directory exists
            os.makedirs(os.path.dirname(self.history_path), exist_ok=True)
            self.history = self._default_structure()
            print(f"  📂 No history found. Created new manifest at {self.history_path}")
        
        return self.history
    
    def _build_url_index(self):
        """Rebuild the fast-lookup URL index from products list."""
        self.history["url_index"] = {}
        for product in self.history["products"]:
            url = product.get("page_url", "")
            if url:
                self.history["url_index"][url] = product["product_id"]
    
    def filter_new(self, product_list):
        """
        Filter a list of products, returning only those NOT in history.
        Deduplication is based on page_url (primary key).
        
        Args:
            product_list: List of product dicts, each must have 'page_url'.
        
        Returns:
            Tuple of (new_products, duplicate_count)
        """
        if self.history is None:
            self.load_history()
        
        # Ensure URL index is up to date
        if not self.history.get("url_index"):
            self._build_url_index()
        
        url_index = self.history["url_index"]
        seen_urls = set()  # Intra-batch dedup
        new_products = []
        duplicate_count = 0
        
        for product in product_list:
            page_url = product.get("page_url", "")
            
            # Skip if no URL (can't dedup, treat as new)
            if not page_url:
                new_products.append(product)
                continue
            
            # Cross-batch dedup: check against history
            if page_url in url_index:
                duplicate_count += 1
                continue
            
            # Intra-batch dedup: check within this batch
            if page_url in seen_urls:
                duplicate_count += 1
                continue
            
            seen_urls.add(page_url)
            new_products.append(product)
        
        print(f"  📊 Dedup: {len(product_list)} input → {len(new_products)} new, {duplicate_count} duplicates filtered")
        return new_products, duplicate_count
    
    def add_products(self, new_products, run_date=None):
        """
        Add new products to the history manifest.
        Should be called after products have been successfully processed.
        
        Args:
            new_products: List of product dicts to add to history.
            run_date: Date string (YYYY-MM-DD). If None, uses today.
        
        Returns:
            Number of products added.
        """
        if self.history is None:
            self.load_history()
        
        run_date = run_date or datetime.now().strftime("%Y-%m-%d")
        added_count = 0
        
        for product in new_products:
            page_url = product.get("page_url", "")
            
            # Double-check not already in history
            if page_url and page_url in self.history.get("url_index", {}):
                continue
            
            # Generate product ID
            product_id = product.get("product_id", f"{run_date.replace('-', '')}-{added_count + 1:03d}")
            
            record = {
                "product_id": product_id,
                "title": product.get("title", ""),
                "page_url": page_url,
                "image_url": product.get("image_url", product.get("original_url", "")),
                "source": product.get("source", ""),
                "first_seen_date": run_date,
                "ai_category": product.get("ai_analysis", {}).get("category", ""),
                "ai_category_label": product.get("ai_analysis", {}).get("category_label", ""),
                "ai_style": product.get("ai_analysis", {}).get("style", ""),
                "ai_confidence": product.get("ai_analysis", {}).get("confidence", 0),
            }
            
            self.history["products"].append(record)
            
            # Update URL index
            if page_url:
                self.history["url_index"][page_url] = product_id
            
            added_count += 1
        
        # Update metadata
        self.history["last_updated"] = run_date
        self.history["total_products_archived"] = len(self.history["products"])
        
        # Add run record
        run_record = {
            "date": run_date,
            "new_count": added_count,
            "total_after": self.history["total_products_archived"]
        }
        self.history["run_history"].append(run_record)
        self.history["total_runs"] = len(self.history["run_history"])
        
        print(f"  📝 History updated: +{added_count} products → total {self.history['total_products_archived']}")
        return added_count
    
    def save_history(self):
        """Save the history manifest to disk."""
        if self.history is None:
            print("  ⚠️ No history to save (not loaded)")
            return
        
        os.makedirs(os.path.dirname(self.history_path), exist_ok=True)
        
        with open(self.history_path, 'w', encoding='utf-8') as f:
            json.dump(self.history, f, ensure_ascii=False, indent=2)
        
        print(f"  💾 History saved: {self.history_path} ({os.path.getsize(self.history_path)} bytes)")
    
    def get_stats(self):
        """Return summary statistics about the history."""
        if self.history is None:
            self.load_history()
        
        # Count by source
        by_source = {}
        by_category = {}
        by_date = {}
        
        for p in self.history["products"]:
            src = p.get("source", "unknown")
            by_source[src] = by_source.get(src, 0) + 1
            
            cat = p.get("ai_category", "uncategorized")
            by_category[cat] = by_category.get(cat, 0) + 1
            
            date = p.get("first_seen_date", "unknown")
            by_date[date] = by_date.get(date, 0) + 1
        
        return {
            "total_products": self.history["total_products_archived"],
            "total_runs": self.history["total_runs"],
            "last_updated": self.history["last_updated"],
            "by_source": by_source,
            "by_category": by_category,
            "by_date": by_date,
            "run_history": self.history["run_history"]
        }
    
    def get_all_products(self):
        """Return all archived products (for archive HTML generation)."""
        if self.history is None:
            self.load_history()
        return self.history.get("products", [])
    
    def get_products_by_date(self, date):
        """Return products first seen on a specific date."""
        if self.history is None:
            self.load_history()
        return [p for p in self.history["products"] if p.get("first_seen_date") == date]
    
    def get_products_by_category(self, category):
        """Return products in a specific AI category."""
        if self.history is None:
            self.load_history()
        return [p for p in self.history["products"] if p.get("ai_category") == category]


if __name__ == "__main__":
    # Self-test
    hm = HistoryManager()
    history = hm.load_history()
    stats = hm.get_stats()
    
    print("\n=== History Stats ===")
    print(f"Total products: {stats['total_products']}")
    print(f"Total runs: {stats['total_runs']}")
    print(f"Last updated: {stats['last_updated']}")
    print(f"By source: {stats['by_source']}")
    print(f"By category: {stats['by_category']}")
    
    # Test dedup
    test_products = [
        {"page_url": "https://example.com/product1", "title": "Test Product 1"},
        {"page_url": "https://example.com/product2", "title": "Test Product 2"},
    ]
    new, dupes = hm.filter_new(test_products)
    print(f"\nDedup test: {len(test_products)} input → {len(new)} new, {dupes} dupes")

