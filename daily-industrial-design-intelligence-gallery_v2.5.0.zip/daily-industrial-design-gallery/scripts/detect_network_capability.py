#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,socket
from urllib.parse import urlparse
import requests

def probe(url:str,timeout:float=6)->dict:
    host=urlparse(url).hostname or ''
    dns=False;http=False;error=''
    try: socket.getaddrinfo(host,443);dns=True
    except Exception as e:error=f'DNS: {e}'
    if dns:
        try:
            r=requests.get(url,timeout=timeout,headers={'User-Agent':'DailyDesignGallery/2.4'});http=r.status_code<500
            if not http:error=f'HTTP {r.status_code}'
        except Exception as e:error=f'HTTP: {e}'
    return {'url':url,'dns':dns,'http':http,'error':error}

def main():
    p=argparse.ArgumentParser();p.add_argument('--url',default='https://www.apple.com/newsroom/');p.add_argument('--output');a=p.parse_args()
    r=probe(a.url);r['native_http']=bool(r['dns'] and r['http']);r['recommended_mode']='native_http' if r['native_http'] else 'agent_assisted'
    text=json.dumps(r,ensure_ascii=False,indent=2)
    if a.output: open(a.output,'w',encoding='utf-8').write(text)
    print(text)
if __name__=='__main__':main()
