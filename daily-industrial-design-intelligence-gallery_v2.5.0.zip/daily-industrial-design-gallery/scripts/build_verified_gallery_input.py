#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from pathlib import Path

def main():
 p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--output',required=True);a=p.parse_args();d=json.loads(Path(a.input).read_text(encoding='utf-8'))
 ps=[x for x in d.get('products',[]) if x.get('image_verified') and x.get('local_image_path') and x.get('page_url')]
 if not ps:raise SystemExit('No publishable products: image_verified, local_image_path and page_url are mandatory.')
 d['products']=ps;d['entities']=ps;d.setdefault('stats',{})['publishable']=len(ps);Path(a.output).write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps({'publishable':len(ps),'output':a.output},ensure_ascii=False))
if __name__=='__main__':main()
