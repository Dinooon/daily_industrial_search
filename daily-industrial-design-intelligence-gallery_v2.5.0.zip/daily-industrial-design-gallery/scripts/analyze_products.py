#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
from pipeline.analyze import analyze_payload
p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--output');a=p.parse_args()
src=Path(a.input);out=Path(a.output or a.input);data=json.loads(src.read_text(encoding='utf-8'));out.write_text(json.dumps(analyze_payload(data),ensure_ascii=False,indent=2),encoding='utf-8');print(out)
