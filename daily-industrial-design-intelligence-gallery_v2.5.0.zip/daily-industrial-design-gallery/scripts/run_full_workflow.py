#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def run(cmd):subprocess.run([sys.executable,*cmd],cwd=ROOT,check=True)
def main():
 p=argparse.ArgumentParser();p.add_argument('--date',required=True);p.add_argument('--publish',action='store_true');p.add_argument('--acquisition-mode',choices=['auto','native_http','agent_assisted','offline'],default='auto');p.add_argument('--agent-manifest');p.add_argument('--offline-products');a=p.parse_args()
 mode=a.acquisition_mode
 cap=ROOT/f'data/{a.date}/network_capability.json';cap.parent.mkdir(parents=True,exist_ok=True)
 if mode=='auto':
  run(['scripts/detect_network_capability.py','--output',str(cap)])
  mode=json.loads(cap.read_text())['recommended_mode']
 if mode=='native_http':
  run(['scripts/run_daily_pipeline.py','--date',a.date]);raw=f'data/{a.date}/collected_data.json';source=f'data/{a.date}/materialized_data.json';run(['scripts/materialize_product_images.py','--input',raw,'--output',source,'--images-dir',f'output/{a.date}/source_images'])
 elif mode=='agent_assisted':
  if not a.agent_manifest:raise SystemExit('--agent-manifest is required when native HTTP is unavailable. Do not fabricate products or images.')
  run(['scripts/validate_tool_manifest.py',a.agent_manifest]);source=f'data/{a.date}/agent_collected_data.json';run(['scripts/import_agent_acquisition.py','--manifest',a.agent_manifest,'--output',source])
 elif mode=='offline':
  if not a.offline_products:raise SystemExit('--offline-products is required for offline mode')
  source=a.offline_products
 else:raise SystemExit(f'unsupported mode: {mode}')
 verified=f'data/{a.date}/image_verified_data.json'
 run(['scripts/validate_product_images.py','--products',source,'--output',verified,'--review-queue',f'data/{a.date}/image_review_queue.json'])
 publishable=f'data/{a.date}/gallery_input.json';run(['scripts/build_verified_gallery_input.py','--input',verified,'--output',publishable])
 run(['scripts/analyze_products.py','--input',publishable])
 staged=f'output/{a.date}/gallery_input_staged.json';run(['scripts/stage_verified_images.py','--input',publishable,'--output',staged,'--images-dir',f'output/{a.date}/images'])
 out=f'output/{a.date}/daily_gallery.html';run(['scripts/generate_html.py','--manifest',staged,'--output',out,'--local'])
 preview=f'output/{a.date}/{a.date}_工业设计图片日报_预览版.html';run(['scripts/build_portable_preview.py','--input',out,'--images-root',f'output/{a.date}','--output',preview])
 download_manifest=f'output/{a.date}/download_manifest.json';run(['scripts/build_download_manifest.py','--date',a.date,'--html',out,'--portable-preview',preview,'--images-dir',f'output/{a.date}/images','--output',download_manifest])
 if a.publish:
  internal=[publishable,f'data/{a.date}/image_review_queue.json',f'data/{a.date}/source_health.json',str(cap)]
  existing=[x for x in internal if (ROOT/x).is_file()]
  cmd=['scripts/publish_to_feishu.py','--products',publishable,'--date',a.date,'--html',out,'--portable-preview',preview,'--images',f'output/{a.date}/images','--download-manifest',download_manifest]
  if existing:cmd+=['--internal-artifacts',*existing]
  run(cmd)
 print(json.dumps({'date':a.date,'acquisition_mode':mode,'gallery':out,'preview':preview,'download_manifest':download_manifest},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
