#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def resolve_image(raw:str, manifest:Path)->Path:
 p=Path(raw)
 if p.is_absolute():return p
 candidates=[ROOT/p,manifest.parent/p]
 for c in candidates:
  if c.is_file():return c.resolve()
 return candidates[0].resolve()

def main():
 p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--output',required=True);p.add_argument('--images-dir',required=True);a=p.parse_args()
 src=Path(a.input);data=json.loads(src.read_text(encoding='utf-8'));dest=Path(a.images_dir);dest.mkdir(parents=True,exist_ok=True)
 for item in data.get('products',[]):
  origin=resolve_image(item['local_image_path'],src);suffix=origin.suffix.lower() or '.jpg';name=f"{item['product_id']}{suffix}";target=dest/name
  if origin.resolve()!=target.resolve():shutil.copy2(origin,target)
  item['local_image_source_path']=str(origin);item['local_image_path']='images/'+name
 data['entities']=data.get('products',[]);Path(a.output).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps({'staged':len(data.get('products',[])),'output':a.output,'images_dir':a.images_dir},ensure_ascii=False))
if __name__=='__main__':main()
