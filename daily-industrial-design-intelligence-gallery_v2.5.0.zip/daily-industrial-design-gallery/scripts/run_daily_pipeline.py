#!/usr/bin/env python3
from __future__ import annotations
import argparse,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
from pipeline.run import run_pipeline
from scripts.config import TODAY,DATA_DIR

def main():
    p=argparse.ArgumentParser(description='Collect, extract, validate and deduplicate industrial-design product intelligence.')
    p.add_argument('--date',default=TODAY);p.add_argument('--source-config');p.add_argument('--max-sources',type=int);p.add_argument('--limit-per-source',type=int);p.add_argument('--force',action='store_true')
    a=p.parse_args();out=DATA_DIR/a.date
    result=run_pipeline(out,a.source_config,a.max_sources,a.limit_per_source,a.force)
    print(f"wrote {len(result['products'])} accepted products to {out}")
if __name__=='__main__':main()
