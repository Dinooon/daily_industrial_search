#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,re,sys
from pathlib import Path
from urllib.parse import urlparse
BAD_IMAGE_HOSTS={'images.unsplash.com','unsplash.com','pexels.com','placehold.co','placeholder.com','via.placeholder.com'}
BAD_IMAGE_PATTERNS=('可爱',' reg','placeholder','dummy','sample-image')

def validate(data:dict)->list[str]:
    errors=[]
    for i,p in enumerate(data.get('products',[])):
        pre=f'products[{i}]'
        for k in ('title','page_url','source','image_url','discovery_method','evidence'):
            if not p.get(k):errors.append(f'{pre}.{k}: missing')
        for k in ('page_url','image_url'):
            u=p.get(k,'');q=urlparse(u)
            if q.scheme not in ('http','https'):errors.append(f'{pre}.{k}: must be http(s)')
        ih=urlparse(p.get('image_url','')).netloc.lower()
        if ih in BAD_IMAGE_HOSTS or any(x in p.get('image_url','').lower() for x in BAD_IMAGE_PATTERNS):errors.append(f'{pre}.image_url: stock/placeholder or malformed URL is forbidden')
        ev=p.get('evidence') or []
        if not any(e.get('url')==p.get('page_url') for e in ev):errors.append(f'{pre}.evidence: must cite page_url')
    return errors

def main():
    p=argparse.ArgumentParser();p.add_argument('manifest');a=p.parse_args();data=json.loads(Path(a.manifest).read_text(encoding='utf-8'));errs=validate(data)
    print(json.dumps({'valid':not errs,'errors':errs},ensure_ascii=False,indent=2));sys.exit(1 if errs else 0)
if __name__=='__main__':main()
