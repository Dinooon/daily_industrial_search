#!/usr/bin/env python3
"""Download traceable product images to local bitmaps. Fails closed; no placeholders."""
from __future__ import annotations
import argparse,json,mimetypes
from pathlib import Path
from urllib.parse import urlparse
import requests
from PIL import Image
from io import BytesIO
ROOT=Path(__file__).resolve().parents[1]
BAD={'images.unsplash.com','unsplash.com','pexels.com','placehold.co','placeholder.com','via.placeholder.com'}

def main():
 p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--output',required=True);p.add_argument('--images-dir',required=True);p.add_argument('--timeout',type=int,default=25);a=p.parse_args()
 src=Path(a.input);data=json.loads(src.read_text(encoding='utf-8'));dest=Path(a.images_dir);dest.mkdir(parents=True,exist_ok=True);failed=[];ok=[]
 for item in data.get('products',[]):
  q=dict(item)
  if q.get('local_image_path'):
   ok.append(q);continue
  url=q.get('image_url','');host=urlparse(url).netloc.lower()
  if not url or host in BAD:failed.append({**q,'image_error':'missing_or_forbidden_image_url'});continue
  try:
   r=requests.get(url,timeout=a.timeout,headers={'User-Agent':'Mozilla/5.0 DailyDesignGallery/2.4','Referer':q.get('page_url','')});r.raise_for_status()
   im=Image.open(BytesIO(r.content));im.load()
   if im.mode in ('RGBA','LA'):
    base=Image.new('RGB',im.size,'white');base.paste(im,mask=im.getchannel('A'));im=base
   elif im.mode!='RGB':im=im.convert('RGB')
   name=f"{q['product_id']}.jpg";target=dest/name;im.save(target,'JPEG',quality=90,optimize=True)
   q['local_image_path']=str(target.relative_to(ROOT) if target.is_relative_to(ROOT) else target);q['image_acquisition_method']='native_http_download';ok.append(q)
  except Exception as e:failed.append({**q,'image_error':str(e)[:300]})
 data['products']=ok;data['entities']=ok;data.setdefault('stats',{})['images_materialized']=len(ok);data['stats']['image_download_failures']=len(failed)
 Path(a.output).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8');Path(a.output).with_name('image_download_failures.json').write_text(json.dumps(failed,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps({'downloaded_or_existing':len(ok),'failed':len(failed)},ensure_ascii=False))
 if not ok:raise SystemExit('No real product image could be materialized; formal report stopped.')
if __name__=='__main__':main()
