from __future__ import annotations
import argparse,json,re
from pathlib import Path
from urllib.parse import urlparse

TYPE_BY_SECTION={
 '工业设计与产品设计媒体':'design_media','设计奖项与获奖数据库':'award','重点展会与发布节点':'event',
 '消费电子与个人设备品牌':'official_brand','家电与智能家居品牌':'official_brand','家具、办公与照明品牌':'official_brand',
 '工具、户外与工程产品品牌':'official_brand','汽车与出行品牌':'official_brand','医疗、专业与工业设备品牌':'official_brand',
 '设计机构与工作室':'design_studio','材料、CMF与制造趋势平台':'materials_manufacturing'
}

def slug(name,url):
    host=urlparse(url).netloc.lower().replace('www.','').split('.')[0]
    base=re.sub(r'[^a-z0-9]+','_',name.lower()).strip('_')
    return (base or host)[:70]

def frequency(source_type,name):
    if source_type=='event':return 'weekly'
    if source_type in ('award','design_studio','materials_manufacturing'):return 'weekly'
    if source_type=='official_brand':return 'every_2_days'
    return 'daily'

def budgets(source_type):
    return {'design_media':(30,6,42),'official_brand':(20,4,48),'award':(15,2,50),'event':(15,3,48),'design_studio':(10,2,50),'materials_manufacturing':(10,2,52)}.get(source_type,(12,2,50))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('markdown');ap.add_argument('--output',default='config/source_catalog.json');a=ap.parse_args()
    section='';sources=[];used_ids={}
    for line in Path(a.markdown).read_text(encoding='utf-8').splitlines():
        if line.startswith('## '):section=line[3:].strip().split('. ',1)[-1]
        m=re.search(r'\[([^\]]+)\]\((https?://[^)]+)\)',line)
        if not m:continue
        name,url=m.group(1).strip(),m.group(2).strip();stype=TYPE_BY_SECTION.get(section)
        if not stype:continue
        cand,detail,threshold=budgets(stype)
        base_id=slug(name,url); used_ids[base_id]=used_ids.get(base_id,0)+1; source_id=base_id if used_ids[base_id]==1 else f'{base_id}_{used_ids[base_id]}'
        sources.append({'id':source_id,'publisher':name,'source_type':stype,'priority':'P0' if stype=='design_media' and name in ('Core77','Dezeen','designboom','Yanko Design','Wallpaper*') else 'P1' if stype=='official_brand' else 'P2','url':url,'enabled':True,'check_frequency':frequency(stype,name),'discovery':['rss','sitemap','html'],'candidate_budget':cand,'detail_fetch_budget':detail,'candidate_score_threshold':threshold,'max_age_days':14 if stype in ('design_media','official_brand') else 45,'trust_level':1.0 if stype=='official_brand' else .8 if stype=='design_media' else .7,'mail_subscription':False})
    out={'schema_version':'2.1','policy':{'mail_subscriptions_enabled':False,'discovery_order':['rss','sitemap','html'],'daily_source_budget':40,'daily_detail_budget':60},'defaults':{'enabled':True,'max_age_days':14,'request_interval_seconds':1.2},'sources':sources}
    Path(a.output).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8');print(f'wrote {len(sources)} sources')
if __name__=='__main__':main()
