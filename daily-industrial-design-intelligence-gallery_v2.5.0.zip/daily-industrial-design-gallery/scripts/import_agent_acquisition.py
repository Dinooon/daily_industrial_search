#!/usr/bin/env python3
from __future__ import annotations
import argparse,hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from scripts.validate_tool_manifest import validate

def pid(p):
    if p.get('product_id'):return p['product_id']
    raw='|'.join([p.get('brand','').strip().lower(),p.get('title','').strip().lower(),p.get('page_url','').split('?')[0]])
    return 'prod_'+hashlib.sha256(raw.encode()).hexdigest()[:16]

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--manifest',required=True);ap.add_argument('--output',required=True);a=ap.parse_args()
    data=json.loads(Path(a.manifest).read_text(encoding='utf-8'));errs=validate(data)
    if errs:raise SystemExit('\n'.join(errs))
    products=[]
    for p in data['products']:
        q=dict(p);q['product_id']=pid(q);q['image_verified']=bool(q.get('local_image_path'));q['acquisition_mode']='agent_assisted';products.append(q)
    out={'schema_version':'2.4','run_date':data['run_date'],'products':products,'entities':products,'stats':{'accepted':len(products),'acquisition_mode':'agent_assisted'}}
    Path(a.output).parent.mkdir(parents=True,exist_ok=True);Path(a.output).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'output':a.output,'products':len(products)},ensure_ascii=False))
if __name__=='__main__':main()
