"""Compatibility wrapper for verified image materialization.

Legacy placeholder generation and browser screenshot scripts were removed in v2.4.
Use `scripts/materialize_product_images.py`; failed downloads are rejected and never
replaced by SVG, stock photography, or AI-generated imagery.
"""
from materialize_product_images import main
if __name__=='__main__': main()
