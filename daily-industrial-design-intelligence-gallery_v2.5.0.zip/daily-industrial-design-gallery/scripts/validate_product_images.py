#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,math
from pathlib import Path
from PIL import Image,ImageStat
ROOT=Path(__file__).resolve().parents[1]

def inspect(path:Path,min_w=500,min_h=300,min_bytes=20000):
    reasons=[]
    if not path.is_file():return False,['missing_file']
    if path.suffix.lower()=='.svg':return False,['svg_forbidden']
    if path.stat().st_size<min_bytes:reasons.append('file_too_small')
    try:
        with Image.open(path) as im:
            im.verify()
        with Image.open(path) as im:
            im=im.convert('RGB')
            if im.width<min_w or im.height<min_h:reasons.append('dimensions_too_small')
            thumb=im.copy();thumb.thumbnail((128,128));stat=ImageStat.Stat(thumb)
            if sum(stat.var)/3<35:reasons.append('low_visual_variance_placeholder_like')
    except Exception:reasons.append('invalid_image')
    return not reasons,reasons

def main():
    p=argparse.ArgumentParser();p.add_argument('--products',required=True);p.add_argument('--output',required=True);p.add_argument('--review-queue');a=p.parse_args()
    src=Path(a.products);data=json.loads(src.read_text(encoding='utf-8'));good=[];bad=[]
    for item in data.get('products',data if isinstance(data,list) else []):
        lp=item.get('local_image_path','');raw=Path(lp)
        if raw.is_absolute(): path=raw
        else:
            root_candidate=(ROOT/raw).resolve(); manifest_candidate=(src.parent/raw).resolve()
            path=root_candidate if root_candidate.is_file() else manifest_candidate
        ok,reasons=inspect(path);q=dict(item);q['image_verified']=ok;q['image_validation_reasons']=reasons
        (good if ok else bad).append(q)
    out=dict(data) if isinstance(data,dict) else {'products':[]};out['products']=good;out['entities']=good;out.setdefault('stats',{})['image_verified']=len(good);out['stats']['image_rejected']=len(bad)
    Path(a.output).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    rq=Path(a.review_queue or Path(a.output).with_name('image_review_queue.json'));rq.write_text(json.dumps(bad,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'verified':len(good),'rejected':len(bad),'review_queue':str(rq)},ensure_ascii=False))
    if not good:raise SystemExit('No verified real product images; formal gallery generation stopped.')
if __name__=='__main__':main()
