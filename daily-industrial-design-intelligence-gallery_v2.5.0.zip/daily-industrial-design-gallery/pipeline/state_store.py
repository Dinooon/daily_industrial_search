from __future__ import annotations
import json
from datetime import datetime, timezone
from pathlib import Path

class SourceStateStore:
    def __init__(self, path):
        self.path=Path(path); self.path.parent.mkdir(parents=True, exist_ok=True)
        try:self.data=json.loads(self.path.read_text(encoding='utf-8'))
        except Exception:self.data={'schema_version':'1.0','sources':{}}
    def get(self, source_id): return self.data.setdefault('sources',{}).get(source_id,{})
    def update(self, source_id, **fields):
        state=self.data.setdefault('sources',{}).setdefault(source_id,{})
        state.update(fields); state['updated_at']=datetime.now(timezone.utc).isoformat()
    def save(self): self.path.write_text(json.dumps(self.data,ensure_ascii=False,indent=2),encoding='utf-8')
