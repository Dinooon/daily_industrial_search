from __future__ import annotations
import json
from pathlib import Path
from scripts.config import SOURCE_CONFIG_PATH

def load_sources(path=SOURCE_CONFIG_PATH,enabled_only=True):
    data=json.loads(Path(path).read_text(encoding='utf-8')); defaults=data.get('defaults',{});out=[]
    for s in data.get('sources',[]):
        x={**defaults,**s}
        if not enabled_only or x.get('enabled',True):out.append(x)
    return out
