from __future__ import annotations
import re
from datetime import datetime, timezone
from urllib.parse import urlparse

POSITIVE={
 'launch':26,'launches':26,'launched':25,'introduces':27,'introduced':25,'unveils':27,'unveiled':25,
 'debuts':24,'new collection':22,'available now':20,'next generation':18,'redesign':14,'prototype':12,
 '新品发布':28,'正式发布':28,'全新一代':20,'上市':18,'量产':18,'联名产品':15,'概念产品':10,
 'product':8,'device':8,'chair':7,'lamp':7,'camera':8,'speaker':8,'vehicle':8,'appliance':8,
}
NEGATIVE={'interview':-35,'opinion':-40,'history':-30,'retrospective':-30,'exhibition':-22,'submit':-45,'competition':-28,'award entry':-25,'tutorial':-35,'how to':-28,'招聘':-50,'访谈':-35,'观点':-40,'展览':-20,'征集':-45,'报名':-45}

def score_candidate(candidate, source, now=None):
    now=now or datetime.now(timezone.utc)
    text=(candidate.get('title','')+' '+candidate.get('summary','')+' '+candidate.get('url','')).lower()
    score=0; reasons=[]
    if source.get('source_type')=='official_brand': score+=30; reasons.append('official_source')
    elif source.get('source_type')=='design_media': score+=18; reasons.append('design_media')
    elif source.get('source_type')=='award': score+=7
    elif source.get('source_type')=='event': score+=10
    for term,val in POSITIVE.items():
        if term in text: score+=val; reasons.append(f'+{term}')
    for term,val in NEGATIVE.items():
        if term in text: score+=val; reasons.append(term)
    if candidate.get('published_at'):
        try:
            dt=datetime.fromisoformat(candidate['published_at'].replace('Z','+00:00'))
            age=(now-dt).total_seconds()/86400
            if age<=3: score+=22; reasons.append('fresh_3d')
            elif age<=14: score+=12; reasons.append('fresh_14d')
            elif age>60: score-=30; reasons.append('old_60d')
        except Exception: pass
    path=urlparse(candidate.get('url','')).path.lower()
    if any(x in path for x in ['/news','/press','/product','/products','/design','/launch']): score+=8
    if any(x in path for x in ['/tag/','/category/','/author/','/search']): score-=18
    include=source.get('include_terms') or []
    if include and any(str(x).lower() in text for x in include): score+=12
    return max(-100,min(100,score)),reasons
