from __future__ import annotations
import hashlib,json
from pathlib import Path
from datetime import date,datetime,timezone
from collectors.http_client import HttpClient
from collectors.discovery import html_links,feed_links,sitemap_links
from collectors.extract import extract_article
from pipeline.source_loader import load_sources
from pipeline.quality import classify
from pipeline.dedupe import dedupe
from pipeline.candidate_scoring import score_candidate
from pipeline.scheduler import is_due
from pipeline.state_store import SourceStateStore
from scripts.config import SOURCE_STATE_PATH, DAILY_SOURCE_BUDGET, DAILY_DETAIL_BUDGET, MIN_DAILY_PRODUCTS, MAX_DAILY_PRODUCTS

def _hash(text):return hashlib.sha256((text or '').encode('utf-8','ignore')).hexdigest()

def _discover(client,source):
    modes=source.get('discovery', ['html']); candidates=[]; entrance=None
    # RSS/Sitemap are attempted before HTML to minimize page parsing.
    if 'rss' in modes:
        for endpoint in source.get('feed_urls',[]) or [source['url'].rstrip('/')+x for x in ['/feed/','/rss','/feed.xml']]:
            try:
                r=client.get(endpoint); found=feed_links(r['text'],source['url'],source.get('candidate_budget',40)*2)
                if found:candidates.extend(found);break
            except Exception:pass
    if 'sitemap' in modes:
        for endpoint in source.get('sitemap_urls',[]) or [source['url'].rstrip('/')+x for x in ['/sitemap.xml','/sitemap_index.xml']]:
            try:
                r=client.get(endpoint); found=sitemap_links(r['text'],source.get('candidate_budget',40)*3)
                if found:candidates.extend(found);break
            except Exception:pass
    if 'html' in modes and len(candidates)<source.get('candidate_budget',40):
        entrance=client.get(source['url']); candidates.extend(html_links(entrance['text'],entrance['final_url'],source.get('candidate_budget',40)*2))
    seen=set();out=[]
    for x in candidates:
        u=x.get('url')
        if not u or u in seen:continue
        seen.add(u);out.append(x)
    return out,entrance

def _candidate_key(c):
    title=''.join(ch.lower() for ch in c.get('title','') if ch.isalnum())[:100]
    return title or c.get('url','').split('?')[0]

def run_pipeline(output_dir,source_config=None,max_sources=None,max_items_per_source=None,force=False):
    output=Path(output_dir);output.mkdir(parents=True,exist_ok=True)
    sources=load_sources(source_config) if source_config else load_sources()
    state=SourceStateStore(SOURCE_STATE_PATH)
    priority_rank={'P0':0,'P1':1,'P2':2,'P3':3}
    def source_order(x):
        due,_=is_due(x,state.get(x['id']))
        last=state.get(x['id']).get('last_checked_at','')
        return (0 if due else 1,priority_rank.get(x.get('priority','P2'),2),last,x.get('publisher',''))
    sources=sorted(sources,key=source_order)
    source_cap=max_sources or DAILY_SOURCE_BUDGET
    sources=sources[:source_cap]
    client=HttpClient(); records=[]; health=[]
    global_seen={};global_detail_count=0
    for s in sources:
        st=state.get(s['id']);due,due_reason=is_due(s,st)
        h={'source_id':s['id'],'publisher':s['publisher'],'source_type':s['source_type'],'status':'ok','due':due,'due_reason':due_reason,'discovered':0,'scored':0,'detail_fetched':0,'parsed':0,'accepted':0,'skipped_unchanged':False,'errors':[]}
        if not due and not force:
            h['status']='not_due';health.append(h);continue
        try:
            candidates,entrance=_discover(client,s);h['discovered']=len(candidates)
            entrance_hash=_hash(entrance['text']) if entrance else ''
            if entrance_hash and entrance_hash==st.get('entrance_hash') and not any(c.get('published_at') for c in candidates) and not force:
                h['status']='unchanged';h['skipped_unchanged']=True;state.update(s['id'],last_checked_at=datetime.now(timezone.utc).isoformat());health.append(h);continue
            scored=[]
            for c in candidates:
                score,reasons=score_candidate(c,s);c={**c,'candidate_score':score,'score_reasons':reasons}
                threshold=int(s.get('candidate_score_threshold',38))
                if score>=threshold:scored.append(c)
            scored.sort(key=lambda x:x['candidate_score'],reverse=True);h['scored']=len(scored)
            budget=int(s.get('detail_fetch_budget',5))
            if max_items_per_source:budget=min(budget,max_items_per_source)
            for c in scored:
                if global_detail_count>=DAILY_DETAIL_BUDGET:break
                key=_candidate_key(c)
                old=global_seen.get(key)
                if old and old.get('candidate_score',-999)>=c['candidate_score']:continue
                if h['detail_fetched']>=budget:break
                try:
                    page=client.get(c['url']);h['detail_fetched']+=1;global_detail_count+=1
                    art=extract_article(page['text'],page['final_url'])
                    item={**c,**art,'page_url':art.get('page_url') or art.get('canonical_url') or page['final_url'],'source_id':s['id'],'publisher':s['publisher'],'source':s['publisher'],'source_type':s['source_type'],'brand':art.get('brand') or s.get('brand',''),'official_url':art.get('canonical_url') if s['source_type']=='official_brand' else '','source_trust':s.get('trust_level',1.0 if s['source_type']=='official_brand' else .75)}
                    item=classify(item,s.get('max_age_days',14));h['parsed']+=1
                    if item['accepted']:
                        h['accepted']+=1;global_seen[key]=item
                except Exception as e:h['errors'].append(str(e)[:300])
            state.update(s['id'],last_checked_at=datetime.now(timezone.utc).isoformat(),last_success_at=datetime.now(timezone.utc).isoformat(),entrance_hash=entrance_hash,last_discovered=h['discovered'],last_accepted=h['accepted'])
        except Exception as e:
            h['status']='failed';h['errors'].append(str(e)[:500]);state.update(s['id'],last_checked_at=datetime.now(timezone.utc).isoformat(),last_error=str(e)[:500])
        health.append(h)
    state.save();records=list(global_seen.values())
    # Keep the report useful on slow news days without allowing unlimited output.
    records=records[:MAX_DAILY_PRODUCTS]
    # Official sources win when a normalized candidate appears in multiple sources.
    records.sort(key=lambda x:(x.get('source_type')!='official_brand',-float(x.get('candidate_score',0))))
    clean,dups=dedupe(records)
    payload={'schema_version':'2.1','run_date':date.today().isoformat(),'products':clean,'entities':clean,'stats':{'configured_sources':len(sources),'checked_sources':sum(1 for x in health if x['status'] not in ('not_due',)),'detail_pages':sum(x['detail_fetched'] for x in health),'accepted':len(clean),'target_min':MIN_DAILY_PRODUCTS,'target_met':len(clean)>=MIN_DAILY_PRODUCTS,'duplicates':len(dups)}}
    (output/'collected_data.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
    (output/'duplicates.json').write_text(json.dumps(dups,ensure_ascii=False,indent=2),encoding='utf-8')
    (output/'source_health.json').write_text(json.dumps(health,ensure_ascii=False,indent=2),encoding='utf-8')
    return payload
