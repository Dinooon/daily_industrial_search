from __future__ import annotations
import re

def _sentences(text):
    text=re.sub(r'\s+',' ',text or '').strip()
    return [s.strip() for s in re.split(r'(?<=[。！？.!?])\s+',text) if len(s.strip())>24]

def evidence_summary(item, category_label='其他'):
    title=item.get('product_name') or item.get('title') or '该产品'
    brand=item.get('brand') or item.get('publisher') or ''
    body=item.get('body_text','')
    keys=['design','designed','material','made from','features','equipped','uses','includes','available','launch','采用','设计','材料','搭载','配备','功能','发布','上市']
    ranked=[]
    for sentence in _sentences(body):
        hits=sum(1 for k in keys if k in sentence.lower())
        if hits: ranked.append((hits,min(len(sentence),220),sentence))
    ranked.sort(key=lambda x:(-x[0],x[1]))
    facts=[x[2] for x in ranked[:2]]
    identity=f"{brand+' ' if brand else ''}{title}是一项{category_label}相关新品或设计项目。"
    if facts:
        desc=identity+' '.join(facts)
    else:
        desc=identity+'当前页面未提取到足够的功能、材料或设计细节，建议查看官方原文确认。'
    return desc[:360], [{'source_url':item.get('canonical_url') or item.get('url'),'source_type':item.get('source_type'),'evidence_text':f[:220]} for f in facts]
