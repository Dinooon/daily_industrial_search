from __future__ import annotations
import json,os
import requests
from scripts.config import CATEGORIES
from pipeline.description import evidence_summary

RULES={
'consumer_electronics':['phone','smartphone','camera','speaker','headphone','earbud','display','monitor','laptop','tablet','charger','drone'],
'furniture_lighting':['chair','table','sofa','lamp','lighting','shelf','furniture','stool'],
'transportation':['car','vehicle','bike','bicycle','scooter','mobility','motorcycle','camper'],
'home_appliances':['vacuum','washer','dryer','refrigerator','oven','purifier','appliance','hair dryer'],
'wearable_tech':['watch','wearable','glasses','headset','ring'],
'medical_health':['medical','healthcare','rehabilitation','diagnostic'],
'sports_outdoors':['outdoor','camping','sport','fitness','hiking'],
'tools_equipment':['tool','pen','equipment','machine'],
'sustainable_design':['recycled','sustainable','circular','biodegradable','waste'],
'kitchen_tableware':['kitchen','faucet','cookware','tableware'],
'commercial_equipment':['industrial','commercial','robot','station']}

def _category(item):
    text=(item.get('title','')+' '+item.get('body_text','')[:5000]).lower();cat='other';score=0
    for k,terms in RULES.items():
        n=sum(1 for t in terms if t in text)
        if n>score:cat=k;score=n
    return cat,score

def heuristic(item):
    cat,score=_category(item);description,evidence=evidence_summary(item,CATEGORIES.get(cat,cat))
    return {
      'category':cat,'category_label':CATEGORIES.get(cat,cat),'subcategory':'','style':'','materials':'',
      'features':description,'description':description,'target_user':'','confidence':round(min(.48+.07*score,.82),2),
      'analysis_mode':'heuristic_evidence','verified_facts':[],'design_observations':[], 'evidence':evidence
    }

def analyze(item):
    url=os.getenv('AI_API_URL');key=os.getenv('AI_API_KEY');model=os.getenv('AI_MODEL','gpt-4.1-mini')
    if not url or not key:return heuristic(item)
    prompt={
      'title':item.get('title'),'product_name':item.get('product_name'),'brand':item.get('brand'),
      'source_type':item.get('source_type'),'source_url':item.get('canonical_url') or item.get('url'),
      'published_at':item.get('published_at'),'text':item.get('body_text','')[:7000],
      'allowed_categories':list(CATEGORIES),
      'instruction':'提取可验证事实与设计观察，再生成60-120字中文产品说明。未被正文支持的材料、上市状态和规格不得写入。'
    }
    schema='''Return JSON only with keys: category, category_label, subcategory, style, materials, verified_facts (array of strings), design_observations (array of strings), evidence (array of {field,value,evidence_text,source_url}), description, features, target_user, confidence. description and features must be identical Chinese text, 60-120 Chinese characters when evidence is sufficient. Clearly separate verified facts from design observations. Do not invent materials, specifications, availability, designer, or release facts. Unknown values must be empty.'''
    try:
        r=requests.post(url,headers={'Authorization':f'Bearer {key}','Content-Type':'application/json'},json={'model':model,'messages':[{'role':'system','content':schema},{'role':'user','content':json.dumps(prompt,ensure_ascii=False)}],'response_format':{'type':'json_object'}},timeout=60)
        r.raise_for_status();data=r.json();content=data['choices'][0]['message']['content'];out=json.loads(content)
        out['features']=out.get('description') or out.get('features') or ''
        out['description']=out['features'];out['analysis_mode']='model_evidence'
        if not out['features']:return heuristic(item)
        return out
    except Exception:return heuristic(item)

def analyze_payload(payload):
    for p in payload.get('products',[]):p['ai_analysis']=analyze(p)
    payload['entities']=payload.get('products',[]);return payload
