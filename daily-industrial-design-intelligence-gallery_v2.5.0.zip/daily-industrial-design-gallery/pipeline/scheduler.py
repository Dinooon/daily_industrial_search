from __future__ import annotations
from datetime import datetime, timezone, timedelta

def is_due(source,state,now=None):
    now=now or datetime.now(timezone.utc)
    freq=source.get('check_frequency','daily')
    if source.get('event_only') and not _event_active(source,now.date()): return False,'outside_event_window'
    last=state.get('last_checked_at')
    if not last:return True,'never_checked'
    try:last_dt=datetime.fromisoformat(last.replace('Z','+00:00'))
    except Exception:return True,'invalid_state'
    hours={'daily':20,'every_2_days':44,'weekly':144,'monthly':600}.get(freq,20)
    return now-last_dt>=timedelta(hours=hours),freq

def _event_active(source,today):
    start=source.get('event_start'); end=source.get('event_end')
    if not start or not end:return False
    try:
        s=datetime.fromisoformat(start).date();e=datetime.fromisoformat(end).date()
        before=int(source.get('active_before_days',30));after=int(source.get('active_after_days',7))
        return s-timedelta(days=before)<=today<=e+timedelta(days=after)
    except Exception:return False
