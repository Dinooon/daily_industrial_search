from __future__ import annotations
from datetime import datetime,timezone,timedelta
from urllib.parse import urlparse

NON_PRODUCT=['interview','opinion','exhibition','architecture','competition opens','submit now','award submission','tutorial','how to','retrospective','history of','leasing program','subscription program','financing program','service launches','partnership','earnings','appointment']
PRODUCT_HINT=['launch','introduc','unveil','new ','product','device','chair','lamp','camera','speaker','watch','phone','vacuum','appliance','tool','vehicle','bike','furniture','collection','machine','robot']
SERVICE_HINT=['leasing','subscription','financing','service','program','membership','platform','software update','app update']
PLACEHOLDER_HOSTS={'placehold.co','placeholder.com','via.placeholder.com'}

def _is_placeholder(url:str)->bool:
    try:return urlparse(url or '').netloc.lower() in PLACEHOLDER_HOSTS
    except Exception:return False

def classify(item,max_age_days=14):
    text=(item.get('title','')+' '+item.get('body_text','')[:3000]).lower()
    source_type=item.get('source_type')
    reason=[]; accepted=True
    page=item.get('page_url') or item.get('canonical_url') or item.get('url')
    image=item.get('image_url')
    if any(k in text for k in NON_PRODUCT) and not any(k in text for k in PRODUCT_HINT):accepted=False;reason.append('non_product_editorial')
    if any(k in text for k in SERVICE_HINT) and not any(k in text for k in ['device','chair','lamp','camera','speaker','watch','phone','vehicle','furniture','appliance','tool','machine','robot']):
        accepted=False;reason.append('service_or_program_not_physical_product')
    if source_type=='official_brand' and not any(k in text for k in PRODUCT_HINT):accepted=False;reason.append('official_non_product_news')
    if not page:accepted=False;reason.append('missing_source_page')
    if not image or _is_placeholder(image):accepted=False;reason.append('missing_or_placeholder_image')
    pub=item.get('published_at')
    if pub:
        try:
            dt=datetime.fromisoformat(pub.replace('Z','+00:00'))
            if datetime.now(timezone.utc)-dt>timedelta(days=max_age_days):accepted=False;reason.append('older_than_window')
        except Exception:reason.append('invalid_date')
    else:reason.append('missing_date')
    content_type='physical_product' if any(k in text for k in PRODUCT_HINT) and not any(k in text for k in SERVICE_HINT) else 'unknown'
    release_status='released' if any(k in text for k in ['available now','launches','launched','introduces','unveils','正式发布','上市']) else 'unverified'
    score=0.2+(0.25 if source_type=='official_brand' else 0.15)+(0.18 if pub else 0)+(0.18 if image and not _is_placeholder(image) else 0)+(0.12 if page else 0)+(0.07 if len(item.get('body_text',''))>300 else 0)
    return {**item,'page_url':page or '','accepted':accepted,'exclude_reasons':reason,'content_type':content_type,'release_status':release_status,'quality_score':round(min(score,1),2)}
