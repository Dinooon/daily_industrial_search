from __future__ import annotations
import hashlib,re
from urllib.parse import urlsplit,urlunsplit,parse_qsl,urlencode
TRACK={'utm_source','utm_medium','utm_campaign','utm_term','utm_content','fbclid','gclid'}
def normalize_url(url):
    p=urlsplit(url); q=[(k,v) for k,v in parse_qsl(p.query,keep_blank_values=True) if k.lower() not in TRACK]
    return urlunsplit((p.scheme.lower(),p.netloc.lower(),p.path.rstrip('/') or '/',urlencode(q),''))
def norm_text(s):return re.sub(r'[^a-z0-9]+',' ',(s or '').lower()).strip()
def product_id(item):
    basis='|'.join([norm_text(item.get('brand')),norm_text(item.get('product_name') or item.get('title')),normalize_url(item.get('official_url') or item.get('canonical_url') or item.get('url',''))])
    return 'prod_'+hashlib.sha1(basis.encode()).hexdigest()[:16]
def dedupe(items):
    out=[];dups=[];seen={}
    for x in items:
        key=normalize_url(x.get('canonical_url') or x.get('url',''))
        if key in seen:dups.append({'duplicate':x,'kept':seen[key]});continue
        x['canonical_url']=key;x['product_id']=product_id(x);seen[key]=x;out.append(x)
    return out,dups
