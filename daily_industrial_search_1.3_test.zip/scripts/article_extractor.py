#!/usr/bin/env python3
from __future__ import annotations
import json,re
from datetime import datetime
from bs4 import BeautifulSoup
from urllib.parse import urljoin,urlsplit
DATE_KEYS=('datePublished','dateCreated','uploadDate')
def iso_date(value):
    if not value:return None
    s=str(value).strip()
    try:return datetime.fromisoformat(s.replace('Z','+00:00')).date().isoformat()
    except Exception:pass
    for fmt in ('%m/%d/%Y','%Y-%m-%d','%b %d, %Y','%B %d, %Y','%a, %d %b %Y %H:%M:%S %z'):
        try:return datetime.strptime(s,fmt).date().isoformat()
        except Exception:pass
    m=re.search(r'(20\d{2})[-/.](\d{1,2})[-/.](\d{1,2})',s)
    return f'{m.group(1)}-{int(m.group(2)):02d}-{int(m.group(3)):02d}' if m else None
def date_from_url(url):
    p=urlsplit(url).path
    m=re.search(r'/(20\d{2})/(\d{2})/(\d{2})/',p)
    if m:return f'{m.group(1)}-{m.group(2)}-{m.group(3)}',.90,'url_path'
    return None,0.0,None
def _nodes(payload):
    stack=payload if isinstance(payload,list) else [payload]
    for node in stack:
        if not isinstance(node,dict):continue
        yield node
        graph=node.get('@graph')
        if isinstance(graph,list): yield from (x for x in graph if isinstance(x,dict))
def extract_metadata(html,url):
    soup=BeautifulSoup(html or '','lxml')
    out={'title':None,'description':None,'image_url':None,'published_at':None,'modified_at':None,'date_confidence':0.0,'date_source':None,'canonical_url':url,'body_text':'','author':None,'brand':None,'product_name':None,'evidence':[]}
    can=soup.find('link',rel=lambda x:x and 'canonical' in x)
    if can and can.get('href'):out['canonical_url']=urljoin(url,can['href'])
    meta_map={'og:title':'title','og:description':'description','og:image':'image_url','article:published_time':'published_at','article:modified_time':'modified_at'}
    for prop,key in meta_map.items():
        tag=soup.find('meta',property=prop)
        if tag and tag.get('content'): out[key]=tag['content'].strip(); out['evidence'].append({'field':key,'source':'meta','value':out[key]})
    for script in soup.find_all('script',type='application/ld+json'):
        try: payload=json.loads(script.string or '{}')
        except Exception: continue
        for node in _nodes(payload):
            typ=node.get('@type'); types=typ if isinstance(typ,list) else [typ]
            out['title']=out['title'] or node.get('headline') or node.get('name')
            out['description']=out['description'] or node.get('description')
            if any(t=='Product' for t in types if t):
                out['product_name']=node.get('name') or out['product_name']
                brand=node.get('brand'); out['brand']=(brand.get('name') if isinstance(brand,dict) else brand) or out['brand']
            img=node.get('image')
            if not out['image_url'] and img: out['image_url']=img[0] if isinstance(img,list) else (img.get('url') if isinstance(img,dict) else img)
            author=node.get('author')
            if not out['author'] and author: out['author']=author.get('name') if isinstance(author,dict) else str(author)
            for k in DATE_KEYS:
                if node.get(k) and not out['published_at']:
                    out['published_at']=node[k]; out['date_confidence']=.98; out['date_source']='json_ld'; out['evidence'].append({'field':'published_at','source':'json_ld','value':node[k]})
    if not out['title'] and soup.title:out['title']=soup.title.get_text(' ',strip=True)
    if out['published_at']:
        out['published_at']=iso_date(out['published_at'])
        if not out['date_confidence']:out['date_confidence']=.95;out['date_source']='meta'
    if not out['published_at']:
        for tag in soup.find_all('time'):
            d=iso_date(tag.get('datetime') or tag.get_text(' ',strip=True))
            if d: out['published_at']=d;out['date_confidence']=.85;out['date_source']='time_element';break
    if not out['published_at']:
        d,c,s=date_from_url(url);out['published_at']=d;out['date_confidence']=c;out['date_source']=s
    body=soup.find('article') or soup.find('main') or soup.body
    if body:
        for x in body.find_all(['script','style','nav','footer','aside']):x.decompose()
        out['body_text']=re.sub(r'\s+',' ',body.get_text(' ',strip=True))[:20000]
    return out
