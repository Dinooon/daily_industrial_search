#!/usr/bin/env python3
from __future__ import annotations
import hashlib,re
from difflib import SequenceMatcher

def norm(s): return re.sub(r'[^a-z0-9]+',' ',(s or '').lower()).strip()
def product_key(item):
    brand=norm(item.get('brand')); name=norm(item.get('product_name') or item.get('title'))
    return hashlib.sha1(f'{brand}|{name}'.encode()).hexdigest()[:16]
def similarity(a,b):
    ta=norm(a.get('product_name') or a.get('title')); tb=norm(b.get('product_name') or b.get('title'))
    score=SequenceMatcher(None,ta,tb).ratio()
    ba,bb=norm(a.get('brand')),norm(b.get('brand'))
    if ba and bb and ba==bb: score+=.15
    if a.get('image_hash') and a.get('image_hash')==b.get('image_hash'): score+=.35
    return min(score,1.0)
def cluster(items,threshold=.82):
    products=[]
    for item in items:
        match=None
        for p in products:
            if similarity(item,p['canonical'])>=threshold: match=p; break
        if not match:
            match={'product_id':'prod_'+product_key(item),'canonical':dict(item),'coverages':[]}; products.append(match)
        match['coverages'].append({'publisher':item.get('publisher'),'url':item.get('canonical_url') or item.get('page_url'),'published_at':item.get('published_at'),'title':item.get('title')})
        if (item.get('quality_score') or 0)>(match['canonical'].get('quality_score') or 0): match['canonical']=dict(item)
    return products
