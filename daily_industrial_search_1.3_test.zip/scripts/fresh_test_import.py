#!/usr/bin/env python3
"""Import externally verified fresh discoveries into the same normalized schema.
Useful in restricted CI environments where direct DNS/browser access is unavailable.
"""
import argparse,json,os,sys
from datetime import date
sys.path.insert(0,os.path.dirname(__file__))
from quality import normalize_product,dedupe_batch
BASE=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def main():
 p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--date',default=date.today().isoformat());a=p.parse_args()
 with open(a.input,encoding='utf-8') as f:items=json.load(f)
 products=[normalize_product(x,a.date) for x in items]
 products,dups=dedupe_batch(products)
 outdir=os.path.join(BASE,'data',a.date);os.makedirs(outdir,exist_ok=True)
 payload={"schema_version":"2.1","run_date":a.date,"collection_mode":"externally_verified_fresh_test","raw_total":len(items),"duplicate_count":len(dups),"total_products":len(products),"products":products}
 with open(os.path.join(outdir,'collected_data.json'),'w',encoding='utf-8') as f:json.dump(payload,f,ensure_ascii=False,indent=2)
 with open(os.path.join(outdir,'duplicates.json'),'w',encoding='utf-8') as f:json.dump(dups,f,ensure_ascii=False,indent=2)
 print(json.dumps({"date":a.date,"accepted":len(products),"duplicates":len(dups)},ensure_ascii=False))
if __name__=='__main__':main()
