#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,sys
from datetime import datetime
from pathlib import Path
from urllib.parse import urlsplit
sys.path.insert(0,str(Path(__file__).parent))
from http_client import CachedHttpClient
from source_registry import source_meta
from sources.generic import discover_html
from sources.feed import discover_feed
from sources.sitemap import discover_sitemap
from article_extractor import extract_metadata
from quality import normalize_product,dedupe_batch
from entity_resolver import cluster
ROOT=Path(__file__).resolve().parents[1]
def load_sources(path):return json.loads(Path(path).read_text())
def discover(client,source):
 errors=[]
 try:
  r=client.get(source['url']); items=discover_html(r['text'],r['final_url'],source.get('patterns'),30)
  if items:return items,'html',errors
 except Exception as e:errors.append(f'primary:{e}')
 for fb in source.get('fallbacks',[]):
  try:
   r=client.get(fb); text=r['text']; items=discover_sitemap(text) if 'sitemap' in fb else discover_feed(text)
   if items:return items,('sitemap' if 'sitemap' in fb else 'rss'),errors
  except Exception as e:errors.append(f'fallback:{fb}:{e}')
 return [],'failed',errors
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--date',default=datetime.now().astimezone().date().isoformat());ap.add_argument('--sources',default=str(ROOT/'config/sources.json'));ap.add_argument('--limit-per-source',type=int,default=12);ap.add_argument('--max-age-days',type=int,default=14);a=ap.parse_args()
 outdir=ROOT/'data'/a.date;outdir.mkdir(parents=True,exist_ok=True);client=CachedHttpClient(ROOT/'.cache/http')
 raw=[];health=[]
 for src in load_sources(a.sources):
  meta=source_meta(src['publisher_id'],src['channel_id']);items,method,errors=discover(client,src);accepted=0
  for item in items[:a.limit_per_source]:
   item.update(meta);item['source_url']=src['url'];item['discovery_method']=item.get('discovery_method',method)
   try:
    detail=client.get(item['page_url']); md=extract_metadata(detail['text'],detail['final_url']); item.update({k:v for k,v in md.items() if v not in (None,'')}); item['fetch_status']='ok';item['from_cache']=detail['from_cache']
   except Exception as e:item['fetch_status']='failed';item['fetch_error']=str(e)
   p=normalize_product(item,a.date)
   if p.get('published_at') and p['published_at']<a.date:
    from datetime import date
    if (date.fromisoformat(a.date)-date.fromisoformat(p['published_at'])).days>a.max_age_days:p['is_product_candidate']=False;p['filter_reason']='outside_freshness_window'
   raw.append(p);accepted+=int(p['is_product_candidate'])
  health.append({'publisher_id':src['publisher_id'],'channel_id':src['channel_id'],'method':method,'discovered':len(items),'processed':min(len(items),a.limit_per_source),'accepted':accepted,'errors':errors})
 deduped,dups=dedupe_batch(raw);candidates=[x for x in deduped if x.get('is_product_candidate')];entities=cluster(candidates)
 payload={'schema_version':'1.3','run_date':a.date,'collection_mode':'live_with_fallbacks','raw_count':len(raw),'deduped_count':len(deduped),'candidate_count':len(candidates),'products':deduped,'entities':entities}
 (outdir/'collected_data.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2));(outdir/'duplicates.json').write_text(json.dumps(dups,ensure_ascii=False,indent=2));(outdir/'source_health.json').write_text(json.dumps(health,ensure_ascii=False,indent=2))
 print(json.dumps({'data':str(outdir/'collected_data.json'),'raw':len(raw),'candidates':len(candidates),'entities':len(entities)},ensure_ascii=False))
if __name__=='__main__':main()
