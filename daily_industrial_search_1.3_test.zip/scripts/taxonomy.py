#!/usr/bin/env python3
ALIASES={'consumer electronics':'electronics','electronic device':'electronics','smart device':'electronics','lighting':'lighting','lamp':'lighting','chair':'furniture','table':'furniture','automotive':'transportation','mobility':'transportation'}
CATEGORIES={'electronics','furniture','lighting','transportation','appliance','medical','tool','outdoor','kitchen','wearable','robotics','material','other'}
def normalize_category(value):
 v=(value or 'other').strip().lower(); v=ALIASES.get(v,v); return v if v in CATEGORIES else 'other'
