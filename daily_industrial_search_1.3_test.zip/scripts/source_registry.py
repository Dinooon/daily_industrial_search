#!/usr/bin/env python3
SOURCES={
 'core77':{'publisher':'Core77','source_type':'design_media','priority':2,'channels':{'home':'https://www.core77.com/'}},
 'designboom':{'publisher':'Designboom','source_type':'design_media','priority':2,'channels':{'design':'https://www.designboom.com/design/'}},
 'yanko':{'publisher':'Yanko Design','source_type':'design_media','priority':2,'channels':{'home':'https://www.yankodesign.com/'}},
 'dezeen':{'publisher':'Dezeen','source_type':'design_media','priority':2,'channels':{'design':'https://www.dezeen.com/design/'}},
 'designmilk':{'publisher':'Design Milk','source_type':'design_media','priority':2,'channels':{'home':'https://design-milk.com/'}},
 'red_dot':{'publisher':'Red Dot','source_type':'award','priority':3,'channels':{'product':'https://www.red-dot.org/pd'}},
}
def source_meta(publisher_id,channel_id='home',collector_id='html_generic_v1'):
 s=SOURCES[publisher_id]
 return {'publisher_id':publisher_id,'publisher':s['publisher'],'channel_id':f'{publisher_id}:{channel_id}','collector_id':collector_id,'source_type':s['source_type'],'source_priority':s['priority']}
