#!/usr/bin/env python3
"""Compatibility wrapper. The maintained collector is collect_products_v2.py."""
from collect_products_v2 import main
if __name__ == "__main__":
    raise SystemExit(main())
