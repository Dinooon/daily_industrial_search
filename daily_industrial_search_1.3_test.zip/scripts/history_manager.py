#!/usr/bin/env python3
import json, os, hashlib, re
from collections import Counter
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode

TRACKING_KEYS = {"utm_source","utm_medium","utm_campaign","utm_term","utm_content","fbclid","gclid","ref"}

def canonicalize_url(url: str) -> str:
    if not url: return ""
    p=urlsplit(url.strip())
    scheme=(p.scheme or "https").lower(); netloc=p.netloc.lower().replace(":80","").replace(":443","")
    path=re.sub(r"/+","/",p.path or "/").rstrip("/") or "/"
    query=urlencode(sorted((k,v) for k,v in parse_qsl(p.query,keep_blank_values=True) if k.lower() not in TRACKING_KEYS))
    return urlunsplit((scheme,netloc,path,query,""))

def title_key(title: str) -> str:
    return re.sub(r"[^a-z0-9\u4e00-\u9fff]+","",(title or "").lower())[:160]

class HistoryManager:
    def __init__(self, base_dir):
        self.base_dir=base_dir
        self.path=os.path.join(base_dir,"data","history_manifest.json")
        self.history={"schema_version":"2.0","products":[],"total_products_archived":0}
        self.url_index=set(); self.title_index=set()
    def load_history(self):
        if os.path.exists(self.path):
            with open(self.path,encoding="utf-8") as f: self.history=json.load(f)
        products=self.history.get("products", self.history.get("items", []))
        self.history["products"]=products
        self.url_index={canonicalize_url(p.get("canonical_url") or p.get("page_url","")) for p in products}
        self.title_index={title_key(p.get("title") or p.get("ai_analysis",{}).get("product_name","")) for p in products if title_key(p.get("title") or p.get("ai_analysis",{}).get("product_name",""))}
        return self.history
    def filter_new(self, products):
        new=[]; duplicates=0; batch_urls=set(); batch_titles=set()
        for p in products:
            c=canonicalize_url(p.get("page_url","")); tk=title_key(p.get("title",""))
            p["canonical_url"]=c
            duplicate = (c and (c in self.url_index or c in batch_urls)) or (tk and len(tk)>18 and (tk in self.title_index or tk in batch_titles))
            if duplicate: duplicates+=1; continue
            if c: batch_urls.add(c)
            if tk: batch_titles.add(tk)
            new.append(p)
        return new, duplicates
    def add_products(self, products, run_date):
        added=0
        for p in products:
            c=canonicalize_url(p.get("canonical_url") or p.get("page_url",""))
            if c in self.url_index: continue
            p["canonical_url"]=c; p.setdefault("first_seen_at",run_date)
            raw=f"{c}|{p.get('title','')}".encode(); p.setdefault("entity_candidate_id","cand_"+hashlib.sha1(raw).hexdigest()[:14])
            self.history["products"].append(p); self.url_index.add(c); added+=1
        self.history["total_products_archived"]=len(self.history["products"])
        return added
    def save_history(self):
        os.makedirs(os.path.dirname(self.path),exist_ok=True)
        with open(self.path,"w",encoding="utf-8") as f: json.dump(self.history,f,ensure_ascii=False,indent=2)
    def get_stats(self):
        ps=self.history.get("products",[])
        return {"by_source":dict(Counter(p.get("source_id","unknown") for p in ps)),"by_category":dict(Counter(p.get("ai_analysis",{}).get("category","unknown") for p in ps)),"by_date":dict(Counter(p.get("first_seen_at") or p.get("date","unknown") for p in ps))}
