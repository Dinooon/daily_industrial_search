#!/usr/bin/env python3
import argparse,json,os,sys
from quality import normalize_product,dedupe_batch
BASE=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--date',required=True); ap.add_argument('--include-non-products',action='store_true'); a=ap.parse_args()
 path=os.path.join(BASE,'data',a.date,'collected_data.json')
 with open(path,encoding='utf-8') as f:data=json.load(f)
 normalized=[normalize_product(p,a.date) for p in data.get('products',[])]
 unique,dups=dedupe_batch(normalized)
 accepted=unique if a.include_non_products else [p for p in unique if p.get('is_product_candidate')]
 data.update({"schema_version":"2.0","raw_total":len(normalized),"duplicate_count":len(dups),"total_products":len(accepted),"products":accepted,"quality_summary":{"unknown_content_type":sum(p['content_type']=='unknown' for p in accepted),"missing_published_at":sum(not p.get('published_at') for p in accepted),"low_quality":sum(p.get('quality_score',0)<60 for p in accepted)}})
 with open(path,'w',encoding='utf-8') as f:json.dump(data,f,ensure_ascii=False,indent=2)
 with open(os.path.join(BASE,'data',a.date,'duplicates.json'),'w',encoding='utf-8') as f:json.dump(dups,f,ensure_ascii=False,indent=2)
 print(json.dumps({k:data[k] for k in ('raw_total','duplicate_count','total_products','quality_summary')},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
