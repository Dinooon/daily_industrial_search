"""
Daily Industrial Design Image Search - HTML Generator (V2 - Subscription + Incremental)
=========================================================================================
Generates premium HTML review documents with the V2 optimized design:
- Space Grotesk + Noto Sans SC + JetBrains Mono fonts
- Warm gold (#c8a96a) on dark (#0a0b0e) color scheme
- Asymmetric bento grid layout
- Scroll-in animations via IntersectionObserver
- Lightbox for full image viewing
- AI summary with ✦ icon and accent border
- "查看原文" and "图片直链" link buttons

V2 Changes:
- New: generate_archive() method for cumulative product archive HTML
- New: "首次发现" date labels on archive cards
- New: "今日增量" badge on daily HTML when in incremental mode
- New: Archive HTML groups products by first_seen_date
- New: History stats summary section in archive HTML

Usage:
    python3 generate_html.py --manifest /path/to/manifest.json --ai-data /path/to/ai_data.json
    python3 generate_html.py --archive --history /path/to/history_manifest.json
"""

import json
import os
import re
import argparse
import html
from datetime import datetime


class HTMLGenerator:
    """Generate V2 HTML document from product data and AI analysis.
    
    V2: Also supports cumulative archive HTML generation.
    """
    
    def __init__(self, date=None, use_local_images=False):
        self.date = date or datetime.now().strftime("%Y-%m-%d")
        self.date_display = datetime.now().strftime("%Y年%m月%d日")
        self.use_local_images = use_local_images
    
    def _get_image_src(self, item):
        """Get image source URL or local filename."""
        if self.use_local_images:
            return item.get("filename", item.get("original_url", ""))
        return item.get("original_url", item.get("image_url", ""))
    
    def _generate_css(self):
        """Generate V2 CSS with design system."""
        return """
/* ========================================
   V2 Design System - Industrial Design Daily
   ======================================== */

:root {
  --bg-primary: #0a0b0e;
  --bg-secondary: #13151a;
  --bg-card: #16181e;
  --bg-card-hover: #1c1f26;
  --bg-glass: rgba(22, 24, 30, 0.7);
  --gold: #c8a96a;
  --gold-dim: #8a7449;
  --gold-light: #d4b87a;
  --gold-glow: rgba(200, 169, 106, 0.15);
  --text-primary: #e8e6e1;
  --text-secondary: #9a958c;
  --text-tertiary: #5c5852;
  --border-subtle: rgba(200, 169, 106, 0.12);
  --border-active: rgba(200, 169, 106, 0.4);
  --font-heading: 'Space Grotesk', sans-serif;
  --font-body: 'Noto Sans SC', sans-serif;
  --font-mono: 'JetBrains Mono', monospace;
  --radius-lg: 20px;
  --radius-md: 14px;
  --radius-sm: 8px;
  --shadow-card: 0 8px 32px rgba(0, 0, 0, 0.4);
  --shadow-hover: 0 12px 48px rgba(200, 169, 106, 0.15);
  --ease: cubic-bezier(0.22, 1, 0.36, 1);
  --ease-fast: cubic-bezier(0.4, 0, 0.2, 1);
  --max-width: 1400px;
  --grid-gap: 24px;
}

* { margin: 0; padding: 0; box-sizing: border-box; }

body {
  background: var(--bg-primary);
  color: var(--text-primary);
  font-family: var(--font-body);
  font-weight: 400;
  line-height: 1.6;
  -webkit-font-smoothing: antialiased;
  overflow-x: hidden;
}

body::before {
  content: '';
  position: fixed;
  top: 0; left: 0; right: 0; bottom: 0;
  background-image: 
    radial-gradient(circle at 20% 10%, rgba(200, 169, 106, 0.04) 0%, transparent 40%),
    radial-gradient(circle at 80% 90%, rgba(200, 169, 106, 0.03) 0%, transparent 40%);
  pointer-events: none;
  z-index: 0;
}

/* Header */
.daily-header {
  position: relative;
  z-index: 1;
  padding: 80px 40px 40px;
  text-align: center;
  max-width: var(--max-width);
  margin: 0 auto;
}

.daily-header .date-line {
  font-family: var(--font-mono);
  font-size: 13px;
  color: var(--gold);
  letter-spacing: 0.15em;
  text-transform: uppercase;
  margin-bottom: 16px;
  opacity: 0;
  animation: fadeInDown 0.8s var(--ease) 0.1s forwards;
}

.daily-header h1 {
  font-family: var(--font-heading);
  font-size: 42px;
  font-weight: 600;
  letter-spacing: -0.02em;
  margin-bottom: 12px;
  opacity: 0;
  animation: fadeInDown 0.8s var(--ease) 0.2s forwards;
}

.daily-header .subtitle {
  font-size: 15px;
  color: var(--text-secondary);
  font-weight: 300;
  margin-bottom: 48px;
  opacity: 0;
  animation: fadeInDown 0.8s var(--ease) 0.3s forwards;
}

/* Incremental badge (V2 NEW) */
.incremental-badge {
  display: inline-block;
  background: rgba(200, 169, 106, 0.1);
  border: 1px solid var(--border-active);
  border-radius: 100px;
  padding: 6px 16px;
  font-family: var(--font-mono);
  font-size: 11px;
  color: var(--gold);
  margin-bottom: 24px;
  opacity: 0;
  animation: fadeInDown 0.8s var(--ease) 0.15s forwards;
}

/* Stats row */
.stats-row {
  display: flex;
  justify-content: center;
  gap: 56px;
  margin-bottom: 32px;
  opacity: 0;
  animation: fadeInUp 0.8s var(--ease) 0.4s forwards;
}

.stat-item { text-align: center; }

.stat-number {
  font-family: var(--font-heading);
  font-size: 36px;
  font-weight: 700;
  color: var(--gold);
  line-height: 1;
}

.stat-label {
  font-family: var(--font-mono);
  font-size: 11px;
  color: var(--text-tertiary);
  letter-spacing: 0.1em;
  text-transform: uppercase;
  margin-top: 8px;
}

/* Filter Bar */
.filter-bar {
  position: sticky;
  top: 0;
  z-index: 100;
  background: rgba(10, 11, 14, 0.85);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border-bottom: 1px solid var(--border-subtle);
  padding: 16px 40px;
  display: flex;
  justify-content: center;
  gap: 8px;
  flex-wrap: wrap;
  opacity: 0;
  animation: fadeInUp 0.6s var(--ease) 0.5s forwards;
}

.filter-btn {
  font-family: var(--font-body);
  font-size: 13px;
  font-weight: 500;
  padding: 8px 20px;
  border: 1px solid var(--border-subtle);
  background: transparent;
  color: var(--text-secondary);
  border-radius: 100px;
  cursor: pointer;
  transition: all 0.3s var(--ease);
  white-space: nowrap;
}

.filter-btn:hover {
  background: var(--bg-card);
  color: var(--text-primary);
  border-color: var(--border-active);
}

.filter-btn.active {
  background: var(--gold);
  color: var(--bg-primary);
  border-color: var(--gold);
  font-weight: 600;
}

.filter-btn .count {
  font-family: var(--font-mono);
  font-size: 11px;
  margin-left: 6px;
  opacity: 0.7;
}

/* Product Grid */
.product-grid {
  position: relative;
  z-index: 1;
  max-width: var(--max-width);
  margin: 0 auto;
  padding: 40px;
  display: grid;
  grid-template-columns: repeat(12, 1fr);
  gap: var(--grid-gap);
}

.product-card {
  grid-column: span 4;
  background: var(--bg-card);
  border: 1px solid var(--border-subtle);
  border-radius: var(--radius-lg);
  overflow: hidden;
  transition: all 0.4s var(--ease);
  cursor: pointer;
  position: relative;
  opacity: 0;
  transform: translateY(30px);
}

.product-card.visible {
  opacity: 1;
  transform: translateY(0);
}

.product-card:hover {
  background: var(--bg-card-hover);
  border-color: var(--border-active);
  box-shadow: var(--shadow-hover);
  transform: translateY(-4px);
}

.product-card.large { grid-column: span 6; }
.product-card.medium { grid-column: span 6; }

.card-image-wrapper {
  position: relative;
  overflow: hidden;
  aspect-ratio: 16 / 10;
  background: var(--bg-secondary);
}

.card-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.6s var(--ease);
  display: block;
}

.product-card:hover .card-image {
  transform: scale(1.05);
}

.card-image-wrapper::after {
  content: '';
  position: absolute;
  inset: 0;
  background: linear-gradient(to bottom, transparent 60%, rgba(10, 11, 14, 0.6));
  opacity: 0;
  transition: opacity 0.4s var(--ease);
}

.product-card:hover .card-image-wrapper::after {
  opacity: 1;
}

.ai-badge {
  position: absolute;
  top: 12px;
  right: 12px;
  background: rgba(10, 11, 14, 0.85);
  backdrop-filter: blur(8px);
  border: 1px solid var(--border-subtle);
  padding: 4px 12px;
  border-radius: 100px;
  font-family: var(--font-mono);
  font-size: 11px;
  color: var(--gold);
  z-index: 2;
}

/* First-seen date badge (V2 NEW - for archive) */
.date-badge {
  position: absolute;
  top: 12px;
  left: 12px;
  background: rgba(10, 11, 14, 0.85);
  backdrop-filter: blur(8px);
  border: 1px solid var(--border-subtle);
  padding: 4px 12px;
  border-radius: 100px;
  font-family: var(--font-mono);
  font-size: 11px;
  color: var(--text-secondary);
  z-index: 2;
}

.card-content { padding: 20px 24px; }

.card-category {
  font-family: var(--font-mono);
  font-size: 11px;
  color: var(--gold-dim);
  letter-spacing: 0.1em;
  text-transform: uppercase;
  margin-bottom: 10px;
}

/* V3.6: Card description paragraph (reference-matched typography) */
.card-desc {
  font-size: 14px;
  color: #d1d5db;
  line-height: 1.7;
  margin-bottom: 24px;
  display: -webkit-box;
  -webkit-line-clamp: 4;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

/* V3.5: Category+style tag on image overlay (semi-transparent, subtle) */
.card-tag-overlay {
  position: absolute;
  bottom: 12px;
  left: 12px;
  display: flex;
  gap: 6px;
  flex-wrap: wrap;
  z-index: 3;
}

.card-tag {
  display: inline-flex;
  align-items: center;
  padding: 4px 10px;
  border-radius: 100px;
  font-family: var(--font-mono);
  font-size: 11px;
  font-weight: 500;
  letter-spacing: 0.03em;
  background: rgba(10, 11, 14, 0.65);
  backdrop-filter: blur(6px);
  -webkit-backdrop-filter: blur(6px);
  border: 1px solid rgba(255, 255, 255, 0.15);
  color: rgba(232, 230, 225, 0.85);
}

.card-tag-category {
  border-color: rgba(200, 169, 106, 0.3);
  color: rgba(200, 169, 106, 0.9);
}

.card-tag-style {
  color: rgba(154, 149, 140, 0.8);
}

.card-title {
  font-family: var(--font-heading);
  font-size: 21px;
  font-weight: 700;
  color: #ffffff;
  line-height: 1.3;
  margin-bottom: 10px;
}

.card-source {
  font-size: 14px;
  color: #9ca3af;
  margin-bottom: 20px;
}

.card-source .source-name {
  color: #fbbf24;
  font-weight: 500;
}

.ai-summary {
  background: rgba(200, 169, 106, 0.06);
  border-left: 2px solid var(--gold);
  border-radius: 0 var(--radius-sm) var(--radius-sm) 0;
  padding: 14px 16px;
  margin-bottom: 16px;
}

.ai-summary-icon {
  font-family: var(--font-mono);
  font-size: 12px;
  color: var(--gold);
  margin-bottom: 6px;
  display: flex;
  align-items: center;
  gap: 6px;
}

.ai-summary-text {
  font-size: 13px;
  color: var(--text-secondary);
  line-height: 1.5;
}

.card-actions {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

.card-btn {
  font-family: var(--font-body);
  font-size: 14px;
  font-weight: 500;
  padding: 8px 20px;
  border-radius: 100px;
  text-decoration: none;
  transition: all 0.3s var(--ease);
  display: inline-flex;
  align-items: center;
  gap: 4px;
}

.card-btn-primary {
  background: #fbbf24;
  color: #1f2937;
  border: 1px solid #fbbf24;
}

.card-btn-primary:hover {
  background: #f59e0b;
  border-color: #f59e0b;
}

.card-btn-secondary {
  background: transparent;
  color: #9ca3af;
  border: 1px solid #374151;
}

.card-btn-secondary:hover {
  color: #fbbf24;
  border-color: #fbbf24;
}

.card-select {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  cursor: pointer;
}

.card-select input {
  width: 16px;
  height: 16px;
  accent-color: var(--gold);
  cursor: pointer;
}

.card-select .select-label {
  font-size: 14px;
  color: #e5e7eb;
}

/* Date section divider (V2 NEW - for archive) */
.date-section-divider {
  grid-column: span 12;
  display: flex;
  align-items: center;
  gap: 16px;
  margin: 20px 0 8px;
}

.date-section-divider .date-text {
  font-family: var(--font-heading);
  font-size: 20px;
  font-weight: 500;
  color: var(--gold);
  white-space: nowrap;
}

.date-section-divider .date-line-sep {
  flex: 1;
  height: 1px;
  background: var(--border-subtle);
}

.date-section-divider .date-count {
  font-family: var(--font-mono);
  font-size: 12px;
  color: var(--text-tertiary);
}

/* Lightbox */
.lightbox {
  position: fixed;
  inset: 0;
  background: rgba(5, 6, 8, 0.95);
  backdrop-filter: blur(20px);
  display: none;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  padding: 40px;
}

.lightbox.active { display: flex; }

.lightbox img {
  max-width: 90%;
  max-height: 85vh;
  object-fit: contain;
  border-radius: var(--radius-md);
}

.lightbox-close {
  position: absolute;
  top: 24px;
  right: 24px;
  background: var(--bg-card);
  border: 1px solid var(--border-subtle);
  color: var(--text-primary);
  width: 40px;
  height: 40px;
  border-radius: 50%;
  font-size: 20px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s var(--ease);
}

.lightbox-close:hover {
  background: var(--gold);
  color: var(--bg-primary);
}

.lightbox-info {
  position: absolute;
  bottom: 24px;
  left: 50%;
  transform: translateX(-50%);
  text-align: center;
  max-width: 600px;
}

.lightbox-info h3 {
  font-family: var(--font-heading);
  font-size: 18px;
  color: var(--text-primary);
  margin-bottom: 8px;
}

.lightbox-info a {
  font-family: var(--font-mono);
  font-size: 12px;
  color: var(--gold);
  text-decoration: none;
}

/* Action Bar (selection) */
.action-bar {
  position: fixed;
  bottom: 24px;
  left: 50%;
  transform: translateX(-50%) translateY(100px);
  background: var(--bg-card);
  border: 1px solid var(--border-active);
  border-radius: 100px;
  padding: 12px 24px;
  display: flex;
  align-items: center;
  gap: 16px;
  box-shadow: var(--shadow-hover);
  z-index: 200;
  transition: transform 0.4s var(--ease);
}

.action-bar.show {
  transform: translateX(-50%) translateY(0);
}

.action-count {
  font-family: var(--font-mono);
  font-size: 13px;
  color: var(--gold);
  white-space: nowrap;
}

.action-btn {
  font-family: var(--font-body);
  font-size: 13px;
  font-weight: 500;
  padding: 6px 16px;
  border-radius: 100px;
  background: var(--gold);
  color: var(--bg-primary);
  border: none;
  cursor: pointer;
  transition: all 0.3s var(--ease);
}

.action-btn:hover {
  background: var(--gold-light);
}

.action-clear {
  font-family: var(--font-body);
  font-size: 13px;
  padding: 6px 16px;
  border-radius: 100px;
  background: transparent;
  color: var(--text-secondary);
  border: 1px solid var(--border-subtle);
  cursor: pointer;
  transition: all 0.3s var(--ease);
}

.action-clear:hover {
  color: var(--text-primary);
  border-color: var(--border-active);
}

/* Footer */
.daily-footer {
  position: relative;
  z-index: 1;
  text-align: center;
  padding: 60px 40px 40px;
  max-width: var(--max-width);
  margin: 0 auto;
  border-top: 1px solid var(--border-subtle);
  margin-top: 40px;
}

.daily-footer p {
  font-family: var(--font-mono);
  font-size: 12px;
  color: var(--text-tertiary);
  letter-spacing: 0.1em;
}

/* Animations */
@keyframes fadeInDown {
  from { opacity: 0; transform: translateY(-20px); }
  to { opacity: 1; transform: translateY(0); }
}

@keyframes fadeInUp {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}

/* Responsive */
@media (max-width: 1024px) {
  .product-card,
  .product-card.large,
  .product-card.medium {
    grid-column: span 6;
  }
  .stats-row { gap: 32px; }
  .daily-header h1 { font-size: 32px; }
}

@media (max-width: 640px) {
  .product-card,
  .product-card.large,
  .product-card.medium {
    grid-column: span 12;
  }
  .daily-header { padding: 48px 20px 24px; }
  .daily-header h1 { font-size: 26px; }
  .stats-row { gap: 20px; flex-wrap: wrap; }
  .stat-number { font-size: 28px; }
  .product-grid { padding: 20px; gap: 16px; }
  .filter-bar { padding: 12px 16px; }
  .filter-btn { font-size: 12px; padding: 6px 14px; }
}
"""
    
    # Category to natural noun phrase mapping (Chinese keys)
    CATEGORY_NOUN_MAP = {
        "消费电子": "消费电子产品",
        "交通运输": "交通工具",
        "可持续设计": "可持续设计产品",
        "家具与照明": "家具/照明产品",
        "可穿戴科技": "可穿戴设备",
        "家居用品": "家居用品",
        "家用电器": "家用电器",
        "玩具": "玩具收藏品",
        "体育与户外": "户外运动装备",
        "厨房与餐具": "厨房/餐具用品",
        "工业设备": "工业设备",
        "医疗健康": "医疗健康产品",
        "工具设备": "工具设备",
    }
    
    # English category key to Chinese (for AI analysis data)
    CATEGORY_EN_TO_CN = {
        "consumer_electronics": "消费电子",
        "transportation": "交通运输",
        "sustainable_design": "可持续设计",
        "furniture_lighting": "家具与照明",
        "wearable_tech": "可穿戴科技",
        "home_appliances": "家居用品",
        "toys": "玩具",
        "sports_outdoors": "体育与户外",
        "kitchen_tableware": "厨房与餐具",
        "commercial_equipment": "工业设备",
        "medical_health": "医疗健康",
        "tools_equipment": "工具设备",
    }
    
    @classmethod
    def _get_category_noun(cls, chinese_cat):
        """Get a natural noun phrase for the category."""
        # If English key passed, convert to Chinese first
        if chinese_cat in cls.CATEGORY_EN_TO_CN:
            chinese_cat = cls.CATEGORY_EN_TO_CN[chinese_cat]
        for part in chinese_cat.split("/"):
            part = part.strip()
            if part in cls.CATEGORY_NOUN_MAP:
                return cls.CATEGORY_NOUN_MAP[part]
        for key, val in cls.CATEGORY_NOUN_MAP.items():
            if key in chinese_cat or chinese_cat in key:
                return val
        return "工业设计产品"
    
    @staticmethod
    def _extract_product_name(title):
        """Extract a cleaner product name from article headline."""
        cleaned = re.sub(r"^(This|These|The|A|An)\s+", "", title)
        if ": " in title:
            candidates = title.split(": ")
            after_colon = candidates[-1].strip()
            after_colon = re.sub(r"^(This|These|The|A|An)\s+", "", after_colon)
            if 5 < len(after_colon) < 80: return after_colon
        m = re.match(r"^((?:This|These|The)\s+)?(.+?)\s+(?:is|are|will|can|packs|just|has|could|review|imagines|finds|taught)\b", title, re.IGNORECASE)
        if m:
            phrase = m.group(2).strip()
            if 5 < len(phrase) < 80: return phrase
        verb_split = re.split(r"\s+(?:is|are|will|can|packs|just|has|could|by|from|review|imagines|finds|taught|just)\b", cleaned, flags=re.IGNORECASE)
        if verb_split and 5 < len(verb_split[0]) < 80: return verb_split[0]
        if " by " in cleaned:
            before_by = cleaned.split(" by ")[0].strip()
            if 5 < len(before_by) < 80: return before_by
        if "(" in title:
            before_paren = title.split("(")[0].strip()
            before_paren = re.sub(r"^(This|These|The|A|An)\s+", "", before_paren)
            if 5 < len(before_paren) < 80: return before_paren
        if "," in title:
            before_comma = title.split(",")[0].strip()
            before_comma = re.sub(r"^(This|These|The|A|An)\s+", "", before_comma)
            if 5 < len(before_comma) < 80: return before_comma
        if " just " in cleaned.lower():
            before_just = re.split(r"\s+just\s+", cleaned, flags=re.IGNORECASE)[0].strip()
            if 5 < len(before_just) < 80: return before_just
        words = cleaned.split()
        if len(words) > 8:
            short_name = " ".join(words[:6])
            if len(short_name) < 80: return short_name
        if len(cleaned) <= 80: return cleaned
        truncated = cleaned[:60]
        last_space = truncated.rfind(" ")
        if last_space > 20: truncated = truncated[:last_space]
        return truncated
    
    @staticmethod
    def _build_paragraph_desc(ai, title):
        """Build natural paragraph description following reference HTML pattern.
        V3.3: "产品名 是一款/是一系列 [category noun]，采用 [color+material]，[features]. 整体呈现 [style] 风格。"
        """
        if not ai:
            return f"{title}展现了独特的工业设计理念，融合了现代美学与功能性。"
        style = ai.get("style", "")
        material = ai.get("material", ai.get("materials", ""))
        features = ai.get("features", "")
        color = ai.get("color", "")
        category = ai.get("category", "")
        if not category:
            # Try category_label
            category = ai.get("category_label", "")
        product_name = HTMLGenerator._extract_product_name(title)
        cat_noun = HTMLGenerator._get_category_noun(category)
        is_series = any(kw in title.lower() for kw in ["collection", "series", "set", "line", "系列", "套装"])
        quantifier = "是一系列" if is_series else "是一款"
        style_primary = style.split("/")[0].strip() if style else ""
        style_secondary = style.split("/")[1].strip() if "/" in style else ""
        style_primary_clean = style_primary.replace("风格", "") if style_primary.endswith("风格") else style_primary
        style_secondary_clean = style_secondary.replace("风格", "") if style_secondary.endswith("风格") else style_secondary
        feat_items = [f.strip() for f in re.split(r"[、，,]", features) if f.strip()] if features else []
        parts = [f"{product_name} {quantifier}{cat_noun}"]
        if color and material: parts.append(f"采用{color}{material}")
        elif material: parts.append(f"采用{material}")
        elif color: parts.append(f"{color}外观设计")
        if feat_items:
            if len(feat_items) == 1: parts.append(feat_items[0])
            elif len(feat_items) == 2: parts.append(f"{feat_items[0]}，搭配{feat_items[1]}")
            elif len(feat_items) == 3: parts.append(f"{feat_items[0]}，搭配{feat_items[1]}，并集成{feat_items[2]}")
            else:
                connectors = ["搭配", "集成", "搭载", "配备", "结合"]
                feat_desc = feat_items[0]
                for i, feat in enumerate(feat_items[1:]):
                    conn = connectors[i % len(connectors)]
                    if feat.startswith(conn): feat_desc += f"，{feat}"
                    else: feat_desc += f"，{conn}{feat}"
                parts.append(feat_desc)
        desc = "，".join(parts) + "。"
        if style_primary_clean and style_secondary_clean:
            desc += f"整体呈现{style_primary_clean}风格，融入{style_secondary_clean}元素。"
        elif style_primary_clean:
            desc += f"整体呈现{style_primary_clean}风格。"
        return desc
    
    def _generate_card_html(self, product, index, is_archive=False):
        """Generate HTML for a single product card.
        
        Args:
            product: Product dict
            index: Card index for staggered animation
            is_archive: If True, show first_seen_date badge (V2 NEW)
        """
        size_class = ""
        if index == 0:
            size_class = "large"
        elif index < 3:
            size_class = ""
        
        img_src = product.get("image_url", product.get("original_url", ""))
        
        ai = product.get("ai_analysis", {})
        ai_confidence = ai.get("confidence", 0)
        ai_features = ai.get("features", "")
        ai_category = ai.get("category", "unknown")
        ai_category_label = ai.get("category_label", "")
        ai_style = ai.get("style", "")
        
        # V3.5: Clean title — strip HTML tags, extract alt text, decode entities
        # Some source data has raw <img> tags as titles instead of text
        raw_title = product.get("title", "Untitled")
        if "<" in raw_title or "&lt;" in raw_title:
            # Try to extract alt text from <img> tag
            alt_match = re.search(r'alt="([^"]+)"', raw_title)
            if alt_match:
                raw_title = alt_match.group(1)
            else:
                # No alt text — check if stripped text is meaningful
                stripped = re.sub(r'<[^>]*>', '', raw_title).strip()
                # Check if stripped result is valid text (not HTML remnant, not URL)
                is_valid = (len(stripped) > 10 
                            and not stripped.startswith('<') 
                            and not stripped.startswith('http')
                            and not stripped.startswith('www.'))
                if is_valid:
                    raw_title = stripped[:100]
                else:
                    # Fallback: derive title from page_url slug
                    page_url_fallback = product.get("page_url", "")
                    if page_url_fallback:
                        slug = page_url_fallback.rstrip('/').split('/')[-1]
                        slug = slug.replace('-', ' ').replace('_', ' ')
                        raw_title = slug.title()[:100]
                    else:
                        raw_title = "Untitled"
            # Decode HTML entities
            raw_title = raw_title.replace('&#8217;', "'").replace('&#8211;', '-').replace('&amp;', '&').replace('&#8230;', '...').replace('&quot;', '"').replace('&lt;', '<').replace('&gt;', '>')
        title = html.escape(raw_title)
        page_url = product.get("page_url", "")
        original_url = product.get("original_url", product.get("image_url", ""))
        source = product.get("source", "")
        
        # Build natural paragraph description (reference-style)
        ai_desc = self._build_paragraph_desc(ai, title)
        
        # V2 NEW: Date badge for archive
        date_badge_html = ""
        if is_archive and product.get("first_seen_date"):
            date_badge_html = f'<div class="date-badge">📅 {product["first_seen_date"]}</div>'
        
        # AI badge
        confidence_pct = int(ai_confidence * 100) if ai_confidence else 0
        ai_badge_html = f'<div class="ai-badge">AI {confidence_pct}%</div>' if confidence_pct else ""
        
        # V3.4: Category+style tags on image overlay (red border, prominent)
        tag_overlay_html = ""
        if ai_category_label:
            tag_overlay_html = f'<div class="card-tag-overlay"><span class="card-tag card-tag-category">{ai_category_label}</span>'
            if ai_style:
                # Split style by / and create individual tags
                style_parts = [s.strip() for s in ai_style.split('/') if s.strip()]
                for sp in style_parts:
                    tag_overlay_html += f'<span class="card-tag card-tag-style">{sp}</span>'
            tag_overlay_html += '</div>'
        
        # AI summary replaced by natural paragraph description (reference-style)
        ai_summary_html = f'<p class="card-desc">{html.escape(ai_desc)}</p>' if ai_desc else ""
        
        # Action buttons
        actions_html = ""
        if page_url:
            actions_html += f'<a class="card-btn card-btn-primary" href="{page_url}" target="_blank">查看原文 ↗</a>'
        if original_url:
            actions_html += f'<a class="card-btn card-btn-secondary" href="{original_url}" target="_blank">图片直链 ↗</a>'
        
        # Selection checkbox
        product_id = product.get("product_id", str(index))
        select_html = f"""
        <label class="card-select">
          <input type="checkbox" data-id="{product_id}" data-title="{title}" data-img="{original_url}" data-page="{page_url}">
          <span class="select-label">保留</span>
        </label>
        """
        
        return f"""
        <div class="product-card {size_class}" data-category="{ai_category}" data-index="{index}" onclick="openLightbox('{img_src}', '{title}')">
          <div class="card-image-wrapper">
            <img class="card-image" src="{img_src}" alt="{title}" loading="lazy" onerror="this.style.display='none';this.parentElement.style.background='var(--bg-secondary)';">
            {date_badge_html}
            {ai_badge_html}
            {tag_overlay_html}
          </div>
          <div class="card-content">
            <h3 class="card-title">{title}</h3>
            <div class="card-source">来源: <span class="source-name">{source}</span></div>
            {ai_summary_html}
            <div class="card-actions" onclick="event.stopPropagation()">
              {actions_html}
              {select_html}
            </div>
          </div>
        </div>
        """
    
    def _generate_js(self):
        """Generate JavaScript for interactions."""
        return """
// Scroll-in animations
const observerOptions = { root: null, rootMargin: '0px', threshold: 0.1 };
const cardObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const index = parseInt(entry.target.dataset.index || 0);
      setTimeout(() => { entry.target.classList.add('visible'); }, Math.min(index * 80, 600));
      cardObserver.unobserve(entry.target);
    }
  });
}, observerOptions);
document.querySelectorAll('.product-card').forEach(card => cardObserver.observe(card));

// Filter
const filterButtons = document.querySelectorAll('.filter-btn');
const productCards = document.querySelectorAll('.product-card');
filterButtons.forEach(btn => {
  btn.addEventListener('click', () => {
    const category = btn.dataset.category;
    filterButtons.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    productCards.forEach(card => {
      if (category === 'all' || card.dataset.category === category) {
        card.style.display = '';
        card.classList.remove('visible');
        cardObserver.observe(card);
      } else {
        card.style.display = 'none';
      }
    });
  });
});

// Lightbox
const lightbox = document.getElementById('lightbox');
const lightboxImg = document.getElementById('lightbox-img');
const lightboxTitle = document.getElementById('lightbox-title');
function openLightbox(src, title) {
  lightboxImg.src = src;
  lightboxTitle.textContent = title;
  lightbox.classList.add('active');
  document.body.style.overflow = 'hidden';
}
function closeLightbox() {
  lightbox.classList.remove('active');
  document.body.style.overflow = '';
}
document.querySelector('.lightbox-close').addEventListener('click', closeLightbox);
lightbox.addEventListener('click', (e) => { if (e.target === lightbox) closeLightbox(); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeLightbox(); });

// Selection
const checkboxes = document.querySelectorAll('.card-select input[type="checkbox"]');
const actionBar = document.getElementById('actionBar');
const actionCount = document.getElementById('actionCount');
let selected = [];
checkboxes.forEach(cb => {
  cb.addEventListener('change', () => {
    if (cb.checked) {
      selected.push({ id: cb.dataset.id, title: cb.dataset.title, img: cb.dataset.img, page: cb.dataset.page });
    } else {
      selected = selected.filter(s => s.id !== cb.dataset.id);
    }
    actionCount.textContent = `已选 ${selected.length} 项`;
    if (selected.length > 0) { actionBar.classList.add('show'); } else { actionBar.classList.remove('show'); }
  });
});

// Export selection
document.getElementById('exportBtn')?.addEventListener('click', () => {
  const blob = new Blob([JSON.stringify(selected, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `selected_${new Date().toISOString().slice(0,10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
});

// Clear selection
document.getElementById('clearBtn')?.addEventListener('click', () => {
  checkboxes.forEach(cb => cb.checked = false);
  selected = [];
  actionCount.textContent = '已选 0 项';
  actionBar.classList.remove('show');
});
"""
    
    def generate(self, products, ai_data=None, output_path=None, 
                 is_incremental=False, new_count=None):
        """
        Generate the complete daily HTML document.
        
        Args:
            products: List of product dicts
            ai_data: Dict mapping product_id to AI analysis results
            output_path: Path to save HTML file
            is_incremental: V2 NEW - show incremental badge
            new_count: V2 NEW - number of new products (for badge text)
        
        Returns:
            HTML string
        """
        if ai_data:
            for product in products:
                pid = product.get("product_id", "")
                if pid in ai_data:
                    product["ai_analysis"] = ai_data[pid]
        
        categories_count = {}
        for p in products:
            cat = p.get("ai_analysis", {}).get("category", "other")
            categories_count[cat] = categories_count.get(cat, 0) + 1
        
        total_images = sum(len(p.get("thumbnails", [])) + 1 for p in products)
        
        # Filter buttons
        cat_labels = {
            "consumer_electronics": "消费电子", "furniture_lighting": "家具照明",
            "transportation": "交通工具", "home_appliances": "家用电器",
            "tools_equipment": "工具设备", "sustainable_design": "可持续设计",
            "wearable_tech": "可穿戴设备", "kitchen_tableware": "厨房餐厨",
            "medical_health": "医疗健康", "sports_outdoors": "户外运动",
            "commercial_equipment": "工业设备",
        }
        
        filter_buttons_html = f'<button class="filter-btn active" data-category="all">全部 <span class="count">{len(products)}</span></button>'
        for cat, count in sorted(categories_count.items(), key=lambda x: -x[1]):
            label = cat_labels.get(cat, cat)
            filter_buttons_html += f'<button class="filter-btn" data-category="{cat}">{label} <span class="count">{count}</span></button>'
        
        # Product cards
        cards_html = ""
        for i, product in enumerate(products):
            ai = product.get("ai_analysis", {})
            if "category_label" not in ai:
                cat = ai.get("category", "other")
                ai["category_label"] = cat_labels.get(cat, cat)
                product["ai_analysis"] = ai
            cards_html += self._generate_card_html(product, i)
        
        # Incremental badge
        incremental_badge_html = ""
        if is_incremental:
            badge_text = f"📡 增量更新 · 今日新增 {new_count or len(products)} 个产品"
            incremental_badge_html = f'<div class="incremental-badge">{badge_text}</div>'
        
        html_doc = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>工业设计日报 · {self.date}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=Noto+Sans+SC:wght@300;400;500;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
  <style>{self._generate_css()}</style>
</head>
<body>
  <header class="daily-header">
    <div class="date-line">{self.date} · DAILY DESIGN DIGEST</div>
    {incremental_badge_html}
    <h1>工业设计日报</h1>
    <p class="subtitle">每日精选全球工业设计最新产品资讯</p>
    <div class="stats-row">
      <div class="stat-item"><div class="stat-number">{len(products)}</div><div class="stat-label">Products</div></div>
      <div class="stat-item"><div class="stat-number">{total_images}</div><div class="stat-label">Images</div></div>
      <div class="stat-item"><div class="stat-number">{len(categories_count)}</div><div class="stat-label">Categories</div></div>
      <div class="stat-item"><div class="stat-number">{len(set(p.get('source','') for p in products))}</div><div class="stat-label">Sources</div></div>
    </div>
  </header>
  <nav class="filter-bar">{filter_buttons_html}</nav>
  <main class="product-grid">{cards_html}</main>
  <div class="action-bar" id="actionBar">
    <span class="action-count" id="actionCount">已选 0 项</span>
    <button class="action-btn" id="exportBtn">导出选择</button>
    <button class="action-clear" id="clearBtn">清除</button>
  </div>
  <div class="lightbox" id="lightbox">
    <button class="lightbox-close" aria-label="Close">×</button>
    <img id="lightbox-img" src="" alt="">
    <div class="lightbox-info"><h3 id="lightbox-title"></h3></div>
  </div>
  <footer class="daily-footer">
    <p>Powered by Daily Industrial Design Image Search · Subscription + Incremental Mode · {self.date_display}</p>
  </footer>
  <script>{self._generate_js()}</script>
</body>
</html>"""
        
        if output_path:
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(html_doc)
            print(f"HTML generated: {output_path} ({len(html_doc)} bytes)")
        
        return html_doc
    
    def generate_archive(self, history_products, output_path=None):
        """
        V2 NEW: Generate cumulative archive HTML from all history products.
        Products are grouped by first_seen_date with date section dividers.
        
        Args:
            history_products: List of product records from history_manifest.json
            output_path: Path to save archive HTML
        
        Returns:
            HTML string
        """
        # Group by date
        by_date = {}
        for p in history_products:
            date = p.get("first_seen_date", "Unknown")
            if date not in by_date:
                by_date[date] = []
            by_date[date].append(p)
        
        # Sort dates descending (newest first)
        sorted_dates = sorted(by_date.keys(), reverse=True)
        
        # Category labels
        cat_labels = {
            "consumer_electronics": "消费电子", "furniture_lighting": "家具照明",
            "transportation": "交通工具", "home_appliances": "家用电器",
            "tools_equipment": "工具设备", "sustainable_design": "可持续设计",
            "wearable_tech": "可穿戴设备", "kitchen_tableware": "厨房餐厨",
            "medical_health": "医疗健康", "sports_outdoors": "户外运动",
            "commercial_equipment": "工业设备",
        }
        
        # Count categories
        categories_count = {}
        for p in history_products:
            cat = p.get("ai_category", "other")
            categories_count[cat] = categories_count.get(cat, 0) + 1
        
        # Filter buttons
        filter_buttons_html = f'<button class="filter-btn active" data-category="all">全部 <span class="count">{len(history_products)}</span></button>'
        for cat, count in sorted(categories_count.items(), key=lambda x: -x[1]):
            label = cat_labels.get(cat, cat)
            filter_buttons_html += f'<button class="filter-btn" data-category="{cat}">{label} <span class="count">{count}</span></button>'
        
        # Generate cards grouped by date
        cards_html = ""
        card_index = 0
        for date_str in sorted_dates:
            date_products = by_date[date_str]
            cards_html += f"""
            <div class="date-section-divider">
              <span class="date-text">📅 {date_str}</span>
              <span class="date-line-sep"></span>
              <span class="date-count">{len(date_products)} products</span>
            </div>
            """
            for product in date_products:
                # Convert history record to product format
                prod = {
                    "product_id": product.get("product_id", ""),
                    "title": product.get("title", ""),
                    "source": product.get("source", ""),
                    "page_url": product.get("page_url", ""),
                    "image_url": product.get("image_url", ""),
                    "original_url": product.get("image_url", ""),
                    "first_seen_date": product.get("first_seen_date", ""),
                    "ai_analysis": {
                        "category": product.get("ai_category", "unknown"),
                        "category_label": product.get("ai_category_label", "") or cat_labels.get(product.get("ai_category", ""), "其他"),
                        "style": product.get("ai_style", ""),
                        "material": product.get("ai_material", ""),
                        "features": product.get("ai_features", ""),
                        "color": product.get("ai_color", ""),
                        "confidence": product.get("ai_confidence", 0),
                    }
                }
                cards_html += self._generate_card_html(prod, card_index, is_archive=True)
                card_index += 1
        
        # Stats
        total_dates = len(sorted_dates)
        total_sources = len(set(p.get("source", "") for p in history_products))
        
        html_doc = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>工业设计累计档案 · Archive Master</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=Noto+Sans+SC:wght@300;400;500;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
  <style>{self._generate_css()}</style>
</head>
<body>
  <header class="daily-header">
    <div class="date-line">ARCHIVE MASTER · CUMULATIVE COLLECTION</div>
    <div class="incremental-badge">📚 累计归档 · {len(history_products)} 个产品 · {total_dates} 次采集</div>
    <h1>工业设计灵感库</h1>
    <p class="subtitle">所有历史采集产品的累计档案，按首次发现日期排序</p>
    <div class="stats-row">
      <div class="stat-item"><div class="stat-number">{len(history_products)}</div><div class="stat-label">Total Products</div></div>
      <div class="stat-item"><div class="stat-number">{total_dates}</div><div class="stat-label">Collection Days</div></div>
      <div class="stat-item"><div class="stat-number">{len(categories_count)}</div><div class="stat-label">Categories</div></div>
      <div class="stat-item"><div class="stat-number">{total_sources}</div><div class="stat-label">Sources</div></div>
    </div>
  </header>
  <nav class="filter-bar">{filter_buttons_html}</nav>
  <main class="product-grid">{cards_html}</main>
  <div class="action-bar" id="actionBar">
    <span class="action-count" id="actionCount">已选 0 项</span>
    <button class="action-btn" id="exportBtn">导出选择</button>
    <button class="action-clear" id="clearBtn">清除</button>
  </div>
  <div class="lightbox" id="lightbox">
    <button class="lightbox-close" aria-label="Close">×</button>
    <img id="lightbox-img" src="" alt="">
    <div class="lightbox-info"><h3 id="lightbox-title"></h3></div>
  </div>
  <footer class="daily-footer">
    <p>Archive Master · Subscription + Incremental Mode · Last updated: {self.date_display}</p>
  </footer>
  <script>{self._generate_js()}</script>
</body>
</html>"""
        
        if output_path:
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(html_doc)
            print(f"Archive HTML generated: {output_path} ({len(html_doc)} bytes)")
        
        return html_doc


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate daily industrial design HTML")
    parser.add_argument("--manifest", help="Path to download manifest JSON")
    parser.add_argument("--ai-data", help="Path to AI analysis JSON")
    parser.add_argument("--output", default=None, help="Output HTML file path")
    parser.add_argument("--local", action="store_true", help="Use local image paths")
    parser.add_argument("--archive", action="store_true", help="Generate archive HTML from history")
    parser.add_argument("--history", help="Path to history_manifest.json (for --archive mode)")
    args = parser.parse_args()
    
    if args.archive:
        # Archive mode
        history_path = args.history or "/home/ubuntu/daily_industrial_search/data/history_manifest.json"
        with open(history_path, 'r', encoding='utf-8') as f:
            history = json.load(f)
        
        products = history.get("products", [])
        generator = HTMLGenerator()
        output = args.output or "/home/ubuntu/daily_industrial_search/output/archive_master.html"
        generator.generate_archive(products, output)
    else:
        # Daily mode
        with open(args.manifest, 'r', encoding='utf-8') as f:
            manifest = json.load(f)
        
        products = {}
        for item in manifest:
            pid = item["product_id"]
            if pid not in products:
                products[pid] = {
                    "product_id": pid,
                    "title": item["title"],
                    "source": item["source"],
                    "page_url": item.get("page_url", ""),
                    "image_url": item["original_url"],
                    "original_url": item["original_url"],
                    "thumbnails": [],
                    "filename": item.get("filename", ""),
                }
            else:
                products[pid]["thumbnails"].append(item["original_url"])
        
        product_list = list(products.values())
        
        ai_data = {}
        if args.ai_data and os.path.exists(args.ai_data):
            with open(args.ai_data, 'r', encoding='utf-8') as f:
                ai_data = json.load(f)
        
        generator = HTMLGenerator(use_local_images=args.local)
        output = args.output or f"daily_review_{generator.date}.html"
        generator.generate(product_list, ai_data, output, is_incremental=True, new_count=len(product_list))

