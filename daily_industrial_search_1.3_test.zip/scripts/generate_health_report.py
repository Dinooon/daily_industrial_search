#!/usr/bin/env python3
import argparse,json,os
from collections import Counter,defaultdict
BASE=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def main():
 p=argparse.ArgumentParser();p.add_argument('--date',required=True);a=p.parse_args()
 path=os.path.join(BASE,'data',a.date,'collected_data.json')
 with open(path,encoding='utf-8') as f:d=json.load(f)
 ps=d.get('products',[]); by=Counter(x.get('publisher','unknown') for x in ps)
 report={"date":a.date,"collection_mode":d.get('collection_mode','live'),"accepted":len(ps),"publishers":dict(by),"missing_date":sum(not x.get('published_at') for x in ps),"unknown_type":sum(x.get('content_type')=='unknown' for x in ps),"duplicate_count":d.get('duplicate_count',0),"warnings":[]}
 if report['missing_date']/max(1,len(ps))>.5:report['warnings'].append('missing_date_rate_high')
 if len(by)<3:report['warnings'].append('publisher_diversity_low')
 out=os.path.join(BASE,'data',a.date,'source_health.json')
 with open(out,'w',encoding='utf-8') as f:json.dump(report,f,ensure_ascii=False,indent=2)
 print(json.dumps(report,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
