from __future__ import annotations
import re
from bs4 import BeautifulSoup
from urllib.parse import urljoin,urlsplit

def discover_html(html,base_url,include_patterns=None,limit=30):
    soup=BeautifulSoup(html,'lxml'); include_patterns=include_patterns or []
    out=[]; seen=set()
    for a in soup.find_all('a',href=True):
        url=urljoin(base_url,a['href']); path=urlsplit(url).path
        if url in seen or urlsplit(url).netloc!=urlsplit(base_url).netloc: continue
        if include_patterns and not any(re.search(p,path,re.I) for p in include_patterns): continue
        title=' '.join(a.get_text(' ',strip=True).split())
        img=a.find('img'); image=None
        if img: image=img.get('data-src') or img.get('data-lazy-src') or img.get('src')
        if len(title)<8:
            slug=path.rstrip('/').split('/')[-1].replace('-',' '); title=slug.title()
        if len(title)<8: continue
        seen.add(url); out.append({'title':title[:240],'page_url':url,'image_url':urljoin(base_url,image) if image else None})
        if len(out)>=limit: break
    return out
