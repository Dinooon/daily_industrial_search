from __future__ import annotations
from bs4 import BeautifulSoup

def discover_sitemap(xml,limit=50):
 soup=BeautifulSoup(xml,'xml'); out=[]
 for node in soup.find_all('url')[:limit]:
  loc=node.find('loc'); last=node.find('lastmod')
  if loc: out.append({'title':'','page_url':loc.get_text(strip=True),'published_at':last.get_text(strip=True) if last else None,'discovery_method':'sitemap'})
 return out
