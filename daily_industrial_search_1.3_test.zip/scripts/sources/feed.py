from __future__ import annotations
from bs4 import BeautifulSoup

def discover_feed(xml,limit=30):
 soup=BeautifulSoup(xml,'xml');out=[]
 entries=soup.find_all(['item','entry'])
 for e in entries[:limit]:
  title=e.find('title');link=e.find('link');published=e.find(['pubDate','published','updated'])
  href=(link.get('href') if link and link.get('href') else link.get_text(strip=True) if link else '')
  image=None
  enclosure=e.find('enclosure'); media=e.find(lambda t:getattr(t,'name',None) in ('media:content','media:thumbnail'))
  if enclosure:image=enclosure.get('url')
  if media and not image:image=media.get('url')
  out.append({'title':title.get_text(' ',strip=True) if title else '','page_url':href,'image_url':image,'published_at':published.get_text(' ',strip=True) if published else None,'discovery_method':'rss'})
 return out
