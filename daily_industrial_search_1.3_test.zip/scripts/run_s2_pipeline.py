#!/usr/bin/env python3
"""
Stage 2-4 Pipeline: Dedup → Download → AI Analysis → Update History
====================================================================
Orchestrates the post-collection processing pipeline:
  Stage 2: Dedup collected data against history_manifest.json (page_url)
  Stage 3: Download new product images to temp_images/{date}/
  Stage 4: AI multimodal analysis via /llm/ask endpoint, append to manifest

Usage:
    python scripts/run_s2_pipeline.py [--date 2026-07-23]
"""

import os
import sys
import json
import time
import base64
import re
import argparse
import httpx

# Add scripts dir to path
SCRIPTS_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPTS_DIR)

from history_manager import HistoryManager

# ── Constants ──────────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
from datetime import datetime
DATE_DEFAULT = datetime.now().astimezone().strftime("%Y-%m-%d")
LLM_BASE = os.getenv("LLM_BASE_URL", "https://beta.ecouser.net/api/v1").rstrip("/")
LLM_TIMEOUT = 120
CONFIDENCE_THRESHOLD = 0.60

# Category mapping (must match config.py CATEGORIES keys)
VALID_CATEGORIES = {
    "consumer_electronics", "furniture_lighting", "transportation",
    "home_appliances", "tools_equipment", "sustainable_design",
    "wearable_tech", "kitchen_tableware", "medical_health",
    "sports_outdoors", "commercial_equipment", "other",
}

CATEGORY_LABELS = {
    "consumer_electronics": "消费电子",
    "furniture_lighting": "家具照明",
    "transportation": "交通工具",
    "home_appliances": "家用电器",
    "tools_equipment": "工具设备",
    "sustainable_design": "可持续设计",
    "wearable_tech": "可穿戴设备",
    "kitchen_tableware": "厨房餐厨",
    "medical_health": "医疗健康",
    "sports_outdoors": "户外运动",
    "commercial_equipment": "工业设备",
    "other": "其他",
}


# ── Stage 2: Dedup ─────────────────────────────────────────────────
def stage2_dedup(date):
    print(f"\n{'='*60}")
    print(f"Stage 2: Deduplication against history_manifest.json")
    print(f"{'='*60}")

    collected_path = os.path.join(BASE_DIR, "data", date, "collected_data.json")
    with open(collected_path, 'r', encoding='utf-8') as f:
        collected = json.load(f)

    products = collected["products"]
    print(f"  Loaded {len(products)} products from {collected_path}")

    hm = HistoryManager(base_dir=BASE_DIR)
    hm.load_history()

    new_products, dup_count = hm.filter_new(products)
    print(f"  Result: {len(new_products)} new, {dup_count} duplicates filtered")

    return hm, new_products


# ── Stage 3: Download Images ───────────────────────────────────────
def stage3_download(new_products, date):
    print(f"\n{'='*60}")
    print(f"Stage 3: Download new product images")
    print(f"{'='*60}")

    import requests
    from PIL import Image
    from io import BytesIO

    temp_dir = os.path.join(BASE_DIR, "temp_images", date)
    os.makedirs(temp_dir, exist_ok=True)

    download_manifest = []
    success_count = 0

    for i, product in enumerate(new_products):
        product_id = f"{date.replace('-', '')}-{i+1:03d}"
        filename = f"{product_id}.jpg"
        filepath = os.path.join(temp_dir, filename)
        image_url = product.get("image_url", "")

        if not image_url:
            print(f"  ❌ {product_id}: no image_url")
            download_manifest.append({
                "product_id": product_id, "filename": filename,
                "title": product.get("title", ""), "source": product.get("source", ""),
                "page_url": product.get("page_url", ""), "original_url": "",
                "cloud_path": None, "status": "failed", "error": "no image_url"
            })
            continue

        try:
            headers = {"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"}
            resp = requests.get(image_url, headers=headers, timeout=30)
            resp.raise_for_status()

            img = Image.open(BytesIO(resp.content))
            if img.mode in ("CMYK", "RGBA", "P"):
                img = img.convert("RGB")
            img.save(filepath, "JPEG", quality=90)

            size_kb = os.path.getsize(filepath) // 1024
            print(f"  ✅ {filename} ({size_kb}KB) — {product.get('title', '')[:50]}")

            download_manifest.append({
                "product_id": product_id, "filename": filename,
                "title": product.get("title", ""), "source": product.get("source", ""),
                "source_id": product.get("source_id", ""),
                "page_url": product.get("page_url", ""), "original_url": image_url,
                "cloud_path": filepath, "size_bytes": os.path.getsize(filepath),
                "status": "success"
            })
            # Attach product_id back to the product dict for later stages
            product["product_id"] = product_id
            success_count += 1

        except Exception as e:
            print(f"  ❌ {filename}: {e}")
            download_manifest.append({
                "product_id": product_id, "filename": filename,
                "title": product.get("title", ""), "source": product.get("source", ""),
                "page_url": product.get("page_url", ""), "original_url": image_url,
                "cloud_path": None, "status": "failed", "error": str(e)
            })
            product["product_id"] = product_id

    manifest_path = os.path.join(temp_dir, "download_manifest.json")
    with open(manifest_path, 'w', encoding='utf-8') as f:
        json.dump(download_manifest, f, ensure_ascii=False, indent=2)

    print(f"\n  Download complete: {success_count}/{len(new_products)} images saved to {temp_dir}")
    return download_manifest


# ── Stage 4: AI Multimodal Analysis ────────────────────────────────
def build_analysis_prompt(title, source, page_url, published_at=None, content_type=None):
    return f"""Analyze this industrial design product image and extract structured information.

Product context:
- Title: {title}
- Source: {source}
- Article URL: {page_url}
- Published at: {published_at or "unknown"}
- Preliminary content type: {content_type or "unknown"}

Return a JSON object with exactly these fields:
{{
  "product_name": "concise product name (English)",
  "designer": "designer or brand name, empty string if unknown",
  "category": "one of: consumer_electronics, furniture_lighting, transportation, home_appliances, tools_equipment, sustainable_design, wearable_tech, kitchen_tableware, medical_health, sports_outdoors, commercial_equipment, other",
  "category_label": "Chinese label for the category",
  "style": "design style keywords separated by /, e.g. 极简风格/工业风格",
  "material": "primary materials, e.g. 铝合金,塑料",
  "color": "dominant color(s), e.g. 黑色,银色",
  "features": "key design features separated by commas in Chinese",
  "description": "one-sentence Chinese description of the product",
  "content_type": "physical_product, concept_product, material_innovation, architecture, editorial, competition, branding, or other",
  "release_status": "released, preorder, crowdfunding, concept, award_only, old_or_unknown",
  "is_new_product": "boolean; false when evidence is insufficient",
  "evidence_note": "briefly state which fields come from title/context vs visual inference",
  "confidence": "float 0.0-1.0; cap at 0.75 if only visually inferred"
}}

Return ONLY the JSON object, no markdown formatting, no explanation."""


def parse_ai_response(content):
    """Parse the AI response and extract the JSON object."""
    # Strip markdown code fences if present
    content = content.strip()
    if content.startswith("```"):
        content = re.sub(r'^```(?:json)?\s*\n?', '', content)
        content = re.sub(r'\n?```\s*$', '', content)

    # Try to find JSON object
    match = re.search(r'\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}', content, re.DOTALL)
    if match:
        content = match.group(0)

    try:
        data = json.loads(content)
    except json.JSONDecodeError:
        return None

    # Normalize and validate
    category = data.get("category", "other")
    if category not in VALID_CATEGORIES:
        category = "other"

    # Always use canonical label to ensure consistency across products
    category_label = CATEGORY_LABELS.get(category, "其他")

    try:
        confidence = float(data.get("confidence", 0))
    except (ValueError, TypeError):
        confidence = 0.0
    confidence = max(0.0, min(1.0, confidence))

    return {
        "product_name": data.get("product_name", ""),
        "designer": data.get("designer", ""),
        "category": category,
        "category_label": category_label,
        "style": data.get("style", ""),
        "material": data.get("material", ""),
        "color": data.get("color", ""),
        "features": data.get("features", ""),
        "description": data.get("description", ""),
        "content_type": data.get("content_type", "other"),
        "release_status": data.get("release_status", "old_or_unknown"),
        "is_new_product": bool(data.get("is_new_product", False)),
        "evidence_note": data.get("evidence_note", ""),
        "confidence": confidence,
    }


def analyze_image_with_llm(image_path, title, source, page_url):
    """Call /llm/ask with multimodal attachment (base64 image)."""
    with open(image_path, "rb") as f:
        image_b64 = base64.b64encode(f.read()).decode("utf-8")

    prompt = build_analysis_prompt(title, source, page_url)

    payload = {
        "request": prompt,
        "attachments": [{
            "media_type": "image",
            "source_type": "base64",
            "data": image_b64,
            "media_format": "jpeg",
        }],
    }

    with httpx.AsyncClient(timeout=LLM_TIMEOUT) as client:
        import asyncio
        loop = asyncio.new_event_context() if False else asyncio.get_event_loop()
        resp = loop.run_until_complete(client.post(f"{LLM_BASE}/llm/ask", json=payload))
        resp.raise_for_status()
        return resp.json()


def stage4_ai_analysis(new_products, download_manifest, date):
    print(f"\n{'='*60}")
    print(f"Stage 4: AI Multimodal Analysis (/llm/ask)")
    print(f"{'='*60}")

    temp_dir = os.path.join(BASE_DIR, "temp_images", date)
    ai_results = {}
    success_count = 0
    fail_count = 0
    low_confidence_count = 0

    # Build lookup: product_id → manifest entry
    manifest_lookup = {m["product_id"]: m for m in download_manifest}

    for i, product in enumerate(new_products):
        product_id = product.get("product_id", "")
        if not product_id:
            product_id = f"{date.replace('-', '')}-{i+1:03d}"
            product["product_id"] = product_id

        manifest_entry = manifest_lookup.get(product_id, {})
        if manifest_entry.get("status") != "success":
            print(f"  ⏭️  {product_id}: skipped (download failed)")
            fail_count += 1
            continue

        image_path = manifest_entry["cloud_path"]
        title = product.get("title", "")
        source = product.get("source", "")
        page_url = product.get("page_url", "")

        print(f"  [{i+1}/{len(new_products)}] Analyzing {product_id}: {title[:50]}...")

        try:
            # Use synchronous httpx call directly
            with open(image_path, "rb") as f:
                image_b64 = base64.b64encode(f.read()).decode("utf-8")

            prompt = build_analysis_prompt(title, source, page_url, product.get("published_at"), product.get("content_type"))
            payload = {
                "request": prompt,
                "attachments": [{
                    "media_type": "image",
                    "source_type": "base64",
                    "data": image_b64,
                    "media_format": "jpeg",
                }],
            }

            with httpx.Client(timeout=LLM_TIMEOUT) as client:
                resp = client.post(f"{LLM_BASE}/llm/ask", json=payload)
                resp.raise_for_status()
                result = resp.json()

            content = result.get("data", {}).get("content", "")
            analysis = parse_ai_response(content)

            if analysis is None:
                print(f"      ❌ Failed to parse AI response")
                fail_count += 1
                # Still record with empty analysis
                ai_results[product_id] = {
                    "product_name": "", "designer": "", "category": "other",
                    "category_label": "其他", "style": "", "material": "",
                    "color": "", "features": "", "description": "",
                    "confidence": 0.0,
                }
                continue

            confidence = analysis["confidence"]
            conf_pct = int(confidence * 100)
            status_icon = "✅" if confidence >= CONFIDENCE_THRESHOLD else "⚠️"
            print(f"      {status_icon} {analysis['category_label']} | conf={conf_pct}% | {analysis.get('style', '')}")

            if confidence < CONFIDENCE_THRESHOLD:
                low_confidence_count += 1

            ai_results[product_id] = analysis
            success_count += 1

            # Rate limit: be nice to the API
            time.sleep(1)

        except Exception as e:
            print(f"      ❌ Error: {e}")
            fail_count += 1
            ai_results[product_id] = {
                "product_name": "", "designer": "", "category": "other",
                "category_label": "其他", "style": "", "material": "",
                "color": "", "features": "", "description": "",
                "confidence": 0.0,
            }

    # Save AI analysis results
    ai_data_path = os.path.join(BASE_DIR, "data", date, "ai_analysis.json")
    os.makedirs(os.path.dirname(ai_data_path), exist_ok=True)
    with open(ai_data_path, 'w', encoding='utf-8') as f:
        json.dump(ai_results, f, ensure_ascii=False, indent=2)

    print(f"\n  AI Analysis complete: {success_count} analyzed, {fail_count} failed, "
          f"{low_confidence_count} below threshold ({CONFIDENCE_THRESHOLD})")
    print(f"  Results saved to {ai_data_path}")

    return ai_results


# ── Update History Manifest ────────────────────────────────────────
def update_history(hm, new_products, ai_results, date):
    print(f"\n{'='*60}")
    print(f"Updating history_manifest.json")
    print(f"{'='*60}")

    # Merge AI data into products
    for product in new_products:
        pid = product.get("product_id", "")
        if pid in ai_results:
            product["ai_analysis"] = ai_results[pid]

    added = hm.add_products(new_products, run_date=date)
    hm.save_history()

    print(f"  History updated: +{added} products")
    return added


# ── Main ───────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="Run Stage 2-4 pipeline")
    parser.add_argument("--date", default=DATE_DEFAULT, help="Date string (YYYY-MM-DD)")
    args = parser.parse_args()
    date = args.date

    print(f"Pipeline Date: {date}")
    print(f"Base Dir: {BASE_DIR}")

    # Stage 2: Dedup
    hm, new_products = stage2_dedup(date)

    if not new_products:
        print("\nNo new products to process. Pipeline complete.")
        return

    # Stage 3: Download
    download_manifest = stage3_download(new_products, date)

    # Stage 4: AI Analysis
    ai_results = stage4_ai_analysis(new_products, download_manifest, date)

    # Update History
    update_history(hm, new_products, ai_results, date)

    # Summary
    print(f"\n{'='*60}")
    print(f"Pipeline Summary")
    print(f"{'='*60}")
    print(f"  Date: {date}")
    print(f"  New products found: {len(new_products)}")
    print(f"  Images downloaded: {sum(1 for m in download_manifest if m['status'] == 'success')}")
    print(f"  AI analyses completed: {len(ai_results)}")
    print(f"  History total after update: {hm.history['total_products_archived']}")
    stats = hm.get_stats()
    print(f"  By source: {stats['by_source']}")
    print(f"  By category: {stats['by_category']}")
    print(f"  By date: {stats['by_date']}")


if __name__ == "__main__":
    main()
