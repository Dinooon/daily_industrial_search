#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, random, time
from pathlib import Path
from urllib.parse import urlsplit
import requests

class CachedHttpClient:
    def __init__(self, cache_dir: Path, timeout: int=30, per_domain_delay: float=0.8, retries: int=3):
        self.cache_dir=Path(cache_dir); self.cache_dir.mkdir(parents=True,exist_ok=True)
        self.timeout=timeout; self.delay=per_domain_delay; self.retries=retries
        self.session=requests.Session(); self.session.headers.update({
            'User-Agent':'DailyIndustrialDesignSearch/1.3 (+respectful research collector)',
            'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language':'en-US,en;q=0.9'})
        self.last_by_domain={}
    def _paths(self,url):
        key=hashlib.sha256(url.encode()).hexdigest(); return self.cache_dir/f'{key}.body', self.cache_dir/f'{key}.json'
    def get(self,url,use_cache=True,max_age=21600):
        body_path,meta_path=self._paths(url)
        if use_cache and body_path.exists() and meta_path.exists():
            meta=json.loads(meta_path.read_text())
            if time.time()-meta.get('saved_at',0)<max_age:
                return {'url':url,'final_url':meta.get('final_url',url),'status':meta.get('status',200),'text':body_path.read_text(errors='replace'),'from_cache':True,'headers':meta.get('headers',{})}
        domain=urlsplit(url).netloc.lower(); wait=self.delay-(time.time()-self.last_by_domain.get(domain,0))
        if wait>0: time.sleep(wait+random.uniform(0,.25))
        last=None
        for attempt in range(self.retries):
            try:
                r=self.session.get(url,timeout=self.timeout,allow_redirects=True)
                self.last_by_domain[domain]=time.time()
                if r.status_code in (429,500,502,503,504):
                    delay=float(r.headers.get('Retry-After') or (2**attempt)); time.sleep(min(delay,20)); last=f'HTTP {r.status_code}'; continue
                r.raise_for_status(); text=r.text
                body_path.write_text(text,errors='replace')
                meta={'saved_at':time.time(),'final_url':r.url,'status':r.status_code,'headers':dict(r.headers)}; meta_path.write_text(json.dumps(meta,ensure_ascii=False))
                return {'url':url,'final_url':r.url,'status':r.status_code,'text':text,'from_cache':False,'headers':dict(r.headers)}
            except Exception as e:
                last=str(e); time.sleep(min(2**attempt,10))
        raise RuntimeError(f'GET failed after {self.retries} attempts: {url}: {last}')
