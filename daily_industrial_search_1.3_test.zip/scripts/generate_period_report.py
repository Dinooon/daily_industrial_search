#!/usr/bin/env python3
"""Generate monthly or half-year JSON/Markdown trend summaries from history_manifest.json."""
import argparse,json,os
from collections import Counter,defaultdict
from datetime import date
BASE=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def in_period(d,start,end): return bool(d and start<=d<=end)
def main():
 ap=argparse.ArgumentParser(); g=ap.add_mutually_exclusive_group(required=True); g.add_argument('--month',help='YYYY-MM'); g.add_argument('--half',help='YYYY-H1 or YYYY-H2'); a=ap.parse_args()
 if a.month:
  y,m=map(int,a.month.split('-')); import calendar; start=f'{y:04d}-{m:02d}-01'; end=f'{y:04d}-{m:02d}-{calendar.monthrange(y,m)[1]:02d}'; label=a.month
 else:
  y=int(a.half[:4]); h=a.half[-2:]; start=f'{y}-01-01' if h=='H1' else f'{y}-07-01'; end=f'{y}-06-30' if h=='H1' else f'{y}-12-31'; label=a.half
 with open(os.path.join(BASE,'data','history_manifest.json'),encoding='utf-8') as f:h=json.load(f)
 ps=[p for p in h.get('products',[]) if in_period(p.get('first_seen_at') or p.get('date'),start,end)]
 cats=Counter(); sources=Counter(); types=Counter(); statuses=Counter(); styles=Counter(); materials=Counter()
 for p in ps:
  ai=p.get('ai_analysis',{}); cats[ai.get('category','unknown')]+=1; sources[p.get('publisher') or p.get('source','unknown')]+=1; types[ai.get('content_type') or p.get('content_type','unknown')]+=1; statuses[ai.get('release_status') or p.get('release_status','unknown')]+=1
  for x in str(ai.get('style','')).replace(',','/').split('/'): 
   if x.strip(): styles[x.strip()]+=1
  for x in str(ai.get('material','')).replace('，',',').split(','):
   if x.strip(): materials[x.strip()]+=1
 verified=sum(bool(p.get('published_at')) for p in ps); new=sum(bool(p.get('ai_analysis',{}).get('is_new_product')) for p in ps)
 report={'period':label,'start':start,'end':end,'total_candidates':len(ps),'verified_new_products':new,'date_verified':verified,'date_verification_rate':round(verified/len(ps),3) if ps else 0,'by_category':dict(cats.most_common()),'by_content_type':dict(types.most_common()),'by_release_status':dict(statuses.most_common()),'by_publisher':dict(sources.most_common()),'top_styles':dict(styles.most_common(15)),'top_materials':dict(materials.most_common(15))}
 out=os.path.join(BASE,'output'); os.makedirs(out,exist_ok=True)
 jp=os.path.join(out,f'period_report_{label}.json'); mp=os.path.join(out,f'period_report_{label}.md')
 with open(jp,'w',encoding='utf-8') as f:json.dump(report,f,ensure_ascii=False,indent=2)
 with open(mp,'w',encoding='utf-8') as f:
  f.write(f'# 工业设计资讯汇总：{label}\n\n- 候选记录：{len(ps)}\n- AI 判定新品：{new}\n- 日期验证率：{report["date_verification_rate"]:.1%}\n\n')
  for title,key in [('品类','by_category'),('内容类型','by_content_type'),('发布状态','by_release_status'),('来源机构','by_publisher'),('设计风格','top_styles'),('材料','top_materials')]:
   f.write(f'## {title}\n\n'); [f.write(f'- {k}: {v}\n') for k,v in report[key].items()]; f.write('\n')
 print(mp)
if __name__=='__main__':main()
