#!/usr/bin/env python3
"""
Stage 1: Collect product links and image URLs from 8 subscription sources.
- Static pages (Core77 Blog, Core77 Awards): requests + BeautifulSoup
- JS-rendered pages (Designboom, Yanko Design x4, LeManoosh): Playwright headless browser

Fixes from original collect_products.py:
- Designboom: increased timeout to 60s, uses static.designboom.com CDN
- Yanko: uses data-src attribute (not src) for lazy-loaded images
- Yanko: derives title from URL slug when heading text is unavailable
"""

import json
import os
import sys
import argparse
import subprocess
import time
import re
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse, unquote
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATE = datetime.now().astimezone().strftime("%Y-%m-%d")

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
}

all_products = []
collection_log = []


def log(msg):
    entry = f"[{datetime.now().strftime('%H:%M:%S')}] {msg}"
    print(entry, flush=True)
    collection_log.append(entry)


# ============================================================
# STATIC PAGE COLLECTORS (requests + BeautifulSoup)
# ============================================================

def collect_core77_blog():
    """Collect from Core77 main page (redirects from /posts and /blog)."""
    source_id = "core77_blog"
    url = "https://www.core77.com/"
    log(f"--- Collecting: {source_id} ({url}) ---")
    products = []
    try:
        resp = requests.get(url, headers=HEADERS, timeout=30)
        resp.raise_for_status()
        soup = BeautifulSoup(resp.text, 'lxml')

        # Core77 main page has article tiles with links to /posts/{id}/{slug}
        # and corresponding lead images from s3files.core77.com
        seen_urls = set()
        
        # Find all post links and their associated images
        # Pattern: href="/posts/{id}/{slug}" with nearby img src from s3files
        post_links = {}
        for a in soup.find_all('a', href=True):
            href = a.get('href', '')
            # Match post URLs like /posts/144752/...
            match = re.search(r'/posts/(\d+)/([^"?]+)', href)
            if match:
                post_id = match.group(1)
                slug = match.group(2)
                clean_url = f"https://www.core77.com/posts/{post_id}/{slug}"
                
                if post_id not in post_links:
                    # Derive title from slug
                    title = slug.replace('-', ' ').strip()
                    post_links[post_id] = {"url": clean_url, "title": title}

        # Find lead images associated with posts
        # Images have pattern: s3files.core77.com/blog/images/lead_n_spotlight/{img_id}_lead_400_{post_id}_.jpg
        for img in soup.find_all('img'):
            src = img.get('src', '')
            if 's3files.core77.com' in src and 'lead_n_spotlight' in src:
                # Extract post_id from image URL
                match = re.search(r'_(\d+)_\.(?:jpg|jpeg|png)', src)
                if not match:
                    match = re.search(r'_(\d+)_\w*\.(?:jpg|jpeg|png)', src)
                if match:
                    img_post_id = match.group(1)
                    if img_post_id in post_links:
                        post = post_links[img_post_id]
                        if post["url"] not in seen_urls:
                            seen_urls.add(post["url"])
                            full_img_url = src if src.startswith('http') else f"https://{src}"
                            products.append({
                                "source": "Core77 Blog",
                                "source_id": source_id,
                                "title": post["title"][:200],
                                "page_url": post["url"],
                                "image_url": full_img_url,
                            })
                            log(f"  + {post['title'][:60]}")

        # If we didn't find enough via image matching, visit detail pages
        if len(products) < 5:
            log(f"  Only {len(products)} found via image matching, visiting detail pages...")
            for post_id, post in list(post_links.items())[:10]:
                if post["url"] in seen_urls:
                    continue
                try:
                    time.sleep(0.3)
                    detail_resp = requests.get(post["url"], headers=HEADERS, timeout=30)
                    detail_resp.raise_for_status()
                    detail_soup = BeautifulSoup(detail_resp.text, 'lxml')
                    
                    # Find the main article image
                    img_url = None
                    for img in detail_soup.find_all('img'):
                        src = img.get('src', '')
                        if 's3files.core77.com/blog/images/' in src and 'lead_n_spotlight' not in src:
                            if not src.endswith('.gif') and not src.endswith('.svg'):
                                img_url = src if src.startswith('http') else f"https://{src}"
                                break
                    
                    if img_url:
                        seen_urls.add(post["url"])
                        products.append({
                            "source": "Core77 Blog",
                            "source_id": source_id,
                            "title": post["title"][:200],
                            "page_url": post["url"],
                            "image_url": img_url,
                        })
                        log(f"  + (detail) {post['title'][:60]}")
                except Exception as e:
                    log(f"  ! Detail page error: {e}")

    except Exception as e:
        log(f"  X Collection error: {e}")
    
    log(f"  [{source_id}] Collected {len(products)} products")
    return products


def collect_core77_awards():
    """Collect from Core77 Design Awards page."""
    source_id = "core77_awards"
    url = "https://designawards.core77.com/"
    log(f"--- Collecting: {source_id} ({url}) ---")
    products = []
    try:
        resp = requests.get(url, headers=HEADERS, timeout=30)
        resp.raise_for_status()
        soup = BeautifulSoup(resp.text, 'lxml')

        seen_urls = set()
        
        # The awards page has lead images with post IDs
        # Find images that link to award projects
        for img in soup.find_all('img'):
            src = img.get('src', '')
            if 's3files.core77.com' not in src or 'lead_n_spotlight' not in src:
                continue
            if src.endswith('.gif') or src.endswith('.svg') or src.endswith('.png'):
                # Skip logos/icons (but keep award images)
                if 'logo' in src.lower() or 'sponsor' in src.lower():
                    continue
            
            # Extract post_id from image URL
            match = re.search(r'_(\d+)_\w*\.(?:jpg|jpeg|png)', src)
            if not match:
                continue
            post_id = match.group(1)
            
            # Find the anchor that wraps or is near this image
            anchor = img.find_parent('a')
            if anchor and anchor.get('href'):
                page_url = urljoin(url, anchor['href'])
            else:
                page_url = f"https://www.core77.com/posts/{post_id}/"
            
            if page_url in seen_urls:
                continue
            seen_urls.add(page_url)
            
            # Try to get title from alt or nearby heading
            title = img.get('alt', '').strip()
            if not title or len(title) < 5:
                parent = img.find_parent()
                if parent:
                    heading = parent.find(['h1', 'h2', 'h3', 'h4', 'h5'])
                    if heading:
                        title = heading.get_text(strip=True)
                    else:
                        a_tag = parent.find('a')
                        if a_tag:
                            title = a_tag.get_text(strip=True)
            
            if not title or len(title) < 5:
                title = f"Core77 Design Awards Entry #{post_id}"
            
            full_img_url = src if src.startswith('http') else f"https://{src}"
            products.append({
                "source": "Core77 Design Awards",
                "source_id": source_id,
                "title": title[:200],
                "page_url": page_url,
                "image_url": full_img_url,
            })
        
        # Limit to 15 to avoid flooding
        products = products[:15]

    except Exception as e:
        log(f"  X Collection error: {e}")
    
    log(f"  [{source_id}] Collected {len(products)} products")
    return products


# ============================================================
# JS-RENDERED PAGE COLLECTORS (Playwright)
# ============================================================

def collect_designboom_playwright():
    """Collect from Designboom using Playwright (JS-rendered)."""
    source_id = "designboom_product"
    url = "https://www.designboom.com/design/"
    log(f"--- Collecting: {source_id} ({url}) ---")
    products = []
    
    from playwright.sync_api import sync_playwright
    
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            context = browser.new_context(
                user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                viewport={'width': 1920, 'height': 1080}
            )
            page = context.new_page()
            
            log(f"  Navigating to {url}...")
            try:
                page.goto(url, wait_until='domcontentloaded', timeout=60000)
            except Exception:
                log(f"  ! domcontentloaded timeout, trying commit...")
                page.goto(url, wait_until='commit', timeout=30000)
            
            page.wait_for_timeout(8000)
            
            # Scroll to trigger lazy loading
            for i in range(3):
                page.evaluate(f"window.scrollTo(0, {500 * (i+1)})")
                page.wait_for_timeout(1500)
            
            # Designboom: find images with alt text and their parent anchor links
            # Images use static.designboom.com CDN
            extracted = page.evaluate("""() => {
                const results = [];
                const seen = new Set();
                
                document.querySelectorAll('img').forEach(img => {
                    const src = img.src || img.getAttribute('data-src') || img.getAttribute('data-lazy-src') || '';
                    const alt = img.alt || '';
                    
                    if (!src || src.includes('logo') || src.includes('icon') || src.includes('avatar') || src.includes('svg') || src.endsWith('.gif')) return;
                    if (!src.includes('designboom')) return;
                    
                    let anchor = img.closest('a[href]');
                    if (!anchor) {
                        const parent = img.parentElement;
                        if (parent) {
                            anchor = parent.querySelector('a[href]') || (parent.parentElement ? parent.parentElement.querySelector('a[href]') : null);
                        }
                    }
                    
                    let link = anchor ? anchor.href : '';
                    let title = alt;
                    
                    if (!title || title.length < 5) {
                        const container = img.closest('div, article, li, section');
                        if (container) {
                            const h = container.querySelector('h1, h2, h3, h4, h5, .title');
                            if (h) title = h.textContent.trim();
                        }
                    }
                    
                    if (link && !seen.has(link) && title.length > 5 && link.includes('designboom.com')) {
                        seen.add(link);
                        results.push({ title: title.substring(0, 200), link, imgSrc: src });
                    }
                });
                
                return results;
            }""")
            
            log(f"  Extracted {len(extracted)} items")
            seen = set()
            for item in extracted[:15]:
                page_url = item["link"]
                if page_url in seen:
                    continue
                seen.add(page_url)
                products.append({
                    "source": "Designboom",
                    "source_id": source_id,
                    "title": item["title"][:200],
                    "page_url": page_url,
                    "image_url": item["imgSrc"],
                })
                log(f"  + {item['title'][:60]}")
            
            browser.close()
    
    except Exception as e:
        log(f"  X Playwright error: {e}")
    
    log(f"  [{source_id}] Collected {len(products)} products")
    return products


def collect_yanko_playwright(source_id, source_name, url, max_items=10):
    """Collect from Yanko Design using Playwright.
    
    Key fix: Yanko uses lazy-loaded images where src is an SVG placeholder.
    The actual image URL is in the data-src attribute.
    """
    log(f"--- Collecting: {source_id} ({url}) ---")
    products = []
    
    from playwright.sync_api import sync_playwright
    
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            context = browser.new_context(
                user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                viewport={'width': 1920, 'height': 1080}
            )
            page = context.new_page()
            
            log(f"  Navigating to {url}...")
            try:
                page.goto(url, wait_until='domcontentloaded', timeout=45000)
            except Exception:
                log(f"  ! Navigation timeout, trying commit...")
                try:
                    page.goto(url, wait_until='commit', timeout=30000)
                except Exception as nav_err:
                    log(f"  ! Navigation failed: {nav_err}")
                    browser.close()
                    return products
            page.wait_for_timeout(5000)
            
            # Scroll to trigger lazy loading
            for i in range(3):
                page.evaluate(f"window.scrollTo(0, {600 * (i+1)})")
                page.wait_for_timeout(1500)
            
            # Yanko Design: article URLs match pattern /YYYY/MM/DD/...
            # Images are lazy-loaded: src is SVG placeholder, actual URL in data-src
            # Title can be from heading, alt text, or URL slug
            extracted = page.evaluate("""(maxItems) => {
                const results = [];
                const seen = new Set();
                
                const datePattern = /yankodesign\\.com\\/\\d{4}\\/\\d{2}\\/\\d{2}\\//;
                const articleLinks = document.querySelectorAll('a[href]');
                
                for (const a of articleLinks) {
                    const href = a.href;
                    if (!datePattern.test(href)) continue;
                    if (seen.has(href)) continue;
                    
                    // Get title: try heading in container, then alt text, then URL slug
                    let title = '';
                    const container = a.closest('article, .post-item, .entry, .grid-item, .jeg_post, li');
                    if (container) {
                        const heading = container.querySelector('h1, h2, h3, h4, h5, .post-title, .entry-title, .title, .jeg_post_title');
                        if (heading) {
                            title = heading.textContent.trim();
                        }
                    }
                    
                    // Try alt text from images in the link
                    if (!title || title.length < 5) {
                        const img = a.querySelector('img');
                        if (img && img.alt && img.alt.length > 5) {
                            title = img.alt.trim();
                        }
                    }
                    
                    // Derive from URL slug
                    if (!title || title.length < 5) {
                        const slugMatch = href.match(/\\d{4}\\/\\d{2}\\/\\d{2}\\/([^/]+)/);
                        if (slugMatch) {
                            title = slugMatch[1].replace(/-/g, ' ').replace(/\\b\\w/g, c => c.toUpperCase());
                        }
                    }
                    
                    if (!title || title.length < 5) continue;
                    
                    // Find image: check data-src first (lazy-loaded), then src
                    let imgSrc = '';
                    const imgs = a.querySelectorAll('img');
                    for (const img of imgs) {
                        // Check data-src (lazy loading attribute)
                        const dataSrc = img.getAttribute('data-src') || '';
                        if (dataSrc && dataSrc.includes('yankodesign.com') && !dataSrc.startsWith('data:')) {
                            imgSrc = dataSrc;
                            break;
                        }
                        // Check src
                        const src = img.src || '';
                        if (src && src.includes('yankodesign.com') && !src.startsWith('data:')) {
                            imgSrc = src;
                            break;
                        }
                    }
                    
                    // Check container images if anchor has none
                    if (!imgSrc && container) {
                        const containerImgs = container.querySelectorAll('img');
                        for (const img of containerImgs) {
                            const dataSrc = img.getAttribute('data-src') || '';
                            if (dataSrc && dataSrc.includes('yankodesign.com') && !dataSrc.startsWith('data:')) {
                                imgSrc = dataSrc;
                                break;
                            }
                            const src = img.src || '';
                            if (src && src.includes('yankodesign.com') && !src.startsWith('data:')) {
                                imgSrc = src;
                                break;
                            }
                        }
                    }
                    
                    if (imgSrc) {
                        seen.add(href);
                        results.push({ 
                            title: title.substring(0, 200), 
                            link: href, 
                            imgSrc: imgSrc 
                        });
                    }
                }
                
                return results.slice(0, maxItems);
            }""", max_items)
            
            log(f"  Extracted {len(extracted)} items")
            for item in extracted:
                products.append({
                    "source": source_name,
                    "source_id": source_id,
                    "title": item["title"][:200],
                    "page_url": item["link"],
                    "image_url": item["imgSrc"],
                })
                log(f"  + {item['title'][:60]}")
            
            browser.close()
    
    except Exception as e:
        log(f"  X Playwright error: {e}")
    
    log(f"  [{source_id}] Collected {len(products)} products")
    return products


def collect_lemanoosh_playwright():
    """Collect from LeManoosh using Playwright."""
    source_id = "lemanoosh_feed"
    url = "https://www.lemanoosh.com/"
    log(f"--- Collecting: {source_id} ({url}) ---")
    products = []
    
    from playwright.sync_api import sync_playwright
    
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            context = browser.new_context(
                user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                viewport={'width': 1920, 'height': 1080}
            )
            page = context.new_page()
            
            log(f"  Navigating to {url}...")
            try:
                page.goto(url, wait_until='load', timeout=20000)
                page.wait_for_timeout(3000)
            except Exception as nav_err:
                log(f"  ! Navigation timeout, trying with commit...")
                try:
                    page.goto(url, wait_until='commit', timeout=15000)
                    page.wait_for_timeout(5000)
                except Exception as nav_err2:
                    log(f"  ! Navigation failed: {nav_err2}")
                    browser.close()
                    return products
            
            # LeManoosh: find product images and their parent links
            extracted = page.evaluate("""() => {
                const results = [];
                const seen = new Set();
                
                document.querySelectorAll('img').forEach(img => {
                    const src = img.src || img.getAttribute('data-src') || img.getAttribute('data-original') || '';
                    const alt = img.alt || '';
                    
                    if (!src || src.includes('logo') || src.includes('icon') || src.includes('avatar') || src.includes('svg')) return;
                    if (!src.includes('lemanoosh')) return;
                    
                    let anchor = img.closest('a[href]');
                    if (!anchor) {
                        const parent = img.parentElement;
                        if (parent) {
                            anchor = parent.querySelector('a[href]');
                        }
                    }
                    
                    if (!anchor) return;
                    
                    const link = anchor.href;
                    if (seen.has(link) || link.includes('#')) return;
                    
                    let title = alt;
                    if (!title || title.length < 3) {
                        const container = img.closest('div, article, li, section');
                        if (container) {
                            const h = container.querySelector('h1, h2, h3, h4, h5, .title');
                            if (h) title = h.textContent.trim();
                            else title = anchor.textContent.trim();
                        }
                    }
                    
                    if (title.length > 2) {
                        seen.add(link);
                        results.push({ title: title.substring(0, 200), link, imgSrc: src });
                    }
                });
                
                return results;
            }""")
            
            log(f"  Extracted {len(extracted)} items")
            seen = set()
            for item in extracted[:10]:
                if item["link"] in seen:
                    continue
                seen.add(item["link"])
                products.append({
                    "source": "LeManoosh",
                    "source_id": source_id,
                    "title": item["title"][:200],
                    "page_url": item["link"],
                    "image_url": item["imgSrc"],
                })
                log(f"  + {item['title'][:60]}")
            
            browser.close()
    
    except Exception as e:
        log(f"  X Playwright error: {e}")
    
    log(f"  [{source_id}] Collected {len(products)} products")
    return products


# ============================================================
# MAIN COLLECTION
# ============================================================

def main():
    global DATE
    parser = argparse.ArgumentParser(description="Collect industrial design product candidates")
    parser.add_argument("--date", default=DATE, help="YYYY-MM-DD; defaults to local date")
    parser.add_argument("--skip-postprocess", action="store_true")
    args = parser.parse_args()
    DATE = args.date
    log("=" * 60)
    log(f"Starting collection for {DATE}")
    log("=" * 60)
    
    # --- Static page sources ---
    log("\n>>> STATIC PAGE SOURCES (requests + BeautifulSoup) <<<\n")
    
    # 1. Core77 Blog (main page, since /posts redirects to /)
    products = collect_core77_blog()
    all_products.extend(products)
    
    # 2. Core77 Awards
    products = collect_core77_awards()
    all_products.extend(products)
    
    # --- JS-rendered page sources ---
    log("\n>>> JS-RENDERED PAGE SOURCES (Playwright) <<<\n")
    
    # 3. Designboom
    products = collect_designboom_playwright()
    all_products.extend(products)
    
    # 4. Yanko Design Homepage
    products = collect_yanko_playwright(
        "yanko_home", "Yanko Design",
        "https://www.yankodesign.com/", max_items=10
    )
    all_products.extend(products)
    
    # 5. Yanko Design - Consumer Electronics
    products = collect_yanko_playwright(
        "yanko_consumer_electronics", "Yanko Design - Consumer Electronics",
        "https://www.yankodesign.com/category/product-design/consumer-electronics/", max_items=8
    )
    all_products.extend(products)
    
    # 6. Yanko Design - Furniture & Lighting
    products = collect_yanko_playwright(
        "yanko_furniture", "Yanko Design - Furniture & Lighting",
        "https://www.yankodesign.com/category/product-design/furniture-lighting/", max_items=8
    )
    all_products.extend(products)
    
    # 7. Yanko Design - Transportation
    products = collect_yanko_playwright(
        "yanko_transportation", "Yanko Design - Transportation",
        "https://www.yankodesign.com/category/product-design/transportation/", max_items=8
    )
    all_products.extend(products)
    
    # 8. LeManoosh
    products = collect_lemanoosh_playwright()
    all_products.extend(products)
    
    # --- Summary ---
    log("\n" + "=" * 60)
    log(f"COLLECTION COMPLETE: {len(all_products)} total products")
    log("=" * 60)
    
    by_source = {}
    for p in all_products:
        src = p.get("source_id", "unknown")
        by_source[src] = by_source.get(src, 0) + 1
    
    log("\nProducts by source:")
    for src, count in sorted(by_source.items()):
        log(f"  {src}: {count}")
    
    # --- Write collected data to JSON ---
    data_dir = os.path.join(BASE_DIR, "data", DATE)
    os.makedirs(data_dir, exist_ok=True)
    
    json_path = os.path.join(data_dir, "collected_data.json")
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump({
            "date": DATE,
            "total_products": len(all_products),
            "products": all_products,
            "by_source": by_source,
        }, f, ensure_ascii=False, indent=2)
    log(f"\nJSON data saved: {json_path}")
    
    # --- Write collected data to Markdown ---
    md_path = os.path.join(data_dir, "collected_data.md")
    with open(md_path, 'w', encoding='utf-8') as f:
        f.write(f"# Collected Industrial Design Products - {DATE}\n\n")
        f.write(f"**Date:** {DATE}\n")
        f.write(f"**Total products:** {len(all_products)}\n")
        f.write(f"**Sources:** {len(by_source)}\n\n")
        f.write(f"## Summary by Source\n\n")
        f.write(f"| Source | Count |\n|--------|-------|\n")
        for src, count in sorted(by_source.items()):
            f.write(f"| {src} | {count} |\n")
        f.write(f"\n## Product Details\n\n")
        for i, p in enumerate(all_products, 1):
            f.write(f"### {i}. {p['title']}\n\n")
            f.write(f"- **Source:** {p['source']}\n")
            f.write(f"- **Source ID:** {p['source_id']}\n")
            f.write(f"- **Page URL:** {p['page_url']}\n")
            f.write(f"- **Image URL:** {p['image_url']}\n\n")
    log(f"Markdown data saved: {md_path}")
    
    # --- Write collection log ---
    log_path = os.path.join(data_dir, "collection_log.txt")
    with open(log_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(collection_log))
    log(f"Collection log saved: {log_path}")
    
    if not args.skip_postprocess:
        try:
            subprocess.run([sys.executable, os.path.join(BASE_DIR, "scripts", "postprocess_collection.py"), "--date", DATE], check=True)
            log("Quality normalization and batch dedup completed")
        except Exception as e:
            log(f"! Postprocess failed: {e}")

    if len(all_products) == 0:
        log("\n! WARNING: All sources returned 0 products! Fallback keyword search may be needed.")
        return 1
    else:
        log(f"\n SUCCESS: {len(all_products)} products collected from {len(by_source)} sources")
        return 0


if __name__ == "__main__":
    sys.exit(main())
