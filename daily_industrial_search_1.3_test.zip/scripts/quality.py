#!/usr/bin/env python3
from __future__ import annotations
import re
from urllib.parse import urlsplit,urlunsplit,parse_qsl,urlencode
from article_extractor import date_from_url
TRACKING={'utm_source','utm_medium','utm_campaign','utm_term','utm_content','fbclid','gclid','ref'}
EXCLUDE={'editorial':['opinion','interview','how to','guide','tutorial','history of','call for entries','roundtable'],'architecture':['architecture','building','pavilion','museum','interior design'],'branding':['branding','visual identity','graphic design','logo']}
CONCEPT=['concept','prototype','speculative','imagines','student project']
PRODUCT=['chair','lamp','speaker','camera','phone','watch','vehicle','bike','tool','appliance','table','desk','robot','wearable','device','furniture','kitchen','monitor','headphone','product']
def canonicalize(url):
 p=urlsplit((url or '').strip()); q=urlencode(sorted((k,v) for k,v in parse_qsl(p.query,keep_blank_values=True) if k.lower() not in TRACKING)); return urlunsplit(((p.scheme or 'https').lower(),p.netloc.lower(),(p.path or '/').rstrip('/') or '/',q,''))
def slug_title(url):
 s=(urlsplit(url).path.rstrip('/').split('/')[-1] or '').replace('-',' ').replace('_',' ');s=re.sub(r'^\d+[- ]*','',s);return re.sub(r'\s+',' ',s).strip().title()
def classify_content(title='',body='',source_type='design_media'):
 t=f'{title} {body[:2500]}'.lower()
 for kind,words in EXCLUDE.items():
  if any(w in t for w in words):return kind,False,f'text_hint:{kind}'
 if source_type=='award' and not any(w in t for w in PRODUCT):return 'award_project',False,'award_requires_product_evidence'
 if any(w in t for w in CONCEPT):return 'concept_product',True,'concept_keyword'
 if any(w in t for w in PRODUCT):return 'physical_product',True,'product_keyword'
 return 'unknown',False,'insufficient_product_evidence'
def normalize_product(p,run_date):
 p=dict(p);p['canonical_url']=canonicalize(p.get('canonical_url') or p.get('page_url',''));p['domain']=urlsplit(p['canonical_url']).netloc
 if not p.get('title'):p['title']=slug_title(p['canonical_url'])
 kind,ok,reason=classify_content(p.get('title',''),p.get('body_text',''),p.get('source_type','design_media'));p['content_type']=kind;p['is_product_candidate']=ok;p['filter_reason']=reason
 if not p.get('published_at'):
  d,c,s=date_from_url(p['canonical_url']);p['published_at']=d;p['date_confidence']=c;p['date_source']=s
 p.setdefault('first_seen_at',run_date);p.setdefault('product_release_at',None);p.setdefault('release_status','unknown');p.setdefault('evidence',[])
 score=sum([25 if p.get('title') else 0,20 if p.get('canonical_url') else 0,15 if p.get('image_url') else 0,15 if p.get('published_at') else 0,15 if len(p.get('body_text',''))>300 else 0,10 if kind!='unknown' else 0]);p['quality_score']=score
 return p
def dedupe_batch(products):
 out=[];dups=[];seen={}
 for p in products:
  k=p.get('canonical_url') or canonicalize(p.get('page_url',''))
  if k in seen:dups.append({'duplicate':p,'kept':seen[k],'reason':'canonical_url'});continue
  seen[k]=p;out.append(p)
 return out,dups
