# Daily Industrial Design Search 1.3

面向工业设计新品情报的可测试采集与分析管线。

## 1.3 已完成

- 列表页发现后自动抓取详情页，并提取 JSON-LD、OpenGraph、canonical、正文、作者、品牌、产品名称及发布日期。
- 统一 `publisher_id / channel_id / collector_id`，避免媒体、频道和采集器统计混淆。
- HTML 失败后依次尝试 RSS 和 Sitemap。
- 域名级限速、HTTP 缓存、429/5xx 指数退避及错误记录。
- 基于 canonical URL 的批次去重。
- Product/coverage 初步分离，支持跨媒体标题、品牌和图片哈希聚类。
- 固定分类标签和别名入口。
- 来源健康数据、字段证据和质量分数。
- pytest、Dockerfile 和 CI 示例。
- 清理旧日期产物，测试夹具使用 2026-07-28 新鲜公开资讯。

## 安装

```bash
python -m pip install -r requirements.txt
playwright install chromium
```

## 实时采集

```bash
python scripts/collect_products_v3.py --date 2026-07-28
```

默认只保留最近 14 天候选，可调整：

```bash
python scripts/collect_products_v3.py --date 2026-07-28 --max-age-days 30 --limit-per-source 20
```

输出：

- `data/<date>/collected_data.json`
- `data/<date>/duplicates.json`
- `data/<date>/source_health.json`

`collected_data.json` 同时保存文章记录 `products` 和合并后的产品实体 `entities`。

## 自动测试

```bash
pytest -q
```

## 当前边界

跨媒体聚类当前是确定性基础版本，适合先测试；生产环境可继续接入 embedding、图片感知哈希及人工合并反馈。受站点条款、robots、网络和页面改版影响，某些来源仍可能不可访问，健康报告会记录实际回退方式和错误。
