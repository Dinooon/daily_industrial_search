from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from article_extractor import extract_metadata
from quality import canonicalize,normalize_product,dedupe_batch
from entity_resolver import cluster

def test_metadata_jsonld():
 html='''<html><head><link rel="canonical" href="https://example.com/p"><script type="application/ld+json">{"@type":"Product","name":"Arc Lamp","brand":{"name":"Acme"},"datePublished":"2026-07-28","image":"https://example.com/a.jpg"}</script></head><body><article>New aluminum desk lamp product with adjustable lighting.</article></body></html>'''
 m=extract_metadata(html,'https://example.com/x');assert m['product_name']=='Arc Lamp';assert m['brand']=='Acme';assert m['published_at']=='2026-07-28';assert len(m['body_text'])>20

def test_canonical_dedupe():
 a={'title':'New Chair product','page_url':'https://x.com/a?utm_source=z','body_text':'chair product','source_type':'design_media'}
 b={'title':'New Chair product','page_url':'https://x.com/a','body_text':'chair product','source_type':'design_media'}
 items=[normalize_product(a,'2026-07-28'),normalize_product(b,'2026-07-28')];out,dups=dedupe_batch(items);assert len(out)==1 and len(dups)==1

def test_entity_cluster_cross_media():
 a={'title':'Acme Arc Lamp','brand':'Acme','quality_score':80,'publisher':'A','canonical_url':'https://a.test/1'}
 b={'title':'Acme Arc Lamp desk light','brand':'Acme','quality_score':90,'publisher':'B','canonical_url':'https://b.test/2'}
 groups=cluster([a,b],threshold=.7);assert len(groups)==1;assert len(groups[0]['coverages'])==2
