from pathlib import Path
import json,sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from quality import normalize_product,dedupe_batch
from entity_resolver import cluster

def test_fresh_20260728_fixture():
 p=Path(__file__).parent/'fixtures'/'fresh_2026-07-28.json';data=json.loads(p.read_text())
 items=[normalize_product(x,'2026-07-28') for x in data]
 out,dups=dedupe_batch(items);assert len(dups)==0;assert all(x['published_at'] for x in out);assert len(cluster([x for x in out if x['is_product_candidate']]))>=2
